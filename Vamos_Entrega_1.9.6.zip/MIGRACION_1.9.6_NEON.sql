-- Vamos!! 1.9.6. Repetible y sin borrado de datos.
BEGIN;

ALTER TABLE trips
  ADD COLUMN IF NOT EXISTS cancellation_reason varchar(300);

ALTER TABLE bookings
  ADD COLUMN IF NOT EXISTS cancellation_reason varchar(300);

ALTER TABLE bookings
  ADD COLUMN IF NOT EXISTS passenger_completed_at timestamptz;

CREATE INDEX IF NOT EXISTS bookings_passenger_completed_idx
  ON bookings(passenger_completed_at DESC)
  WHERE passenger_completed_at IS NOT NULL;

COMMIT;
