# Vamos!! 1.9.7 — Responde Ya

Número de atención: +591 76008546 (WhatsApp Business existente).

## Incluido
- Botón «Responde Ya · Ayuda» en el inicio de Vamos!! para Android y web.
- Asistente de reglas compartido en el servidor; no requiere una clave de IA.
- Orientación para buscar/publicar viajes, reservas, comunidades, aportes y seguridad. Las acciones abren pantallas existentes; este chat NO busca viajes por texto ni crea reservas.
- Solicitudes de soporte autenticadas en la app.
- Bandeja «Responde Ya · Soporte» en /admin; permite contactar por WhatsApp y cerrar consultas.
- Webhook oficial de WhatsApp con verificación del cuerpo original, control del número autorizado y registro de mensajes procesados.
- Solicitar soporte por WhatsApp abre una consulta y pausa las respuestas del bot. Los textos posteriores se añaden a esa consulta, hasta 6000 caracteres. Cerrar la consulta reactiva el bot para nuevos mensajes.
- WhatsApp permanece desactivado por defecto. Sin vincular la cuenta, el enlace de WhatsApp abre la atención habitual del número, sin automatización.

## Instalar sin modificar datos existentes
1. Respalda el despliegue y la base de datos.
2. Ejecuta backend/MIGRACION_RESPONDE_YA.sql en la base Neon que usa la API. Es una migración adicional, no sustituye migraciones anteriores ni borra usuarios/viajes.
3. Publica el backend y la carpeta admin de esta entrega. Si el repositorio contiene el ZIP: sube este paquete y ajusta Dockerfile y el script web para descomprimir Vamos_MVP_Fullstack_1.9.7_RespondeYa.zip, en lugar del ZIP anterior. Conserva los parámetros de conexión existentes.
4. Reconstruye y publica la versión web desde vamos_app. Compila Android y distribuye la APK actualizada. Actualizar solamente la API NO modifica la web ni una APK ya instalada.
5. Prueba con pasajero y conductor: Ayuda, abrir búsqueda, publicar, reservas, comunidades, enviar consulta y revisar la bandeja con una cuenta ADMIN.

## Activar WhatsApp después de autorizar Meta
No elimines ni migres la cuenta actual de WhatsApp Business para probar. Comprueba primero si el negocio y proveedor admiten el flujo de coexistencia de Meta; su disponibilidad no se verifica con este archivo.

Autoriza +591 76008546 en WhatsApp Business Platform usando el flujo adecuado para la cuenta. Configura en el servidor:
- WHATSAPP_ACCESS_TOKEN: token con permiso para enviar mensajes del número.
- WHATSAPP_PHONE_NUMBER_ID: identificador del número autorizado (NO es el teléfono 76008546).
- WHATSAPP_APP_SECRET: secreto de la aplicación de Meta, para autenticar webhooks.
- WHATSAPP_VERIFY_TOKEN: valor secreto elegido para verificar el webhook.
- WHATSAPP_GRAPH_VERSION: versión Graph vigente habilitada en la aplicación, con formato vNN.0.
- WHATSAPP_ENABLED=true solo después de completar los pasos anteriores.

URL del webhook si el backend continúa en el dominio actual:
https://vamos-api.onrender.com/api/v1/assistant/whatsapp

En Meta, verifica esta URL con el token configurado y suscribe el campo messages de la cuenta autorizada. Prueba recepción, respuesta, consulta repetida y soporte/pausa. El webhook solo responde a mensajes recientes entrantes: no envía campañas, notificaciones de reserva ni plantillas fuera de la ventana de atención.

Los mensajes no textuales no reciben una respuesta automática en esta primera versión. La atención manual se realiza en WhatsApp Business o el canal autorizado. No hay vinculación de identidad WhatsApp–Vamos!!: los viajes y datos privados siguen exigiendo iniciar sesión en Vamos!!.

## Validación y límites
- Backend: compilación correcta y 70 pruebas automatizadas aprobadas.
- JavaScript del panel: comprobación de sintaxis aprobada.
- Flutter: SDK no disponible en el entorno de esta entrega; ejecutar flutter analyze, flutter test y compilaciones web/Android antes de producción.
- SQL: no ejecutado contra la base de producción en esta entrega.
- No desplegado, sin credenciales Meta ni mensajes reales enviados.
- Los envíos y la transacción SQL no forman una operación atómica con Meta: si Meta acepta el envío y después falla la confirmación en la base de datos, un reintento puede repetir la respuesta. El registro elimina repeticiones después de un procesamiento confirmado y serializa contactos entre servidores.
- Los registros de soporte contienen datos de contacto visibles solo para administradores. Establece una política de conservación apropiada antes de producción; este paquete no borra historiales automáticamente.

Referencias oficiales para la conexión:
https://developers.facebook.com/documentation/business-messaging/whatsapp/embedded-signup/version-4
https://whatsapp.github.io/WhatsApp-Nodejs-SDK/api-reference/webhooks/start/
