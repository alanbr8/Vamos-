# Vamos!! 1.9.7 — soporte RespondeYa por WhatsApp

## Cambios

- Nuevo **Centro de ayuda RespondeYa** para web y Android.
- Contacto oficial por WhatsApp al **76008546** (Bolivia: `+591 76008546`).
- Acceso antes de iniciar sesión, desde Inicio y desde Mi perfil.
- Temas rápidos para cuenta, identidad, vehículo, comunidades, viajes, pagos, seguridad y otras consultas.
- Mensaje contextual prellenado; el usuario conserva el control y confirma el envío en WhatsApp.
- Aviso para no compartir contraseñas, códigos, documentos ni datos bancarios por WhatsApp.
- Separación expresa entre soporte y emergencias: SOS y Policía 110 continúan siendo los canales correspondientes.

## Despliegue

1. Subir `Vamos_MVP_Fullstack_1.9.7.zip` a la raíz de GitHub.
2. Reemplazar `.github/workflows/main.yml`, `.github/workflows/web.yml` y, si corresponde, `.github/workflows/ios.yml` con los archivos de `delivery`.
3. Actualizar `Dockerfile` y `render-web-build.sh` para que descompriman `Vamos_MVP_Fullstack_1.9.7.zip`.
4. Esperar los despliegues exitosos de `Vamos-api` y `vamos-web` en Render.
5. Ejecutar **Compilar Vamos Android** y descargar el APK nuevo.

## Base de datos

Esta versión no añade tablas ni columnas. **No se ejecuta una migración nueva en Neon.**

## Prueba mínima

1. En la portada, pulsar **AYUDA POR WHATSAPP**.
2. Elegir un tema y comprobar que se abra WhatsApp con el número `+591 76008546`.
3. Verificar que el mensaje mencione el tema elegido y que no se envíe automáticamente.
4. Repetir desde Inicio y desde Mi perfil.
5. Confirmar que SOS continúa abriendo sus opciones propias y no se confunde con soporte.
