import 'package:url_launcher/url_launcher.dart';

class SupportTopic {
  const SupportTopic(this.title, this.message);

  final String title;
  final String message;
}

class SupportService {
  static const phone = '59176008546';

  static const topics = <SupportTopic>[
    SupportTopic('Cuenta e inicio de sesión', 'mi cuenta o el inicio de sesión'),
    SupportTopic('Verificación de identidad', 'la verificación de mi identidad'),
    SupportTopic('Vehículo y documentos', 'mi vehículo o sus documentos'),
    SupportTopic('Comunidades', 'una comunidad de Vamos!!'),
    SupportTopic('Viajes y reservas', 'un viaje o una reserva'),
    SupportTopic('Pagos y aportes', 'un pago o aporte de viaje'),
    SupportTopic('Seguridad o reporte', 'seguridad o un reporte'),
    SupportTopic('Otra consulta', 'otra consulta sobre Vamos!!'),
  ];

  static Uri whatsappUri(SupportTopic topic) => Uri.https(
        'wa.me',
        '/$phone',
        {'text': 'Hola, equipo RespondeYa de Vamos!!. Necesito ayuda con ${topic.message}.'},
      );

  static Future<bool> open(SupportTopic topic) => launchUrl(
        whatsappUri(topic),
        mode: LaunchMode.externalApplication,
        webOnlyWindowName: '_blank',
      );
}
