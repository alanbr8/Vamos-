import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class ApiException implements Exception {
  const ApiException(this.message, [this.statusCode]);
  final String message;
  final int? statusCode;
  @override
  String toString() => message;
}

class ApiClient {
  ApiClient._()
    : baseUrl = AppConfig.apiBaseUrl,
      requestTimeout = const Duration(seconds: 75);
  ApiClient.forTesting({
    required this.baseUrl,
    this.requestTimeout = const Duration(seconds: 75),
  });
  final String baseUrl;
  final Duration requestTimeout;
  void close() => _http.close();
  static final instance = ApiClient._();
  final http.Client _http = http.Client();
  void Function()? onSessionExpired;

  Future<Map<String, dynamic>> assistantMessage(String message) => _request('POST', '/assistant/message', body: {'message': message});
  Future<Map<String, dynamic>> assistantSupport(String message) => _request('POST', '/assistant/support', body: {'message': message});
  Future<List<dynamic>> assistantTickets() => _requestList('GET', '/assistant/support');
  Future<Map<String, dynamic>> resolveAssistantTicket(String id) => _request('POST', '/assistant/support/$id/resolve');

  Future<Map<String, dynamic>> saveSearch(Map<String, dynamic> criteria) =>
      _request('POST', '/saved-searches', body: criteria);
  Future<List<dynamic>> savedSearches() => _requestList('GET', '/saved-searches');
  Future<Map<String, dynamic>> cancelSearch(String id) =>
      _request('PATCH', '/saved-searches/$id/cancel');

  Future<Map<String, dynamic>> register({
    String usageMode = 'PASSENGER',
    required String firstName,
    required String lastName,
    required String email,
    required String phone,
    required String password,
  }) async {
    final response = await _request(
      'POST',
      '/auth/register',
      body: {
        'usageMode': usageMode,
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'phone': phone,
        'password': password,
      },
      authenticated: false,
    );
    await SessionStore.instance.save(response);
    return response;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await _request(
      'POST',
      '/auth/login',
      body: {'email': email, 'password': password},
      authenticated: false,
    );
    await SessionStore.instance.save(response);
    return response;
  }

  Future<Map<String, dynamic>> forgotPassword(String email) => _request(
    'POST',
    '/auth/forgot-password',
    body: {'email': email},
    authenticated: false,
  );

  Future<Map<String, dynamic>> resetPassword(String token, String password) =>
      _request(
        'POST',
        '/auth/reset-password',
        body: {'token': token, 'password': password},
        authenticated: false,
      );

  Future<List<dynamic>> communities([String path='']) => _requestList('GET','/communities$path');
  Future<Map<String,dynamic>> community(String path,{String method='GET',Map<String,dynamic>? body}) => _request(method,'/communities$path',body:body);
  Future<Map<String,dynamic>> payment(String path,{String method='GET',Map<String,dynamic>? body}) => _request(method,'/payments/$path',body:body);
  Future<Map<String,dynamic>> registerPush(String token) => _request('POST','/push/register',body:{'token':token},expireSession:false);
  Future<Map<String,dynamic>> unregisterPush(String token) => _request('POST','/push/unregister',body:{'token':token},expireSession:false);
  Future<Map<String,dynamic>> displayPhoto(String id,{bool vehicle=false}) => _request('GET','/photos/${vehicle ? 'vehicle' : 'profile'}/$id');
  Future<Map<String,dynamic>> profilePhotoStatus() => _request('GET','/photos/profile/me/status');
  Future<Map<String,dynamic>> saveDisplayPhoto(Map<String,dynamic> body) => _request('POST','/photos',body:body);
  Future<Map<String,dynamic>> deleteDisplayPhoto({String? vehicleId}) => _request('DELETE',vehicleId == null ? '/photos/profile' : '/photos/vehicle/$vehicleId');
  Future<List<dynamic>> documents() => _requestList('GET', '/documents');
  Future<Map<String,dynamic>> uploadDocument(Map<String,dynamic> data) => _request('POST','/documents',body:data);
  Future<Map<String,dynamic>> documentImage(String id) => _request('GET','/documents/$id/image');
  Future<Map<String,dynamic>> deleteDocument(String id) => _request('DELETE','/documents/$id');

  Future<Map<String, dynamic>> profile() => _request('GET', '/users/me');

  Future<List<dynamic>> vehicles() async =>
      (await _requestList('GET', '/vehicles/me'));

  Future<Map<String, dynamic>> createVehicle(Map<String, dynamic> vehicle) =>
      _request('POST', '/vehicles', body: vehicle);

  Future<Map<String, dynamic>> createTrip(Map<String, dynamic> trip) =>
      _request('POST', '/trips', body: trip);

  Future<Map<String, dynamic>> updateTrip(String id, Map<String, dynamic> data) =>
      _request('PATCH', '/trips/$id', body: data);

  Future<Map<String, dynamic>> cancelTrip(String id, String reason) =>
      _request('PATCH', '/trips/$id/cancel', body: {'reason': reason});

  Future<List<dynamic>> searchTrips(Map<String, dynamic> criteria) =>
      _requestList('POST', '/trips/search', body: criteria);

  Future<Map<String,dynamic>> createBooking(String tripId,{int seats=1,double? meetingLat,double? meetingLng,String? meetingLabel,required double passengerOriginLat,required double passengerOriginLng,required double passengerDestinationLat,required double passengerDestinationLng,required List<dynamic> passengerRoute})=>
      _request('POST','/bookings',body:{'tripId':tripId,'seats':seats,if(meetingLat!=null)'meetingLat':meetingLat,if(meetingLng!=null)'meetingLng':meetingLng,if(meetingLabel!=null)'meetingLabel':meetingLabel,'passengerOriginLat':passengerOriginLat,'passengerOriginLng':passengerOriginLng,'passengerDestinationLat':passengerDestinationLat,'passengerDestinationLng':passengerDestinationLng,'passengerRoute':passengerRoute});

  Future<List<dynamic>> driverTrips() =>
      _requestList('GET', '/trips/me/driver');

  Future<List<dynamic>> passengerBookings() =>
      _requestList('GET', '/bookings/me');

  Future<Map<String, dynamic>> bookingAction(String bookingId, String action,{String? reason}) =>
      _request('PATCH', '/bookings/$bookingId/$action',body:{if(reason!=null)'reason':reason});

  Future<Map<String,dynamic>> confirmArrival(String bookingId) =>
      _request('PATCH','/bookings/$bookingId/confirm-arrival');

  Future<Map<String,dynamic>> tracking(String id) => _request('GET','/tracking/$id',expireSession:false);
  Future<Map<String,dynamic>> trackingAction(String id,String action,{Map<String,dynamic>? data}) => _request('POST','/tracking/$id/$action',body:data,expireSession:false);
  Future<Map<String,dynamic>> shareTracking(String booking) => _request('POST','/tracking/booking/$booking/share');
  Future<Map<String,dynamic>> revokeTracking(String booking) => _request('POST','/tracking/booking/$booking/revoke');
  Future<Map<String,dynamic>> departTrip(String id) => _request('PATCH','/trips/$id/depart');
  Future<Map<String,dynamic>> estimateRoute(Map<String,dynamic> points) => _request('POST','/routes/estimate',body:points);
  Future<Map<String,dynamic>> verifyEncounter(String id,String code) => _request('PATCH','/bookings/$id/verify-encounter',body:{'code':code});
  Future<Map<String, dynamic>> startTrip(String tripId, String code) =>
      _request('PATCH', '/trips/$tripId/start', body: {'code': code});

  Future<Map<String, dynamic>> completeTrip(String tripId) =>
      _request('PATCH', '/trips/$tripId/complete');

  Future<Map<String, dynamic>> createRating(Map<String, dynamic> rating) =>
      _request('POST', '/ratings', body: rating);

  Future<List<dynamic>> ratings() => _requestList('GET', '/ratings/me');

  Future<Map<String, dynamic>> createIncident(Map<String, dynamic> incident) =>
      _request('POST', '/incidents', body: incident);

  Future<List<dynamic>> incidents() => _requestList('GET', '/incidents/me');

  Future<List<dynamic>> notifications() =>
      _requestList('GET', '/notifications');

  Future<int> unreadNotificationCount() async {
    final response = await _request('GET', '/notifications/unread-count');
    return int.tryParse(response['count']?.toString() ?? '') ?? 0;
  }

  Future<Map<String, dynamic>> readNotification(String id) =>
      _request('PATCH', '/notifications/$id/read');

  Future<Map<String, dynamic>> readAllNotifications() =>
      _request('PATCH', '/notifications/read-all');

  Future<List<dynamic>> messages(String bookingId) =>
      _requestList('GET', '/bookings/$bookingId/messages');

  Future<Map<String, dynamic>> sendMessage(String bookingId, String body) =>
      _request('POST', '/bookings/$bookingId/messages', body: {'body': body});

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    bool authenticated = true,
    bool expireSession = true,
  }) async {
    final decoded = await _send(
      method,
      path,
      body: body,
      authenticated: authenticated,
      expireSession: expireSession,
    );
    if (decoded is Map<String, dynamic>) return decoded;
    throw const ApiException(
      'La respuesta del servidor no tiene el formato esperado',
    );
  }

  Future<List<dynamic>> _requestList(
    String method,
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final decoded = await _send(method, path, body: body);
    if (decoded is List<dynamic>) return decoded;
    throw const ApiException('La respuesta del servidor no contiene una lista');
  }

  Future<dynamic> _send(
    String method,
    String path, {
    Map<String, dynamic>? body,
    bool authenticated = true,
    bool expireSession = true,
  }) async {
    try {
      final headers=<String,String>{'Content-Type':'application/json'};
      if (authenticated) {
        final token = SessionStore.instance.accessToken;
        if (token == null)
          throw const ApiException('Debes iniciar sesión', 401);
        headers['Authorization']='Bearer $token';
      }
      final request=http.Request(method,Uri.parse('${baseUrl}$path'))..headers.addAll(headers);
      if(body!=null)request.body=jsonEncode(body);
      final streamed=await _http.send(request).timeout(requestTimeout);
      final response=await http.Response.fromStream(streamed).timeout(const Duration(seconds:20));
      final text=response.body;
      dynamic decoded;
      try {
        decoded = text.isEmpty ? <String, dynamic>{} : jsonDecode(text);
      } on FormatException {
        throw ApiException(
          response.statusCode >= 500
              ? 'El servidor no está disponible. Espera un momento y reintenta.'
              : 'El servidor devolvió una respuesta inválida.',
          response.statusCode,
        );
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        if (response.statusCode == 401 && authenticated && expireSession) {
          await SessionStore.instance.clear();
          onSessionExpired?.call();
        }
        final message = decoded is Map<String, dynamic>
            ? decoded['message']
            : null;
        throw ApiException(
          message is List
              ? message.join(', ')
              : (message?.toString() ?? 'Error del servidor'),
          response.statusCode,
        );
      }
      return decoded;
    } on TimeoutException {
      throw const ApiException(
        'El servidor está tardando demasiado. Comprueba en Viajes si la operación se guardó antes de repetirla.',
      );
    } on http.ClientException {
      throw const ApiException(
        'No se pudo conectar con la API. Revisa tu conexión y que el servidor esté disponible.',
      );
    } on FormatException {
      throw const ApiException('El servidor devolvió una respuesta inválida.');
    }
  }
}
