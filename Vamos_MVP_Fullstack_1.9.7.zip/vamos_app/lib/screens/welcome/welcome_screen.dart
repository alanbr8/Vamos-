import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../widgets/vamos_logo.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              const VamosLogo(),
              const SizedBox(height: 28),
              const Text(
                'Comparte el viaje, divide los gastos y llega acompañado.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, height: 1.4),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () => Navigator.pushNamed(context, AppRoutes.login),
                child: const Text('INICIAR SESIÓN'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                ),
                onPressed: () =>
                    Navigator.pushNamed(context, AppRoutes.register),
                child: const Text('CREAR CUENTA'),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => Navigator.pushNamed(context, AppRoutes.support),
                icon: const Icon(Icons.support_agent),
                label: const Text('AYUDA POR WHATSAPP'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
