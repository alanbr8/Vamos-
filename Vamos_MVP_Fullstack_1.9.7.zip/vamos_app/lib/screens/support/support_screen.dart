import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/support_service.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  bool opening = false;

  Future<void> contact(SupportTopic topic) async {
    if (opening) return;
    setState(() => opening = true);
    try {
      final opened = await SupportService.open(topic);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No se pudo abrir WhatsApp. Comunícate al 76008546.'),
        ));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No se pudo abrir WhatsApp. Comunícate al 76008546.'),
        ));
      }
    } finally {
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Ayuda · RespondeYa')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFE4F3E8),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Icon(Icons.support_agent, color: AppColors.green, size: 30),
                    SizedBox(width: 12),
                    Expanded(child: Text('¿En qué podemos ayudarte?', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800))),
                  ]),
                  SizedBox(height: 10),
                  Text('Selecciona un tema y conversa por WhatsApp con el canal de soporte de Vamos!!.'),
                ],
              ),
            ),
            const SizedBox(height: 18),
            ...SupportService.topics.map((topic) => Card(
                  child: ListTile(
                    enabled: !opening,
                    leading: const Icon(Icons.chat_outlined, color: AppColors.green),
                    title: Text(topic.title),
                    subtitle: const Text('Abrir conversación en WhatsApp'),
                    trailing: const Icon(Icons.open_in_new),
                    onTap: () => contact(topic),
                  ),
                )),
            const SizedBox(height: 14),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Protege tu información', style: TextStyle(fontWeight: FontWeight.w800)),
                  SizedBox(height: 8),
                  Text('Nunca envíes contraseñas, códigos de acceso, fotografías de documentos ni datos bancarios por WhatsApp.'),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'RespondeYa es un canal de orientación. En una emergencia llama a la Policía 110 o utiliza SOS dentro de Vamos!!.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
}
