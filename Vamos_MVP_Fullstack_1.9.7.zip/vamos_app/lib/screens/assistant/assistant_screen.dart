import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api_client.dart';
import '../../services/session_store.dart';
import '../../core/routes/app_routes.dart';
import '../communities/communities_screen.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});
  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}
class _AssistantScreenState extends State<AssistantScreen> {
  final input = TextEditingController();
  final scroll = ScrollController();
  final messages = <Map<String, dynamic>>[
    {'text': 'Soy Responde Ya de Vamos!!. Puedo orientarte para buscar viajes, ofrecer un viaje, consultar reservas, ingresar a comunidades o solicitar soporte.', 'mine': false}
  ];
  bool busy = false, handoff = false;
  String? error;
  @override
  void dispose() { input.dispose(); scroll.dispose(); super.dispose(); }
  Future<void> send([String? suggestion]) async {
    final text = (suggestion ?? input.text).trim();
    if (busy || text.isEmpty) return;
    if (text.length > 1500) { setState(() => error = 'Usa hasta 1500 caracteres.'); return; }
    setState(() { busy = true; error = null; messages.add({'text': text, 'mine': true}); });
    try {
      final reply = await ApiClient.instance.assistantMessage(text);
      if (!mounted) return;
      setState(() { messages.add({...reply, 'mine': false}); handoff = reply['handoff'] == true; input.clear(); });
    } catch (_) { if (mounted) setState(() => error = 'No se pudo consultar al asistente. Tu mensaje sigue disponible para reintentar.'); }
    finally { if (mounted) { setState(() => busy = false); WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted && scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 180), curve: Curves.easeOut); }); } }
  }
  Future<void> support() async {
    final text = input.text.trim();
    if (busy || text.isEmpty) { setState(() => error = 'Escribe primero el problema que quieres enviar al administrador.'); return; }
    setState(() { busy = true; error = null; });
    try {
      final reply = await ApiClient.instance.assistantSupport(text);
      if (mounted) setState(() { messages.add({'text': '${reply['text']}\nReferencia: ${reply['id']}', 'mine': false}); input.clear(); handoff = false; });
    } catch (_) { if (mounted) setState(() => error = 'No se pudo registrar la consulta. Puedes reintentar.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  void navigate(String action) {
    if (action == 'communities') { Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const CommunitiesScreen())); return; }
    if ([AppRoutes.searchTrip, AppRoutes.offerVehicle, AppRoutes.myTrips, AppRoutes.safety].contains(action)) Navigator.pushNamed(context, action);
  }
  Future<void> openWhatsApp([String phone = '59176008546']) async {
    try { if (!await launchUrl(Uri.https('wa.me', '/$phone'), mode: LaunchMode.externalApplication)) throw Exception(); }
    catch (_) { if (mounted) setState(() => error = 'No se pudo abrir WhatsApp. Contacta al +591 76008546.'); }
  }
  Future<void> tickets() async {
    try {
      final list = await ApiClient.instance.assistantTickets();
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Consultas pendientes'),
        content: SizedBox(width: 520, child: list.isEmpty ? const Text('No hay consultas pendientes.') : ListView(shrinkWrap: true, children: list.map((item) => ListTile(
          title: Text(item['message'].toString()), subtitle: Text('${item['channel']} · ${item['contact_phone'] ?? item['user_id'] ?? ''}\n${item['created_at']}'),
          trailing: PopupMenuButton<String>(onSelected: (value) async {
            if (value == 'contact') { await openWhatsApp(item['contact_phone'].toString()); return; }
            try { await ApiClient.instance.resolveAssistantTicket(item['id'].toString()); if (ctx.mounted) Navigator.pop(ctx); }
            catch (_) { if (mounted) setState(() => error = 'No se pudo cerrar la consulta.'); }
          }, itemBuilder: (_) => [if (item['channel'] == 'WHATSAPP') const PopupMenuItem(value: 'contact', child: Text('Contactar por WhatsApp')), const PopupMenuItem(value: 'resolve', child: Text('Cerrar consulta y reactivar asistente'))]),
        )).toList())), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Volver'))],
      ));
    } catch (_) { if (mounted) setState(() => error = 'No se pudo cargar la bandeja de soporte.'); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Responde Ya · Vamos!!'), actions: [if (SessionStore.instance.user?['role'] == 'ADMIN') IconButton(onPressed: tickets, tooltip: 'Bandeja de soporte', icon: const Icon(Icons.support_agent))]),
    body: SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Wrap(spacing: 8, runSpacing: 6, children: ['Buscar viaje','Publicar viaje','Reservas','Comunidades','Soporte'].map((label) => ActionChip(label: Text(label), onPressed: busy ? null : () => send(label))).toList())),
      Expanded(child: ListView.builder(controller: scroll, padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: messages.length, itemBuilder: (_, i) {
        final item = messages[i], mine = item['mine'] == true;
        return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(constraints: const BoxConstraints(maxWidth: 560), margin: const EdgeInsets.symmetric(vertical: 6), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: mine ? const Color(0xFFE0F4E9) : Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SelectableText(item['text'].toString(), style: const TextStyle(fontSize: 16, height: 1.4)),
          if (item['action'] != null) TextButton(onPressed: () => navigate(item['action'].toString()), child: const Text('Continuar en Vamos!!')),
        ])));
      })),
      if (error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      if (busy) const LinearProgressIndicator(),
      if (handoff) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: FilledButton.icon(onPressed: busy ? null : support, icon: const Icon(Icons.support_agent), label: const Text('Solicitar atención con el texto escrito'))),
      Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: TextField(controller: input, enabled: !busy, maxLength: 1500, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'Escribe tu consulta', counterText: ''), onSubmitted: (_) => send())), IconButton(onPressed: busy ? null : () => send(), tooltip: 'Enviar consulta', icon: const Icon(Icons.send))])),
      TextButton.icon(onPressed: busy ? null : () => openWhatsApp(), icon: const Icon(Icons.chat_outlined), label: const Text('Contactar por WhatsApp · 76008546')),
    ])),
  );
}
