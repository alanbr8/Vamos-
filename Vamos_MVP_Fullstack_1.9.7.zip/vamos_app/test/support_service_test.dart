import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/services/support_service.dart';

void main() {
  test('RespondeYa usa el número boliviano y un mensaje contextual', () {
    final uri = SupportService.whatsappUri(SupportService.topics.first);
    expect(uri.host, 'wa.me');
    expect(uri.path, '/59176008546');
    expect(uri.queryParameters['text'], contains('mi cuenta'));
    expect(uri.queryParameters['text'], contains('Vamos!!'));
  });

  test('ofrece los temas esenciales de soporte', () {
    final titles = SupportService.topics.map((topic) => topic.title).toList();
    expect(titles, containsAll(<String>[
      'Verificación de identidad',
      'Comunidades',
      'Viajes y reservas',
      'Seguridad o reporte',
    ]));
  });
}
