BEGIN;
CREATE TABLE IF NOT EXISTS assistant_support (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES users(id) ON DELETE CASCADE,
 channel text NOT NULL CHECK(channel IN ('APP','WHATSAPP')), phone_hash text, contact_phone text,
 message text NOT NULL, status text NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','CLOSED')),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS assistant_support_open_idx ON assistant_support(phone_hash) WHERE status='OPEN';
CREATE TABLE IF NOT EXISTS assistant_whatsapp_processed(id text PRIMARY KEY, created_at timestamptz NOT NULL DEFAULT now());
COMMIT;
