import { Body, HttpCode, Controller, Get, Headers, Param, Post, Query, RawBodyRequest, Req, Res, UseGuards, ForbiddenException, ServiceUnavailableException, ParseUUIDPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IsString, MaxLength, MinLength } from 'class-validator';
import { createHmac, timingSafeEqual } from 'crypto';
import { Request, Response } from 'express';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
import { AdminGuard } from './admin.guard';
import { AssistantService } from './assistant.service';
class MessageDto { @IsString() @MinLength(1) @MaxLength(1500) message!: string; }
export function validSignature(body: Buffer | undefined, signature: string | undefined, secret: string | undefined) {
  if (!body || !secret || !signature || !/^sha256=[a-f0-9]{64}$/.test(signature)) return false;
  const expected = createHmac('sha256',secret).update(body).digest();
  return timingSafeEqual(expected,Buffer.from(signature.slice(7),'hex'));
}
@Controller('assistant')
export class AssistantController {
 constructor(private readonly service: AssistantService, private readonly config: ConfigService) {}
 @Post('message') @UseGuards(JwtAuthGuard) reply(@Body() dto: MessageDto) { return this.service.reply(dto.message); }
 @Post('support') @UseGuards(JwtAuthGuard) support(@Req() req: AuthRequest,@Body() dto: MessageDto) { return this.service.support(req.userId,dto.message); }
 @Get('support') @UseGuards(JwtAuthGuard,AdminGuard) tickets() { return this.service.tickets(); }
 @Post('support/:id/resolve') @UseGuards(JwtAuthGuard,AdminGuard) resolve(@Param('id',new ParseUUIDPipe()) id: string) { return this.service.resolve(id); }
 @Get('whatsapp') verify(@Query('hub.mode') mode: string,@Query('hub.verify_token') token: string,@Query('hub.challenge') challenge: string,@Res() res: Response) {
   const expected=this.config.get<string>('WHATSAPP_VERIFY_TOKEN');
   if (!expected || mode!=='subscribe' || token!==expected || !challenge) throw new ForbiddenException();
   return res.type('text/plain').send(challenge);
 }
 @Post('whatsapp') @HttpCode(200) async inbound(@Req() req: RawBodyRequest<Request>,@Headers('x-hub-signature-256') signature: string,@Body() body: any) {
   if (!this.service.ready()) throw new ServiceUnavailableException('WhatsApp pendiente de activación');
   if (!validSignature(req.rawBody,signature,this.config.get('WHATSAPP_APP_SECRET'))) throw new ForbiddenException();
   return this.service.inbound(body);
 }
}
