import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { createHash } from 'crypto';

export type AssistantReply = { text: string; action?: string; handoff?: boolean };
export function assistantReply(message: string): AssistantReply {
  const text = message.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (/\b(emergencia|accidente|peligro|auxilio|sos)\b/.test(text)) return { text: 'Si hay peligro inmediato, contacta los servicios de emergencia locales. Usa el botón SOS de Vamos!! para las funciones de seguridad disponibles. Este chat no es un servicio de emergencias.', action: '/safety' };
  if (/\b(soporte|persona|administrador|asesor|problema|reclamo)\b/.test(text)) return { text: 'Puedo registrar tu consulta para el administrador. Escribe el problema y pulsa «Solicitar atención». No incluyas contraseñas ni documentos.', handoff: true };
  if (/\b(buscar|busco|pasajero|destino|origen|bajada|viaje)\b/.test(text) && !/\b(publicar|conductor|ofrecer)\b/.test(text)) return { text: 'Abre «Buscar viaje» e indica origen, destino, fecha y hora. Revisa los resultados y coordina el punto de subida y bajada antes de solicitar un asiento. Este chat no confirma disponibilidad ni reservas.', action: '/search-trip' };
  if (/\b(publicar|conductor|ofrecer|conducir)\b/.test(text)) return { text: 'Para ofrecer un viaje, registra tu vehículo y después indica ruta, fecha, hora, plazas y aporte. Revisa los datos antes de publicarlo.', action: '/offer-vehicle' };
  if (/\b(reserva|reservas|cancelar|aceptado|rechazado|solicitud|estado)\b/.test(text)) return { text: 'Consulta «Mis viajes» con tu sesión de Vamos!! para ver el estado real de tus reservas o publicaciones. Una solicitud no es una reserva aceptada.', action: '/my-trips' };
  if (/\b(comunidad|comunidades|empresa|grupo)\b/.test(text)) return { text: 'En «Comunidades Vamos!!» busca tu grupo y solicita ingreso indicando el motivo. La admisión depende del administrador; este asistente no aprueba solicitudes.', action: 'communities' };
  if (/\b(pago|aporte|precio|costo|gastos)\b/.test(text)) return { text: 'El aporte se consulta en cada viaje. Revisa el importe y coordina con el conductor antes de aceptar. Nunca compartas claves bancarias por este chat.' };
  return { text: 'Soy Responde Ya de Vamos!!. Puedo orientarte para buscar viajes, ofrecer un viaje, consultar reservas, ingresar a comunidades o solicitar soporte. ¿Qué necesitas?' };
}

@Injectable()
export class AssistantService {
  constructor(private readonly db: DataSource, private readonly config: ConfigService) {}
  reply(message: string) { return assistantReply(message); }
  async support(userId: string, message: string) {
    const [ticket] = await this.db.query(`INSERT INTO assistant_support(user_id,channel,message) VALUES($1,'APP',$2) RETURNING id,created_at`, [userId,message]);
    return { ...ticket, text: 'Consulta registrada para revisión del administrador. No se ha confirmado un horario de respuesta.' };
  }
  ready() {
    return this.config.get('WHATSAPP_ENABLED') === 'true' && ['WHATSAPP_ACCESS_TOKEN','WHATSAPP_PHONE_NUMBER_ID','WHATSAPP_APP_SECRET','WHATSAPP_VERIFY_TOKEN','WHATSAPP_GRAPH_VERSION'].every(k => !!this.config.get(k));
  }
  async inbound(payload: any) {
    if (!this.ready()) throw new ServiceUnavailableException('WhatsApp pendiente de activación');
    for (const entry of payload.entry || []) for (const change of entry.changes || []) {
      const value = change.value;
      if (change.field !== 'messages' || value?.metadata?.phone_number_id !== this.config.get('WHATSAPP_PHONE_NUMBER_ID')) continue;
      for (const message of value.messages || []) {
        if (message.type !== 'text' || typeof message.text?.body !== 'string' || typeof message.id !== 'string' || typeof message.from !== 'string' || !/^\d{8,15}$/.test(message.from)) continue;
        const age = Date.now()/1000-Number(message.timestamp);
        if (!Number.isFinite(age) || age < -60 || age > 23*3600) continue;
        const phoneHash = createHash('sha256').update(message.from).digest('hex');
        await this.db.transaction(async manager => {
          // Shared lock serializes this contact across replicas, including manual handoff.
          await manager.query('SELECT pg_advisory_xact_lock(hashtext($1))',[phoneHash]);
          const [seen] = await manager.query('SELECT id FROM assistant_whatsapp_processed WHERE id=$1',[message.id]);
          if (seen) return;
          const [paused] = await manager.query("SELECT id FROM assistant_support WHERE phone_hash=$1 AND channel='WHATSAPP' AND status='OPEN' LIMIT 1",[phoneHash]);
          if (paused) { await manager.query("UPDATE assistant_support SET message=left(message || E'\\n' || $2,6000) WHERE id=$1",[paused.id,message.text.body.slice(0,1500)]); await manager.query('INSERT INTO assistant_whatsapp_processed(id) VALUES($1)',[message.id]); return; }
          const text = message.text.body.slice(0,1500);
          const reply = this.reply(text);
          if (reply.handoff) {
            await manager.query("INSERT INTO assistant_support(channel,phone_hash,contact_phone,message) VALUES('WHATSAPP',$1,$2,$3)",[phoneHash,message.from,text]);
            reply.text = 'Tu consulta se registró para revisión del administrador. La respuesta automática queda pausada mientras se atiende. No se ha confirmado un horario de respuesta.';
          }
          // Private trips and reservations require app sign-in; never infer account from a phone.
          if (reply.action) reply.text += '\nAbre Vamos!! e inicia sesión para continuar.';
          const response = await fetch(`https://graph.facebook.com/${this.config.get('WHATSAPP_GRAPH_VERSION')}/${this.config.get('WHATSAPP_PHONE_NUMBER_ID')}/messages`,{
            method:'POST',signal:AbortSignal.timeout(8000),headers:{Authorization:`Bearer ${this.config.get('WHATSAPP_ACCESS_TOKEN')}`,'Content-Type':'application/json'},
            body:JSON.stringify({messaging_product:'whatsapp',to:message.from,type:'text',text:{body:reply.text}})
          });
          if (!response.ok) throw new ServiceUnavailableException('No se pudo enviar la respuesta');
          await manager.query('INSERT INTO assistant_whatsapp_processed(id) VALUES($1)',[message.id]);
        });
      }
    }
    return { received: true };
  }
  tickets() { return this.db.query("SELECT id,channel,user_id,contact_phone,message,status,created_at FROM assistant_support WHERE status='OPEN' ORDER BY created_at DESC LIMIT 100"); }
  async resolve(id: string) { const rows = await this.db.query("UPDATE assistant_support SET status='CLOSED' WHERE id=$1 RETURNING id",[id]); return { resolved: rows.length>0 }; }
}
