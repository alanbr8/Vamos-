import { assistantReply, AssistantService } from './assistant.service';
import { validSignature } from './assistant.controller';
import { createHmac } from 'crypto';
import { ConfigService } from '@nestjs/config';

describe('Responde Ya', () => {
  it('routes existing screens without claiming reservations', () => {
    expect(assistantReply('busco un viaje').action).toBe('/search-trip');
    expect(assistantReply('publicar viaje').action).toBe('/offer-vehicle');
    expect(assistantReply('estado de mi reserva').action).toBe('/my-trips');
    expect(assistantReply('comunidades').action).toBe('communities');
  });
  it('prioritizes emergencies and handles human support', () => {
    expect(assistantReply('accidente, necesito soporte').action).toBe('/safety');
    expect(assistantReply('hablar con una persona').handoff).toBe(true);
  });
  it('accepts only correctly signed unchanged raw request bodies', () => {
    const body=Buffer.from('{"entry":[]}'), secret='test-only-secret';
    const signature='sha256='+createHmac('sha256',secret).update(body).digest('hex');
    expect(validSignature(body,signature,secret)).toBe(true);
    expect(validSignature(Buffer.from('{}'),signature,secret)).toBe(false);
    expect(validSignature(body,'sha256=abc',secret)).toBe(false);
    expect(validSignature(undefined,signature,secret)).toBe(false);
    expect(validSignature(body,signature,undefined)).toBe(false);
  });
  it('keeps WhatsApp disabled until complete server configuration', () => {
    const s=new AssistantService({} as any,new ConfigService({WHATSAPP_ENABLED:'false'}));
    expect(s.ready()).toBe(false);
  });
  it('does not answer paused contacts or repeat processed messages', async () => {
    const manager={query:jest.fn().mockResolvedValueOnce([]).mockResolvedValueOnce([{id:'already'}])};
    const db={transaction:jest.fn(cb=>cb(manager))};
    const cfg=new ConfigService({WHATSAPP_ENABLED:'true',WHATSAPP_ACCESS_TOKEN:'test',WHATSAPP_PHONE_NUMBER_ID:'123',WHATSAPP_APP_SECRET:'test',WHATSAPP_VERIFY_TOKEN:'test',WHATSAPP_GRAPH_VERSION:'vTEST'});
    const service=new AssistantService(db as any,cfg);
    const spy=jest.spyOn(global,'fetch');
    const payload={entry:[{changes:[{field:'messages',value:{metadata:{phone_number_id:'123'},messages:[{id:'already',from:'59170000000',type:'text',timestamp:String(Math.floor(Date.now()/1000)),text:{body:'hola'}}]}}]}]};
    await service.inbound(payload);expect(spy).not.toHaveBeenCalled();
    manager.query.mockReset().mockResolvedValueOnce([]).mockResolvedValueOnce([]).mockResolvedValueOnce([{id:'paused'}]).mockResolvedValueOnce([]);
    await service.inbound(payload);expect(spy).not.toHaveBeenCalled();spy.mockRestore();
  });
  it('never sends a response for an unrelated business number',async()=>{
    const db={transaction:jest.fn()};
    const cfg=new ConfigService({WHATSAPP_ENABLED:'true',WHATSAPP_ACCESS_TOKEN:'test',WHATSAPP_PHONE_NUMBER_ID:'123',WHATSAPP_APP_SECRET:'test',WHATSAPP_VERIFY_TOKEN:'test',WHATSAPP_GRAPH_VERSION:'vTEST'});
    await new AssistantService(db as any,cfg).inbound({entry:[{changes:[{field:'messages',value:{metadata:{phone_number_id:'other'},messages:[{type:'text'}]}}]}]});
    expect(db.transaction).not.toHaveBeenCalled();
  });
});
