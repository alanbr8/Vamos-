import { BadRequestException, Injectable, UnauthorizedException, ServiceUnavailableException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { createHash, randomBytes } from 'crypto';
import { ForgotPasswordDto, LoginDto, RegisterDto, ResetPasswordDto } from './dtos';

@Injectable()
export class AuthService {
  constructor(private readonly db: DataSource, private readonly jwt: JwtService) {}

  async register(dto: RegisterDto) {
    if (Buffer.byteLength(dto.password, 'utf8') > 72) throw new BadRequestException('La contraseña es demasiado larga. Utiliza hasta 72 bytes.');
    const passwordHash = await bcrypt.hash(dto.password, 12);
    try {
      const [user] = await this.db.query(
        `INSERT INTO users(first_name,last_name,email,phone,password_hash,usage_mode)
         VALUES($1,$2,lower($3),$4,$5,$6)
         RETURNING id,first_name AS "firstName",last_name AS "lastName",email,phone,usage_mode AS "usageMode"`,
        [dto.firstName, dto.lastName, dto.email, dto.phone, passwordHash,dto.usageMode??'PASSENGER'],
      );
      return { user, accessToken: await this.jwt.signAsync({ sub: user.id }) };
    } catch (error: unknown) {
      if ((error as { code?: string }).code === '23505') throw new BadRequestException('Correo o celular ya registrado');
      throw error;
    }
  }

  async login(dto: LoginDto) {
    const [user] = await this.db.query('SELECT * FROM users WHERE email=lower($1) AND status=$2', [dto.email, 'ACTIVE']);
    if (!user || !(await bcrypt.compare(dto.password, user.password_hash))) throw new UnauthorizedException('Credenciales incorrectas');
    return { accessToken: await this.jwt.signAsync({ sub: user.id }), user: { id: user.id, firstName: user.first_name, lastName: user.last_name, email: user.email, usageMode:user.usage_mode } };
  }

  async requestPasswordReset(dto: ForgotPasswordDto) {
    const development = process.env.PASSWORD_RESET_RETURN_TOKEN === 'true' && process.env.NODE_ENV !== 'production';
    if (!development && (!process.env.RESEND_API_KEY || !process.env.PASSWORD_RESET_FROM || !process.env.APP_WEB_URL)) {
      throw new ServiceUnavailableException('La recuperación por correo requiere configuración del administrador.');
    }
    const [user] = await this.db.query(
      'SELECT id FROM users WHERE email=lower($1) AND status=$2',
      [dto.email, 'ACTIVE']);
    const response: { message: string; devToken?: string } = {
      message: 'Si el correo está registrado, recibirás instrucciones para recuperar tu contraseña.',
    };
    if (!user) return response;

    const token = randomBytes(32).toString('hex');
    const tokenHash = createHash('sha256').update(token).digest('hex');
    await this.db.transaction(async manager => {
      await manager.query(
        'UPDATE password_reset_tokens SET used_at=now() WHERE user_id=$1 AND used_at IS NULL',
        [user.id]);
      await manager.query(
        `INSERT INTO password_reset_tokens(user_id,token_hash,expires_at)
         VALUES($1,$2,now()+interval '30 minutes')`,
        [user.id, tokenHash]);
    });
    if (development) {
      response.devToken = token;
    } else {
      const web = process.env.APP_WEB_URL!.replace(/\/$/, '');
      const link = `${web}/#/forgot-password?token=${encodeURIComponent(token)}`;
      const delivery = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json'},
        body: JSON.stringify({
          from: process.env.PASSWORD_RESET_FROM,
          to: [dto.email.trim().toLowerCase()],
          subject: 'Recupera tu contraseña de Vamos!!',
          html: `<h2>Recuperación de contraseña</h2><p>Recibimos una solicitud para tu cuenta de Vamos!!.</p><p><a href="${link}">Crear una nueva contraseña</a></p><p>El enlace vence en 30 minutos. Si no hiciste esta solicitud, ignora este mensaje.</p>`,
          text: `Recupera tu contraseña de Vamos!!: ${link}\nEl enlace vence en 30 minutos.`,
        }),
      });
      if (!delivery.ok) throw new ServiceUnavailableException('No pudimos enviar el correo en este momento. Intenta nuevamente más tarde.');
    }
    return response;
  }

  async resetPassword(dto: ResetPasswordDto) {
    const tokenHash = createHash('sha256').update(dto.token).digest('hex');
    if (Buffer.byteLength(dto.password, 'utf8') > 72) throw new BadRequestException('La contraseña es demasiado larga. Utiliza hasta 72 bytes.');
    const passwordHash = await bcrypt.hash(dto.password, 12);
    return this.db.transaction(async manager => {
      const [reset] = await manager.query(
        `SELECT id,user_id AS "userId" FROM password_reset_tokens
         WHERE token_hash=$1 AND used_at IS NULL AND expires_at>now()
         FOR UPDATE`, [tokenHash]);
      if (!reset) throw new BadRequestException('El enlace es inválido o expiró');
      await manager.query('UPDATE users SET password_hash=$2,updated_at=now() WHERE id=$1', [reset.userId, passwordHash]);
      await manager.query('UPDATE password_reset_tokens SET used_at=now() WHERE user_id=$1 AND used_at IS NULL', [reset.userId]);
      return { message: 'Contraseña actualizada correctamente' };
    });
  }
}
