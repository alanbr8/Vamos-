import { Body, Controller, Get, Param, Patch, Query, Req, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminCommunityCreationDto, AdminCommunityDecisionDto, AdminIncidentStatusDto, AdminUserStatusDto, AdminVehicleStatusDto } from './dtos';
import { AdminGuard } from './admin.guard';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';

@Controller('admin')
@UseGuards(JwtAuthGuard, AdminGuard)
export class AdminController {
  constructor(private readonly admin: AdminService) {}

  @Get('summary') summary() { return this.admin.summary(); }
  @Get('vehicles') vehicles(@Query('status') status?: string) { return this.admin.vehicles(status); }
  @Patch('vehicles/:id') vehicleStatus(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: AdminVehicleStatusDto) {
    return this.admin.updateVehicle(req.userId, id, dto);
  }
  @Get('incidents') incidents(@Query('status') status?: string) { return this.admin.incidents(status); }
  @Patch('incidents/:id') incidentStatus(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: AdminIncidentStatusDto) {
    return this.admin.updateIncident(req.userId, id, dto);
  }
  @Get('users') users(@Query('status') status?: string) { return this.admin.users(status); }
  @Patch('users/:id/status') userStatus(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: AdminUserStatusDto) {
    return this.admin.updateUser(req.userId, id, dto);
  }
  @Get('audit-logs') auditLogs() { return this.admin.auditLogs(); }
  @Get('community-requests') communityRequests(@Query('status') status?: string) { return this.admin.communityRequests(status); }
  @Patch('community-requests/:communityId/:userId') communityDecision(@Req() req: AuthRequest,@Param('communityId') communityId:string,@Param('userId') userId:string,@Body() dto:AdminCommunityDecisionDto){
    return this.admin.updateCommunityRequest(req.userId,communityId,userId,dto);
  }
  @Get('community-creations') communityCreations(@Query('status') status?:string){return this.admin.communityCreations(status);}
  @Patch('community-creations/:id') communityCreation(@Req() req:AuthRequest,@Param('id') id:string,@Body() dto:AdminCommunityCreationDto){return this.admin.updateCommunityCreation(req.userId,id,dto);}
}
