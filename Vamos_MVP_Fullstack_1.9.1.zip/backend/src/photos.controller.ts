import { BadRequestException, Body, ConflictException, Controller, Delete, Get, Header, Injectable, NotFoundException, Param, ParseUUIDPipe, Patch, Post, Req, ServiceUnavailableException, UseGuards } from '@nestjs/common';
import { Equals, IsIn, IsInt, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';
import { DataSource } from 'typeorm';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
import { validateDocument } from './documents.service';
import { AdminGuard } from './admin.guard';
export class DisplayPhotoDto {
  @IsString() @MaxLength(1400000) base64!: string;
  @IsOptional() @IsUUID() vehicleId?: string;
  @Equals(true) consent!: boolean;
}
export class ReviewProfilePhotoDto {
  @IsIn(['APPROVED','REJECTED']) status!:string;
  @IsInt() @Min(1) version!:number;
  @IsOptional() @IsString() @MaxLength(300) reason?:string;
}
@Injectable()
export class PhotosService {
  constructor(private readonly db:DataSource){}
  private key(){
    const key=process.env.DOCUMENT_ENCRYPTION_KEY||'';
    if(!/^[a-fA-F0-9]{64}$/.test(key))throw new ServiceUnavailableException('El administrador debe configurar el almacenamiento de fotos');
    return Buffer.from(key,'hex');
  }
  async save(owner:string,dto:DisplayPhotoDto){
    const {bytes,mime}=validateDocument({kind:'CI_FRONT',base64:dto.base64,consent:dto.consent});
    const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',this.key(),iv);
    const encrypted=Buffer.concat([cipher.update(bytes),cipher.final()]);
    return this.db.transaction(async m=>{
      await m.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[owner]);
      if(dto.vehicleId){
        const [car]=await m.query('SELECT id FROM vehicles WHERE id=$1 AND owner_id=$2 FOR UPDATE',[dto.vehicleId,owner]);
        if(!car)throw new NotFoundException('Vehículo no encontrado');
      }
      if(!dto.vehicleId){
        const [submission]=await m.query(`INSERT INTO profile_photo_submissions(owner_id,ciphertext,iv,tag,mime)
        VALUES($1,$2,$3,$4,$5) ON CONFLICT(owner_id) DO UPDATE SET ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,
        tag=EXCLUDED.tag,mime=EXCLUDED.mime,status='PENDING',reason=NULL,reviewed_by=NULL,reviewed_at=NULL,
        submitted_at=now(),updated_at=now(),version=profile_photo_submissions.version+1
        RETURNING id,status,version`,[owner,encrypted,iv,cipher.getAuthTag(),mime]);
        return submission;
      }
      const conflict='(vehicle_id) WHERE vehicle_id IS NOT NULL';
      const [result]=await m.query(`INSERT INTO display_photos(owner_id,vehicle_id,ciphertext,iv,tag,mime)
      VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT ${conflict} DO UPDATE SET ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,mime=EXCLUDED.mime,updated_at=now()
      RETURNING id`,[owner,dto.vehicleId||null,encrypted,iv,cipher.getAuthTag(),mime]);
      return result;
    });
  }
  async profileStatus(owner:string){
    const [row]=await this.db.query(`SELECT
      COALESCE((SELECT s.status FROM profile_photo_submissions s WHERE s.owner_id=$1),
        CASE WHEN EXISTS(SELECT 1 FROM display_photos p WHERE p.owner_id=$1 AND p.vehicle_id IS NULL) THEN 'APPROVED' ELSE 'NOT_SUBMITTED' END) AS status,
      (SELECT s.reason FROM profile_photo_submissions s WHERE s.owner_id=$1) AS reason,
      COALESCE((SELECT s.version FROM profile_photo_submissions s WHERE s.owner_id=$1),0) AS version,
      (SELECT s.updated_at FROM profile_photo_submissions s WHERE s.owner_id=$1) AS "updatedAt",
      EXISTS(SELECT 1 FROM display_photos p WHERE p.owner_id=$1 AND p.vehicle_id IS NULL) AS "hasApprovedPhoto"`,[owner]);
    return row;
  }
  queue(){return this.db.query(`SELECT s.id,s.owner_id AS "ownerId",s.status,s.reason,s.version,s.updated_at AS "updatedAt",
    u.first_name||' '||u.last_name AS owner,u.email,
    vamos_identity_ready(u.id,(now() AT TIME ZONE 'America/La_Paz')::date) AS "identityVerified"
    FROM profile_photo_submissions s JOIN users u ON u.id=s.owner_id
    ORDER BY (s.status='PENDING') DESC,s.updated_at DESC LIMIT 200`);}
  async submissionImage(id:string){
    const [photo]=await this.db.query('SELECT ciphertext,iv,tag,mime,version FROM profile_photo_submissions WHERE id=$1',[id]);
    if(!photo)throw new NotFoundException('Foto no encontrada');
    const decipher=createDecipheriv('aes-256-gcm',this.key(),photo.iv);decipher.setAuthTag(photo.tag);
    return {base64:Buffer.concat([decipher.update(photo.ciphertext),decipher.final()]).toString('base64'),mime:photo.mime,version:photo.version};
  }
  async review(admin:string,id:string,dto:ReviewProfilePhotoDto){
    if(dto.status==='REJECTED'&&!dto.reason?.trim())throw new BadRequestException('Indica el motivo del rechazo');
    return this.db.transaction(async m=>{
      const [photo]=await m.query('SELECT * FROM profile_photo_submissions WHERE id=$1 FOR UPDATE',[id]);
      if(!photo)throw new NotFoundException('Foto no encontrada');
      if(photo.version!==dto.version)throw new ConflictException('La foto cambió. Actualiza y revisa la nueva versión');
      if(photo.status!=='PENDING')throw new BadRequestException('Esta foto ya fue revisada');
      if(dto.status==='APPROVED'){
        const [identity]=await m.query(`SELECT vamos_identity_ready($1,(now() AT TIME ZONE 'America/La_Paz')::date) AS ready`,[photo.owner_id]);
        if(!identity?.ready)throw new BadRequestException('Primero deben estar aprobados el carnet y la selfie del usuario');
        await m.query(`INSERT INTO display_photos(owner_id,vehicle_id,ciphertext,iv,tag,mime)
        VALUES($1,NULL,$2,$3,$4,$5) ON CONFLICT(owner_id) WHERE vehicle_id IS NULL DO UPDATE SET
        ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,mime=EXCLUDED.mime,updated_at=now()`,
        [photo.owner_id,photo.ciphertext,photo.iv,photo.tag,photo.mime]);
      }
      const [saved]=await m.query(`WITH changed AS (UPDATE profile_photo_submissions SET status=$2,reason=$3,
        reviewed_by=$4,reviewed_at=now(),updated_at=now() WHERE id=$1 RETURNING id,status,version,owner_id AS "ownerId") SELECT * FROM changed`,
        [id,dto.status,dto.status==='REJECTED'?dto.reason!.trim():null,admin]);
      await m.query(`INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data)
        VALUES($1,'PROFILE_PHOTO_REVIEWED','PROFILE_PHOTO',$2,$3,$4)`,[admin,id,{status:photo.status,version:photo.version},{status:dto.status,reason:dto.reason||null}]);
      await m.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'PROFILE_PHOTO_REVIEW','Foto de perfil',$2,$3)`,
        [photo.owner_id,dto.status==='APPROVED'?'Tu foto de perfil fue aprobada':`Tu foto necesita cambios: ${dto.reason}`,{photoId:id,status:dto.status}]);
      return saved;
    });
  }
  async get(id:string,vehicle:boolean){
    // Fotos destinadas a los viajes, visibles a usuarios autenticados. Nunca se consulta verification_documents.
    const [photo]=await this.db.query(`SELECT p.ciphertext,p.iv,p.tag,p.mime FROM display_photos p JOIN users u ON u.id=p.owner_id
    WHERE u.status='ACTIVE' AND ${vehicle?'p.vehicle_id=$1':'p.owner_id=$1 AND p.vehicle_id IS NULL'}`,[id]);
    if(!photo)throw new NotFoundException('Sin foto');
    const decipher=createDecipheriv('aes-256-gcm',this.key(),photo.iv);decipher.setAuthTag(photo.tag);
    return {base64:Buffer.concat([decipher.update(photo.ciphertext),decipher.final()]).toString('base64'),mime:photo.mime};
  }
  async remove(owner:string,vehicleId?:string){
    if(!vehicleId)throw new BadRequestException('La foto de perfil aprobada solo puede cambiarse mediante una nueva verificación');
    await this.db.query(`DELETE FROM display_photos WHERE owner_id=$1 AND ${vehicleId?'vehicle_id=$2':'vehicle_id IS NULL'}`,vehicleId?[owner,vehicleId]:[owner]);
    return {removed:true};
  }
}
@Controller('photos')
@UseGuards(JwtAuthGuard)
export class PhotosController {
  constructor(private readonly photos:PhotosService){}
  @Post() save(@Req() req:AuthRequest,@Body() dto:DisplayPhotoDto){return this.photos.save(req.userId,dto);}
  @Get('profile/me/status') profileStatus(@Req() req:AuthRequest){return this.photos.profileStatus(req.userId);}
  @Get('admin/queue') @UseGuards(AdminGuard) queue(){return this.photos.queue();}
  @Get('admin/:id/image') @UseGuards(AdminGuard) @Header('Cache-Control','no-store') submission(@Param('id',ParseUUIDPipe) id:string){return this.photos.submissionImage(id);}
  @Patch('admin/:id') @UseGuards(AdminGuard) review(@Req() req:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() dto:ReviewProfilePhotoDto){return this.photos.review(req.userId,id,dto);}
  @Get('profile/:id') @Header('Cache-Control','no-store') profile(@Param('id',ParseUUIDPipe) id:string){return this.photos.get(id,false);}
  @Get('vehicle/:id') @Header('Cache-Control','no-store') vehicle(@Param('id',ParseUUIDPipe) id:string){return this.photos.get(id,true);}
  @Delete('profile') removeProfile(@Req() req:AuthRequest){return this.photos.remove(req.userId);}
  @Delete('vehicle/:id') removeVehicle(@Req() req:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.photos.remove(req.userId,id);}
}
