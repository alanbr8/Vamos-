# Vamos!! 1.8.16 · Corrección de integración de comunidades

Corrige la prueba de integración para respetar el nuevo flujo de aprobación:

1. La comunidad se crea pendiente y todavía no entrega código.
2. Operaciones aprueba la creación.
3. Recién entonces se obtiene el código y se solicita el ingreso con un motivo.

Además, el servicio rechaza de forma controlada las solicitudes sin código o motivo, evitando un `TypeError` y una respuesta genérica de error interno.

La entrega compila y supera 63 pruebas unitarias. La integración PostgreSQL/PostGIS debe ejecutarse nuevamente en GitHub Actions.
