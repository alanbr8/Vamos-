# Vamos!! Web 1.9.0

Versión web responsive y PWA basada en la misma aplicación Flutter, API de Render y base Neon.

## Funciones reutilizadas

- Registro, acceso y perfil.
- Vehículos y documentos.
- Publicación, búsqueda y reserva de viajes.
- Comunidades y sus aprobaciones.
- Chat, calificaciones, incidentes y pagos.
- Mapas, ubicación y seguimiento mientras la página permanece abierta.

## Límites del navegador

- El seguimiento web se detiene o puede ser suspendido cuando se cierra la pestaña o el sistema bloquea Safari/Chrome. Para conductores se recomienda Android durante un viaje activo.
- Las notificaciones push web requieren configuración adicional de Firebase; la bandeja interna continúa operativa.
- Cámara, GPS y fotos requieren HTTPS y permiso del usuario.

## Publicación gratuita con GitHub Pages

1. Copiar `delivery/web.yml` a `.github/workflows/web.yml` en el repositorio.
2. En GitHub abrir **Settings → Pages → Build and deployment → Source** y seleccionar **GitHub Actions**.
3. Ejecutar **Actions → Publicar Vamos Web → Run workflow**.
4. Cuando termine, abrir `https://alanbr8.github.io/Vamos-/`.

El workflow genera la plataforma web, analiza el código, ejecuta pruebas, compila en modo release y publica el resultado. Mantiene el ZIP esperado por el repositorio con nombre `Vamos_MVP_Fullstack_1.8.0.zip`; al reemplazar entregas se conserva ese nombre dentro de GitHub.
