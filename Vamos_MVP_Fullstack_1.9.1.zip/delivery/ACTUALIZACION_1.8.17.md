# Vamos!! 1.8.17 · Tipos SQL de comunidades

Corrige el error PostgreSQL `42P08` (`text versus character varying`) detectado por GitHub Actions.

Las consultas nuevas de creación, aprobación, rechazo y administración de comunidades declaran ahora explícitamente `text` o `varchar` para cada parámetro reutilizado. Esto evita que PostgreSQL deduzca tipos incompatibles para un mismo marcador.

El backend compila, supera 63 pruebas unitarias y el archivo de integración tiene sintaxis válida. Volver a ejecutar GitHub Actions para confirmar la integración contra PostgreSQL/PostGIS.
