# Vamos!! 1.8.15 · Visto bueno para crear comunidades

## Nuevo flujo

1. El usuario completa nombre, categoría, descripción y condiciones de la comunidad.
2. La creación queda en estado **PENDING**.
3. El panel de operaciones muestra la solicitud en **Comunidades → Creación de comunidades**.
4. Operaciones puede dar el visto bueno o rechazar indicando un motivo.
5. Solo una comunidad aprobada muestra su código, admite solicitudes y permite viajes privados.

El creador queda registrado desde el inicio como administrador principal, pero sus facultades permanecen bloqueadas hasta la aprobación. La decisión se audita y genera una notificación.

## Despliegue

Ejecutar, en este orden, sobre Neon:

1. `database/migrations/017_community_administration.sql`
2. `database/migrations/018_community_creation_approval.sql`

Luego desplegar el backend y compilar el nuevo APK. Las comunidades que ya existían antes de la migración 018 permanecen aprobadas; las nuevas requieren revisión.

## Prueba mínima

- Crear una comunidad y comprobar que no aparece el código de invitación.
- Confirmar que el panel central la cuenta como pendiente.
- Aprobarla y comprobar la notificación al creador.
- Verificar que entonces aparecen el código, la administración de miembros y los viajes.
- Crear otra, rechazarla con motivo y comprobar que el motivo aparece en la aplicación.
