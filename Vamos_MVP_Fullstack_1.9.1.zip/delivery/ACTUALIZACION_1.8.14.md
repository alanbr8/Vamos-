# Vamos!! 1.8.14 · Administración de comunidades

## Qué cambia

- El creador se identifica como **Administrador principal** y ya no puede aprobarse, rechazarse ni retirarse a sí mismo.
- El administrador principal puede designar o retirar administradores entre los miembros aprobados.
- La solicitud de ingreso exige explicar el motivo (20 a 1000 caracteres).
- En comunidades de empresa se exige además ubicación de trabajo y cargo.
- Los administradores de la comunidad ven estos datos y pueden aprobar o rechazar.
- El panel central de operaciones incorpora una sección **Comunidades** para revisar las mismas solicitudes.
- Las decisiones del panel central quedan en la auditoría y generan una notificación al solicitante.

## Despliegue

1. Ejecutar `database/migrations/017_community_administration.sql` en Neon sobre la base de producción.
2. Subir el código a GitHub y esperar el despliegue correcto de la API en Render.
3. Compilar e instalar el nuevo APK. La versión anterior no envía el motivo obligatorio al solicitar ingreso.
4. Probar con tres cuentas: administrador principal, administrador delegado y solicitante.

## Prueba mínima

1. Crear una comunidad y comprobar que el creador aparece como Administrador principal, sin botones contra sí mismo.
2. Solicitar ingreso desde otra cuenta indicando motivo, ubicación y cargo.
3. Aprobar desde la aplicación; luego designar al miembro como administrador.
4. Enviar otra solicitud y aprobarla desde el panel de operaciones.
5. Confirmar que ambos miembros acceden a los viajes privados y que la decisión central aparece en Auditoría.
