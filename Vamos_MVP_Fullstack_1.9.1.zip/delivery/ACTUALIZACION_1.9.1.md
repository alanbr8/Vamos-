# Vamos!! 1.9.1 — comunidades, recuperación y verificación

## Funciones incluidas

- Búsqueda de comunidades aprobadas por nombre.
- Solicitud de ingreso desde el resultado de búsqueda, con motivo y datos laborales para comunidades de empresa.
- Invitación compartible desde la administración de cada comunidad; incluye nombre y código.
- Recuperación real de contraseña por correo, con enlace de un solo uso válido por 30 minutos.
- Foto de perfil enviada a revisión administrativa y conservada de forma cifrada.
- La foto aprobada no puede eliminarse ni sustituirse directamente: una nueva foto vuelve al proceso de revisión.
- El administrador puede comparar la propuesta con el carnet y la selfie ya revisados, y aprobarla o rechazarla con motivo.
- Viñetas de “Usuario verificado” y “Vehículo verificado” en los resultados de viajes.

## Actualización obligatoria de Neon

Ejecuta una sola vez, en **Neon > SQL Editor**, todo el contenido de:

`database/migrations/019_profile_photo_review.sql`

No ejecutes nuevamente `database/init.sql` sobre la base de producción.

## Variables nuevas del backend en Render

En el servicio de la API, abre **Environment** y agrega:

| Variable | Valor esperado |
| --- | --- |
| `RESEND_API_KEY` | Clave API creada en Resend |
| `PASSWORD_RESET_FROM` | Remitente verificado, por ejemplo `Vamos!! <soporte@tudominio.com>` |
| `APP_WEB_URL` | URL pública sin barra final, por ejemplo `https://vamos-web.onrender.com` |

Mantén `PASSWORD_RESET_RETURN_TOKEN=false` y `NODE_ENV=production` en producción.
Después de guardar las variables, realiza **Manual Deploy > Deploy latest commit**.

## Panel administrativo

En `https://vamos-api.onrender.com/admin/` aparecerá la sección **Fotos de perfil**.
La aprobación exige que el carnet y la selfie del usuario ya estén aprobados. Toda
decisión queda registrada en la bitácora administrativa.

## Orden recomendado para publicar

1. Sustituir en GitHub el ZIP anterior por esta versión y confirmar el commit.
2. Ejecutar la migración `019_profile_photo_review.sql` en Neon.
3. Configurar las tres variables de correo en el backend de Render.
4. Desplegar primero la API y luego el sitio estático/PWA.
5. Probar con una cuenta no administrativa: buscar comunidad, solicitar ingreso,
   recuperar contraseña y enviar una foto de perfil.
6. Probar con la cuenta administrativa: revisar la foto y confirmar las viñetas.
