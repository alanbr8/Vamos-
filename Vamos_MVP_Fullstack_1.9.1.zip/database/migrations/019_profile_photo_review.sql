BEGIN;

CREATE TABLE IF NOT EXISTS profile_photo_submissions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL UNIQUE REFERENCES users(id),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 1048576),
 iv bytea NOT NULL,
 tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK(mime IN ('image/jpeg','image/png')),
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED')),
 reason varchar(300),
 version integer NOT NULL DEFAULT 1,
 reviewed_by uuid REFERENCES users(id),
 reviewed_at timestamptz,
 submitted_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS profile_photo_review_idx
 ON profile_photo_submissions(status,updated_at DESC);

COMMIT;
