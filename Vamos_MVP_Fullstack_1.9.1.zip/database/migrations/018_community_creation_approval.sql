ALTER TABLE communities ADD COLUMN IF NOT EXISTS approval_status varchar(12) NOT NULL DEFAULT 'APPROVED';
ALTER TABLE communities ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;
ALTER TABLE communities ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES users(id);
ALTER TABLE communities ADD COLUMN IF NOT EXISTS rejection_reason varchar(500);

DO $$ BEGIN
 ALTER TABLE communities ADD CONSTRAINT communities_approval_status_check CHECK(approval_status IN ('PENDING','APPROVED','REJECTED'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS communities_approval_idx ON communities(approval_status,created_at);

CREATE OR REPLACE FUNCTION vamos_community_access(cid uuid,uid uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT cid IS NULL OR EXISTS(SELECT 1 FROM community_members m JOIN communities c ON c.id=m.community_id JOIN users u ON u.id=c.owner_id
 WHERE m.community_id=cid AND m.user_id=uid AND m.status='APPROVED' AND c.approval_status='APPROVED' AND u.status='ACTIVE');
$$;
