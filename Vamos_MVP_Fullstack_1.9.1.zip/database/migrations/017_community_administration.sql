ALTER TABLE community_members ADD COLUMN IF NOT EXISTS role varchar(12) NOT NULL DEFAULT 'MEMBER';
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS request_reason varchar(1000);
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS organization_location varchar(200);
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS job_title varchar(120);
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES users(id);
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS review_note varchar(500);

DO $$ BEGIN
 ALTER TABLE community_members ADD CONSTRAINT community_members_role_check CHECK(role IN ('MEMBER','ADMIN'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

UPDATE community_members m SET role='ADMIN'
FROM communities c WHERE c.id=m.community_id AND c.owner_id=m.user_id;

CREATE INDEX IF NOT EXISTS community_members_review_idx ON community_members(status,created_at);
