import 'services/live_tracking_service.dart';
import 'dart:async';
import 'services/push_service.dart';
import 'screens/notifications/notifications_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';

import 'core/routes/app_routes.dart';
import 'core/theme/app_theme.dart';
import 'services/session_store.dart';
import 'services/api_client.dart';

final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  bool interruptedPhoto = false;
  if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
    try {
      // Una foto recuperada nunca se envía sin confirmar su tipo y propietario.
      final lost = await ImagePicker().retrieveLostData();
      interruptedPhoto = !lost.isEmpty;
    } catch (_) { interruptedPhoto = true; }
  }
  final restored = await SessionStore.instance.restore();
  ApiClient.instance.onSessionExpired = () {
    navigatorKey.currentState?.pushNamedAndRemoveUntil(
      AppRoutes.login,
      (_) => false,
    );
  };
  runApp(VamosApp(sessionRestored: restored));
  SessionStore.instance.onChanged = () => unawaited(PushService.instance.sync());
  SessionStore.instance.beforeClear = () async { await LiveTrackingService.instance.stop(); await PushService.instance.logout(); };
  PushService.instance.onOpen = (id) {
    navigatorKey.currentState?.push(MaterialPageRoute<void>(builder:(_)=>NotificationsScreen(notificationId:id)));
  };
  PushService.instance.onForeground = (id) {
    final context=navigatorKey.currentContext;
    if(context!=null)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:const Text('Tienes una nueva notificación de Vamos!'),action:SnackBarAction(label:'Ver',onPressed:()=>PushService.instance.onOpen?.call(id))));
  };
  WidgetsBinding.instance.addPostFrameCallback((_)=>unawaited(PushService.instance.sync()));
  if (interruptedPhoto) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final context = navigatorKey.currentContext;
      if (context != null) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Se interrumpió la selección de foto. No se envió. Vuelve a Documentos para tomarla o elegirla nuevamente.'),
        duration: Duration(seconds: 8),
      ));
    });
  }
}

class VamosApp extends StatelessWidget {
  const VamosApp({super.key, required this.sessionRestored});
  final bool sessionRestored;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Vamos!!',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: sessionRestored ? AppRoutes.home : AppRoutes.welcome,
      routes: AppRoutes.routes,
      builder:(context,child)=>ColoredBox(color:AppColors.background,child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:760),child:child??const SizedBox.shrink()))),
    );
  }
}
