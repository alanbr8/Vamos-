import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'api_client.dart';

class LiveTrackingService {
 static final instance=LiveTrackingService();
 final status=ValueNotifier<String>('Ubicación detenida');
 StreamSubscription<Position>? _stream;
 Timer? _timer;
 String? tripId;
 bool _sending=false;
 DateTime? _sentAt;
 Future<void> start(String id) async {
  if(!kIsWeb&&defaultTargetPlatform!=TargetPlatform.android)throw Exception('El seguimiento está habilitado en Android y en la versión web mientras permanezca abierta.');
  if(!await Geolocator.isLocationServiceEnabled())throw Exception('Activa la ubicación del teléfono.');
  var permission=await Geolocator.checkPermission();
  if(permission==LocationPermission.denied)permission=await Geolocator.requestPermission();
  if(permission==LocationPermission.denied||permission==LocationPermission.deniedForever)throw Exception('Permite la ubicación precisa mientras usas Vamos.');
  await stop();
  await ApiClient.instance.trackingAction(id,'start');
  tripId=id;_sentAt=null;status.value='Ubicación activa · esperando GPS';
  final settings=kIsWeb?const LocationSettings(accuracy:LocationAccuracy.high,distanceFilter:0):AndroidSettings(
    accuracy:LocationAccuracy.high,distanceFilter:0,intervalDuration:const Duration(seconds:15),
    foregroundNotificationConfig:const ForegroundNotificationConfig(
      notificationTitle:'Vamos! · Compartiendo ubicación',
      notificationText:'Tu viaje está siendo seguido. Abre Vamos para detener la ubicación.',enableWakeLock:true,
    ),
  );
  _stream=Geolocator.getPositionStream(locationSettings:settings).listen((p)=>_send(id,p),onError:(Object e){status.value='Sin señal de ubicación. Revisa el GPS y los permisos.';});
  _timer=Timer.periodic(const Duration(seconds:30),(_)async{
    if(tripId!=id)return;
    try{final state=await ApiClient.instance.tracking(id);if(tripId==id&&state['enabled']!=true)await stop();}
    on ApiException catch(e){if(tripId==id&&(e.statusCode==404||e.statusCode==401||e.statusCode==403))await stop();}
  });
 }
 Future<void> _send(String id,Position p)async{
  if(tripId!=id||_sending||(_sentAt!=null&&DateTime.now().difference(_sentAt!).inSeconds<12))return;
  _sending=true;
  try{
    final result=await ApiClient.instance.trackingAction(id,'position',data:{'latitude':p.latitude,'longitude':p.longitude,'accuracy':p.accuracy.clamp(0,1000),'recordedAt':p.timestamp.toUtc().toIso8601String()});
    if(tripId==id){_sentAt=DateTime.now();status.value=result['accepted']==true?'Ubicación enviada · ${_sentAt!.hour}:${_sentAt!.minute.toString().padLeft(2,'0')}':'Esperando una ubicación reciente';}
  }on ApiException catch(e){if(tripId==id&&(e.statusCode==404||e.statusCode==401||e.statusCode==403)){await stop();}else{status.value='Sin conexión. Se reintentará con una ubicación nueva.';}}
  finally{_sending=false;}
 }
 Future<void> stop()async{
  final id=tripId;tripId=null;_timer?.cancel();_timer=null;
  await _stream?.cancel();_stream=null;status.value='Ubicación detenida';
  if(id!=null){try{await ApiClient.instance.trackingAction(id,'stop');}catch(_){}}
 }
}
