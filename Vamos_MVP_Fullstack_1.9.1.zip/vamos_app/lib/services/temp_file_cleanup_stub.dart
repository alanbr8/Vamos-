Future<void> deleteTemporaryFile(String path) async {}
