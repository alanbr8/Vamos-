import 'dart:io';

Future<void> deleteTemporaryFile(String path) async {
  try { await File(path).delete(); } catch (_) {}
}
