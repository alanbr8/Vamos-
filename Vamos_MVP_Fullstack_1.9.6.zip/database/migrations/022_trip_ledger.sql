-- Marcas de tiempo permanentes para la bitácora regulatoria de recorridos.
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS accepted_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS rejected_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS no_show_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS completed_at timestamptz;

UPDATE bookings SET accepted_at=COALESCE(accepted_at,created_at)
 WHERE status IN ('ACCEPTED','COMPLETED','CANCELLED','NO_SHOW') AND accepted_at IS NULL;
UPDATE bookings SET completed_at=COALESCE(completed_at,encounter_verified_at,created_at)
 WHERE status='COMPLETED' AND completed_at IS NULL;
UPDATE bookings SET cancelled_at=COALESCE(cancelled_at,created_at)
 WHERE status='CANCELLED' AND cancelled_at IS NULL;
UPDATE bookings SET rejected_at=COALESCE(rejected_at,created_at)
 WHERE status='REJECTED' AND rejected_at IS NULL;
UPDATE bookings SET no_show_at=COALESCE(no_show_at,created_at)
 WHERE status='NO_SHOW' AND no_show_at IS NULL;

CREATE INDEX IF NOT EXISTS bookings_ledger_idx
 ON bookings(COALESCE(completed_at,encounter_verified_at,accepted_at,created_at) DESC)
 WHERE accepted_at IS NOT NULL;
