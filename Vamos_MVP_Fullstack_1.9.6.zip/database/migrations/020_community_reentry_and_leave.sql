ALTER TABLE community_members ADD COLUMN IF NOT EXISTS rejection_count integer NOT NULL DEFAULT 0;
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS retry_at timestamptz;

WITH counts AS (
 SELECT m.community_id,m.user_id,count(n.id)::integer AS total
 FROM community_members m LEFT JOIN notifications n ON n.user_id=m.user_id
  AND n.type='COMMUNITY_REVIEW' AND n.data->>'communityId'=m.community_id::text
  AND n.data->>'status'='REJECTED' AND COALESCE((n.data->>'removed')::boolean,false)=false
 WHERE m.status='REJECTED' GROUP BY m.community_id,m.user_id
)
UPDATE community_members m SET rejection_count=GREATEST(m.rejection_count,c.total),
 retry_at=CASE WHEN GREATEST(m.rejection_count,c.total)=1 THEN m.reviewed_at+interval '3 days'
               WHEN GREATEST(m.rejection_count,c.total)=2 THEN m.reviewed_at+interval '7 days' ELSE NULL END
FROM counts c WHERE c.community_id=m.community_id AND c.user_id=m.user_id;

ALTER TABLE community_members DROP CONSTRAINT IF EXISTS community_members_status_check;
ALTER TABLE community_members ADD CONSTRAINT community_members_status_check
 CHECK(status IN ('PENDING','APPROVED','REJECTED','LEFT','REMOVED'));

CREATE INDEX IF NOT EXISTS community_members_retry_idx
 ON community_members(user_id,community_id,status,retry_at);
