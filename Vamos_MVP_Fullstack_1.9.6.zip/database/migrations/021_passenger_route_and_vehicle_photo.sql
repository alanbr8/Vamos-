ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_origin geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_destination geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_route geography(LineString,4326);

CREATE INDEX IF NOT EXISTS bookings_passenger_route_idx ON bookings USING gist(passenger_route);
