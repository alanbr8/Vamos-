CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TYPE user_status AS ENUM ('ACTIVE', 'SUSPENDED', 'BLOCKED');
CREATE TYPE user_role AS ENUM ('USER', 'ADMIN');
CREATE TYPE verification_status AS ENUM ('DRAFT', 'PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED');
CREATE TYPE trip_status AS ENUM ('DRAFT', 'PUBLISHED', 'RESERVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
CREATE TYPE booking_status AS ENUM ('PENDING', 'ACCEPTED', 'REJECTED', 'CANCELLED', 'NO_SHOW', 'COMPLETED');
CREATE TYPE incident_status AS ENUM ('RECEIVED', 'REVIEWING', 'RESOLVED', 'DISMISSED');

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name varchar(80) NOT NULL,
  last_name varchar(80) NOT NULL,
  email varchar(180) UNIQUE NOT NULL,
  phone varchar(30) UNIQUE NOT NULL,
  password_hash text NOT NULL,
  photo_url text,
  status user_status NOT NULL DEFAULT 'ACTIVE',
  role user_role NOT NULL DEFAULT 'USER',
  identity_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES users(id),
  brand varchar(50) NOT NULL,
  model varchar(50) NOT NULL,
  year smallint NOT NULL CHECK (year BETWEEN 1950 AND 2100),
  color varchar(30) NOT NULL,
  license_plate varchar(20) NOT NULL,
  CONSTRAINT vehicles_owner_plate_key UNIQUE(owner_id,license_plate),
  passenger_seats smallint NOT NULL CHECK (passenger_seats BETWEEN 1 AND 7),
  front_photo_url text,
  side_photo_url text,
  document_url text,
  verification_status verification_status NOT NULL DEFAULT 'PENDING',
  rejection_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES users(id),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id),
  origin_label text NOT NULL,
  origin geography(Point, 4326) NOT NULL,
  destination_label text NOT NULL,
  destination geography(Point, 4326) NOT NULL,
  route geography(LineString, 4326) NOT NULL,
  departure_at timestamptz NOT NULL,
  available_seats smallint NOT NULL CHECK (available_seats BETWEEN 0 AND 7),
  contribution numeric(8,2) NOT NULL CHECK (contribution >= 0),
  recurring_days smallint[] NOT NULL DEFAULT '{}',
  preferences jsonb NOT NULL DEFAULT '{}',
  status trip_status NOT NULL DEFAULT 'PUBLISHED',
  meeting_code char(4) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id),
  passenger_id uuid NOT NULL REFERENCES users(id),
  seats smallint NOT NULL DEFAULT 1 CHECK (seats > 0),
  meeting_point_label text,
  meeting_point geography(Point, 4326),
  status booking_status NOT NULL DEFAULT 'PENDING',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, passenger_id)
);

CREATE TABLE ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id),
  from_user_id uuid NOT NULL REFERENCES users(id),
  to_user_id uuid NOT NULL REFERENCES users(id),
  overall smallint NOT NULL CHECK (overall BETWEEN 1 AND 5),
  punctuality smallint CHECK (punctuality BETWEEN 1 AND 5),
  kindness smallint CHECK (kindness BETWEEN 1 AND 5),
  safety smallint CHECK (safety BETWEEN 1 AND 5),
  driving smallint CHECK (driving BETWEEN 1 AND 5),
  comment varchar(300),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, from_user_id, to_user_id)
);

CREATE TABLE incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid REFERENCES trips(id),
  reporter_id uuid NOT NULL REFERENCES users(id),
  reported_user_id uuid REFERENCES users(id),
  type varchar(50) NOT NULL,
  description text NOT NULL,
  status incident_status NOT NULL DEFAULT 'RECEIVED',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE emergency_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES users(id),
  name varchar(120) NOT NULL,
  phone varchar(30) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash char(64) UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type varchar(50) NOT NULL,
  title varchar(140) NOT NULL,
  body text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id),
  recipient_id uuid NOT NULL REFERENCES users(id),
  body varchar(1000) NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 1000),
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (sender_id <> recipient_id)
);

CREATE TABLE admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES users(id),
  action varchar(80) NOT NULL,
  entity_type varchar(40) NOT NULL,
  entity_id uuid NOT NULL,
  previous_data jsonb NOT NULL DEFAULT '{}',
  new_data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX trips_origin_gix ON trips USING GIST (origin);
CREATE INDEX trips_destination_gix ON trips USING GIST (destination);
CREATE INDEX trips_route_gix ON trips USING GIST (route);
CREATE INDEX bookings_meeting_point_gix ON bookings USING GIST (meeting_point);
CREATE INDEX trips_departure_status_idx ON trips (departure_at, status);
CREATE INDEX bookings_trip_status_idx ON bookings (trip_id, status);
CREATE INDEX password_reset_user_idx ON password_reset_tokens (user_id, expires_at DESC);
CREATE INDEX notifications_user_created_idx ON notifications (user_id, created_at DESC);
CREATE INDEX notifications_unread_idx ON notifications (user_id) WHERE read_at IS NULL;
CREATE INDEX messages_booking_created_idx ON messages (booking_id, created_at);
CREATE INDEX messages_recipient_unread_idx ON messages (recipient_id) WHERE read_at IS NULL;
CREATE INDEX admin_audit_created_idx ON admin_audit_logs (created_at DESC);
CREATE INDEX admin_audit_entity_idx ON admin_audit_logs (entity_type, entity_id);

CREATE TABLE IF NOT EXISTS saved_searches (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 criteria jsonb NOT NULL,
 origin_label text NOT NULL,
 destination_label text NOT NULL,
 active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id,criteria)
);
CREATE INDEX IF NOT EXISTS saved_searches_user_idx ON saved_searches(user_id);
CREATE TABLE IF NOT EXISTS saved_search_matches (
 search_id uuid NOT NULL REFERENCES saved_searches(id) ON DELETE CASCADE,
 trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
 PRIMARY KEY(search_id,trip_id)
);

-- Documentos privados para instalaciones nuevas.
BEGIN;
CREATE TABLE IF NOT EXISTS verification_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL REFERENCES users(id),
 vehicle_id uuid REFERENCES vehicles(id),
 kind varchar(24) NOT NULL CHECK (kind IN ('CI_FRONT','CI_BACK','SELFIE','LICENSE_FRONT','LICENSE_BACK','VEHICLE_FRONT','VEHICLE_SIDE','SOAT')),
 ciphertext bytea NOT NULL,
 iv bytea NOT NULL,
 tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK (mime IN ('image/jpeg','image/png')),
 expires_on date,
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
 reason varchar(300),
 version integer NOT NULL DEFAULT 1,
 consent_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 reviewed_by uuid REFERENCES users(id),
 reviewed_at timestamptz,
 CHECK ((kind IN ('VEHICLE_FRONT','VEHICLE_SIDE','SOAT')) = (vehicle_id IS NOT NULL)),
 CHECK (kind NOT IN ('LICENSE_FRONT','LICENSE_BACK','SOAT') OR expires_on IS NOT NULL),
 CHECK (octet_length(ciphertext) BETWEEN 1 AND 1048576)
);
CREATE UNIQUE INDEX IF NOT EXISTS verification_person_kind ON verification_documents(owner_id,kind) WHERE vehicle_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS verification_vehicle_kind ON verification_documents(vehicle_id,kind) WHERE vehicle_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS verification_review_status ON verification_documents(status,updated_at);
CREATE OR REPLACE FUNCTION vamos_identity_ready(person uuid, day date) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT count(*)=3 FROM verification_documents WHERE owner_id=person AND vehicle_id IS NULL
 AND kind IN ('CI_FRONT','CI_BACK','SELFIE') AND status='APPROVED' AND (expires_on IS NULL OR expires_on>=day)
$$;
CREATE OR REPLACE FUNCTION vamos_documents_ready(person uuid, car uuid, day date) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT vamos_identity_ready(person,day)
 AND (SELECT count(*)=2 FROM verification_documents WHERE owner_id=person AND vehicle_id IS NULL
 AND kind IN ('LICENSE_FRONT','LICENSE_BACK') AND status='APPROVED' AND expires_on>=day)
 AND (SELECT count(*)=3 FROM verification_documents WHERE owner_id=person AND vehicle_id=car
 AND kind IN ('VEHICLE_FRONT','VEHICLE_SIDE','SOAT') AND status='APPROVED' AND (expires_on IS NULL OR expires_on>=day))
$$;
COMMIT;

BEGIN;
CREATE TABLE IF NOT EXISTS display_photos (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL REFERENCES users(id),
 vehicle_id uuid REFERENCES vehicles(id),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 1048576),
 iv bytea NOT NULL, tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK(mime IN ('image/jpeg','image/png')),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS display_profile_unique ON display_photos(owner_id) WHERE vehicle_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS display_vehicle_unique ON display_photos(vehicle_id) WHERE vehicle_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS profile_photo_submissions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL UNIQUE REFERENCES users(id),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 1048576),
 iv bytea NOT NULL, tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK(mime IN ('image/jpeg','image/png')),
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED')),
 reason varchar(300), version integer NOT NULL DEFAULT 1,
 reviewed_by uuid REFERENCES users(id), reviewed_at timestamptz,
 submitted_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS profile_photo_review_idx ON profile_photo_submissions(status,updated_at DESC);
COMMIT;

BEGIN;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolution_detail varchar(2000);
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolved_at timestamptz;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolved_by uuid REFERENCES users(id);
CREATE TABLE IF NOT EXISTS push_devices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES users(id),
 token text UNIQUE NOT NULL,
 binding uuid NOT NULL DEFAULT gen_random_uuid(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS push_devices_user_idx ON push_devices(user_id);
CREATE TABLE IF NOT EXISTS push_deliveries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 notification_id uuid NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
 device_id uuid NOT NULL REFERENCES push_devices(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id),
 binding uuid NOT NULL,
 attempts integer NOT NULL DEFAULT 0,
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','SENT','EXPIRED','FAILED')),
 next_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL,
 last_error varchar(80),
 UNIQUE(notification_id,device_id)
);
CREATE INDEX IF NOT EXISTS push_pending_idx ON push_deliveries(next_at) WHERE status='PENDING';
CREATE OR REPLACE FUNCTION queue_vamos_push() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO push_deliveries(notification_id,device_id,user_id,binding,expires_at)
 SELECT NEW.id,d.id,NEW.user_id,d.binding,now()+CASE WHEN NEW.type='ROUTE_DEPARTED' THEN interval '15 minutes' ELSE interval '24 hours' END
 FROM push_devices d WHERE d.user_id=NEW.user_id ON CONFLICT DO NOTHING;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS vamos_push_after_notification ON notifications;
CREATE TRIGGER vamos_push_after_notification AFTER INSERT ON notifications FOR EACH ROW EXECUTE FUNCTION queue_vamos_push();
COMMIT;

BEGIN;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS route_departed_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_code varchar(6) NOT NULL DEFAULT lpad(floor(random()*1000000)::int::text,6,'0');
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_verified_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_failures integer NOT NULL DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_locked_until timestamptz;
COMMIT;

BEGIN;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS tracking_enabled boolean NOT NULL DEFAULT false;
CREATE TABLE IF NOT EXISTS trip_live_positions (
 trip_id uuid PRIMARY KEY REFERENCES trips(id) ON DELETE CASCADE,
 latitude double precision NOT NULL CHECK(latitude BETWEEN -90 AND 90),
 longitude double precision NOT NULL CHECK(longitude BETWEEN -180 AND 180),
 accuracy double precision NOT NULL CHECK(accuracy BETWEEN 0 AND 1000),
 recorded_at timestamptz NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS trip_share_links (
 booking_id uuid PRIMARY KEY REFERENCES bookings(id) ON DELETE CASCADE,
 token_hash text UNIQUE NOT NULL,
 expires_at timestamptz NOT NULL
);
CREATE OR REPLACE FUNCTION close_vamos_tracking() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.status IN ('COMPLETED','CANCELLED') THEN
  NEW.tracking_enabled=false;
  DELETE FROM trip_live_positions WHERE trip_id=NEW.id;
  DELETE FROM trip_share_links WHERE booking_id IN (SELECT id FROM bookings WHERE trip_id=NEW.id);
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS close_vamos_tracking ON trips;
CREATE TRIGGER close_vamos_tracking BEFORE UPDATE OF status ON trips FOR EACH ROW EXECUTE FUNCTION close_vamos_tracking();
COMMIT;

-- Preferencia de uso; no altera permisos administrativos ni aprobaciones.
ALTER TABLE users ADD COLUMN IF NOT EXISTS usage_mode varchar(12) NOT NULL DEFAULT 'PASSENGER' CHECK (usage_mode IN ('PASSENGER','DRIVER'));
UPDATE users SET usage_mode='DRIVER' WHERE EXISTS(SELECT 1 FROM vehicles v WHERE v.owner_id=users.id);
CREATE TABLE IF NOT EXISTS payment_qrs (
 owner_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 ciphertext bytea NOT NULL, iv bytea NOT NULL, tag bytea NOT NULL, mime varchar(30) NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_method varchar(8) NOT NULL DEFAULT 'CASH' CHECK(payment_method IN ('CASH','QR'));
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_confirmed_at timestamptz;

CREATE TABLE IF NOT EXISTS communities (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES users(id),
 name varchar(80) NOT NULL, description varchar(500) NOT NULL DEFAULT '',
 category varchar(20) NOT NULL CHECK(category IN ('GENERAL','WOMEN','COMPANY','NEIGHBORHOOD','RESIDENTIAL','SCHOOL')),
 invite_code varchar(32) NOT NULL UNIQUE,
 approval_status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK(approval_status IN ('PENDING','APPROVED','REJECTED')),
 reviewed_at timestamptz, reviewed_by uuid REFERENCES users(id), rejection_reason varchar(500),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS community_members (
 community_id uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id), status varchar(12) NOT NULL CHECK(status IN ('PENDING','APPROVED','REJECTED')),
 role varchar(12) NOT NULL DEFAULT 'MEMBER' CHECK(role IN ('MEMBER','ADMIN')),
 request_reason varchar(1000), organization_location varchar(200), job_title varchar(120),
 reviewed_at timestamptz, reviewed_by uuid REFERENCES users(id), review_note varchar(500),
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(community_id,user_id)
);
ALTER TABLE trips ADD COLUMN IF NOT EXISTS community_id uuid REFERENCES communities(id);
CREATE INDEX IF NOT EXISTS trips_community_idx ON trips(community_id,departure_at);
CREATE INDEX IF NOT EXISTS community_members_user_idx ON community_members(user_id,status);
CREATE INDEX IF NOT EXISTS community_members_review_idx ON community_members(status,created_at);
CREATE INDEX IF NOT EXISTS communities_approval_idx ON communities(approval_status,created_at);
CREATE OR REPLACE FUNCTION vamos_community_access(cid uuid,uid uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT cid IS NULL OR EXISTS(SELECT 1 FROM community_members m JOIN communities c ON c.id=m.community_id JOIN users u ON u.id=c.owner_id
 WHERE m.community_id=cid AND m.user_id=uid AND m.status='APPROVED' AND c.approval_status='APPROVED' AND u.status='ACTIVE');
$$;
-- Reingreso escalonado y salida voluntaria de comunidades (migración 020)
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS rejection_count integer NOT NULL DEFAULT 0;
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS retry_at timestamptz;
ALTER TABLE community_members DROP CONSTRAINT IF EXISTS community_members_status_check;
ALTER TABLE community_members ADD CONSTRAINT community_members_status_check CHECK(status IN ('PENDING','APPROVED','REJECTED','LEFT','REMOVED'));
CREATE INDEX IF NOT EXISTS community_members_retry_idx ON community_members(user_id,community_id,status,retry_at);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_origin geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_destination geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_route geography(LineString,4326);
CREATE INDEX IF NOT EXISTS bookings_passenger_route_idx ON bookings USING gist(passenger_route);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS accepted_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS rejected_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS no_show_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS completed_at timestamptz;
CREATE INDEX IF NOT EXISTS bookings_ledger_idx ON bookings(COALESCE(completed_at,encounter_verified_at,accepted_at,created_at) DESC) WHERE accepted_at IS NOT NULL;
