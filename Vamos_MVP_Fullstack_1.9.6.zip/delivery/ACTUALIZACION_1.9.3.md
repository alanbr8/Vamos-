# Vamos!! 1.9.3 — reingreso y salida de comunidades

- Primer rechazo: permite volver a solicitar después de 3 días.
- Segundo rechazo: permite volver a solicitar después de 7 días.
- Tercer rechazo: bloquea definitivamente nuevas solicitudes a esa comunidad.
- La salida voluntaria y el retiro de un miembro no suman rechazos.
- Los miembros pueden salir si no tienen viajes ni reservas activas.
- El administrador principal puede transferir la comunidad a un miembro aprobado y luego salir.
- Se conserva el historial para auditoría.

## Base de datos

Ejecutar `database/migrations/020_community_reentry_and_leave.sql` en Neon antes de desplegar la API.

## Despliegue

Subir `Vamos_MVP_Fullstack_1.9.3.zip` a la raíz de GitHub y actualizar los comandos y workflows para utilizar ese nombre.
