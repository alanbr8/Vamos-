# Vamos!! 1.9.4 — mapas coordinados y foto del vehículo

- El mapa del recorrido muestra como información adicional únicamente los kilómetros.
- Se omiten duración estimada, coordenadas y textos técnicos; se conserva la atribución cartográfica obligatoria.
- Para publicar un viaje se exige una foto visible del vehículo.
- Las fotos privadas de verificación nunca se utilizan como fotografía pública.
- La gestión del conductor presenta un solo mapa con la ruta del conductor y las rutas de los pasajeros.
- El mapa identifica el Punto Vamos! y el punto de bajada de cada pasajero.
- Incluye íntegramente las mejoras de comunidades de la versión 1.9.3.

Ejecutar primero las migraciones `020_community_reentry_and_leave.sql` y `021_passenger_route_and_vehicle_photo.sql` en Neon.
