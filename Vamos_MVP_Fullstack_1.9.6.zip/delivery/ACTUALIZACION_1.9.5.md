# Vamos!! 1.9.5 — actualización consolidada

Esta versión reemplaza las entregas 1.9.3 y 1.9.4. No subas esos paquetes por separado.

Incluye:

- reingreso escalonado a comunidades (3 días, 7 días y bloqueo indefinido);
- salida voluntaria, retiro con causa y traspaso de administrador principal;
- mapa único con las rutas del conductor y del pasajero;
- fotografía pública del vehículo obligatoria para publicar;
- compatibilidad con solicitudes creadas por versiones anteriores;
- bitácora ATT con fechas de aceptación, encuentro, cancelación y finalización;
- exportación CSV desde el panel de operaciones;
- correcciones de listados, doble rechazo y pruebas de compilación.

## Orden obligatorio

1. Ejecutar una sola vez `MIGRACION_1.9.5_NEON.sql` en Neon SQL Editor. Es repetible y no borra datos.
2. Subir a GitHub `Vamos_MVP_Fullstack_1.9.5.zip`, `Dockerfile`, `render-web-build.sh` y los workflows suministrados.
3. En Render, desplegar primero **Vamos-api** y comprobar `/health`.
4. Desplegar **vamos-web**.
5. Ejecutar **Compilar Vamos Android** y descargar el APK nuevo.

No reinicies la base de datos antes de comprobar esta versión. El borrado de pruebas debe hacerse después de respaldar la bitácora y justo antes del lanzamiento general.
