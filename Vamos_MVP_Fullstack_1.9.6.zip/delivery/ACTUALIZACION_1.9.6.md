# Vamos!! 1.9.6 — preparación para prueba piloto

## Cambios

- El pasajero debe registrar partida y punto de bajada antes de solicitar un asiento.
- Puede elegir **Me bajo en el destino final del conductor** o marcar otro punto.
- La API valida que la ruta del pasajero coincida con ambos puntos.
- La cancelación de un viaje o reserva exige un motivo de 5 a 300 caracteres.
- Al finalizar, el pasajero confirma que llegó a su punto de bajada.
- Se conservan los horarios existentes de aceptación, encuentro y finalización para la bitácora ATT.

## Orden de despliegue

1. En Neon, confirmar que estás en `production` (`Default`) y en la base `neondb`.
2. Ejecutar `MIGRACION_1.9.6_NEON.sql`. Es repetible y no borra información.
3. Subir a la raíz de GitHub `Vamos_MVP_Fullstack_1.9.6.zip`, `Dockerfile` y `render-web-build.sh`.
4. Reemplazar `.github/workflows/main.yml`, `.github/workflows/web.yml` y, si corresponde, `.github/workflows/ios.yml` con los archivos de `delivery`.
5. Esperar el despliegue exitoso de `Vamos-api` y después el de `vamos-web` en Render.
6. Ejecutar **Compilar Vamos Android** en GitHub Actions e instalar el APK nuevo en los teléfonos piloto.

## Prueba mínima antes de invitar usuarios

1. Conductor: publicar un viaje.
2. Pasajero: elegir partida, bajada y Punto Vamos; solicitar asiento.
3. Conductor: aceptar y verificar que el mapa muestre ambas rutas.
4. Pasajero: cancelar una reserva de prueba indicando motivo y comprobar la liberación del cupo.
5. Repetir el viaje, confirmar encuentro, finalizar y confirmar llegada como pasajero.
6. Revisar que la bitácora administrativa conserve los estados y horarios.

No ejecutar nuevamente el script de reinicio de datos: el reinicio piloto ya fue realizado.
