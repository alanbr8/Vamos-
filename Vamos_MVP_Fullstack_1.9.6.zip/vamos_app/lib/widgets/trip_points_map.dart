import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class TripPointsMap extends StatelessWidget {
  const TripPointsMap({super.key,required this.data,this.meeting,this.passengers=const []});
  final Map<String,dynamic> data;
  final Map<String,dynamic>? meeting;
  final List<dynamic> passengers;

  LatLng? point(Map? source,String prefix){
    if(source==null)return null;
    final lat=double.tryParse('${source['${prefix}Lat']}'),lng=double.tryParse('${source['${prefix}Lng']}');
    if(lat==null||lng==null||!lat.isFinite||!lng.isFinite||lat.abs()>90||lng.abs()>180)return null;
    return LatLng(lat,lng);
  }
  List<LatLng> route(dynamic value){
    final result=<LatLng>[];
    if(value is List)for(final p in value){if(p is List&&p.length>=2&&p[0] is num&&p[1] is num){final lat=(p[1] as num).toDouble(),lng=(p[0] as num).toDouble();if(lat.isFinite&&lng.isFinite&&lat.abs()<=90&&lng.abs()<=180)result.add(LatLng(lat,lng));}}
    return result;
  }

  @override
  Widget build(BuildContext context){
    final start=point(data,'origin'),end=point(data,'destination'),pick=point(meeting??data,'meeting'),live=point(data,'driver');
    final driverRoute=route(data['route']);
    final allPoints=<LatLng>[if(live!=null)live,...driverRoute,if(start!=null)start,if(end!=null)end,if(pick!=null)pick];
    final markers=<Marker>[],lines=<Polyline>[if(driverRoute.length>=2)Polyline(points:driverRoute,color:Colors.blue.shade700,strokeWidth:5)];
    void add(LatLng? p,String label,Color color){if(p!=null){allPoints.add(p);markers.add(Marker(point:p,width:125,height:64,child:Column(children:[Container(padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),color:Colors.white,child:Text(label,style:TextStyle(color:color,fontWeight:FontWeight.bold))),Icon(Icons.location_on,color:color,size:32)])));}}
    add(live,data['stale']==true?'Última posición':'Conductor',data['stale']==true?Colors.grey:Colors.blue);
    add(start,'Partida',Colors.green.shade800);add(end,'Destino',Colors.red.shade800);add(pick,'Punto Vamos!',Colors.blue.shade800);
    for(var i=0;i<passengers.length;i++){
      final p=passengers[i] as Map,name=(p['passenger']??'Pasajero ${i+1}').toString(),passengerRoute=route(p['passengerRoute']);
      if(passengerRoute.length>=2){lines.add(Polyline(points:passengerRoute,color:Colors.orange.shade700,strokeWidth:4));allPoints.addAll(passengerRoute);}
      add(point(p,'meeting'),'Punto Vamos! · $name',Colors.blue.shade800);
      add(point(p,'passengerDestination'),'Punto bajada · $name',Colors.purple.shade700);
    }
    if(allPoints.isEmpty)return const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('No hay coordenadas disponibles.')));
    final distinct=allPoints.map((p)=>'${p.latitude},${p.longitude}').toSet().length,estimate=data['routeEstimate'] is Map?data['routeEstimate'] as Map:null;
    final km=(double.tryParse('${estimate?['distanceMeters']}')??0)/1000;
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(passengers.isEmpty?'Recorrido':'Ruta del conductor y pasajeros',style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:8),SizedBox(height:passengers.isEmpty?260:360,child:FlutterMap(
        key:ValueKey(allPoints.map((p)=>'${p.latitude},${p.longitude}').join('|')),
        options:MapOptions(initialCenter:allPoints.first,initialZoom:15,initialCameraFit:distinct>1?CameraFit.bounds(bounds:LatLngBounds.fromPoints(allPoints),padding:const EdgeInsets.all(46),maxZoom:16):null),
        children:[TileLayer(urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',userAgentPackageName:'com.vamoscarpool.app'),if(lines.isNotEmpty)PolylineLayer(polylines:lines),MarkerLayer(markers:markers),const RichAttributionWidget(attributions:[TextSourceAttribution('OpenStreetMap')])],
      )),
      if(km>0)Text('${km.toStringAsFixed(1)} km',style:const TextStyle(fontWeight:FontWeight.bold)),
      if(passengers.isNotEmpty)const Padding(padding:EdgeInsets.only(top:6),child:Text('Azul: conductor · Naranja: pasajero · Marcadores: Punto Vamos! y punto de bajada.')),
    ])));
  }
}
