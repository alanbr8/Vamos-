import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/api_client.dart';
import '../trips/search_trip_screen.dart';
import '../trips/publish_trip_screen.dart';

const communityCategories={'GENERAL':'General','WOMEN':'Mujeres','COMPANY':'Empresa','NEIGHBORHOOD':'Zona o barrio','RESIDENTIAL':'Urbanización','SCHOOL':'Familias de colegio'};
String memberStatus(dynamic s)=>{'PENDING':'En revisión','APPROVED':'Miembro aprobado','REJECTED':'No aprobado','LEFT':'Saliste de la comunidad','REMOVED':'Retirado de la comunidad'}[s]??'$s';
String communityStatus(dynamic s)=>{'PENDING':'Creación pendiente','APPROVED':'Comunidad aprobada','REJECTED':'Creación rechazada'}[s]??'$s';
class CommunitiesScreen extends StatefulWidget {
 const CommunitiesScreen({super.key});
 @override State<CommunitiesScreen> createState()=>_CommunitiesScreenState();
}
class _CommunitiesScreenState extends State<CommunitiesScreen>{
 final search=TextEditingController();List<dynamic> groups=[],results=[];bool busy=false,searching=false;String? error;
 @override void initState(){super.initState();load();}
 Future<void> load()async{setState(()=>busy=true);try{final r=await ApiClient.instance.communities();if(mounted)setState((){groups=r;error=null;});}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> form(bool create)async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>CommunityForm(create:create)));if(mounted)await load();}
 Future<void> find()async{final q=search.text.trim();if(q.length<2){setState(()=>error='Escribe al menos 2 caracteres.');return;}setState(()=>searching=true);try{final r=await ApiClient.instance.communities('/search?q=${Uri.encodeQueryComponent(q)}');if(mounted)setState((){results=r;error=null;});}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>searching=false);}}
 @override void dispose(){search.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Comunidades Vamos!!'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
 const Text('Comparte viajes con tu comunidad',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
 const Text('Busca una comunidad por nombre o ingresa con un código. Toda solicitud queda sujeta a aprobación.'),
 TextField(controller:search,textInputAction:TextInputAction.search,onSubmitted:(_)=>find(),decoration:InputDecoration(labelText:'Buscar comunidad por nombre',prefixIcon:const Icon(Icons.search),suffixIcon:IconButton(onPressed:searching?null:find,icon:const Icon(Icons.arrow_forward)))),
 if(searching)const LinearProgressIndicator(),
 ...results.map((g){final rejected=g['membershipStatus']=='REJECTED',blocked=rejected&&(int.tryParse('${g['rejectionCount']}')??0)>=3,canRequest=g['membershipStatus']==null||(rejected&&!blocked);final retry=g['retryAt']==null?'':DateTime.tryParse(g['retryAt'].toString())?.toLocal().toString().substring(0,16)??'';return Card(child:ListTile(title:Text(g['name']),subtitle:Text('${communityCategories[g['category']]} · ${g['description']??''}${blocked?'\nIngreso bloqueado después de tres rechazos.':rejected?'\nPodrás solicitar nuevamente${retry.isEmpty?' cuando termine el plazo':' desde $retry'}.':''}'),trailing:canRequest?const Icon(Icons.group_add):Text(blocked?'Bloqueado':memberStatus(g['membershipStatus'])),onTap:!canRequest?null:()async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>CommunityRequestScreen(community:g)));if(mounted){await load();await find();}}));}),
 FilledButton.icon(onPressed:busy?null:()=>form(false),icon:const Icon(Icons.group_add),label:const Text('INGRESAR CON CÓDIGO')),
 OutlinedButton(onPressed:busy?null:()=>form(true),child:const Text('CREAR COMUNIDAD')),
 if(busy)const LinearProgressIndicator(),if(error!=null)Text(error!),
 if(!busy&&groups.isEmpty)const Text('Aún no tienes comunidades.'),
 ...groups.map((g)=>Card(child:ListTile(title:Text(g['name']),subtitle:Text('${communityCategories[g['category']]} · ${communityStatus(g['communityStatus'])}${g['communityStatus']=='APPROVED'?' · ${memberStatus(g['status'])}':''}${g['admin']==true?' · Administrador':''}${g['status']=='REJECTED'&&(g['reviewNote']??'').toString().isNotEmpty?'\nCausa: ${g['reviewNote']}':''}'),trailing:const Icon(Icons.chevron_right),onTap:()async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>CommunityDetail(id:g['id'])));if(mounted)await load();}))),
 ]));
}
class CommunityRequestScreen extends StatefulWidget{
 const CommunityRequestScreen({super.key,required this.community});final Map community;
 @override State<CommunityRequestScreen> createState()=>_CommunityRequestScreenState();
}
class _CommunityRequestScreenState extends State<CommunityRequestScreen>{
 final reason=TextEditingController(),location=TextEditingController(),job=TextEditingController();bool busy=false;String? error;
 @override void dispose(){reason.dispose();location.dispose();job.dispose();super.dispose();}
 Future<void> send()async{if(reason.text.trim().length<20){setState(()=>error='Explica en al menos 20 caracteres por qué deseas ingresar.');return;}setState(()=>busy=true);try{await ApiClient.instance.community('/${widget.community['id']}/request',method:'POST',body:{'reason':reason.text.trim(),'organizationLocation':location.text.trim(),'jobTitle':job.text.trim()});if(mounted)Navigator.pop(context);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('Solicitar ingreso')),body:ListView(padding:const EdgeInsets.all(20),children:[
  Text(widget.community['name']??'',style:Theme.of(context).textTheme.headlineSmall),Text(widget.community['description']??''),
  TextField(controller:reason,maxLength:1000,minLines:3,maxLines:5,decoration:const InputDecoration(labelText:'¿Por qué deseas ingresar?')),
  TextField(controller:location,maxLength:200,decoration:const InputDecoration(labelText:'Empresa o ubicación de trabajo (si corresponde)')),
  TextField(controller:job,maxLength:120,decoration:const InputDecoration(labelText:'Cargo o función (si corresponde)')),
  if(widget.community['category']=='COMPANY')const Text('Para esta comunidad la ubicación y el cargo son obligatorios.'),
  if(error!=null)Text(error!),FilledButton(onPressed:busy?null:send,child:Text(busy?'ENVIANDO…':'SOLICITAR INGRESO')),
 ]));
}
class CommunityForm extends StatefulWidget {
 const CommunityForm({super.key,required this.create});final bool create;
 @override State<CommunityForm> createState()=>_CommunityFormState();
}
class _CommunityFormState extends State<CommunityForm>{
 final name=TextEditingController(),description=TextEditingController(),reason=TextEditingController(),location=TextEditingController(),jobTitle=TextEditingController();String category='GENERAL';bool busy=false;String? error;
 @override void dispose(){name.dispose();description.dispose();reason.dispose();location.dispose();jobTitle.dispose();super.dispose();}
 Future<void> save()async{
  if(!widget.create&&reason.text.trim().length<20){setState(()=>error='Explica en al menos 20 caracteres por qué deseas ingresar.');return;}
  setState(()=>busy=true);try{await ApiClient.instance.community(widget.create?'':'/join',method:'POST',body:widget.create?{'name':name.text.trim(),'description':description.text.trim(),'category':category}:{'code':name.text.trim().toLowerCase(),'reason':reason.text.trim(),'organizationLocation':location.text.trim(),'jobTitle':jobTitle.text.trim()});if(mounted)Navigator.pop(context);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.create?'Crear comunidad':'Ingresar con código')),body:ListView(padding:const EdgeInsets.all(20),children:[
 TextField(controller:name,maxLength:widget.create?80:32,decoration:InputDecoration(labelText:widget.create?'Nombre de la comunidad':'Código de invitación')),
 if(widget.create)...[
 DropdownButtonFormField<String>(initialValue:category,items:communityCategories.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:busy?null:(v)=>setState(()=>category=v??'GENERAL')),
 TextField(controller:description,maxLength:500,maxLines:3,decoration:const InputDecoration(labelText:'Descripción y condiciones de ingreso')),
 const Text('Como administrador debes revisar las solicitudes y la pertenencia al grupo. El nombre o la categoría no acreditan una afiliación oficial.'),
 if(category=='WOMEN')const Text('Comunidad de mujeres: el administrador revisa el ingreso de conductoras y pasajeras. Vamos!! no verifica el género automáticamente.'),
 if(category=='SCHOOL')const Text('Para cuentas de padres o tutores adultos. No crea cuentas de menores ni habilita viajes de niños sin acompañamiento.'),
 ] else ...[
 TextField(controller:reason,maxLength:1000,minLines:3,maxLines:5,decoration:const InputDecoration(labelText:'¿Por qué deseas ingresar?',hintText:'Explica tu relación con la comunidad y el motivo de tu solicitud')),
 TextField(controller:location,maxLength:200,decoration:const InputDecoration(labelText:'Empresa o ubicación de trabajo (si corresponde)',hintText:'Ej.: Planta Norte, Santa Cruz')),
 TextField(controller:jobTitle,maxLength:120,decoration:const InputDecoration(labelText:'Cargo o función (si corresponde)',hintText:'Ej.: Analista de laboratorio')),
 const Text('En comunidades de empresa, la ubicación y el cargo son obligatorios.'),
 ],
 if(error!=null)Text(error!),FilledButton(onPressed:busy?null:save,child:Text(busy?'GUARDANDO…':widget.create?'CREAR':'SOLICITAR INGRESO')),
 ]));
}
class CommunityDetail extends StatefulWidget{
 const CommunityDetail({super.key,required this.id});final String id;
 @override State<CommunityDetail> createState()=>_CommunityDetailState();
}
class _CommunityDetailState extends State<CommunityDetail>{
 Map<String,dynamic>? group;List<dynamic> members=[],trips=[];bool busy=false;String? error;
 @override void initState(){super.initState();load();}
 Future<void> load()async{
 setState(()=>busy=true);
 try{
  final g=await ApiClient.instance.community('/${widget.id}');
  final active=g['communityStatus']=='APPROVED';
  final m=active&&g['admin']==true?await ApiClient.instance.communities('/${widget.id}/members'):<dynamic>[];
  final t=active&&g['status']=='APPROVED'?await ApiClient.instance.communities('/${widget.id}/trips'):<dynamic>[];
  if(mounted)setState((){group=g;members=m;trips=t;error=null;});
 }catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> action(String suffix,{Map<String,dynamic>? body})async{
 setState(()=>busy=true);try{await ApiClient.instance.community('/${widget.id}/$suffix',method:'POST',body:body);if(mounted)await load();}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> rejectOrRemove(Map member)async{
  final approved=member['status']=='APPROVED',controller=TextEditingController();String? validation;
  final reason=await showDialog<String>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(context,setDialogState)=>AlertDialog(
   title:Text(approved?'Retirar de la comunidad':'Rechazar solicitud'),
   content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(approved?'${member['name']} perderá el acceso a los nuevos viajes de esta comunidad.':'Explica por qué no se aprueba el ingreso de ${member['name']}.'),TextField(controller:controller,maxLength:500,minLines:2,maxLines:4,autofocus:true,decoration:InputDecoration(labelText:'Causa obligatoria',errorText:validation))]),
   actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext),child:const Text('Cancelar')),FilledButton(onPressed:(){final value=controller.text.trim();if(value.length<5){setDialogState(()=>validation='Escribe al menos 5 caracteres.');return;}Navigator.pop(dialogContext,value);},child:Text(approved?'RETIRAR':'RECHAZAR'))]
  )));controller.dispose();if(reason!=null&&mounted)await action('members/${member['id']}',body:{'status':'REJECTED','note':reason});
 }
 Future<void> leaveCommunity()async{
  final controller=TextEditingController();
  final confirmed=await showDialog<bool>(context:context,builder:(dialogContext)=>AlertDialog(title:const Text('Salir de la comunidad'),content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Perderás el acceso a los viajes de esta comunidad. Si tienes viajes o reservas activos, primero deberás resolverlos.'),TextField(controller:controller,maxLength:500,maxLines:3,decoration:const InputDecoration(labelText:'Motivo (opcional)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),child:const Text('SALIR'))]));
  final note=controller.text.trim();controller.dispose();
  if(confirmed==true&&mounted){setState(()=>busy=true);try{await ApiClient.instance.community('/${widget.id}/leave',method:'POST',body:{'note':note});if(mounted)Navigator.pop(context);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(group?['name']??'Comunidad'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
 if(busy)const LinearProgressIndicator(),if(error!=null)Text(error!),
 if(group!=null)...[
 Text(group!['description']??''),Text(communityStatus(group!['communityStatus']),style:const TextStyle(fontWeight:FontWeight.bold)),
 if(group!['communityStatus']=='PENDING')const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('La solicitud fue enviada al equipo de operaciones. El código de invitación y los viajes se habilitarán después de su aprobación.'))),
 if(group!['communityStatus']=='REJECTED')Card(child:Padding(padding:const EdgeInsets.all(16),child:Text('La creación no fue aprobada.${(group!['rejectionReason']??'').toString().isNotEmpty?' Motivo: ${group!['rejectionReason']}':''}'))),
 if(group!['communityStatus']=='APPROVED')Text(memberStatus(group!['status'])),
 if(group!['status']=='REJECTED'&&(group!['reviewNote']??'').toString().isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(16),child:Text('Causa: ${group!['reviewNote']}'))),
 if(group!['communityStatus']=='APPROVED'&&group!['admin']==true)...[
 const Text('Código de invitación (ingreso sujeto a aprobación):'),SelectableText(group!['code']??''),
 TextButton(onPressed:()=>Clipboard.setData(ClipboardData(text:group!['code']??'')),child:const Text('COPIAR CÓDIGO')),
 FilledButton.icon(onPressed:()async{final text='Te invito a la comunidad ${group!['name']} en Vamos!!. Abre Comunidades, selecciona “Ingresar con código” y usa: ${group!['code']}';try{await SharePlus.instance.share(ShareParams(text:text,subject:'Invitación a ${group!['name']} en Vamos!!'));}catch(_){await Clipboard.setData(ClipboardData(text:text));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Invitación copiada. Puedes pegarla en WhatsApp, correo o mensajería.')));}},icon:const Icon(Icons.share),label:const Text('COMPARTIR INVITACIÓN')),
 TextButton(onPressed:busy?null:()async{final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Renovar el código?'),content:const Text('El código anterior dejará de aceptar nuevas solicitudes. Los miembros actuales conservan su acceso.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Renovar'))]));if(yes==true&&mounted)await action('rotate');},child:const Text('RENOVAR CÓDIGO')),
 const Text('Miembros y solicitudes',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 ...members.map((m){
  final details=<String>[memberStatus(m['status']),if(m['owner']==true)'Administrador principal' else if(m['role']=='ADMIN')'Administrador',if((m['requestReason']??'').toString().isNotEmpty)'Motivo: ${m['requestReason']}',if((m['organizationLocation']??'').toString().isNotEmpty)'Ubicación: ${m['organizationLocation']}',if((m['jobTitle']??'').toString().isNotEmpty)'Cargo: ${m['jobTitle']}'];
  return Card(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[ListTile(title:Text('${m['name']} ${m['surname']}'),subtitle:Text(details.join('\n'))),
   if(m['self']!=true)Wrap(children:[
    if(m['status']!='APPROVED')TextButton(onPressed:busy?null:()=>action('members/${m['id']}',body:{'status':'APPROVED'}),child:const Text('Aprobar')),
    if(m['status']=='APPROVED'&&group!['owner']==true&&m['owner']!=true)TextButton(onPressed:busy?null:()=>action('members/${m['id']}/role',body:{'role':m['role']=='ADMIN'?'MEMBER':'ADMIN'}),child:Text(m['role']=='ADMIN'?'QUITAR COMO ADMINISTRADOR':'NOMBRAR ADMINISTRADOR')),
    if(m['status']=='APPROVED'&&group!['owner']==true&&m['owner']!=true)TextButton(onPressed:busy?null:()async{final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Transferir administración principal'),content:Text('${m['name']} pasará a ser responsable principal de la comunidad. Después podrás salir si lo deseas.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('TRANSFERIR'))]));if(yes==true&&mounted)await action('members/${m['id']}/transfer');},child:const Text('TRANSFERIR ADMINISTRACIÓN PRINCIPAL')),
    TextButton(onPressed:busy?null:()=>rejectOrRemove(m),child:Text(m['status']=='APPROVED'?'Retirar de la comunidad':'Rechazar solicitud'))
   ])
  ]));
 }),
 ],
 if(group!['communityStatus']=='APPROVED'&&group!['status']=='APPROVED')...[
 if(group!['owner']!=true)OutlinedButton.icon(onPressed:busy?null:leaveCommunity,icon:const Icon(Icons.logout),label:const Text('SALIR DE LA COMUNIDAD')),
 FilledButton.icon(onPressed:busy?null:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>PublishTripScreen(communityId:widget.id))),icon:const Icon(Icons.add_road),label:const Text('OFRECER A ESTA COMUNIDAD')),
 const Text('Viajes disponibles',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 const Text('Tus propias ofertas están en Mis viajes. Las reservas de la comunidad también se guardan allí.'),
 if(trips.isEmpty&&!busy)const Text('No hay ofertas disponibles de otros miembros.'),
 ...trips.map((t)=>Card(child:ListTile(title:Text('${t['origin']} → ${t['destination']}'),subtitle:Text('${DateTime.tryParse(t['departureAt'].toString())?.toLocal()} · Bs ${t['contribution']} · ${t['seats']} asientos'),onTap:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>MatchDetailScreen(fromCommunity:true,match:tripMatchFromApi(Map<String,dynamic>.from(t),''))))))),
 ],
 ],
 ]));
}
