import '../../widgets/trip_points_map.dart';
import '../../widgets/display_photo.dart';
import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../models/map_point.dart';
import '../../models/trip_match.dart';
import '../map/location_picker_screen.dart';
import '../../services/location_service.dart';
import '../../services/api_client.dart';

class SearchTripScreen extends StatefulWidget {
  const SearchTripScreen({super.key, this.savedSearch});
  final Map<String, dynamic>? savedSearch;

  @override
  State<SearchTripScreen> createState() => _SearchTripScreenState();
}

class _SearchTripScreenState extends State<SearchTripScreen> {
  final origin = TextEditingController();
  final destination = TextEditingController();
  DateTime date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 7, minute: 0);
  double flexibility = 30;
  bool searched = false;
  MapPoint? originPoint;
  MapPoint? destinationPoint;
  bool loading = false;
  String? searchError;
  List<TripMatch> liveMatches = [];

  bool saved = false;
  String? saveError;

  @override
  void initState() {
    super.initState();
    final record = widget.savedSearch;
    if (record != null) {
      final c = record['criteria'] as Map;
      origin.text = record['origin'].toString();
      destination.text = record['destination'].toString();
      originPoint = MapPoint(latitude: (c['originLat'] as num).toDouble(), longitude: (c['originLng'] as num).toDouble(), label: origin.text);
      destinationPoint = MapPoint(latitude: (c['destinationLat'] as num).toDouble(), longitude: (c['destinationLng'] as num).toDouble(), label: destination.text);
      final from = DateTime.parse(c['departureFrom'].toString()).toLocal();
      final to = DateTime.parse(c['departureTo'].toString()).toLocal();
      date = from.add(Duration(milliseconds: to.difference(from).inMilliseconds ~/ 2));
      time = TimeOfDay.fromDateTime(date);
      flexibility = to.difference(from).inMinutes / 2;
      saved = true;
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) search(); });
    }
  }

  @override
  void dispose() {
    origin.dispose();
    destination.dispose();
    super.dispose();
  }

  Future<void> search() async {
    if (origin.text.trim().isEmpty ||
        destination.text.trim().isEmpty ||
        originPoint == null ||
        destinationPoint == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ingresa y selecciona el origen y destino en el mapa'),
        ),
      );
      return;
    }
    setState(() {
      loading = true;
      searchError = null;
      liveMatches = [];
      saveError = null;
    });
    final center = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
    try {
      final criteria = <String, dynamic>{
        'originLat': originPoint!.latitude,
        'originLng': originPoint!.longitude,
        'destinationLat': destinationPoint!.latitude,
        'destinationLng': destinationPoint!.longitude,
        'departureFrom': center
            .subtract(Duration(minutes: flexibility.round()))
            .toUtc()
            .toIso8601String(),
        'departureTo': center
            .add(Duration(minutes: flexibility.round()))
            .toUtc()
            .toIso8601String(),
        'maxDistanceMeters': 1500,
      };
      if (!saved) {
        try {
          await ApiClient.instance.saveSearch({...criteria, 'originLabel': origin.text.trim(), 'destinationLabel': destination.text.trim()});
          saved = true;
        } on ApiException catch (error) {
          saveError = 'No se guardó la alerta: ${error.message}';
        }
      }
      final response = await ApiClient.instance.searchTrips(criteria);
      if (!mounted) return;
      liveMatches = response
          .map(
            (item) => tripMatchFromApi(
              item as Map<String, dynamic>,
              time.format(context),
            ),
          )
          .toList();
    } on ApiException catch (error) {
      searchError = error.message;
    } finally {
      if (mounted)
        setState(() {
          loading = false;
          searched = true;
        });
    }
  }

  Future<void> pickPoint(bool isOrigin) async {
    final point = await Navigator.push<MapPoint>(
      context,
      MaterialPageRoute(
        builder: (_) => LocationPickerScreen(
          title: isOrigin ? '¿Dónde te recogemos?' : 'Seleccionar destino',
          initialPoint: isOrigin ? originPoint : destinationPoint,
          routePoints: [if (!isOrigin && originPoint != null) originPoint!],
        ),
      ),
    );
    if (point == null || !mounted) return;
    setState(() {
      if (isOrigin) {
        originPoint = point;
        if (origin.text.trim().isEmpty) origin.text = point.label;
      } else {
        destinationPoint = point;
        if (destination.text.trim().isEmpty) destination.text = point.label;
      }
    });
  }

  Future<void> pickDate() async {
    final value = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (value != null) setState(() => date = value);
  }

  Future<void> pickTime() async {
    final value = await showTimePicker(context: context, initialTime: time);
    if (value != null) setState(() => time = value);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(searched ? 'Viajes encontrados' : 'Buscar un viaje'),
    ),
    body: searched ? results() : form(),
  );

  Widget form() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text('¿A dónde vamos?', style: Theme.of(context).textTheme.headlineSmall),
      const Text('Guardaremos tu búsqueda en Mis viajes y te avisaremos en Notificaciones si aparece una ruta compatible. La búsqueda vence al terminar el horario elegido.'),
      const SizedBox(height: 22),
      TextField(
        controller: origin,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(
          labelText: '¿Dónde te recogemos?',
          hintText: 'Ej.: Av. Banzer, 5.º Anillo',
          prefixIcon: Icon(Icons.trip_origin),
        ),
      ),
      TextButton.icon(
        onPressed: () => pickPoint(true),
        icon: const Icon(Icons.map_outlined),
        label: Text(
          originPoint == null ? 'MARCAR ORIGEN EN EL MAPA' : 'CAMBIAR ORIGEN',
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: destination,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(
          labelText: '¿A dónde vas?',
          hintText: 'Ej.: Parque Industrial',
          prefixIcon: Icon(Icons.location_on_outlined),
        ),
      ),
      TextButton.icon(
        onPressed: () => pickPoint(false),
        icon: const Icon(Icons.map_outlined),
        label: Text(
          destinationPoint == null
              ? 'MARCAR DESTINO EN EL MAPA'
              : 'CAMBIAR DESTINO',
        ),
      ),
      const SizedBox(height: 14),
      Row(
        children: [
          Expanded(
            child: PickerCard(
              icon: Icons.calendar_today_outlined,
              label: 'Fecha',
              value: formatDate(date),
              onTap: pickDate,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: PickerCard(
              icon: Icons.schedule,
              label: 'Hora ideal',
              value: time.format(context),
              onTap: pickTime,
            ),
          ),
        ],
      ),
      const SizedBox(height: 20),
      Text('Flexibilidad: ± ${flexibility.round()} minutos'),
      Slider(
        min: 0,
        max: 90,
        divisions: 6,
        label: '${flexibility.round()} min',
        value: flexibility,
        onChanged: (value) => setState(() => flexibility = value),
      ),
      MapBox(
        label: originPoint == null || destinationPoint == null
            ? 'Selecciona ambos puntos para buscar'
            : 'Distancia directa: ${(LocationService.distanceMeters(originPoint!, destinationPoint!) / 1000).toStringAsFixed(1)} km',
      ),
      const SizedBox(height: 20),
      ElevatedButton.icon(
        onPressed: loading ? null : search,
        icon: const Icon(Icons.search),
        label: Text(loading ? 'BUSCANDO…' : 'BUSCAR VIAJES'),
      ),
    ],
  );

  Widget results() => Column(
    children: [
      if (saved) const Padding(padding: EdgeInsets.all(12), child: Text('Búsqueda guardada en Mis viajes. Las alertas se consultan dentro de la app.')),
      if (saveError != null) Padding(padding: const EdgeInsets.all(12), child: Text(saveError!)),
      if (searchError != null)
        MaterialBanner(
          content: Text(searchError!),
          actions: [
            TextButton(
              onPressed: loading ? null : search,
              child: const Text('REINTENTAR'),
            ),
          ],
        ),
      if (searchError == null && liveMatches.isEmpty)
        const Padding(
          padding: EdgeInsets.all(20),
          child: Text(
            'No encontramos viajes para esa fecha y esos puntos. Prueba otro horario.',
          ),
        ),
      Container(
        color: Colors.white,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const Icon(Icons.route, color: AppColors.green),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${origin.text.trim()} → ${destination.text.trim()}\n${formatDate(date)} · ${time.format(context)}',
              ),
            ),
            TextButton(
              onPressed: () => setState(() { searched = false; saved = false; }),
              child: const Text('Editar'),
            ),
          ],
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
        child: Row(
          children: [
            Text(
              '${liveMatches.length} coincidencias',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            const Icon(Icons.tune, size: 19),
            const Text(' Mejor ruta'),
          ],
        ),
      ),
      Expanded(
        child: ListView.separated(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 20),
          itemCount: liveMatches.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (_, index) => MatchCard(
            match: liveMatches[index],
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder:(_)=>MatchDetailScreen(match:liveMatches[index],passengerOrigin:originPoint,passengerDestination:destinationPoint),
              ),
            ),
          ),
        ),
      ),
    ],
  );
}

class PickerCard extends StatelessWidget {
  const PickerCard({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
    margin: EdgeInsets.zero,
    child: InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: AppColors.green),
            Text(label, style: const TextStyle(color: Colors.black54)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    ),
  );
}

class MapBox extends StatelessWidget {
  const MapBox({super.key, required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => Container(
    height: 180,
    decoration: BoxDecoration(
      color: const Color(0xFFE4F6EE),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.map_outlined, size: 54, color: AppColors.green),
        const SizedBox(height: 8),
        Text(label),
      ],
    ),
  );
}

class MatchCard extends StatelessWidget {
  const MatchCard({super.key, required this.match, required this.onTap});
  final TripMatch match;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
    child: InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                DisplayPhoto(id:match.driverId),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        match.driver,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      if(match.driverVerified)const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.verified,size:16,color:AppColors.green),SizedBox(width:4),Text('Usuario verificado',style:TextStyle(color:AppColors.green,fontSize:12,fontWeight:FontWeight.bold))]),
                      Text('★ ${match.rating} · ${match.trips} viajes'),
                    ],
                  ),
                ),
                Chip(
                  label: Text('${match.compatibility}%'),
                  backgroundColor: const Color(0xFFE4F6EE),
                  labelStyle: const TextStyle(
                    color: AppColors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const Divider(),
            InfoRow(icon: Icons.schedule, text: match.time),
            DisplayPhoto(id:match.vehicleId,vehicle:true,size:130),
            InfoRow(icon: Icons.directions_car_outlined, text: match.vehicle),
            if(match.vehicleVerified)const Align(alignment:Alignment.centerLeft,child:Chip(avatar:Icon(Icons.verified,size:16,color:AppColors.green),label:Text('Vehículo verificado'))),
            InfoRow(icon: Icons.place_outlined, text: match.meetingPoint),
            const SizedBox(height: 8),
            Row(
              children: [
                Text('${match.seats} asientos'),
                const Spacer(),
                Text(
                  'Bs ${match.price.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Icon(icon, size: 19, color: Colors.black54),
        const SizedBox(width: 8),
        Expanded(child: Text(text)),
      ],
    ),
  );
}

class MatchDetailScreen extends StatefulWidget {
  const MatchDetailScreen({super.key,required this.match,this.fromCommunity=false,this.passengerOrigin,this.passengerDestination});
  final bool fromCommunity;
  final TripMatch match;
  final MapPoint? passengerOrigin,passengerDestination;

  @override
  State<MatchDetailScreen> createState() => _MatchDetailScreenState();
}

class _MatchDetailScreenState extends State<MatchDetailScreen> {
  int requestedSeats = 1;
  MapPoint? meeting;
  MapPoint? passengerOrigin,passengerDestination;
  bool useDriverDestination=false;
  final reference = TextEditingController();
  @override
  void initState(){super.initState();passengerOrigin=widget.passengerOrigin;passengerDestination=widget.passengerDestination;}
  @override
  void dispose(){reference.dispose();super.dispose();}
  Map<String,dynamic> get mapData => {
    'route':widget.match.route,'routeEstimate':widget.match.routeEstimate,
    'origin':widget.match.origin,'destination':widget.match.destination,
    'originLat':widget.match.originLat,'originLng':widget.match.originLng,
    'destinationLat':widget.match.destinationLat,'destinationLng':widget.match.destinationLng,
    if(meeting!=null)'meetingLat':meeting!.latitude,
    if(meeting!=null)'meetingLng':meeting!.longitude,
    'meetingLabel':reference.text.trim().isEmpty?'Propuesto por el pasajero':reference.text.trim(),
  };
  Future<void> chooseMeeting() async {
    final match=widget.match;
    final points=<MapPoint>[
      if(passengerOrigin!=null)passengerOrigin! else if(match.originLat!=null&&match.originLng!=null)MapPoint(latitude:match.originLat!,longitude:match.originLng!,label:'Partida'),
      if(passengerDestination!=null)passengerDestination! else if(match.destinationLat!=null&&match.destinationLng!=null)MapPoint(latitude:match.destinationLat!,longitude:match.destinationLng!,label:'Destino'),
    ];
    final selected=await Navigator.push<MapPoint>(context,MaterialPageRoute(builder:(_)=>LocationPickerScreen(title:'Elige tu Punto Vamos!',initialPoint:meeting??(points.isEmpty?null:points.first),routePoints:points,showRouteLine:false)));
    if(selected!=null&&mounted)setState(()=>meeting=selected);
  }
  Future<void> choosePassengerPoint(bool origin) async {
    final match=widget.match,current=origin?passengerOrigin:passengerDestination;
    final fallback=origin
      ?(match.originLat==null||match.originLng==null?null:MapPoint(latitude:match.originLat!,longitude:match.originLng!,label:'Mi partida'))
      :(match.destinationLat==null||match.destinationLng==null?null:MapPoint(latitude:match.destinationLat!,longitude:match.destinationLng!,label:'Mi destino'));
    final selected=await Navigator.push<MapPoint>(context,MaterialPageRoute(builder:(_)=>LocationPickerScreen(title:origin?'Selecciona tu partida':'Selecciona tu destino',initialPoint:current??fallback,showRouteLine:false)));
    if(selected!=null&&mounted)setState((){if(origin)passengerOrigin=selected;else{passengerDestination=selected;useDriverDestination=false;}meeting=null;});
  }
  bool requested = false;
  bool requesting = false;
  String? bookingId;

  Future<void> requestSeat() async {
    if(meeting==null){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Elige tu Punto Vamos! antes de solicitar el asiento.')));
      await chooseMeeting();
      return;
    }
    final tripId = widget.match.id;
    if (tripId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Este viaje no está disponible. Vuelve a buscar.'),
        ),
      );
      return;
    }
    setState(() => requesting = true);
    try {
      final po=passengerOrigin??(widget.match.originLat==null||widget.match.originLng==null?null:MapPoint(latitude:widget.match.originLat!,longitude:widget.match.originLng!,label:'Origen del pasajero'));
      final pd=useDriverDestination
        ?(widget.match.destinationLat==null||widget.match.destinationLng==null?null:MapPoint(latitude:widget.match.destinationLat!,longitude:widget.match.destinationLng!,label:'Destino final del conductor'))
        :passengerDestination??(widget.match.destinationLat==null||widget.match.destinationLng==null?null:MapPoint(latitude:widget.match.destinationLat!,longitude:widget.match.destinationLng!,label:'Destino del pasajero'));
      if(po==null||pd==null)throw const ApiException('Selecciona tu partida y tu destino antes de solicitar el asiento.');
      final passengerEstimate=await ApiClient.instance.estimateRoute({'originLat':po.latitude,'originLng':po.longitude,'destinationLat':pd.latitude,'destinationLng':pd.longitude});
      final response=await ApiClient.instance.createBooking(tripId,seats:requestedSeats,meetingLat:meeting!.latitude,meetingLng:meeting!.longitude,meetingLabel:reference.text.trim().isEmpty?'Punto Vamos!':reference.text.trim(),passengerOriginLat:po.latitude,passengerOriginLng:po.longitude,passengerDestinationLat:pd.latitude,passengerDestinationLng:pd.longitude,passengerRoute:passengerEstimate['route'] as List<dynamic>);
      if (mounted) {
        setState(() {
          bookingId = response['id']?.toString();
          requested = true;
        });
      }
    } on ApiException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => requesting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final match = widget.match;
    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del viaje')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TripPointsMap(data:mapData),
          if(!requested)...[
            if(widget.fromCommunity)...[
              OutlinedButton.icon(onPressed:requesting?null:()=>choosePassengerPoint(true),icon:const Icon(Icons.trip_origin),label:Text(passengerOrigin==null?'SELECCIONA TU PARTIDA':'CAMBIAR TU PARTIDA')),
              OutlinedButton.icon(onPressed:requesting?null:()=>choosePassengerPoint(false),icon:const Icon(Icons.flag_outlined),label:Text(passengerDestination==null?'SELECCIONA TU DESTINO':'CAMBIAR TU DESTINO')),
            ],
            SwitchListTile(
              contentPadding:EdgeInsets.zero,
              value:useDriverDestination,
              onChanged:requesting?null:(value)=>setState((){useDriverDestination=value;if(value&&widget.match.destinationLat!=null&&widget.match.destinationLng!=null)passengerDestination=MapPoint(latitude:widget.match.destinationLat!,longitude:widget.match.destinationLng!,label:'Destino final del conductor');}),
              title:const Text('Me bajo en el destino final del conductor'),
              subtitle:const Text('Desactívalo si necesitas seleccionar otro punto de bajada.'),
            ),
            if(!useDriverDestination&&!widget.fromCommunity)
              OutlinedButton.icon(onPressed:requesting?null:()=>choosePassengerPoint(false),icon:const Icon(Icons.flag_outlined),label:Text(passengerDestination==null?'SELECCIONA TU PUNTO DE BAJADA':'CAMBIAR PUNTO DE BAJADA')),
            OutlinedButton.icon(onPressed:requesting?null:chooseMeeting,icon:const Icon(Icons.add_location_alt),label:Text(meeting==null?'ELIGE TU PUNTO VAMOS!':'CAMBIAR PUNTO VAMOS!')),
            TextField(controller:reference,enabled:!requesting,maxLength:200,decoration:const InputDecoration(labelText:'Referencia del Punto Vamos! (opcional)',hintText:'Ej.: entrada del supermercado')),
            const Text('El conductor verá el punto al recibir tu solicitud. Coordina por el chat cuando la acepte.'),
            const SizedBox(height:16),
          ],
          Center(
            child: Column(
              children: [
                DisplayPhoto(id:match.driverId,size:72),
                const SizedBox(height: 8),
                Text(
                  match.driver,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text('★ ${match.rating} · ${match.trips} viajes realizados'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  InfoRow(
                    icon: Icons.route,
                    text: '${match.origin} → ${match.destination}',
                  ),
                  InfoRow(icon: Icons.schedule, text: 'Salida ${match.time}'),
                  DisplayPhoto(id:match.vehicleId,vehicle:true,size:180),
                  InfoRow(icon: Icons.directions_car, text: match.vehicle),
                  InfoRow(
                    icon: Icons.event_seat,
                    text: '${match.seats} asientos disponibles',
                  ),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Punto de encuentro',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  InfoRow(icon: Icons.place, text: match.meetingPoint),
                  const Text(
                    'Coordina el lugar exacto con el conductor por el chat de la reserva.',
                  ),
                ],
              ),
            ),
          ),
          Card(
            color: const Color(0xFFE4F6EE),
            child: ListTile(
              leading: const Icon(Icons.auto_awesome, color: AppColors.green),
              title: Text(widget.fromCommunity ? 'Viaje de tu comunidad' : '${match.compatibility}% compatible'),
              subtitle: Text(
                widget.fromCommunity ? 'Revisa el recorrido y propone tu Punto Vamos! antes de solicitar un asiento.' : 'Estimación de cercanía a la ruta registrada del conductor.',
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (!requested) ...[
            DropdownButtonFormField<int>(
              initialValue: requestedSeats,
              decoration: const InputDecoration(labelText: 'Asientos para ti y tus acompañantes'),
              items: List.generate(match.seats.clamp(0,7).toInt(), (i) => DropdownMenuItem(value: i+1, child: Text('${i+1} asiento(s)'))),
              onChanged: requesting ? null : (value) { if(value!=null) setState(() => requestedSeats=value); },
            ),
            const Text('Incluye un asiento por cada acompañante, también menores que viajen contigo. Coordina con el conductor sus necesidades de traslado.'),
            Text('Bs ${match.price.toStringAsFixed(2)} por asiento · Total Bs ${(match.price * requestedSeats).toStringAsFixed(2)}'),
            const SizedBox(height: 12),
          ],
          if (!requested)
            ElevatedButton(
              onPressed: requesting || match.seats < requestedSeats ? null : requestSeat,
              child: Text(
                requesting
                    ? 'ENVIANDO SOLICITUD…'
                    : 'SOLICITAR $requestedSeats ASIENTO(S) · Bs ${(match.price * requestedSeats).toStringAsFixed(2)}',
              ),
            )
          else ...[
            Card(
              child: ListTile(
                leading: const Icon(Icons.hourglass_top, color: Colors.orange),
                title: const Text('Solicitud enviada'),
                subtitle: const Text(
                  'Consulta la respuesta del conductor en Viajes o Notificaciones.',
                ),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context,
                AppRoutes.home,
                (_) => false,
              ),
              child: const Text('VOLVER AL INICIO'),
            ),
          ],
        ],
      ),
    );
  }
}

String formatDate(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

TripMatch tripMatchFromApi(Map<String, dynamic> data, String fallbackTime) {
  final parsed = DateTime.tryParse(data['departureAt']?.toString() ?? '');
  final local = parsed?.toLocal();
  final departure = local == null
      ? fallbackTime
      : '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';

  return TripMatch(
    route:data['route'] as List?,routeEstimate:data['routeEstimate'] as Map<String,dynamic>?,
    id: data['id']?.toString(),
    originLat:double.tryParse('${data['originLat']}'),originLng:double.tryParse('${data['originLng']}'),
    destinationLat:double.tryParse('${data['destinationLat']}'),destinationLng:double.tryParse('${data['destinationLng']}'),
    driverId:data['driverId']?.toString(),
    vehicleId:data['vehicleId']?.toString(),
    driverVerified:data['driverVerified']==true,
    vehicleVerified:data['vehicleVerified']==true,
    driver: data['driver']?.toString() ?? 'Conductor',
    rating: double.tryParse(data['rating']?.toString() ?? '') ?? 0,
    trips: int.tryParse(data['tripCount']?.toString() ?? '') ?? 0,
    vehicle: data['vehicle']?.toString() ?? 'Vehículo',
    origin: data['origin']?.toString() ?? 'Origen',
    destination: data['destination']?.toString() ?? 'Destino',
    time: departure,
    seats: int.tryParse(data['seats']?.toString() ?? '') ?? 1,
    price: double.tryParse(data['contribution']?.toString() ?? '') ?? 0,
    compatibility:
        double.tryParse(data['compatibility']?.toString() ?? '')?.round() ?? 0,
    meetingPoint: 'Por coordinar con el conductor',
    walkMinutes: 0,
    detourMinutes: 0,
  );
}
