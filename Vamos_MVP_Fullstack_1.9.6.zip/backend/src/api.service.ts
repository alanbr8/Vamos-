import { randomInt } from 'node:crypto';
import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource, EntityManager } from 'typeorm';
import { SaveSearchDto, BookingDto, IncidentDto, RatingDto, SearchTripsDto, SendMessageDto, TripDto, VehicleDto } from './dtos';

@Injectable()
export class ApiService {
  constructor(private readonly db: DataSource) {}

  async profile(userId: string) {
    const [user] = await this.db.query(
      `SELECT u.id,u.usage_mode AS "usageMode",u.first_name AS "firstName",u.last_name AS "lastName",u.email,u.phone,vamos_identity_ready(u.id,(now() AT TIME ZONE 'America/La_Paz')::date) AS "identityVerified",
       COALESCE((SELECT status FROM profile_photo_submissions WHERE owner_id=u.id),'NOT_SUBMITTED') AS "profilePhotoStatus",
       COALESCE(round(avg(r.overall),1),0) AS rating,count(DISTINCT r.id)::int AS "ratingCount"
       FROM users u LEFT JOIN ratings r ON r.to_user_id=u.id WHERE u.id=$1 GROUP BY u.id`, [userId]);
    if (!user) throw new NotFoundException('Usuario no encontrado');
    return user;
  }

  vehicles(userId: string) {
    return this.db.query('SELECT id,brand,model,year,color,license_plate AS "licensePlate",passenger_seats AS "passengerSeats",verification_status AS status FROM vehicles WHERE owner_id=$1 ORDER BY created_at DESC', [userId]);
  }

  async createVehicle(userId: string, dto: VehicleDto) {
    const verificationStatus = 'PENDING';
    const [vehicle] = await this.db.query(
      `INSERT INTO vehicles(owner_id,brand,model,year,color,license_plate,passenger_seats,verification_status)
       VALUES($1,$2,$3,$4,$5,upper($6),$7,$8)
       ON CONFLICT (owner_id,license_plate) DO NOTHING
       RETURNING id,brand,model,year,color,license_plate AS "licensePlate",
       passenger_seats AS "passengerSeats",verification_status AS status`,
      [userId, dto.brand, dto.model, dto.year, dto.color,
       dto.licensePlate, dto.passengerSeats, verificationStatus]);
    if (!vehicle) throw new ConflictException('Esta placa ya está registrada en tu cuenta. Consulta Mi vehículo.');
    return vehicle;
  }

  private validateTrip(dto: TripDto) {
    if (new Date(dto.departureAt).getTime() <= Date.now()) {
      throw new BadRequestException('La salida debe estar en el futuro');
    }
    if (dto.originLat === dto.destinationLat && dto.originLng === dto.destinationLng) {
      throw new BadRequestException('El origen y el destino deben ser diferentes');
    }
    if (dto.route.length < 2 || dto.route.some(point => !Array.isArray(point) || point.length !== 2 ||
        !Number.isFinite(point[0]) || !Number.isFinite(point[1]) || Math.abs(point[0]) > 180 || Math.abs(point[1]) > 90)) {
      throw new BadRequestException('La ruta debe contener al menos dos coordenadas válidas');
    }
    if (dto.route[0][0] !== dto.originLng || dto.route[0][1] !== dto.originLat ||
        dto.route.at(-1)![0] !== dto.destinationLng || dto.route.at(-1)![1] !== dto.destinationLat) {
      throw new BadRequestException('La ruta debe empezar en el origen y terminar en el destino');
    }
  }

  private async checkDocuments(manager: EntityManager, userId: string, dto: TripDto) {
    await manager.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId]);
    if(dto.communityId){
      await manager.query('SELECT id FROM communities WHERE id=$1 FOR UPDATE',[dto.communityId]);
      const [access]=await manager.query('SELECT vamos_community_access($1,$2) AS allowed',[dto.communityId,userId]);
      if(!access?.allowed)throw new ForbiddenException('Necesitas ser miembro aprobado de la comunidad');
    }
    const [check] = await manager.query(`SELECT vamos_documents_ready($1,$2,($3::timestamptz AT TIME ZONE 'America/La_Paz')::date) AS ready`,[userId,dto.vehicleId,dto.departureAt]);
    if (!check?.ready) throw new ForbiddenException('Completa y solicita la revisión de tu carnet, selfie, licencia, fotos del vehículo y SOAT. Deben estar aprobados y vigentes en la fecha del viaje.');
    const [visiblePhoto]=await manager.query(`SELECT id FROM display_photos WHERE owner_id=$1 AND vehicle_id=$2`,[userId,dto.vehicleId]);
    if(!visiblePhoto)throw new ForbiddenException('Agrega la foto visible del vehículo antes de publicar. La foto de verificación es privada y no se muestra en los viajes.');
  }

  async createTrip(userId: string, dto: TripDto) {
    this.validateTrip(dto);
    const routeGeoJson = JSON.stringify({ type: 'LineString', coordinates: dto.route });
    return this.db.transaction(async manager => {
    await this.checkDocuments(manager,userId,dto);
    const [trip] = await manager.query(
      `INSERT INTO trips(driver_id,vehicle_id,origin_label,origin,destination_label,destination,route,departure_at,available_seats,contribution,recurring_days,preferences,meeting_code,community_id)
       SELECT $1,$2,$3,ST_SetSRID(ST_MakePoint($4,$5),4326)::geography,$6,ST_SetSRID(ST_MakePoint($7,$8),4326)::geography,
       ST_SetSRID(ST_GeomFromGeoJSON($9),4326)::geography,$10,$11,$12,$13,$14,lpad((floor(random()*10000))::int::text,4,'0'),$15
       FROM vehicles WHERE id=$2 AND owner_id=$1 AND verification_status='VERIFIED' AND passenger_seats >= $11 RETURNING id,status,meeting_code AS "meetingCode"`,
      [userId, dto.vehicleId, dto.originLabel, dto.originLng, dto.originLat, dto.destinationLabel, dto.destinationLng, dto.destinationLat, routeGeoJson, dto.departureAt, dto.availableSeats, dto.contribution, dto.recurringDays ?? [], dto.preferences ?? {}, dto.communityId ?? null]);
    if (!trip) throw new ForbiddenException('El vehículo debe estar verificado, pertenecer a tu cuenta y tener suficientes asientos');
    await this.matchSavedSearches(null, manager, trip.id);
    return trip;
    });
  }

  async updateTrip(userId: string, id: string, dto: TripDto) {
    this.validateTrip(dto);
    return this.db.transaction(async manager => {
      await this.checkDocuments(manager,userId,dto);
      const [trip] = await manager.query(`SELECT id,status,route_departed_at FROM trips WHERE id=$1 AND driver_id=$2 FOR UPDATE`,[id,userId]);
      if (!trip || trip.status !== 'PUBLISHED' || trip.route_departed_at) throw new BadRequestException('Solo puedes editar un viaje publicado antes de iniciarlo');
      const [active] = await manager.query(`SELECT id FROM bookings WHERE trip_id=$1 AND status IN ('PENDING','ACCEPTED') LIMIT 1`,[id]);
      if (active) throw new BadRequestException('Hay solicitudes pendientes o aceptadas. Cancela el viaje si necesitas cambiar sus condiciones');
      const [vehicle] = await manager.query(`SELECT id FROM vehicles WHERE id=$1 AND owner_id=$2 AND verification_status='VERIFIED' AND passenger_seats >= $3`,[dto.vehicleId,userId,dto.availableSeats]);
      if (!vehicle) throw new BadRequestException('Selecciona un vehículo aprobado con suficientes asientos');
      const [updated] = await manager.query(`WITH changed AS (UPDATE trips SET vehicle_id=$2,origin_label=$3,
        origin=ST_SetSRID(ST_MakePoint($4,$5),4326)::geography,destination_label=$6,
        destination=ST_SetSRID(ST_MakePoint($7,$8),4326)::geography,
        route=ST_SetSRID(ST_GeomFromGeoJSON($9),4326)::geography,departure_at=$10,
        available_seats=$11,contribution=$12,recurring_days=$13,preferences=$14,community_id=CASE WHEN $16::boolean THEN $15::uuid ELSE community_id END
        WHERE id=$1 RETURNING id,status) SELECT * FROM changed`,
        [id,dto.vehicleId,dto.originLabel,dto.originLng,dto.originLat,dto.destinationLabel,dto.destinationLng,dto.destinationLat,
         JSON.stringify({type:'LineString',coordinates:dto.route}),dto.departureAt,dto.availableSeats,dto.contribution,dto.recurringDays ?? [],dto.preferences ?? {},dto.communityId ?? null,dto.communityId !== undefined]);
      await this.matchSavedSearches(null,manager,id);
      return updated;
    });
  }

  async cancelTrip(userId: string, id: string, reason?: string) {
    const cancellationReason=reason?.trim();
    if(!cancellationReason||cancellationReason.length<5)throw new BadRequestException('Indica el motivo de cancelación');
    return this.db.transaction(async manager => {
      const [trip] = await manager.query(`SELECT id,status FROM trips WHERE id=$1 AND driver_id=$2 FOR UPDATE`,[id,userId]);
      if (!trip || !['PUBLISHED','RESERVED'].includes(trip.status)) throw new BadRequestException('Solo puedes cancelar un viaje antes de iniciarlo');
      await manager.query(`WITH cancelled AS (UPDATE bookings SET status='CANCELLED'
        WHERE trip_id=$1 AND status IN ('PENDING','ACCEPTED') RETURNING id,passenger_id)
        INSERT INTO notifications(user_id,type,title,body,data)
        SELECT passenger_id,'TRIP_CANCELLED','Viaje cancelado','El conductor canceló el viaje. Puedes buscar otra opción.',
        jsonb_build_object('tripId',$1::uuid,'bookingId',id) FROM cancelled`,[id]);
      const [updated] = await manager.query(`WITH changed AS (UPDATE trips SET status='CANCELLED',cancellation_reason=$2 WHERE id=$1 RETURNING id,status,cancellation_reason AS "cancellationReason") SELECT * FROM changed`,[id,cancellationReason]);
      return updated;
    });
  }

  search(userId: string, dto: SearchTripsDto) {
    if (new Date(dto.departureFrom) > new Date(dto.departureTo)) {
      throw new BadRequestException('El intervalo de búsqueda es inválido');
    }
    return this.db.query(
      `SELECT t.id,t.origin_label AS origin,t.destination_label AS destination,t.departure_at AS "departureAt",
       ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS "route",t.preferences->'routeEstimate' AS "routeEstimate",ST_Y(t.origin::geometry) AS "originLat",ST_X(t.origin::geometry) AS "originLng",ST_Y(t.destination::geometry) AS "destinationLat",ST_X(t.destination::geometry) AS "destinationLng",
       t.available_seats AS seats,t.contribution,u.first_name AS driver,u.id AS "driverId",t.vehicle_id AS "vehicleId",
       vamos_identity_ready(u.id,(now() AT TIME ZONE 'America/La_Paz')::date) AS "driverVerified",
       (v.verification_status='VERIFIED') AS "vehicleVerified",
       concat(v.brand,' ',v.model,' · ',v.color) AS vehicle,
       COALESCE((SELECT round(avg(overall),1) FROM ratings WHERE to_user_id=u.id),0) AS rating,
       (SELECT count(*)::int FROM trips WHERE driver_id=u.id AND status='COMPLETED') AS "tripCount",
       round((100 - LEAST(35,ST_Distance(t.route,ST_SetSRID(ST_MakePoint($1,$2),4326)::geography)/100)
                  - LEAST(35,ST_Distance(t.route,ST_SetSRID(ST_MakePoint($3,$4),4326)::geography)/100))::numeric,0) AS compatibility
       FROM trips t JOIN users u ON u.id=t.driver_id JOIN vehicles v ON v.id=t.vehicle_id
       WHERE t.route_departed_at IS NULL AND t.status='PUBLISHED' AND t.available_seats>0 AND t.driver_id<>$8
       AND u.status='ACTIVE' AND v.verification_status='VERIFIED'
       AND vamos_community_access(t.community_id,$8)
       AND t.departure_at>now() AND t.departure_at BETWEEN $5 AND $6
       AND ST_DWithin(t.route,ST_SetSRID(ST_MakePoint($1,$2),4326)::geography,$7)
       AND ST_DWithin(t.route,ST_SetSRID(ST_MakePoint($3,$4),4326)::geography,$7)
       AND ST_LineLocatePoint(t.route::geometry,ST_SetSRID(ST_MakePoint($1,$2),4326))
         < ST_LineLocatePoint(t.route::geometry,ST_SetSRID(ST_MakePoint($3,$4),4326))
       ORDER BY compatibility DESC,t.departure_at LIMIT 30`,
      [dto.originLng, dto.originLat, dto.destinationLng, dto.destinationLat, dto.departureFrom, dto.departureTo, dto.maxDistanceMeters, userId]);
  }

  async saveSearch(userId: string, dto: SaveSearchDto) {
    if (new Date(dto.departureFrom) > new Date(dto.departureTo) || new Date(dto.departureTo).getTime() <= Date.now()) {
      throw new BadRequestException('Elige un horario futuro y un intervalo válido');
    }
    if (dto.originLat === dto.destinationLat && dto.originLng === dto.destinationLng) {
      throw new BadRequestException('El origen y destino deben ser diferentes');
    }
    const {originLat,originLng,destinationLat,destinationLng,maxDistanceMeters} = dto;
    const criteria = {originLat,originLng,destinationLat,destinationLng,maxDistanceMeters: maxDistanceMeters ?? 1500,
      departureFrom:new Date(dto.departureFrom).toISOString(),departureTo:new Date(dto.departureTo).toISOString()};
    return this.db.transaction(async manager => {
      const [saved] = await manager.query(`INSERT INTO saved_searches(user_id,criteria,origin_label,destination_label)
        VALUES($1,$2,$3,$4) ON CONFLICT(user_id,criteria) DO UPDATE SET active=true,
        origin_label=EXCLUDED.origin_label,destination_label=EXCLUDED.destination_label RETURNING id`,
        [userId,criteria,dto.originLabel,dto.destinationLabel]);
      await this.matchSavedSearches(userId, manager);
      return saved;
    });
  }

  async savedSearches(userId: string) {
    await this.matchSavedSearches(userId);
    return this.db.query(`SELECT id,criteria,origin_label AS origin,destination_label AS destination,
      CASE WHEN NOT active THEN 'CANCELLED' WHEN (criteria->>'departureTo')::timestamptz<=now()
      THEN 'EXPIRED' ELSE 'ACTIVE' END AS status FROM saved_searches WHERE user_id=$1 ORDER BY created_at DESC`,[userId]);
  }

  async cancelSearch(userId: string, id: string) {
    const [saved] = await this.db.query(`WITH changed AS (UPDATE saved_searches SET active=false
      WHERE id=$1 AND user_id=$2 RETURNING id) SELECT id FROM changed`,[id,userId]);
    if (!saved) throw new NotFoundException('Búsqueda no encontrada');
    return saved;
  }

  async matchSavedSearches(userId: string | null, executor: DataSource | EntityManager = this.db, tripId: string | null = null) {
    await executor.query(`WITH candidates AS (
      SELECT s.id AS search_id,t.id AS trip_id FROM saved_searches s
      CROSS JOIN LATERAL (SELECT
        ST_SetSRID(ST_MakePoint((s.criteria->>'originLng')::float8,(s.criteria->>'originLat')::float8),4326) AS origin,
        ST_SetSRID(ST_MakePoint((s.criteria->>'destinationLng')::float8,(s.criteria->>'destinationLat')::float8),4326) AS destination) p
      JOIN trips t ON t.departure_at BETWEEN (s.criteria->>'departureFrom')::timestamptz AND (s.criteria->>'departureTo')::timestamptz
      JOIN users u ON u.id=t.driver_id JOIN vehicles v ON v.id=t.vehicle_id
      WHERE s.active AND ($1::uuid IS NULL OR s.user_id=$1::uuid) AND ($2::uuid IS NULL OR t.id=$2::uuid)
      AND (s.criteria->>'departureTo')::timestamptz>now() AND t.departure_at>now()
      AND t.route_departed_at IS NULL AND t.status='PUBLISHED' AND t.available_seats>0 AND t.driver_id<>s.user_id
      AND u.status='ACTIVE' AND v.verification_status='VERIFIED'
      AND vamos_community_access(t.community_id,s.user_id)
      AND ST_DWithin(t.route,p.origin::geography,(s.criteria->>'maxDistanceMeters')::float8)
      AND ST_DWithin(t.route,p.destination::geography,(s.criteria->>'maxDistanceMeters')::float8)
      AND ST_LineLocatePoint(t.route::geometry,p.origin)<ST_LineLocatePoint(t.route::geometry,p.destination)
      AND NOT EXISTS(SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=s.user_id AND b.status IN ('PENDING','ACCEPTED','COMPLETED'))
    ), added AS (
      INSERT INTO saved_search_matches(search_id,trip_id) SELECT search_id,trip_id FROM candidates
      ON CONFLICT DO NOTHING RETURNING search_id,trip_id
    ) INSERT INTO notifications(user_id,type,title,body,data)
      SELECT s.user_id,'SEARCH_MATCH','Encontramos un viaje compatible',s.origin_label || ' → ' || s.destination_label,
      jsonb_build_object('searchId',s.id,'tripId',a.trip_id)
      FROM added a JOIN saved_searches s ON s.id=a.search_id`,[userId,tripId]);
  }

  async createBooking(userId: string, dto: BookingDto) {
    const hasLat = dto.meetingLat != null, hasLng = dto.meetingLng != null;
    if (hasLat !== hasLng || (dto.meetingLabel && !hasLat) ||
      (hasLat && (!Number.isFinite(dto.meetingLat) || Math.abs(dto.meetingLat!)>90 || !Number.isFinite(dto.meetingLng) || Math.abs(dto.meetingLng!)>180))) {
      throw new BadRequestException('Selecciona un Punto Vamos! válido en el mapa');
    }
    const passengerValues=[dto.passengerOriginLat,dto.passengerOriginLng,dto.passengerDestinationLat,dto.passengerDestinationLng,dto.passengerRoute],hasPassenger=passengerValues.some(v=>v!=null);
    if(!hasPassenger||passengerValues.some(v=>v==null))throw new BadRequestException('Selecciona el punto de partida y el punto de bajada');
    if(dto.passengerOriginLat===dto.passengerDestinationLat&&dto.passengerOriginLng===dto.passengerDestinationLng){
      throw new BadRequestException('El punto de bajada debe ser diferente al punto de partida');
    }
    if(dto.passengerRoute.length<2||dto.passengerRoute.some(point=>!Array.isArray(point)||point.length!==2||!Number.isFinite(point[0])||!Number.isFinite(point[1])||Math.abs(point[0])>180||Math.abs(point[1])>90)){
      throw new BadRequestException('No se pudo validar la ruta del pasajero');
    }
    if(hasPassenger&&(passengerValues.some(v=>v==null)||!Array.isArray(dto.passengerRoute)||dto.passengerRoute.length<2||dto.passengerRoute.some(p=>!Array.isArray(p)||p.length!==2||!Number.isFinite(p[0])||!Number.isFinite(p[1]))||dto.passengerRoute[0][0]!==dto.passengerOriginLng||dto.passengerRoute[0][1]!==dto.passengerOriginLat||dto.passengerRoute.at(-1)![0]!==dto.passengerDestinationLng||dto.passengerRoute.at(-1)![1]!==dto.passengerDestinationLat))throw new BadRequestException('La ruta del pasajero no coincide con sus puntos seleccionados');
    const passengerRoute=hasPassenger?JSON.stringify({type:'LineString',coordinates:dto.passengerRoute}):null;
    return this.db.transaction(async manager => {
      // Lock group before trip, matching membership decisions and publishing.
      const [scope]=await manager.query('SELECT community_id FROM trips WHERE id=$1',[dto.tripId]);
      if(scope?.community_id)await manager.query('SELECT id FROM communities WHERE id=$1 FOR UPDATE',[scope.community_id]);
      const [trip] = await manager.query(
        `SELECT id,driver_id AS "driverId",origin_label AS origin,
         destination_label AS destination,available_seats AS "availableSeats" FROM trips
         WHERE id=$1 AND driver_id<>$2 AND vamos_community_access(community_id,$2) AND route_departed_at IS NULL AND status='PUBLISHED' AND departure_at>now()
         FOR UPDATE`, [dto.tripId, userId]);
      if (!trip || trip.availableSeats < dto.seats) {
        throw new BadRequestException('Viaje sin cupos suficientes');
      }
      const [booking] = await manager.query(
        `INSERT INTO bookings(trip_id,passenger_id,seats,meeting_point,meeting_point_label,encounter_code,passenger_origin,passenger_destination,passenger_route)
         VALUES($1,$2,$3,CASE WHEN $4::float8 IS NULL THEN NULL ELSE ST_SetSRID(ST_MakePoint($5,$4),4326)::geography END,$6,$7,CASE WHEN $8::float8 IS NULL THEN NULL ELSE ST_SetSRID(ST_MakePoint($8,$9),4326)::geography END,CASE WHEN $10::float8 IS NULL THEN NULL ELSE ST_SetSRID(ST_MakePoint($10,$11),4326)::geography END,CASE WHEN $12::text IS NULL THEN NULL ELSE ST_SetSRID(ST_GeomFromGeoJSON($12),4326)::geography END)
         ON CONFLICT (trip_id,passenger_id) DO UPDATE
         SET seats=excluded.seats,status='PENDING',created_at=now(),meeting_point=excluded.meeting_point,meeting_point_label=excluded.meeting_point_label,encounter_code=excluded.encounter_code,passenger_origin=excluded.passenger_origin,passenger_destination=excluded.passenger_destination,passenger_route=excluded.passenger_route,encounter_verified_at=NULL,encounter_failures=0,encounter_locked_until=NULL,passenger_completed_at=NULL,cancellation_reason=NULL
         WHERE bookings.status IN ('REJECTED','CANCELLED','NO_SHOW')
         RETURNING id,status,seats`, [dto.tripId,userId,dto.seats,dto.meetingLat??null,dto.meetingLng??null,hasLat?dto.meetingLabel?.trim()||'Punto Vamos!':null,randomInt(0,1000000).toString().padStart(6,'0'),dto.passengerOriginLng,dto.passengerOriginLat,dto.passengerDestinationLng,dto.passengerDestinationLat,passengerRoute]);
      if (!booking) {
        throw new BadRequestException('Ya tienes una solicitud activa para este viaje');
      }
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         VALUES($1,'BOOKING_REQUEST','Nueva solicitud de asiento',$2,$3)`,
        [trip.driverId, `${trip.origin} → ${trip.destination}`,
         { tripId: dto.tripId, bookingId: booking.id }]);
      return booking;
    });
  }

  async bookingAction(userId: string, bookingId: string, action: string, reason?: string) {
    return this.db.transaction(async manager => {
      const [row] = await manager.query(
        `SELECT b.id,b.trip_id AS "tripId",b.passenger_id AS "passengerId",
         b.seats,b.status,t.driver_id AS "driverId",t.available_seats AS "availableSeats",
         t.status AS "tripStatus",t.departure_at AS "departureAt",b.encounter_verified_at AS "verifiedAt"
         FROM bookings b JOIN trips t ON t.id=b.trip_id
         WHERE b.id=$1 FOR UPDATE OF b,t`, [bookingId]);
      if (!row) throw new NotFoundException('Reserva no encontrada');

      const isDriver = row.driverId === userId;
      const isPassenger = row.passengerId === userId;
      if (!isDriver && !isPassenger) throw new ForbiddenException();

      if (action === 'accept') {
        if (!isDriver || row.status !== 'PENDING') {
          throw new BadRequestException('La solicitud ya no puede aceptarse');
        }
        if (row.tripStatus !== 'PUBLISHED' || new Date(row.departureAt).getTime() <= Date.now() || row.availableSeats < row.seats) {
          throw new BadRequestException('Ya no quedan cupos suficientes');
        }
        const remaining = row.availableSeats - row.seats;
        await manager.query(`UPDATE bookings SET status='ACCEPTED',accepted_at=COALESCE(accepted_at,now()),cancelled_at=NULL WHERE id=$1`, [bookingId]);
        await manager.query(
          `UPDATE trips SET available_seats=$2,status=$3 WHERE id=$1`,
          [row.tripId, remaining, remaining === 0 ? 'RESERVED' : 'PUBLISHED']);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_ACCEPTED','Solicitud aceptada','Tu asiento fue confirmado',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'ACCEPTED', seatsAvailable: remaining };
      }

      if (action === 'reject') {
        if (!isDriver || row.status !== 'PENDING') {
          throw new BadRequestException('La solicitud ya no puede rechazarse');
        }
        await manager.query(`UPDATE bookings SET status='REJECTED',rejected_at=now() WHERE id=$1`, [bookingId]);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_REJECTED','Solicitud rechazada','El conductor no pudo aceptar esta solicitud',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'REJECTED', seatsAvailable: row.availableSeats };
      }

      if (action === 'cancel') {
        const cancellationReason=reason?.trim();
        if(!cancellationReason||cancellationReason.length<5)throw new BadRequestException('Indica el motivo de cancelación');
        if (!isPassenger || !['PENDING', 'ACCEPTED'].includes(row.status)) {
          throw new BadRequestException('La reserva ya no puede cancelarse');
        }
        if (!['PUBLISHED', 'RESERVED'].includes(row.tripStatus)) {
          throw new BadRequestException('El viaje ya comenzó');
        }
        await manager.query(`UPDATE bookings SET status='CANCELLED',cancelled_at=now(),cancellation_reason=$2 WHERE id=$1`, [bookingId,cancellationReason]);
        const restored = row.status === 'ACCEPTED'
          ? row.availableSeats + row.seats
          : row.availableSeats;
        if (row.status === 'ACCEPTED') {
          await manager.query(
            `UPDATE trips SET available_seats=$2,status='PUBLISHED' WHERE id=$1`,
            [row.tripId, restored]);
        }
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_CANCELLED','Reserva cancelada','El pasajero canceló su solicitud',$2)`,
          [row.driverId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'CANCELLED', seatsAvailable: restored };
      }

      if (action === 'no_show') {
        if (!isDriver || row.status !== 'ACCEPTED' || row.tripStatus !== 'IN_PROGRESS' || row.verifiedAt) {
          throw new BadRequestException('No se puede marcar esta ausencia');
        }
        await manager.query(`UPDATE bookings SET status='NO_SHOW',no_show_at=now() WHERE id=$1`, [bookingId]);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'NO_SHOW','Ausencia registrada','El conductor registró tu ausencia',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'NO_SHOW', seatsAvailable: row.availableSeats };
      }

      throw new BadRequestException('Acción inválida');
    });
  }

  async confirmArrival(userId:string,bookingId:string){
    const [confirmed]=await this.db.query(`WITH changed AS (
      UPDATE bookings SET passenger_completed_at=COALESCE(passenger_completed_at,now())
      WHERE id=$1 AND passenger_id=$2 AND status='COMPLETED'
      RETURNING id,status,passenger_completed_at AS "passengerCompletedAt"
    ) SELECT * FROM changed`,[bookingId,userId]);
    if(!confirmed)throw new BadRequestException('Solo puedes confirmar la llegada de un viaje finalizado');
    return confirmed;
  }

  driverTrips(userId: string) {
    return this.db.query(
      `SELECT t.id,t.community_id AS "communityId",t.origin_label AS origin,t.destination_label AS destination,
       t.departure_at AS "departureAt",t.available_seats AS "availableSeats",
       t.contribution,t.status,t.route_departed_at AS "routeDepartedAt",
       t.vehicle_id AS "vehicleId",ST_X(t.origin::geometry) AS "originLng",ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS "route",t.preferences->'routeEstimate' AS "routeEstimate",ST_Y(t.origin::geometry) AS "originLat",
       ST_X(t.destination::geometry) AS "destinationLng",ST_Y(t.destination::geometry) AS "destinationLat",
       t.recurring_days AS "recurringDays",t.preferences,
       COALESCE(json_agg(json_build_object(
         'id',b.id,'passengerId',b.passenger_id,'passenger',u.first_name,
         'seats',b.seats,'status',b.status,'encounterVerifiedAt',b.encounter_verified_at,'meetingLat',ST_Y(b.meeting_point::geometry),'meetingLng',ST_X(b.meeting_point::geometry),'meetingLabel',b.meeting_point_label,
         'passengerOriginLat',ST_Y(b.passenger_origin::geometry),'passengerOriginLng',ST_X(b.passenger_origin::geometry),'passengerDestinationLat',ST_Y(b.passenger_destination::geometry),'passengerDestinationLng',ST_X(b.passenger_destination::geometry),'passengerRoute',ST_AsGeoJSON(b.passenger_route::geometry)::json->'coordinates','passengerCompletedAt',b.passenger_completed_at,'cancellationReason',b.cancellation_reason
       ) ORDER BY b.created_at) FILTER (WHERE b.id IS NOT NULL),'[]') AS bookings
       FROM trips t
       LEFT JOIN bookings b ON b.trip_id=t.id
       LEFT JOIN users u ON u.id=b.passenger_id
       WHERE t.driver_id=$1
       GROUP BY t.id ORDER BY t.departure_at DESC`, [userId]);
  }

  passengerBookings(userId: string) {
    return this.db.query(
      `SELECT b.id,b.seats,b.status,t.id AS "tripId",ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS "route",t.preferences->'routeEstimate' AS "routeEstimate",ST_Y(t.origin::geometry) AS "originLat",ST_X(t.origin::geometry) AS "originLng",ST_Y(t.destination::geometry) AS "destinationLat",ST_X(t.destination::geometry) AS "destinationLng",
       ST_Y(b.meeting_point::geometry) AS "meetingLat",ST_X(b.meeting_point::geometry) AS "meetingLng",b.meeting_point_label AS "meetingLabel",ST_Y(b.passenger_origin::geometry) AS "passengerOriginLat",ST_X(b.passenger_origin::geometry) AS "passengerOriginLng",ST_Y(b.passenger_destination::geometry) AS "passengerDestinationLat",ST_X(b.passenger_destination::geometry) AS "passengerDestinationLng",ST_AsGeoJSON(b.passenger_route::geometry)::json->'coordinates' AS "passengerRoute",t.origin_label AS origin,
       t.destination_label AS destination,t.departure_at AS "departureAt",
       t.contribution,t.route_departed_at AS "routeDepartedAt",b.encounter_verified_at AS "encounterVerifiedAt",b.passenger_completed_at AS "passengerCompletedAt",b.cancellation_reason AS "cancellationReason",CASE WHEN b.status='ACCEPTED' AND b.encounter_verified_at IS NULL THEN b.encounter_code END AS "meetingCode",
       u.id AS "driverId",u.first_name AS driver,t.vehicle_id AS "vehicleId"
       FROM bookings b JOIN trips t ON t.id=b.trip_id
       JOIN users u ON u.id=t.driver_id
       WHERE b.passenger_id=$1 ORDER BY t.departure_at DESC`, [userId]);
  }

  async departTrip(userId:string,tripId:string) {
    return this.db.transaction(async m=>{
      const [trip]=await m.query(`SELECT id,status,route_departed_at FROM trips WHERE id=$1 AND driver_id=$2 FOR UPDATE`,[tripId,userId]);
      if(!trip||!['PUBLISHED','RESERVED'].includes(trip.status))throw new BadRequestException('No se puede avisar la salida de este viaje');
      if(trip.route_departed_at)return {id:tripId,status:trip.status,routeDepartedAt:trip.route_departed_at};
      const [saved]=await m.query(`WITH changed AS (UPDATE trips SET route_departed_at=now() WHERE id=$1 RETURNING id,status,route_departed_at AS "routeDepartedAt") SELECT * FROM changed`,[tripId]);
      await m.query(`WITH rejected AS (UPDATE bookings SET status='REJECTED' WHERE trip_id=$1 AND status='PENDING' RETURNING passenger_id)
      INSERT INTO notifications(user_id,type,title,body,data) SELECT passenger_id,'BOOKING_REJECTED','Solicitud cerrada','El conductor salió sin confirmar tu solicitud',$2 FROM rejected`,[tripId,{tripId}]);
      await m.query(`INSERT INTO notifications(user_id,type,title,body,data)
      SELECT passenger_id,'ROUTE_DEPARTED','¡Tu conductor está saliendo!','Dirígete a tu Punto Vamos! y entrega el código al encontrarte con el conductor.',jsonb_build_object('tripId',trip_id,'bookingId',id)
      FROM bookings WHERE trip_id=$1 AND status='ACCEPTED'`,[tripId]);
      return saved;
    });
  }

  async verifyEncounter(userId:string,bookingId:string,code:string) {
    if(!/^\d{6}$/.test(code))throw new BadRequestException('Ingresa los seis dígitos del código de esta reserva');
    const result=await this.db.transaction(async m=>{
      const [trip]=await m.query(`SELECT t.id,t.status,t.route_departed_at FROM trips t JOIN bookings b ON b.trip_id=t.id WHERE b.id=$1 AND t.driver_id=$2 FOR UPDATE OF t`,[bookingId,userId]);
      if(!trip||(!trip.route_departed_at&&trip.status!=='IN_PROGRESS')||!['PUBLISHED','RESERVED','IN_PROGRESS'].includes(trip.status))throw new BadRequestException('Primero avisa que estás saliendo; solo el conductor puede confirmar el encuentro');
      const [b]=await m.query(`SELECT * FROM bookings WHERE id=$1 FOR UPDATE`,[bookingId]);
      if(b.status!=='ACCEPTED')throw new BadRequestException('La reserva debe estar aceptada');
      if(b.encounter_verified_at)return {id:bookingId,status:trip.status,encounterVerifiedAt:b.encounter_verified_at};
      if(b.encounter_locked_until&&new Date(b.encounter_locked_until).getTime()>Date.now())return {error:'Demasiados intentos. Espera 15 minutos y confirma el código con el pasajero.'};
      if(b.encounter_code!==code){
        await m.query(`UPDATE bookings SET encounter_failures=CASE WHEN encounter_locked_until IS NOT NULL THEN 1 ELSE encounter_failures+1 END,
        encounter_locked_until=CASE WHEN encounter_locked_until IS NULL AND encounter_failures>=4 THEN now()+interval '15 minutes' ELSE NULL END WHERE id=$1`,[bookingId]);
        return {error:'El código no corresponde a esta reserva'};
      }
      const [verified]=await m.query(`WITH changed AS (UPDATE bookings SET encounter_verified_at=now(),encounter_failures=0,encounter_locked_until=NULL WHERE id=$1 RETURNING id,encounter_verified_at AS "encounterVerifiedAt") SELECT * FROM changed`,[bookingId]);
      await m.query(`UPDATE trips SET status='IN_PROGRESS' WHERE id=$1`,[trip.id]);
      await m.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'ENCOUNTER_CONFIRMED','Encuentro confirmado','El conductor confirmó tu código en el Punto Vamos!',$2)`,[b.passenger_id,{tripId:trip.id,bookingId}]);
      return {...verified,status:'IN_PROGRESS'};
    });
    if('error' in result)throw new BadRequestException(result.error);
    return result;
  }

  async startTrip(_userId:string,_tripId:string,_code:string):Promise<never> {
    throw new BadRequestException('Actualiza Vamos a 1.8.5: primero avisa la salida y luego confirma el código individual de cada pasajero.');
  }

  async completeTrip(userId: string, tripId: string) {
    return this.db.transaction(async manager => {
      const [trip] = await manager.query(
        `WITH changed AS (
           UPDATE trips SET status='COMPLETED' WHERE id=$1 AND driver_id=$2
           AND status='IN_PROGRESS' AND (route_departed_at IS NULL OR NOT EXISTS(SELECT 1 FROM bookings b WHERE b.trip_id=trips.id AND b.status='ACCEPTED' AND b.encounter_verified_at IS NULL)) RETURNING id,status
         ) SELECT id,status FROM changed`, [tripId, userId]);
      if (!trip) throw new BadRequestException('No se puede finalizar el viaje: debe estar en curso y cada pasajero aceptado debe tener el encuentro confirmado o estar marcado como ausente.');
      await manager.query(`UPDATE bookings SET status='COMPLETED',completed_at=now() WHERE trip_id=$1 AND status='ACCEPTED'`, [tripId]);
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         SELECT passenger_id,'TRIP_COMPLETED','Viaje completado','Ya puedes calificar al conductor',$2
         FROM bookings WHERE trip_id=$1 AND status='COMPLETED'`,
        [tripId, { tripId }]);
      return trip;
    });
  }

  async rate(userId: string, dto: RatingDto) {
    const [rating] = await this.db.query(
      `INSERT INTO ratings(trip_id,from_user_id,to_user_id,overall,punctuality,kindness,safety,driving,comment)
       SELECT $1::uuid,$2::uuid,$3::uuid,$4,$5,$6,$7,$8,$9 FROM trips t
       WHERE t.id=$1::uuid AND t.status='COMPLETED' AND $2::uuid<>$3::uuid
       AND (t.driver_id=$2 OR EXISTS (
         SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2 AND b.status='COMPLETED'))
       AND (t.driver_id=$3 OR EXISTS (
         SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$3 AND b.status='COMPLETED'))
       ON CONFLICT (trip_id,from_user_id,to_user_id) DO NOTHING
       RETURNING id,overall`, [dto.tripId, userId, dto.toUserId, dto.overall, dto.punctuality, dto.kindness, dto.safety, dto.driving, dto.comment]);
    if (!rating) throw new BadRequestException('No puedes calificar a este usuario o ya lo calificaste');
    return rating;
  }

  ratings(userId: string) {
    return this.db.query(
      `SELECT r.id,r.overall,r.punctuality,r.kindness,r.safety,r.driving,
       r.comment,r.created_at AS "createdAt",u.first_name AS author
       FROM ratings r JOIN users u ON u.id=r.from_user_id
       WHERE r.to_user_id=$1 ORDER BY r.created_at DESC LIMIT 50`,
      [userId]);
  }

  async incident(userId: string, dto: IncidentDto) {
    const [incident] = await this.db.query(
      `INSERT INTO incidents(trip_id,reporter_id,reported_user_id,type,description)
       SELECT $1,$2,$3,$4,$5
       WHERE ($1::uuid IS NULL AND $3::uuid IS NULL) OR EXISTS (
         SELECT 1 FROM trips t WHERE t.id=$1
         AND (t.driver_id=$2 OR EXISTS (
           SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2))
         AND ($3::uuid IS NULL OR ($3<>$2 AND (t.driver_id=$3 OR EXISTS (
           SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$3))))
       )
       RETURNING id,type,description,status,created_at AS "createdAt"`,
      [dto.tripId, userId, dto.reportedUserId, dto.type, dto.description]);
    if (!incident) throw new ForbiddenException('No puedes reportar usuarios ajenos a este viaje');
    return incident;
  }

  incidents(userId: string) {
    return this.db.query(
      `SELECT id,trip_id AS "tripId",reported_user_id AS "reportedUserId",
       type,description,status,resolution_detail AS "resolutionDetail",resolved_at AS "resolvedAt",created_at AS "createdAt"
       FROM incidents WHERE reporter_id=$1 ORDER BY created_at DESC LIMIT 50`,
      [userId]);
  }

  async notifications(userId: string) {
    await this.matchSavedSearches(userId);
    return this.db.query(
      `SELECT id,type,title,body,data,read_at AS "readAt",created_at AS "createdAt"
       FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100`,
      [userId]);
  }

  async unreadNotifications(userId: string) {
    await this.matchSavedSearches(userId);
    const [result] = await this.db.query(
      'SELECT count(*)::int AS count FROM notifications WHERE user_id=$1 AND read_at IS NULL',
      [userId]);
    return result;
  }

  async readNotification(userId: string, id: string) {
    const [notification] = await this.db.query(
      `WITH changed AS (UPDATE notifications SET read_at=COALESCE(read_at,now())
       WHERE id=$1 AND user_id=$2 RETURNING id,read_at AS "readAt") SELECT * FROM changed`,
      [id, userId]);
    if (!notification) throw new NotFoundException('Notificación no encontrada');
    return notification;
  }

  async readAllNotifications(userId: string) {
    const result = await this.db.query(
      'UPDATE notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL RETURNING id',
      [userId]);
    return { updated: result.length };
  }

  async messages(userId: string, bookingId: string) {
    return this.db.transaction(async manager => {
      const [participant] = await manager.query(
        `SELECT b.passenger_id AS "passengerId",t.driver_id AS "driverId",b.status
         FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1`,
        [bookingId]);
      if (!participant ||
          ![participant.passengerId, participant.driverId].includes(userId) ||
          !['ACCEPTED', 'COMPLETED'].includes(participant.status)) {
        throw new ForbiddenException('El chat está disponible solo para reservas aceptadas');
      }
      await manager.query(
        'UPDATE messages SET read_at=now() WHERE booking_id=$1 AND recipient_id=$2 AND read_at IS NULL',
        [bookingId, userId]);
      return manager.query(
        `SELECT m.id,m.sender_id AS "senderId",u.first_name AS "senderName",
         m.body,m.read_at AS "readAt",m.created_at AS "createdAt",
         (m.sender_id=$2) AS "isMine"
         FROM messages m JOIN users u ON u.id=m.sender_id
         WHERE m.id IN (SELECT id FROM messages WHERE booking_id=$1 ORDER BY created_at DESC,id DESC LIMIT 300) ORDER BY m.created_at ASC,m.id ASC`,
        [bookingId, userId]);
    });
  }

  async sendMessage(userId: string, bookingId: string, dto: SendMessageDto) {
    const body = dto.body.trim();
    if (!body) throw new BadRequestException('El mensaje no puede estar vacío');
    return this.db.transaction(async manager => {
      const [participant] = await manager.query(
        `SELECT b.passenger_id AS "passengerId",t.driver_id AS "driverId",b.status
         FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1 FOR UPDATE OF b`,
        [bookingId]);
      if (!participant ||
          ![participant.passengerId, participant.driverId].includes(userId) ||
          !['ACCEPTED', 'COMPLETED'].includes(participant.status)) {
        throw new ForbiddenException('El chat está disponible solo para reservas aceptadas');
      }
      const recipientId = participant.passengerId === userId
        ? participant.driverId
        : participant.passengerId;
      const [message] = await manager.query(
        `INSERT INTO messages(booking_id,sender_id,recipient_id,body)
         VALUES($1,$2,$3,$4)
         RETURNING id,sender_id AS "senderId",body,read_at AS "readAt",
         created_at AS "createdAt",true AS "isMine"`,
        [bookingId, userId, recipientId, body]);
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         VALUES($1,'CHAT_MESSAGE','Nuevo mensaje',$2,$3)`,
        [recipientId, body.length > 120 ? `${body.substring(0, 117)}...` : body,
         { bookingId, messageId: message.id }]);
      return message;
    });
  }
}
