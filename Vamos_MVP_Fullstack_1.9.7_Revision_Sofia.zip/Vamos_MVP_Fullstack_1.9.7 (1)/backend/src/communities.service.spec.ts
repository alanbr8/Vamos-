import { CommunitiesService, CommunityDto, JoinCommunityDto, MemberDecisionDto, MemberRoleDto } from './communities.service';
import { validate } from 'class-validator';
describe('Comunidades',()=>{
 it('rechaza categorías y decisiones arbitrarias',async()=>{
 expect((await validate(Object.assign(new CommunityDto(),{name:'Grupo',description:'',category:'ADMIN'}))).length).toBeGreaterThan(0);
 expect((await validate(Object.assign(new MemberDecisionDto(),{status:'ADMIN'}))).length).toBeGreaterThan(0);
 expect((await validate(Object.assign(new MemberRoleDto(),{role:'OWNER'}))).length).toBeGreaterThan(0);
 });
 it('exige una explicación suficiente para solicitar ingreso',async()=>{
  expect((await validate(Object.assign(new JoinCommunityDto(),{code:'1234567890123456',reason:'muy breve'}))).length).toBeGreaterThan(0);
  expect(await validate(Object.assign(new JoinCommunityDto(),{code:'1234567890123456',reason:'Trabajo en esta organización y deseo compartir mis recorridos.'}))).toHaveLength(0);
 });
 it('responde con error controlado si el ingreso no trae datos',async()=>{
  const service=new CommunitiesService({transaction:(fn:Function)=>fn({query:jest.fn()})} as any);
  await expect(service.join('user',null as any)).rejects.toThrow('Código y motivo');
 });
 it('exige una causa para rechazar o retirar de una comunidad',async()=>{
  const transaction=jest.fn();const service=new CommunitiesService({transaction} as any);
  await expect(service.decide('admin','group','member','REJECTED','')).rejects.toThrow('Indica una causa');
  expect(transaction).not.toHaveBeenCalled();
 });
 it('no consulta miembros sin administración',async()=>{
 const query=jest.fn().mockResolvedValue([]);const s=new CommunitiesService({query} as any);
 await expect(s.members('other','group')).rejects.toThrow();expect(query).toHaveBeenCalledTimes(1);
 });
 it('no entrega viajes sin aprobación',async()=>{
 const query=jest.fn().mockResolvedValue([{allowed:false}]);const s=new CommunitiesService({query} as any);
 await expect(s.trips('pending','group')).rejects.toThrow();expect(query).toHaveBeenCalledTimes(1);
 });
});
