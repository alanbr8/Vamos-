import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { ActionReasonDto, SaveSearchDto, BookingDto, CodeDto, ForgotPasswordDto, IncidentDto, LoginDto, RatingDto, RegisterDto, ResetPasswordDto, SearchTripsDto, SendMessageDto, TripDto, VehicleDto } from './dtos';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';

@Controller()
export class ApiController {
  constructor(private readonly api: ApiService, private readonly auth: AuthService) {}

  @Get('health') health() { return { status: 'ok', service: 'vamos-api' }; }
  @Post('auth/register') register(@Body() dto: RegisterDto) { return this.auth.register(dto); }
  @Post('auth/login') login(@Body() dto: LoginDto) { return this.auth.login(dto); }
  @Post('auth/forgot-password') forgotPassword(@Body() dto: ForgotPasswordDto) { return this.auth.requestPasswordReset(dto); }
  @Post('auth/reset-password') resetPassword(@Body() dto: ResetPasswordDto) { return this.auth.resetPassword(dto); }

  @UseGuards(JwtAuthGuard) @Get('users/me') profile(@Req() req: AuthRequest) { return this.api.profile(req.userId); }
  @UseGuards(JwtAuthGuard) @Get('vehicles/me') vehicles(@Req() req: AuthRequest) { return this.api.vehicles(req.userId); }
  @UseGuards(JwtAuthGuard) @Post('vehicles') createVehicle(@Req() req: AuthRequest, @Body() dto: VehicleDto) { return this.api.createVehicle(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Post('trips') createTrip(@Req() req: AuthRequest, @Body() dto: TripDto) { return this.api.createTrip(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Post('trips/search') search(@Req() req: AuthRequest, @Body() dto: SearchTripsDto) { return this.api.search(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Post('saved-searches') saveSearch(@Req() req: AuthRequest, @Body() dto: SaveSearchDto) { return this.api.saveSearch(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Get('saved-searches') savedSearches(@Req() req: AuthRequest) { return this.api.savedSearches(req.userId); }
  @UseGuards(JwtAuthGuard) @Patch('saved-searches/:id/cancel') cancelSearch(@Req() req: AuthRequest, @Param('id') id: string) { return this.api.cancelSearch(req.userId, id); }
  @UseGuards(JwtAuthGuard) @Post('bookings') createBooking(@Req() req: AuthRequest, @Body() dto: BookingDto) { return this.api.createBooking(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Get('trips/me/driver') driverTrips(@Req() req: AuthRequest) { return this.api.driverTrips(req.userId); }
  @UseGuards(JwtAuthGuard) @Get('bookings/me') passengerBookings(@Req() req: AuthRequest) { return this.api.passengerBookings(req.userId); }
  @UseGuards(JwtAuthGuard) @Patch('bookings/:id/verify-encounter') encounter(@Req() req:AuthRequest,@Param('id') id:string,@Body() dto:CodeDto){return this.api.verifyEncounter(req.userId,id,dto.code);}
  @UseGuards(JwtAuthGuard) @Patch('bookings/:id/confirm-arrival') confirmArrival(@Req() req: AuthRequest, @Param('id') id: string) { return this.api.confirmArrival(req.userId, id); }
  @UseGuards(JwtAuthGuard) @Patch('bookings/:id/:action') bookingAction(@Req() req: AuthRequest, @Param('id') id: string, @Param('action') action: string, @Body() dto: ActionReasonDto) { return dto?.reason == null ? this.api.bookingAction(req.userId, id, action) : this.api.bookingAction(req.userId, id, action, dto.reason); }
  @UseGuards(JwtAuthGuard) @Patch('trips/:id') updateTrip(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: TripDto) { return this.api.updateTrip(req.userId,id,dto); }
  @UseGuards(JwtAuthGuard) @Patch('trips/:id/cancel') cancelTrip(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: ActionReasonDto) { return this.api.cancelTrip(req.userId,id,dto.reason); }
  @UseGuards(JwtAuthGuard) @Patch('trips/:id/depart') depart(@Req() req: AuthRequest,@Param('id') id:string){return this.api.departTrip(req.userId,id);}
  @UseGuards(JwtAuthGuard) @Patch('trips/:id/start') start(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: CodeDto) { return this.api.startTrip(req.userId, id, dto.code); }
  @UseGuards(JwtAuthGuard) @Patch('trips/:id/complete') complete(@Req() req: AuthRequest, @Param('id') id: string) { return this.api.completeTrip(req.userId, id); }
  @UseGuards(JwtAuthGuard) @Post('ratings') rate(@Req() req: AuthRequest, @Body() dto: RatingDto) { return this.api.rate(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Get('ratings/me') ratings(@Req() req: AuthRequest) { return this.api.ratings(req.userId); }
  @UseGuards(JwtAuthGuard) @Post('incidents') incident(@Req() req: AuthRequest, @Body() dto: IncidentDto) { return this.api.incident(req.userId, dto); }
  @UseGuards(JwtAuthGuard) @Get('incidents/me') incidents(@Req() req: AuthRequest) { return this.api.incidents(req.userId); }
  @UseGuards(JwtAuthGuard) @Get('notifications') notifications(@Req() req: AuthRequest) { return this.api.notifications(req.userId); }
  @UseGuards(JwtAuthGuard) @Get('notifications/unread-count') unreadNotifications(@Req() req: AuthRequest) { return this.api.unreadNotifications(req.userId); }
  @UseGuards(JwtAuthGuard) @Patch('notifications/read-all') readAllNotifications(@Req() req: AuthRequest) { return this.api.readAllNotifications(req.userId); }
  @UseGuards(JwtAuthGuard) @Patch('notifications/:id/read') readNotification(@Req() req: AuthRequest, @Param('id') id: string) { return this.api.readNotification(req.userId, id); }
  @UseGuards(JwtAuthGuard) @Get('bookings/:id/messages') messages(@Req() req: AuthRequest, @Param('id') id: string) { return this.api.messages(req.userId, id); }
  @UseGuards(JwtAuthGuard) @Post('bookings/:id/messages') sendMessage(@Req() req: AuthRequest, @Param('id') id: string, @Body() dto: SendMessageDto) { return this.api.sendMessage(req.userId, id, dto); }
}
