-- Vamos!! 1.9.9: aceptación verificable de términos, privacidad y ubicación.
-- Ejecutar en Neon: rama production, base neondb.
-- Repetible y sin borrado de datos.
BEGIN;

ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_version varchar(20);
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS privacy_version varchar(20);
ALTER TABLE users ADD COLUMN IF NOT EXISTS privacy_accepted_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS location_consent_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS adult_declared_at timestamptz;

CREATE INDEX IF NOT EXISTS users_terms_acceptance_idx
  ON users(terms_accepted_at DESC)
  WHERE terms_accepted_at IS NOT NULL;

COMMIT;

SELECT
  count(*)::int AS usuarios,
  count(*) FILTER (WHERE terms_accepted_at IS NOT NULL)::int AS aceptaron_terminos,
  count(*) FILTER (WHERE privacy_accepted_at IS NOT NULL)::int AS aceptaron_privacidad,
  count(*) FILTER (WHERE location_consent_at IS NOT NULL)::int AS autorizaron_ubicacion
FROM users;
