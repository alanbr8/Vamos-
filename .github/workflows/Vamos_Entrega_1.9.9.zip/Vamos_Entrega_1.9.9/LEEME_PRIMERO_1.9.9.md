# Vamos!! 1.9.9 — orden de actualización

Esta entrega reúne todos los archivos de la versión en un solo ZIP descargable.

1. En Neon, selecciona la rama **production** y la base **neondb**.
2. Abre SQL Editor, pega todo `MIGRACION_1.9.9_NEON.sql` y pulsa **Run**.
3. En GitHub elimina el ZIP anterior de la versión y sube los archivos incluidos en esta entrega: el ZIP 1.9.9, `Dockerfile`, `render-web-build.sh`, los tres flujos dentro de `.github/workflows/` y `terminos.html`.
4. Confirma en GitHub Actions que **Verificar Vamos Web** finalice correctamente.
5. En Render despliega primero **Vamos-api** y después **vamos-web**.
6. Ejecuta manualmente **Compilar Vamos Android** y descarga el APK de prueba generado.

No cambies `DOCUMENT_ENCRYPTION_KEY`, `JWT_SECRET`, la firma Android ni las credenciales Firebase existentes.

La Inspección Técnica Vehicular fue omitida por decisión del proyecto. Se mantienen licencia, fotografías del vehículo y SOAT vigente.
