# Vamos!! 1.9.8 — ruta personalizada y alerta Punto Vamos!

## Mejoras

- El conductor puede conservar la ruta sugerida o seleccionar **Personalizar ruta**.
- La personalización se realiza colocando hasta 8 puntos intermedios sobre calles; el servicio de rutas ajusta cada tramo a vías transitables.
- Se puede deshacer el último punto o borrar toda la personalización antes de calcular.
- Cuando el conductor comparte su ubicación en vivo, el pasajero recibe una alerta al encontrarse a menos de 500 metros de su Punto Vamos!.
- Al acercarse a menos de 150 metros se genera la alerta **¡Tu conductor llegó!**.
- Cada alerta se registra una sola vez por reserva y queda en el historial de notificaciones.
- Para ofrecer viajes es obligatorio tener foto de perfil aprobada, identidad verificada, licencia de conducir, vehículo registrado, fotos del vehículo y SOAT vigente y aprobados.

## Condiciones de funcionamiento

- El viaje debe estar aceptado y tener Punto Vamos! definido.
- El conductor debe haber avisado su salida y activar **Ubicación en vivo**.
- El pasajero debe permitir notificaciones para recibir el aviso fuera de la aplicación.
- Si las notificaciones están desactivadas, el aviso permanece disponible dentro de Vamos!!.

## Despliegue

1. Subir `Vamos_MVP_Fullstack_1.9.8.zip` a la raíz de GitHub.
2. Reemplazar `main.yml`, `web.yml` e `ios.yml` con los archivos de `delivery/`.
3. Actualizar `Dockerfile` y `render-web-build.sh` para usar `Vamos_MVP_Fullstack_1.9.8.zip`.
4. Desplegar primero `vamos-api` y luego `vamos-web` en Render.
5. Esta versión no requiere una nueva migración de Neon.
