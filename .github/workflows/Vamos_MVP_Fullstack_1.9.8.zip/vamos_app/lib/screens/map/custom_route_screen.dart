import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../core/theme/app_theme.dart';
import '../../models/map_point.dart';

class CustomRouteScreen extends StatefulWidget {
  const CustomRouteScreen({super.key, required this.origin, required this.destination, this.initialWaypoints = const []});
  final MapPoint origin;
  final MapPoint destination;
  final List<MapPoint> initialWaypoints;

  @override
  State<CustomRouteScreen> createState() => _CustomRouteScreenState();
}

class _CustomRouteScreenState extends State<CustomRouteScreen> {
  late final List<MapPoint> points = [...widget.initialWaypoints];

  List<LatLng> get line => [
    LatLng(widget.origin.latitude, widget.origin.longitude),
    ...points.map((p) => LatLng(p.latitude, p.longitude)),
    LatLng(widget.destination.latitude, widget.destination.longitude),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Personalizar ruta')),
    body: Column(children: [
      const Padding(
        padding: EdgeInsets.all(12),
        child: Text('Toca calles por las que deseas pasar. Vamos!! ajustará cada tramo a vías transitables. Máximo 8 puntos.'),
      ),
      Expanded(child: FlutterMap(
        options: MapOptions(
          initialCenter: line.first,
          initialZoom: 13,
          onTap: (_, position) {
            if (points.length >= 8) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Puedes colocar hasta 8 puntos intermedios.')));
              return;
            }
            setState(() => points.add(MapPoint(latitude: position.latitude, longitude: position.longitude, label: 'Punto ${points.length + 1}')));
          },
        ),
        children: [
          TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.vamoscarpool.app'),
          PolylineLayer(polylines: [Polyline(points: line, color: AppColors.green, strokeWidth: 5)]),
          MarkerLayer(markers: [
            Marker(point: line.first, width: 44, height: 44, child: const Icon(Icons.trip_origin, color: Colors.green, size: 34)),
            ...List.generate(points.length, (i) => Marker(point: LatLng(points[i].latitude, points[i].longitude), width: 52, height: 52, child: CircleAvatar(backgroundColor: Colors.blue, foregroundColor: Colors.white, child: Text('${i + 1}')))),
            Marker(point: line.last, width: 44, height: 44, child: const Icon(Icons.location_on, color: Colors.red, size: 38)),
          ]),
          const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap')]),
        ],
      )),
      SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: points.isEmpty ? null : () => setState(() => points.removeLast()), icon: const Icon(Icons.undo), label: const Text('DESHACER'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: points.isEmpty ? null : () => setState(points.clear), icon: const Icon(Icons.delete_outline), label: const Text('BORRAR'))),
          ]),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(context, points), child: Text(points.isEmpty ? 'USAR RUTA SUGERIDA' : 'CALCULAR ESTA RUTA'))),
        ]),
      )),
    ]),
  );
}
