import { Body, Controller, Get, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Req, UseGuards, Header, ServiceUnavailableException } from '@nestjs/common';
import { IsDateString, IsNumber, IsString, Length, Max, Min } from 'class-validator';
import { randomBytes, createHash } from 'node:crypto';
import { DataSource } from 'typeorm';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
export class PositionDto {
 @IsNumber() @Min(-90) @Max(90) latitude!:number;
 @IsNumber() @Min(-180) @Max(180) longitude!:number;
 @IsNumber() @Min(0) @Max(1000) accuracy!:number;
 @IsDateString() recordedAt!:string;
}
export class ShareTokenDto { @IsString() @Length(64,64) token!:string; }
const live="t.route_departed_at IS NOT NULL AND t.route_departed_at>now()-interval '24 hours' AND t.status IN ('PUBLISHED','RESERVED','IN_PROGRESS')";
@Injectable()
export class TrackingService {
 private cleanup?:NodeJS.Timeout;
 onModuleInit(){this.cleanup=setInterval(()=>{void this.db.query("DELETE FROM trip_live_positions p USING trips t WHERE p.trip_id=t.id AND (NOT t.tracking_enabled OR t.status IN ('COMPLETED','CANCELLED') OR t.route_departed_at<=now()-interval '24 hours')").catch(()=>{});void this.db.query('DELETE FROM trip_share_links WHERE expires_at<=now()').catch(()=>{});},60000);this.cleanup.unref();}
 onModuleDestroy(){if(this.cleanup)clearInterval(this.cleanup);}
 constructor(private readonly db:DataSource){}
 private async query(sql:string,parameters:any[]=[]):Promise<any[]> {
  try { return await this.db.query(sql,parameters); }
  catch(error:any) {
   const code=error?.driverError?.code ?? error?.code;
   if(code==='42P01'||code==='42703') throw new ServiceUnavailableException('El seguimiento necesita una actualización de la base de datos. El administrador debe ejecutar la migración 016.');
   throw error;
  }
 }
 async toggle(user:string,id:string,enabled:boolean){
  return this.db.transaction(async m=>{
   const [trip]=await m.query(`SELECT t.id FROM trips t WHERE t.id=$1 AND t.driver_id=$2 AND ${live} FOR UPDATE`,[id,user]);
   if(!trip)throw new NotFoundException('El seguimiento no está disponible para este viaje.');
   await m.query('UPDATE trips SET tracking_enabled=$2 WHERE id=$1',[id,enabled]);
   if(!enabled)await m.query('DELETE FROM trip_live_positions WHERE trip_id=$1',[id]);
   return {enabled};
  });
 }
 async position(user:string,id:string,dto:PositionDto){
  const age=Date.now()-Date.parse(dto.recordedAt);
  if(!Number.isFinite(age)||age>120000||age< -30000)return {accepted:false};
  return this.db.transaction(async m=>{
   const [trip]=await m.query(`SELECT t.id FROM trips t JOIN users u ON u.id=t.driver_id WHERE t.id=$1 AND t.driver_id=$2 AND u.status='ACTIVE' AND t.tracking_enabled AND ${live} FOR UPDATE OF t`,[id,user]);
   if(!trip)throw new NotFoundException('Seguimiento detenido.');
   await m.query(`INSERT INTO trip_live_positions(trip_id,latitude,longitude,accuracy,recorded_at) VALUES($1,$2,$3,$4,$5)
    ON CONFLICT(trip_id) DO UPDATE SET latitude=EXCLUDED.latitude,longitude=EXCLUDED.longitude,accuracy=EXCLUDED.accuracy,recorded_at=EXCLUDED.recorded_at,received_at=now()
    WHERE EXCLUDED.recorded_at>trip_live_positions.recorded_at`,[id,dto.latitude,dto.longitude,dto.accuracy,dto.recordedAt]);
   await m.query(`INSERT INTO notifications(user_id,type,title,body,data)
    SELECT b.passenger_id,'DRIVER_NEAR_MEETING','Tu conductor está cerca','Está a menos de 500 metros de tu Punto Vamos!. Prepárate para abordar.',jsonb_build_object('tripId',b.trip_id,'bookingId',b.id,'distanceMeters',round(ST_Distance(b.meeting_point::geography,ST_SetSRID(ST_MakePoint($3,$2),4326)::geography)))
    FROM bookings b WHERE b.trip_id=$1 AND b.status='ACCEPTED' AND b.meeting_point IS NOT NULL
      AND ST_DWithin(b.meeting_point::geography,ST_SetSRID(ST_MakePoint($3,$2),4326)::geography,500)
      AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.user_id=b.passenger_id AND n.type='DRIVER_NEAR_MEETING' AND n.data->>'bookingId'=b.id::text)`,[id,dto.latitude,dto.longitude]);
   await m.query(`INSERT INTO notifications(user_id,type,title,body,data)
    SELECT b.passenger_id,'DRIVER_AT_MEETING','¡Tu conductor llegó!','El vehículo está en tu Punto Vamos!. Dirígete al lugar acordado.',jsonb_build_object('tripId',b.trip_id,'bookingId',b.id,'distanceMeters',round(ST_Distance(b.meeting_point::geography,ST_SetSRID(ST_MakePoint($3,$2),4326)::geography)))
    FROM bookings b WHERE b.trip_id=$1 AND b.status='ACCEPTED' AND b.meeting_point IS NOT NULL
      AND ST_DWithin(b.meeting_point::geography,ST_SetSRID(ST_MakePoint($3,$2),4326)::geography,150)
      AND NOT EXISTS(SELECT 1 FROM notifications n WHERE n.user_id=b.passenger_id AND n.type='DRIVER_AT_MEETING' AND n.data->>'bookingId'=b.id::text)`,[id,dto.latitude,dto.longitude]);
   return {accepted:true};
  });
 }
 async read(user:string,id:string){
  const [allowed]=await this.query(`SELECT t.id FROM trips t WHERE t.id=$1 AND ${live} AND (t.driver_id=$2 OR EXISTS(SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2 AND b.status='ACCEPTED'))`,[id,user]);
  if(!allowed)throw new NotFoundException('Seguimiento no disponible.');
  return this.snapshot(id);
 }
 private async snapshot(id:string){
  const [row]=await this.query(`SELECT t.status,t.tracking_enabled AS enabled,ST_X(t.origin::geometry) AS "originLng",ST_Y(t.origin::geometry) AS "originLat",ST_X(t.destination::geometry) AS "destinationLng",ST_Y(t.destination::geometry) AS "destinationLat",ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS route,t.preferences->'routeEstimate' AS "routeEstimate",
    p.latitude,p.longitude,p.accuracy,p.recorded_at AS "recordedAt",now() AS "serverTime"
    FROM trips t JOIN users u ON u.id=t.driver_id LEFT JOIN trip_live_positions p ON p.trip_id=t.id AND t.tracking_enabled WHERE t.id=$1 AND u.status='ACTIVE' AND ${live}`,[id]);
  if(!row)throw new NotFoundException('Este seguimiento terminó o no está disponible.');
  return row;
 }
 async share(user:string,booking:string){
  const token=randomBytes(32).toString('hex');
  const rows=await this.query(`INSERT INTO trip_share_links(booking_id,token_hash,expires_at)
   SELECT b.id,$3,t.route_departed_at+interval '24 hours' FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1 AND b.passenger_id=$2 AND b.status='ACCEPTED' AND ${live}
   ON CONFLICT(booking_id) DO UPDATE SET token_hash=EXCLUDED.token_hash,expires_at=EXCLUDED.expires_at RETURNING expires_at AS "expiresAt"`,[booking,user,createHash('sha256').update(token).digest('hex')]);
  if(!rows[0])throw new NotFoundException('Solo puedes compartir tu reserva aceptada durante el viaje.');
  return {token,expiresAt:rows[0].expiresAt};
 }
 async revoke(user:string,booking:string){
  await this.query('DELETE FROM trip_share_links s USING bookings b WHERE s.booking_id=b.id AND b.id=$1 AND b.passenger_id=$2',[booking,user]);
  return {revoked:true};
 }
 async shared(token:string){
  const [row]=await this.query(`SELECT b.trip_id FROM trip_share_links s JOIN bookings b ON b.id=s.booking_id JOIN users u ON u.id=b.passenger_id WHERE s.token_hash=$1 AND s.expires_at>now() AND b.status='ACCEPTED' AND u.status='ACTIVE'`,[createHash('sha256').update(token).digest('hex')]);
  if(!row)throw new NotFoundException('El enlace venció o fue revocado.');
  return this.snapshot(row.trip_id);
 }
}
@Controller('tracking')
export class TrackingController {
 constructor(private readonly tracking:TrackingService){}
 @UseGuards(JwtAuthGuard) @Post(':id/start') start(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.tracking.toggle(r.userId,id,true);}
 @UseGuards(JwtAuthGuard) @Post(':id/stop') stop(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.tracking.toggle(r.userId,id,false);}
 @UseGuards(JwtAuthGuard) @Post(':id/position') position(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() dto:PositionDto){return this.tracking.position(r.userId,id,dto);}
 @UseGuards(JwtAuthGuard) @Get(':id') @Header('Cache-Control','no-store') read(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.tracking.read(r.userId,id);}
 @UseGuards(JwtAuthGuard) @Post('booking/:id/share') share(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.tracking.share(r.userId,id);}
 @UseGuards(JwtAuthGuard) @Post('booking/:id/revoke') revoke(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.tracking.revoke(r.userId,id);}
 @Post('shared') @Header('Cache-Control','no-store') shared(@Body() dto:ShareTokenDto){return this.tracking.shared(dto.token);}
}
