import { Body, Controller, Injectable, Logger, OnModuleDestroy, OnModuleInit, Post, Req, UseGuards } from '@nestjs/common';
import { IsString, Length } from 'class-validator';
import { DataSource } from 'typeorm';
import { createSign } from 'node:crypto';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';

export class PushTokenDto { @IsString() @Length(20,4096) token!:string; }
export function pushContent(n:{type:string;id:string;user_id:string}) {
  const near=n.type==='DRIVER_NEAR_MEETING',arrived=n.type==='DRIVER_AT_MEETING';
  // No se envían mensajes de chat ni detalles de incidentes/documentos a la pantalla bloqueada.
  return {
    notification:{title:arrived?'¡Tu conductor llegó!':near?'Tu conductor está cerca':n.type==='ROUTE_DEPARTED'?'¡Tu conductor está saliendo!':'Vamos! · Nueva notificación',body:arrived?'Está en tu Punto Vamos!.':near?'Está a menos de 500 metros. Prepárate para abordar.':n.type==='ROUTE_DEPARTED'?'Prepárate para tu Punto Vamos! y coordina por el chat.':'Abre Vamos para consultar la actualización.'},
    data:{notificationId:n.id,userId:n.user_id,type:n.type},
    android:{priority:'high',ttl:(near||arrived||n.type==='ROUTE_DEPARTED')?'900s':'86400s',notification:{tag:n.id,channelId:(near||arrived)?'vamos_arrival_alerts':undefined}},
  };
}
@Injectable()
export class PushService implements OnModuleInit,OnModuleDestroy {
  private timer?:NodeJS.Timeout;
  private running=false;
  private cached?:{token:string;until:number};
  private logger=new Logger(PushService.name);
  constructor(private readonly db:DataSource){}
  onModuleInit(){
    if(process.env.PUSH_ENABLED!=='true')return;
    try{this.credentials();}catch{this.logger.error('Push desactivado: revisa FIREBASE_SERVICE_ACCOUNT_JSON');return;}
    this.timer=setInterval(()=>void this.tick(),5000);this.timer.unref();void this.tick();
  }
  onModuleDestroy(){if(this.timer)clearInterval(this.timer);}
  register(user:string,token:string){
    return this.db.query(`INSERT INTO push_devices(user_id,token) VALUES($1,$2) ON CONFLICT(token) DO UPDATE SET
      binding=CASE WHEN push_devices.user_id=EXCLUDED.user_id THEN push_devices.binding ELSE gen_random_uuid() END,user_id=EXCLUDED.user_id,updated_at=now() RETURNING id`,[user,token]).then(()=>({registered:true}));
  }
  async unregister(user:string,token:string){await this.db.query('DELETE FROM push_devices WHERE user_id=$1 AND token=$2',[user,token]);return {removed:true};}
  private credentials(){
    const c=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'{}');
    if(typeof c.project_id!=='string'||!/^[a-z0-9-]+$/.test(c.project_id)||typeof c.client_email!=='string'||typeof c.private_key!=='string')throw Error('CONFIG');
    return c as {project_id:string;client_email:string;private_key:string};
  }
  private async accessToken(){
    if(this.cached&&this.cached.until>Date.now())return this.cached.token;
    const c=this.credentials(),now=Math.floor(Date.now()/1000);
    const encode=(v:unknown)=>Buffer.from(JSON.stringify(v)).toString('base64url');
    const unsigned=encode({alg:'RS256',typ:'JWT'})+'.'+encode({iss:c.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600});
    const signature=createSign('RSA-SHA256').update(unsigned).sign(c.private_key,'base64url');
    const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion:unsigned+'.'+signature}),signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw Error('FCM_AUTH');
    const data=await response.json() as {access_token?:string};if(!data.access_token)throw Error('FCM_AUTH');
    this.cached={token:data.access_token,until:Date.now()+50*60000};return data.access_token;
  }
  async tick(){
    if(this.running)return;this.running=true;
    try{
      await this.db.query(`UPDATE push_deliveries SET status='EXPIRED' WHERE status='PENDING' AND (expires_at<=now() OR NOT EXISTS(SELECT 1 FROM push_devices d JOIN users u ON u.id=d.user_id WHERE d.id=push_deliveries.device_id AND d.user_id=push_deliveries.user_id AND d.binding=push_deliveries.binding AND u.status='ACTIVE'))`);
      const jobs=await this.db.query(`WITH candidates AS (
        SELECT id FROM push_deliveries WHERE status='PENDING' AND next_at<=now() AND expires_at>now() ORDER BY next_at LIMIT 5 FOR UPDATE SKIP LOCKED
      ), claimed AS (UPDATE push_deliveries p SET attempts=attempts+1,next_at=now()+interval '2 minutes' FROM candidates c WHERE p.id=c.id RETURNING p.*)
      SELECT c.*,n.type,n.id AS notice_id FROM claimed c JOIN notifications n ON n.id=c.notification_id`);
      for(const job of jobs){
        try{
          // Revalidar la sesión/dispositivo justo antes del envío evita entregar colas antiguas a otra cuenta.
          const [device]=await this.db.query(`SELECT d.token FROM push_devices d JOIN users u ON u.id=d.user_id WHERE d.id=$1 AND d.binding=$2 AND d.user_id=$3 AND u.status='ACTIVE'`,[job.device_id,job.binding,job.user_id]);
          if(!device){await this.finish(job.id,'EXPIRED');continue;}
          const token=await this.accessToken(),c=this.credentials();
          const response=await fetch(`https://fcm.googleapis.com/v1/projects/${c.project_id}/messages:send`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({message:{token:device.token,...pushContent({id:job.notice_id,user_id:job.user_id,type:job.type})}}),signal:AbortSignal.timeout(10000)});
          if(response.ok){await this.finish(job.id,'SENT');continue;}
          const error=await response.json() as {error?:{details?:{errorCode?:string}[]}};
          if(error.error?.details?.some(d=>d.errorCode==='UNREGISTERED')){
            await this.db.query('DELETE FROM push_devices WHERE id=$1 AND binding=$2',[job.device_id,job.binding]);continue;
          }
          if(response.status===401)this.cached=undefined;
          throw Error(`FCM_HTTP_${response.status}`);
        }catch(error){
          const code=error instanceof Error&&/^FCM_(AUTH|HTTP_\d+)$/.test(error.message)?error.message:'FCM_SEND_FAILED';
          await this.db.query(`UPDATE push_deliveries SET status=$2,last_error=$3,next_at=now()+($4::int*interval '1 second') WHERE id=$1`,[job.id,job.attempts>=6?'FAILED':'PENDING',code,Math.min(3600,30*2**job.attempts)]);
          this.logger.warn(`No se entregó push (${code}); se conserva la notificación dentro de la app`);
        }
      }
      await this.db.query("DELETE FROM push_deliveries WHERE status<>'PENDING' AND expires_at<now()-interval '7 days'");
    }catch{this.logger.error('No se pudo procesar la cola push; revisa migración 011 y conexión a la base');}
    finally{this.running=false;}
  }
  private finish(id:string,status:string){return this.db.query('UPDATE push_deliveries SET status=$2,last_error=NULL WHERE id=$1',[id,status]);}
}
@Controller('push')
@UseGuards(JwtAuthGuard)
export class PushController {
  constructor(private readonly push:PushService){}
  @Post('register') register(@Req() r:AuthRequest,@Body() d:PushTokenDto){return this.push.register(r.userId,d.token);}
  @Post('unregister') unregister(@Req() r:AuthRequest,@Body() d:PushTokenDto){return this.push.unregister(r.userId,d.token);}
}
