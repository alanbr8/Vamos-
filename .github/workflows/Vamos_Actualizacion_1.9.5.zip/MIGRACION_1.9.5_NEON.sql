-- Vamos!! 1.9.5. Repetible y sin borrado de datos.
BEGIN;

ALTER TABLE community_members ADD COLUMN IF NOT EXISTS rejection_count integer NOT NULL DEFAULT 0;
ALTER TABLE community_members ADD COLUMN IF NOT EXISTS retry_at timestamptz;

WITH counts AS (
 SELECT m.community_id,m.user_id,count(n.id)::integer AS total
 FROM community_members m LEFT JOIN notifications n ON n.user_id=m.user_id
  AND n.type='COMMUNITY_REVIEW' AND n.data->>'communityId'=m.community_id::text
  AND n.data->>'status'='REJECTED' AND COALESCE((n.data->>'removed')::boolean,false)=false
 WHERE m.status='REJECTED' GROUP BY m.community_id,m.user_id
)
UPDATE community_members m SET rejection_count=GREATEST(m.rejection_count,c.total),
 retry_at=CASE WHEN GREATEST(m.rejection_count,c.total)=1 THEN m.reviewed_at+interval '3 days'
               WHEN GREATEST(m.rejection_count,c.total)=2 THEN m.reviewed_at+interval '7 days' ELSE NULL END
FROM counts c WHERE c.community_id=m.community_id AND c.user_id=m.user_id;

ALTER TABLE community_members DROP CONSTRAINT IF EXISTS community_members_status_check;
ALTER TABLE community_members ADD CONSTRAINT community_members_status_check
 CHECK(status IN ('PENDING','APPROVED','REJECTED','LEFT','REMOVED'));
CREATE INDEX IF NOT EXISTS community_members_retry_idx ON community_members(user_id,community_id,status,retry_at);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_origin geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_destination geography(Point,4326);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS passenger_route geography(LineString,4326);
CREATE INDEX IF NOT EXISTS bookings_passenger_route_idx ON bookings USING gist(passenger_route);

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS accepted_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS rejected_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS no_show_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS completed_at timestamptz;

UPDATE bookings SET accepted_at=COALESCE(accepted_at,created_at)
 WHERE status IN ('ACCEPTED','COMPLETED','CANCELLED','NO_SHOW') AND accepted_at IS NULL;
UPDATE bookings SET completed_at=COALESCE(completed_at,encounter_verified_at,created_at)
 WHERE status='COMPLETED' AND completed_at IS NULL;
UPDATE bookings SET cancelled_at=COALESCE(cancelled_at,created_at)
 WHERE status='CANCELLED' AND cancelled_at IS NULL;
UPDATE bookings SET rejected_at=COALESCE(rejected_at,created_at)
 WHERE status='REJECTED' AND rejected_at IS NULL;
UPDATE bookings SET no_show_at=COALESCE(no_show_at,created_at)
 WHERE status='NO_SHOW' AND no_show_at IS NULL;
CREATE INDEX IF NOT EXISTS bookings_ledger_idx
 ON bookings(COALESCE(completed_at,encounter_verified_at,accepted_at,created_at) DESC)
 WHERE accepted_at IS NOT NULL;

COMMIT;
