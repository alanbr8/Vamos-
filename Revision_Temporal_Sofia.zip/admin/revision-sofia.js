const form = document.querySelector('#acceso');
const clave = document.querySelector('#clave');
const estado = document.querySelector('#estado');
const registros = document.querySelector('#registros');
const titulos = { perfil: 'Perfil', identidad: 'Identidad', vehiculo: 'Vehículo' };

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const token = clave.value.trim();
  clave.value = '';
  registros.replaceChildren();
  estado.textContent = 'Consultando…';
  const button = form.querySelector('button');
  button.disabled = true;
  try {
    const response = await fetch('/admin/revision-sofia/datos', {
      headers: { Authorization: 'Bearer ' + token },
      cache: 'no-store',
    });
    if (!response.ok) {
      estado.textContent = 'La clave es incorrecta o el acceso ha vencido.';
      return;
    }
    const datos = await response.json();
    for (const [grupo, campos] of Object.entries(datos)) {
      const titulo = document.createElement('h2');
      titulo.textContent = titulos[grupo];
      const lista = document.createElement('dl');
      for (const [campo, valor] of Object.entries(campos)) {
        const etiqueta = document.createElement('dt');
        etiqueta.textContent = campo;
        const dato = document.createElement('dd');
        dato.textContent = valor;
        lista.append(etiqueta, dato);
      }
      registros.append(titulo, lista);
    }
    estado.textContent = 'Registros ficticios cargados.';
  } catch {
    estado.textContent = 'No se pudo consultar. Intenta nuevamente.';
  } finally {
    button.disabled = false;
  }
});
