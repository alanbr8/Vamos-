# Activar la revisión de Sofía

Integra los archivos de este ZIP en el código fuente de Vamos!!.
En el arranque de la API, importa `mountReviewPanel` desde `./review-panel`
y llama a `mountReviewPanel(app)` inmediatamente antes de `mountAdminPanel(app)`.
El ZIP incluye el cambio en main.ts para la base 1.10.0. Incorpora solo esas
dos líneas si tu versión de main.ts tiene otros cambios.

En un equipo de confianza genera la clave y su huella:

```sh
node -e 'const c=require("node:crypto");const t=c.randomBytes(32).toString("hex");console.log("Clave temporal:",t);console.log("SOFIA_REVIEW_TOKEN_SHA256:",c.createHash("sha256").update(t).digest("hex"));console.log("SOFIA_REVIEW_EXPIRES_AT:",new Date(Date.now()+72*3600000).toISOString())'
```

Configura las dos variables SOFIA en el servicio Vamos-api de Render y
despliega el código actualizado. Comparte la clave temporal por un canal
privado. La URL es /admin/revision-sofia/ en el mismo dominio de la API.

Verifica que una clave incorrecta no muestre datos y que con la clave correcta
solo aparezcan ejemplos ficticios. Para revocar el acceso antes de tiempo,
elimina SOFIA_REVIEW_TOKEN_SHA256 y aplica el cambio en Render. El vencimiento
se comprueba en cada solicitud. Esta vista no utiliza la base de datos ni
las credenciales del panel general.
