import type { INestApplication } from '@nestjs/common';
import type { Request, Response } from 'express';
import { createHash, timingSafeEqual } from 'node:crypto';
import { resolve } from 'node:path';

export function mountReviewPanel(app: INestApplication) {
  app.use('/admin/revision-sofia', (req: Request, res: Response) => {
    res.set({
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'none'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    });
    const hash = process.env.SOFIA_REVIEW_TOKEN_SHA256 ?? '';
    const expiry = Date.parse(process.env.SOFIA_REVIEW_EXPIRES_AT ?? '');
    if (!/^[a-f0-9]{64}$/.test(hash) || !Number.isFinite(expiry) || Date.now() >= expiry) {
      return res.status(404).send('Acceso de revisión no disponible.');
    }
    if (req.method !== 'GET') return res.status(405).end();

    const root = resolve(__dirname, '../../admin');
    if (req.path === '/') return res.sendFile('revision-sofia.html', { root });
    if (req.path === '/consulta.js') return res.sendFile('revision-sofia.js', { root });
    if (req.path !== '/datos') return res.status(404).end();

    const token = /^Bearer ([a-f0-9]{64})$/.exec(req.get('authorization') ?? '')?.[1];
    if (!token || !timingSafeEqual(createHash('sha256').update(token).digest(), Buffer.from(hash, 'hex'))) {
      return res.status(401).end();
    }

    return res.json({
      perfil: { nombre: 'Persona de Prueba', correo: 'persona@example.invalid', foto: 'Pendiente de revisión' },
      identidad: { tipo: 'Carnet de identidad', referencia: 'DEMO-001', estado: 'Pendiente de revisión' },
      vehiculo: { referencia: 'VEH-DEMO-01', foto: 'Pendiente de revisión', documentos: 'Pendientes de revisión' },
    });
  });
}
