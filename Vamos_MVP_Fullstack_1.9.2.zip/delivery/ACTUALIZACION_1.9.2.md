# Vamos!! 1.9.2 — decisiones de comunidades

- Rechazar una solicitud abre una ventana para registrar la causa.
- La causa es obligatoria y admite entre 5 y 500 caracteres.
- Las solicitudes rechazadas desaparecen de la bandeja activa de la comunidad.
- Los miembros aprobados muestran la opción **Retirar de la comunidad**.
- El retiro exige una causa y bloquea la operación si existen viajes o reservas activos.
- La persona recibe una notificación y puede consultar la causa registrada.
- El panel de operaciones también exige la causa y conserva las decisiones en sus filtros históricos.

Esta actualización no requiere una nueva migración de Neon. Utiliza los campos de revisión
incorporados previamente en la estructura de comunidades.
