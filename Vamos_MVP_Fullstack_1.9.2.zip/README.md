# Vamos!!

MVP de carpool con aplicación Flutter y API NestJS/PostgreSQL/PostGIS.

## Estructura

- `vamos_app/`: aplicación móvil Flutter.
- `backend/`: API REST NestJS.
- `admin/`: panel web de operaciones sin dependencias externas.
- `database/init.sql`: esquema relacional y espacial.
- `docker-compose.yml`: base de datos PostGIS local.

## Versión web

La aplicación también puede compilarse como PWA para navegador. Reutiliza la API de Render y la base Neon; funciona en computadora, Android y iPhone mediante Safari o Chrome. El flujo `delivery/web.yml` analiza, prueba y compila la PWA para publicarla en Render. Consulta `delivery/WEB_PWA_1.9.0.md`, `delivery/ACTUALIZACION_1.9.1.md` y `delivery/ACTUALIZACION_1.9.2.md`.

En navegador, cámara y ubicación requieren HTTPS y autorización del usuario. El seguimiento en vivo funciona mientras la página permanece abierta; Android sigue siendo la opción recomendada para el conductor durante un viaje activo.

La aplicación móvil conecta registro, inicio de sesión, vehículos y búsqueda
geoespacial con la API. También incluye selección táctil de origen y destino,
ubicación GPS, distancia directa y visualización con OpenStreetMap. Los flujos
posteriores a la reserva aún conservan algunos datos demostrativos.

La publicación de viajes funciona de extremo a extremo: carga los vehículos del
conductor, permite elegir uno verificado, limita los asientos según su capacidad,
construye el payload PostGIS/GeoJSON y confirma el viaje mediante `POST /trips`.

Para validar económicamente el MVP sin panel administrativo, el backend permite
activar `VEHICLE_AUTO_VERIFY=true` únicamente en desarrollo. Debe mantenerse
desactivado en producción.

Las reservas ya funcionan de extremo a extremo. El pasajero solicita o cancela
un asiento; el conductor acepta, rechaza o marca ausencia. Las aceptaciones se
procesan dentro de una transacción para evitar sobreventa y los cupos se restauran
cuando una reserva aceptada se cancela antes de iniciar el viaje.

Las calificaciones se vinculan a participantes de viajes completados y solo pueden
enviarse una vez por persona. El perfil calcula la reputación desde datos reales.
Los incidentes se almacenan en la API y validan que reportante y reportado hayan
participado en el viaje. SOS, compartir ubicación y bloqueo siguen identificados
como funciones demostrativas.

La sesión móvil persiste el JWT y los datos mínimos del usuario en almacenamiento
seguro del sistema. La aplicación restaura sesiones válidas, elimina credenciales
vencidas y permite cerrar sesión. La recuperación de contraseña usa tokens de un
solo uso con vencimiento de 30 minutos y correo transaccional mediante Resend.

La bandeja interna genera notificaciones para solicitudes, decisiones de reserva,
cancelaciones, ausencias e inicio o finalización del viaje. Incluye contador de no
leídas, actualización cada 30 segundos, recarga manual y marcado individual o
masivo. Esta aproximación no tiene costo externo; las alertas con la aplicación
cerrada quedan pendientes para una integración push posterior.

El chat interno permite conversar únicamente al conductor y al pasajero de una
reserva aceptada. Los mensajes se almacenan en PostgreSQL, incluyen confirmación
de lectura, generan una notificación interna y se actualizan cada 10 segundos.
No necesita contratar un proveedor externo para validar el MVP.

El panel administrativo web añade métricas, revisión de vehículos, gestión de
incidentes y control del estado de usuarios. Todas sus rutas validan en el
backend que la cuenta tenga el rol `ADMIN`; ocultar botones en la interfaz no es
el mecanismo de seguridad. Para probarlo, aplica la migración 005, asigna el rol
a una cuenta y ejecuta `node admin/server.mjs`.

Las decisiones administrativas quedan registradas en una bitácora con responsable,
fecha y valores anterior/nuevo. La migración `006_admin_audit.sql` habilita este
historial en instalaciones existentes y el backend incluye pruebas automáticas
para permisos administrativos y escritura transaccional de la auditoría.

## Conectar Flutter con la API

Android Emulator usa por defecto `http://10.0.2.2:3000/api/v1`. Para otro
dispositivo o plataforma, inicia Flutter indicando la dirección accesible:

```bash
flutter run --dart-define=API_BASE_URL=http://IP-DE-TU-PC:3000/api/v1
```

En producción utiliza HTTPS. La aplicación móvil guarda el token en el
almacenamiento seguro del sistema y el panel web lo mantiene solo durante la
sesión de la pestaña.
