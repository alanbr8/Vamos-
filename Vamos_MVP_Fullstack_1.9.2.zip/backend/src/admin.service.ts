import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { AdminCommunityCreationDto, AdminCommunityDecisionDto, AdminIncidentStatusDto, AdminUserStatusDto, AdminVehicleStatusDto } from './dtos';

@Injectable()
export class AdminService {
  constructor(private readonly db: DataSource) {}

  async summary() {
    const [row] = await this.db.query(`
      SELECT
        (SELECT count(*)::int FROM users) AS users,
        (SELECT count(*)::int FROM trips) AS trips,
        (SELECT count(*)::int FROM vehicles WHERE verification_status='PENDING') AS "pendingVehicles",
        (SELECT count(*)::int FROM incidents WHERE status IN ('RECEIVED','REVIEWING')) AS "openIncidents",
        (SELECT count(*)::int FROM community_members m JOIN communities c ON c.id=m.community_id WHERE m.status='PENDING' AND c.approval_status='APPROVED') AS "pendingCommunityRequests",
        (SELECT count(*)::int FROM communities WHERE approval_status='PENDING') AS "pendingCommunityCreations"
    `);
    return row;
  }

  communityCreations(status?:string){
    const allowed=['PENDING','APPROVED','REJECTED'];
    if(status&&!allowed.includes(status))throw new BadRequestException('Estado de comunidad inválido');
    return this.db.query(`SELECT c.id,c.name,c.description,c.category,c.approval_status AS status,c.rejection_reason AS "rejectionReason",c.created_at AS "createdAt",u.first_name||' '||u.last_name AS owner,u.email
      FROM communities c JOIN users u ON u.id=c.owner_id WHERE ($1::text IS NULL OR c.approval_status::text=$1::text)
      ORDER BY CASE c.approval_status WHEN 'PENDING' THEN 0 ELSE 1 END,c.created_at DESC LIMIT 200`,[status||null]);
  }

  async updateCommunityCreation(adminId:string,id:string,dto:AdminCommunityCreationDto){
    const reason=dto.reason?.trim()||null;
    if(dto.status==='REJECTED'&&(!reason||reason.length<10))throw new BadRequestException('Explica el rechazo en al menos 10 caracteres');
    return this.db.transaction(async manager=>{
      const [previous]=await manager.query(`SELECT id,owner_id AS "ownerId",name,approval_status AS status,rejection_reason AS "rejectionReason" FROM communities WHERE id=$1 FOR UPDATE`,[id]);
      if(!previous)throw new NotFoundException('Comunidad no encontrada');
      if(previous.status!=='PENDING')throw new BadRequestException('La solicitud de creación ya fue revisada');
      const [updated]=await manager.query(`WITH changed AS (UPDATE communities SET approval_status=$2::varchar,reviewed_at=now(),reviewed_by=$3,rejection_reason=CASE WHEN $2::text='REJECTED' THEN $4::varchar ELSE NULL::varchar END WHERE id=$1 RETURNING id,name,approval_status AS status,rejection_reason AS "rejectionReason") SELECT * FROM changed`,[id,dto.status,adminId,reason]);
      await this.audit(manager,adminId,'COMMUNITY_CREATION_DECIDED','COMMUNITY',id,previous,updated);
      await manager.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'COMMUNITY_CREATION_REVIEW',$2,$3,$4)`,[previous.ownerId,dto.status==='APPROVED'?'Comunidad aprobada':'Creación de comunidad rechazada',dto.status==='APPROVED'?`${previous.name} ya puede recibir solicitudes de ingreso`:reason,{communityId:id,status:dto.status}]);
      return updated;
    });
  }

  communityRequests(status?:string){
    const allowed=['PENDING','APPROVED','REJECTED'];
    if(status&&!allowed.includes(status))throw new BadRequestException('Estado de solicitud inválido');
    return this.db.query(`SELECT m.community_id AS "communityId",m.user_id AS "userId",c.name AS community,c.category,
      u.first_name||' '||u.last_name AS applicant,u.email,m.status,m.request_reason AS "requestReason",
      m.organization_location AS "organizationLocation",m.job_title AS "jobTitle",m.review_note AS "reviewNote",m.created_at AS "createdAt"
      FROM community_members m JOIN communities c ON c.id=m.community_id JOIN users u ON u.id=m.user_id
      WHERE c.owner_id<>m.user_id AND c.approval_status='APPROVED' AND ($1::text IS NULL OR m.status::text=$1::text)
      ORDER BY CASE m.status WHEN 'PENDING' THEN 0 ELSE 1 END,m.created_at DESC LIMIT 200`,[status||null]);
  }

  async updateCommunityRequest(adminId:string,communityId:string,userId:string,dto:AdminCommunityDecisionDto){
    const reason=dto.note?.trim()||'';
    if(dto.status==='REJECTED'&&(reason.length<5||reason.length>500))throw new BadRequestException('Indica una causa de 5 a 500 caracteres');
    return this.db.transaction(async manager=>{
      const [previous]=await manager.query(`SELECT m.status,m.role,m.request_reason AS "requestReason" FROM community_members m JOIN communities c ON c.id=m.community_id WHERE m.community_id=$1 AND m.user_id=$2 AND c.owner_id<>m.user_id FOR UPDATE OF m`,[communityId,userId]);
      if(!previous)throw new NotFoundException('Solicitud no encontrada');
      const [updated]=await manager.query(`WITH changed AS (UPDATE community_members SET status=$3::varchar,role=CASE WHEN $3::text='REJECTED' THEN 'MEMBER'::varchar ELSE role END,reviewed_at=now(),reviewed_by=$4,review_note=$5::varchar WHERE community_id=$1 AND user_id=$2 RETURNING status,role,review_note AS "reviewNote") SELECT * FROM changed`,[communityId,userId,dto.status,adminId,reason||null]);
      await this.audit(manager,adminId,'COMMUNITY_REQUEST_DECIDED','COMMUNITY_MEMBER',userId,previous,{...updated,communityId});
      await manager.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'COMMUNITY_REVIEW',$2,$3,$4)`,[userId,dto.status==='APPROVED'?'Ingreso a comunidad aprobado':previous.status==='APPROVED'?'Retiro de comunidad':'Solicitud de comunidad rechazada',dto.status==='APPROVED'?(reason||'Tu ingreso fue aprobado.'):reason,{communityId,status:dto.status,removed:dto.status==='REJECTED'&&previous.status==='APPROVED'}]);
      return updated;
    });
  }

  vehicles(status?: string) {
    const allowed = ['DRAFT', 'PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de vehículo inválido');
    return this.db.query(
      `SELECT v.id,v.brand,v.model,v.year,v.color,v.license_plate AS "licensePlate",
       v.passenger_seats AS "passengerSeats",v.verification_status AS status,
       v.rejection_reason AS "rejectionReason",v.created_at AS "createdAt",
       u.id AS "ownerId",u.first_name || ' ' || u.last_name AS owner,u.email
       FROM vehicles v JOIN users u ON u.id=v.owner_id
       WHERE ($1::text IS NULL OR v.verification_status::text=$1)
       ORDER BY CASE WHEN v.verification_status='PENDING' THEN 0 ELSE 1 END,v.created_at DESC LIMIT 100`,
      [status || null],
    );
  }

  async updateVehicle(adminId: string, id: string, dto: AdminVehicleStatusDto) {
    return this.db.transaction(async manager => {
      await manager.query('SELECT u.id FROM users u JOIN vehicles v ON v.owner_id=u.id WHERE v.id=$1 FOR UPDATE OF u',[id]);
      if (dto.status === 'VERIFIED') {
        const [check] = await manager.query(`SELECT vamos_documents_ready(owner_id,id,(now() AT TIME ZONE 'America/La_Paz')::date) AS ready FROM vehicles WHERE id=$1`,[id]);
        if (!check?.ready) throw new BadRequestException('Primero aprueba carnet, selfie, licencia, fotos y SOAT vigentes en Documentos');
      }
      const [previous] = await manager.query(
        `SELECT id,verification_status AS status,rejection_reason AS "rejectionReason"
         FROM vehicles WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Vehículo no encontrado');
      const [vehicle] = await manager.query(
        `WITH updated AS (UPDATE vehicles SET verification_status=$2,rejection_reason=$3
         WHERE id=$1 RETURNING id,owner_id AS "ownerId",brand,model,verification_status AS status,
         rejection_reason AS "rejectionReason") SELECT * FROM updated`,
        [id, dto.status, dto.status === 'REJECTED' ? dto.rejectionReason || 'Documentación no aprobada' : null],
      );
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,$2,$3,$4,$5)`,
        [vehicle.ownerId, 'VEHICLE_REVIEW', dto.status === 'VERIFIED' ? 'Vehículo aprobado' : 'Vehículo rechazado',
         dto.status === 'VERIFIED' ? `${vehicle.brand} ${vehicle.model} ya puede publicar viajes` : vehicle.rejectionReason,
         { vehicleId: vehicle.id, status: dto.status }],
      );
      await this.audit(manager, adminId, 'VEHICLE_STATUS_CHANGED', 'VEHICLE', id, previous, vehicle);
      return vehicle;
    });
  }

  incidents(status?: string) {
    const allowed = ['RECEIVED', 'REVIEWING', 'RESOLVED', 'DISMISSED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de incidente inválido');
    return this.db.query(
      `SELECT i.id,i.trip_id AS "tripId",i.type,i.description,i.status,i.resolution_detail AS "resolutionDetail",i.resolved_at AS "resolvedAt",i.created_at AS "createdAt",
       reporter.first_name || ' ' || reporter.last_name AS reporter,
       reported.first_name || ' ' || reported.last_name AS "reportedUser"
       FROM incidents i JOIN users reporter ON reporter.id=i.reporter_id
       LEFT JOIN users reported ON reported.id=i.reported_user_id
       WHERE ($1::text IS NULL OR i.status::text=$1)
       ORDER BY CASE i.status WHEN 'RECEIVED' THEN 0 WHEN 'REVIEWING' THEN 1 ELSE 2 END,i.created_at DESC LIMIT 100`,
      [status || null],
    );
  }

  async updateIncident(adminId: string, id: string, dto: AdminIncidentStatusDto) {
    const closing = ['RESOLVED','DISMISSED'].includes(dto.status);
    const detail = dto.resolutionDetail?.trim();
    if (closing && (!detail || detail.length < 10 || detail.length > 2000)) throw new BadRequestException('Explica cómo se resolvió o por qué se descartó el incidente (10 a 2000 caracteres)');
    return this.db.transaction(async manager => {
      const [previous] = await manager.query(`SELECT id,type,status,reporter_id AS "reporterId",resolution_detail AS "resolutionDetail" FROM incidents WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Incidente no encontrado');
      if (['RESOLVED','DISMISSED'].includes(previous.status)) throw new BadRequestException('Este incidente ya está cerrado. Actualiza la lista para consultar la respuesta.');
      const [incident] = await manager.query(
        `WITH updated AS (UPDATE incidents SET status=$2,resolution_detail=$3::varchar,resolved_at=CASE WHEN $3::varchar IS NULL THEN NULL ELSE now() END,resolved_by=$4 WHERE id=$1
         RETURNING id,type,status,resolution_detail AS "resolutionDetail",resolved_at AS "resolvedAt",created_at AS "createdAt") SELECT * FROM updated`, [id, dto.status, closing ? detail : null, closing ? adminId : null]);
      await this.audit(manager, adminId, 'INCIDENT_STATUS_CHANGED', 'INCIDENT', id, previous, incident);
      if(closing)await manager.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'INCIDENT_UPDATED',$2,'Tu reporte tiene una respuesta. Abre el Centro de seguridad para consultarla.',$3)`,[previous.reporterId,dto.status==='RESOLVED'?'Reporte resuelto':'Reporte descartado',{incidentId:id}]);
      return incident;
    });
  }

  users(status?: string) {
    const allowed = ['ACTIVE', 'SUSPENDED', 'BLOCKED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de usuario inválido');
    return this.db.query(
      `SELECT u.id,u.first_name AS "firstName",u.last_name AS "lastName",u.email,
       u.status,u.role,u.identity_verified AS "identityVerified",u.created_at AS "createdAt",
       count(DISTINCT t.id)::int AS "tripCount"
       FROM users u LEFT JOIN trips t ON t.driver_id=u.id
       WHERE ($1::text IS NULL OR u.status::text=$1)
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT 100`, [status || null]);
  }

  async updateUser(adminId: string, id: string, dto: AdminUserStatusDto) {
    if (adminId === id && dto.status !== 'ACTIVE') {
      throw new BadRequestException('No puedes suspender o bloquear tu propia cuenta');
    }
    return this.db.transaction(async manager => {
      const [previous] = await manager.query(`SELECT id,status,role FROM users WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Usuario no encontrado');
      const [user] = await manager.query(
        `WITH updated AS (UPDATE users SET status=$2,updated_at=now() WHERE id=$1
         RETURNING id,first_name AS "firstName",last_name AS "lastName",status,role) SELECT * FROM updated`, [id, dto.status]);
      await this.audit(manager, adminId, 'USER_STATUS_CHANGED', 'USER', id, previous, user);
      return user;
    });
  }

  auditLogs() {
    return this.db.query(
      `SELECT l.id,l.action,l.entity_type AS "entityType",l.entity_id AS "entityId",
       l.previous_data AS "previousData",l.new_data AS "newData",l.created_at AS "createdAt",
       u.first_name || ' ' || u.last_name AS administrator
       FROM admin_audit_logs l JOIN users u ON u.id=l.admin_id
       ORDER BY l.created_at DESC LIMIT 200`,
    );
  }

  private audit(manager: { query: (sql: string, params?: unknown[]) => Promise<unknown> }, adminId: string,
    action: string, entityType: string, entityId: string, previousData: unknown, newData: unknown) {
    return manager.query(
      `INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data)
       VALUES($1,$2,$3,$4,$5,$6)`,
      [adminId, action, entityType, entityId, previousData, newData],
    );
  }
}
