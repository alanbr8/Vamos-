import { BadRequestException, Body, Controller, Get, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Query, Req, UseGuards } from '@nestjs/common';
import { IsIn, IsOptional, IsString, Length, MaxLength } from 'class-validator';
import { randomBytes } from 'node:crypto';
import { DataSource } from 'typeorm';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
export class CommunityDto {
 @IsString() @Length(3,80) name!:string;
 @IsString() @MaxLength(500) description!:string;
 @IsIn(['GENERAL','WOMEN','COMPANY','NEIGHBORHOOD','RESIDENTIAL','SCHOOL']) category!:string;
}
export class JoinCommunityDto {
 @IsString() @Length(16,32) code!:string;
 @IsString() @Length(20,1000) reason!:string;
 @IsOptional() @IsString() @MaxLength(200) organizationLocation?:string;
 @IsOptional() @IsString() @MaxLength(120) jobTitle?:string;
}
export class CommunityRequestDto {
 @IsString() @Length(20,1000) reason!:string;
 @IsOptional() @IsString() @MaxLength(200) organizationLocation?:string;
 @IsOptional() @IsString() @MaxLength(120) jobTitle?:string;
}
export class MemberDecisionDto { @IsIn(['APPROVED','REJECTED']) status!:string; @IsOptional() @IsString() @MaxLength(500) note?:string; }
export class MemberRoleDto { @IsIn(['MEMBER','ADMIN']) role!:string; }
@Injectable()
export class CommunitiesService {
 constructor(private readonly db:DataSource){}
 list(user:string){return this.db.query(`SELECT c.id,c.name,c.description,c.category,c.approval_status AS "communityStatus",c.rejection_reason AS "rejectionReason",m.status,m.review_note AS "reviewNote",(m.role='ADMIN' AND m.status='APPROVED') AS admin,c.owner_id=$1 AS owner FROM communities c JOIN community_members m ON m.community_id=c.id WHERE m.user_id=$1 ORDER BY c.name`,[user]);}
 search(user:string,q:string){const term=q?.trim();if(!term||term.length<2)throw new BadRequestException('Escribe al menos 2 caracteres');return this.db.query(`SELECT c.id,c.name,c.description,c.category,
   m.status AS "membershipStatus",c.owner_id=$1 AS owner
   FROM communities c JOIN users o ON o.id=c.owner_id LEFT JOIN community_members m ON m.community_id=c.id AND m.user_id=$1
   WHERE c.approval_status='APPROVED' AND o.status='ACTIVE' AND c.name ILIKE '%'||$2||'%'
   ORDER BY CASE WHEN lower(c.name)=lower($2) THEN 0 ELSE 1 END,c.name LIMIT 30`,[user,term]);}
 async create(user:string,d:CommunityDto){return this.db.transaction(async m=>{
  const [c]=await m.query(`INSERT INTO communities(owner_id,name,description,category,invite_code,approval_status) VALUES($1,$2,$3,$4,$5,'PENDING') RETURNING id,approval_status AS "communityStatus"`,[user,d.name.trim(),d.description.trim(),d.category,randomBytes(12).toString('hex')]);
  await m.query("INSERT INTO community_members(community_id,user_id,status,role,reviewed_at,reviewed_by) VALUES($1,$2,'APPROVED','ADMIN',now(),$2)",[c.id,user]);return c;
 });}
 async join(user:string,d:JoinCommunityDto){return this.db.transaction(async m=>{
  if(!d?.code||!d?.reason)throw new BadRequestException('Código y motivo de ingreso son obligatorios');
  const [c]=await m.query(`SELECT c.id,c.category FROM communities c JOIN users u ON u.id=c.owner_id WHERE c.invite_code=$1 AND c.approval_status='APPROVED' AND u.status='ACTIVE' FOR UPDATE OF c`,[d.code.trim().toLowerCase()]);if(!c)throw new NotFoundException('Código no válido o comunidad aún no aprobada');
  return this.requestWithManager(m,user,c,d);
 });}
 async request(user:string,id:string,d:CommunityRequestDto){return this.db.transaction(async m=>{
  const [c]=await m.query(`SELECT c.id,c.category FROM communities c JOIN users u ON u.id=c.owner_id
   WHERE c.id=$1 AND c.approval_status='APPROVED' AND u.status='ACTIVE' FOR UPDATE OF c`,[id]);
  if(!c)throw new NotFoundException('Comunidad no disponible');
  return this.requestWithManager(m,user,c,d);
 });}
 private async requestWithManager(m:{query:(sql:string,params?:unknown[])=>Promise<any[]>},user:string,c:{id:string;category:string},d:CommunityRequestDto){
  const location=d.organizationLocation?.trim()||null,job=d.jobTitle?.trim()||null;
  if(c.category==='COMPANY'&&(!location||!job))throw new BadRequestException('Para una comunidad de empresa indica tu ubicación de trabajo y cargo');
  const rows=await m.query(`INSERT INTO community_members(community_id,user_id,status,role,request_reason,organization_location,job_title) VALUES($1,$2,'PENDING','MEMBER',$3,$4,$5)
   ON CONFLICT(community_id,user_id) DO UPDATE SET status='PENDING',role='MEMBER',request_reason=EXCLUDED.request_reason,organization_location=EXCLUDED.organization_location,job_title=EXCLUDED.job_title,reviewed_at=NULL,reviewed_by=NULL,review_note=NULL
   WHERE community_members.status='REJECTED' RETURNING status`,[c.id,user,d.reason.trim(),location,job]);
  if(!rows.length)throw new BadRequestException('Ya perteneces a la comunidad o tu solicitud está en revisión');
  return {requested:true};
 }
 async detail(user:string,id:string){const [c]=await this.db.query(`SELECT c.id,c.name,c.description,c.category,c.approval_status AS "communityStatus",c.rejection_reason AS "rejectionReason",m.status,m.review_note AS "reviewNote",(m.role='ADMIN' AND m.status='APPROVED') AS admin,c.owner_id=$2 AS owner,CASE WHEN m.role='ADMIN' AND m.status='APPROVED' AND c.approval_status='APPROVED' THEN c.invite_code END AS code FROM communities c JOIN community_members m ON m.community_id=c.id WHERE c.id=$1 AND m.user_id=$2`,[id,user]);if(!c)throw new NotFoundException('Comunidad no disponible');return c;}
 async members(user:string,id:string){await this.admin(user,id);return this.db.query(`SELECT m.user_id AS id,u.first_name AS name,u.last_name AS surname,m.status,m.role,c.owner_id=m.user_id AS owner,m.user_id=$2 AS self,m.request_reason AS "requestReason",m.organization_location AS "organizationLocation",m.job_title AS "jobTitle",m.review_note AS "reviewNote" FROM community_members m JOIN users u ON u.id=m.user_id JOIN communities c ON c.id=m.community_id WHERE m.community_id=$1 AND m.status<>'REJECTED' ORDER BY CASE m.status WHEN 'PENDING' THEN 0 ELSE 1 END,m.created_at`,[id,user]);}
 private async admin(user:string,id:string){const [c]=await this.db.query(`SELECT c.id,c.owner_id FROM communities c JOIN community_members m ON m.community_id=c.id WHERE c.id=$1 AND c.approval_status='APPROVED' AND m.user_id=$2 AND m.status='APPROVED' AND m.role='ADMIN'`,[id,user]);if(!c)throw new NotFoundException('La comunidad no está aprobada o no tienes administración');return c;}
 async rotate(user:string,id:string){await this.admin(user,id);const [c]=await this.db.query(`WITH changed AS (UPDATE communities SET invite_code=$2 WHERE id=$1 RETURNING id) SELECT * FROM changed`,[id,randomBytes(12).toString('hex')]);if(!c)throw new NotFoundException('Comunidad no disponible');return {rotated:true};}
 async decide(user:string,id:string,target:string,status:string,note?:string){
  const reason=note?.trim()||'';
  if(status==='REJECTED'&&(reason.length<5||reason.length>500))throw new BadRequestException('Indica una causa de 5 a 500 caracteres');
  return this.db.transaction(async m=>{
  const [c]=await m.query(`SELECT c.owner_id,c.name,t.status AS "targetStatus" FROM communities c JOIN community_members a ON a.community_id=c.id JOIN community_members t ON t.community_id=c.id AND t.user_id=$3 WHERE c.id=$1 AND a.user_id=$2 AND a.status='APPROVED' AND a.role='ADMIN' FOR UPDATE OF c,t`,[id,user,target]);if(!c||target===c.owner_id||target===user)throw new BadRequestException('No puedes modificar este miembro');
  if(status==='REJECTED'){
   const [active]=await m.query(`SELECT t.id FROM trips t WHERE t.community_id=$1 AND t.status IN ('PUBLISHED','RESERVED','IN_PROGRESS') AND (t.driver_id=$2 OR EXISTS(SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2 AND b.status IN ('PENDING','ACCEPTED'))) LIMIT 1`,[id,target]);
   if(active)throw new BadRequestException('El miembro tiene viajes o reservas activos. Debe resolverlos antes de retirarlo.');
  }
  const rows=await m.query(`WITH changed AS (UPDATE community_members SET status=$3::varchar,role=CASE WHEN $3::text='REJECTED' THEN 'MEMBER'::varchar ELSE role END,reviewed_at=now(),reviewed_by=$4,review_note=$5::varchar WHERE community_id=$1 AND user_id=$2 AND status IN ('PENDING','APPROVED') RETURNING user_id) SELECT * FROM changed`,[id,target,status,user,reason||null]);if(!rows.length)throw new NotFoundException('Solicitud o miembro no encontrado');
  const removed=status==='REJECTED'&&c.targetStatus==='APPROVED';
  await m.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'COMMUNITY_REVIEW',$2,$3,$4)`,[target,status==='APPROVED'?`Ingreso aprobado en ${c.name}`:removed?`Retiro de ${c.name}`:`Solicitud rechazada en ${c.name}`,status==='APPROVED'?'Tu ingreso a la comunidad fue aprobado.':reason,{communityId:id,status,removed}]);
  return {updated:true};
 });}
 async role(user:string,id:string,target:string,role:string){return this.db.transaction(async m=>{
  const [c]=await m.query('SELECT owner_id FROM communities WHERE id=$1 AND owner_id=$2 FOR UPDATE',[id,user]);
  if(!c)throw new BadRequestException('Solo el administrador principal puede designar administradores');
  if(target===c.owner_id)throw new BadRequestException('El administrador principal no puede cambiarse');
  const rows=await m.query(`WITH changed AS (UPDATE community_members SET role=$3::varchar WHERE community_id=$1 AND user_id=$2 AND status='APPROVED' RETURNING user_id) SELECT * FROM changed`,[id,target,role]);
  if(!rows.length)throw new NotFoundException('Miembro aprobado no encontrado');return {updated:true};
 });}
 async trips(user:string,id:string){const [access]=await this.db.query('SELECT vamos_community_access($1,$2) AS allowed',[id,user]);if(!access?.allowed)throw new NotFoundException('Necesitas aprobación para ver los viajes');return this.db.query(`SELECT t.id,t.origin_label AS origin,t.destination_label AS destination,t.departure_at AS "departureAt",t.available_seats AS seats,t.contribution,u.first_name AS driver,u.id AS "driverId",t.vehicle_id AS "vehicleId",concat(v.brand,' ',v.model) AS vehicle,vamos_identity_ready(u.id,(now() AT TIME ZONE 'America/La_Paz')::date) AS "driverVerified",(v.verification_status='VERIFIED') AS "vehicleVerified",COALESCE((SELECT round(avg(overall),1) FROM ratings WHERE to_user_id=u.id),0) AS rating,(SELECT count(*)::int FROM trips WHERE driver_id=u.id AND status='COMPLETED') AS "tripCount",0 AS compatibility,ST_Y(t.origin::geometry) AS "originLat",ST_X(t.origin::geometry) AS "originLng",ST_Y(t.destination::geometry) AS "destinationLat",ST_X(t.destination::geometry) AS "destinationLng",ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS route,t.preferences->'routeEstimate' AS "routeEstimate" FROM trips t JOIN users u ON u.id=t.driver_id JOIN vehicles v ON v.id=t.vehicle_id WHERE t.community_id=$1 AND t.driver_id<>$2 AND t.status='PUBLISHED' AND t.departure_at>now() AND t.route_departed_at IS NULL AND t.available_seats>0 AND u.status='ACTIVE' AND v.verification_status='VERIFIED' AND vamos_community_access(t.community_id,$2) ORDER BY t.departure_at LIMIT 100`,[id,user]);}
}
@Controller('communities') @UseGuards(JwtAuthGuard)
export class CommunitiesController {
 constructor(private readonly s:CommunitiesService){}
 @Get() list(@Req() r:AuthRequest){return this.s.list(r.userId);}
 @Get('search') search(@Req() r:AuthRequest,@Query('q') q:string){return this.s.search(r.userId,q);}
 @Post() create(@Req() r:AuthRequest,@Body() d:CommunityDto){return this.s.create(r.userId,d);}
 @Post('join') join(@Req() r:AuthRequest,@Body() d:JoinCommunityDto){return this.s.join(r.userId,d);}
 @Post(':id/request') request(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() d:CommunityRequestDto){return this.s.request(r.userId,id,d);}
 @Get(':id') detail(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.detail(r.userId,id);}
 @Get(':id/members') members(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.members(r.userId,id);}
 @Get(':id/trips') trips(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.trips(r.userId,id);}
 @Post(':id/rotate') rotate(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.rotate(r.userId,id);}
 @Post(':id/members/:user') decide(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Param('user',ParseUUIDPipe) user:string,@Body() d:MemberDecisionDto){return this.s.decide(r.userId,id,user,d.status,d.note);}
 @Post(':id/members/:user/role') role(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Param('user',ParseUUIDPipe) user:string,@Body() d:MemberRoleDto){return this.s.role(r.userId,id,user,d.role);}
}
