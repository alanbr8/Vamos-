# Vamos!! 1.8.11 — Efectivo, QR y registro por uso

## Instalación en orden
1. Ejecutar database/migrations/014_payments_usage.sql en Neon → SQL Editor → production → neondb. Es adicional a 013, necesaria para seguimiento; no ejecutar init.sql en una base existente.
2. Renombrar este ZIP a Vamos_MVP_Fullstack_1.8.0.zip y reemplazar el del repositorio. Esperar a que Vamos-api en Render despliegue correctamente.
3. Ejecutar Compilar Vamos Android, esperar ambas tareas en verde e instalar la nueva APK como actualización. No cambiar claves ni main.yml.

## Cambios
- Registro: elegir Pasajero o Conductor y pasajero. Se almacena una preferencia de uso, no un permiso administrativo. Los pasajeros ven carnet y selfie; las licencias están en el recorrido de conductor. Perfil permite activar posteriormente la opción de ofrecer viajes. Se mantienen las aprobaciones exigidas para publicar.
- Ofrecer viaje usa una pantalla de selección de vehículo sin botones de ver/reemplazar fotos/documentos. Se conservan en Perfil → Mi vehículo. Si falta aprobación, se indica cómo gestionar documentos allí.
- Perfil recarga la foto al actualizar. Si falla la consulta, muestra un botón para reintentar. Se consulta la misma foto que aparece en los viajes: no se convierte el carnet en foto pública. La causa de la incidencia reportada aún requiere comprobarse en el celular.
- Perfil → Mi QR bancario permite subir/reemplazar/retirar la imagen original del banco, máximo 1 MB, con consentimiento. Se almacena cifrada usando la clave existente. No genera un QR bancario nuevo ni valida su titular, vencimiento o importe.
- Reserva aceptada o completada → Pago del aporte: efectivo por defecto; QR si el conductor lo cargó. El pasajero elige el método y verifica destinatario e importe en su banco. Se muestra el total por todos los asientos de la reserva. El conductor registra manualmente la recepción del aporte completo. No hay cobros, confirmación bancaria automática ni reembolsos automáticos. Una cancelación no revierte una transferencia o entrega de efectivo.
- Se conserva todo el trabajo de 1.8.10: logo, SOS, seguimiento temporal, documentos, Punto Vamos!, push, etc.

## Comprobaciones
Backend compilado y 55 pruebas unitarias locales aprobadas. Sintaxis de integración verificada. Nuevas pruebas PostGIS cubren efectivo/QR, autorización de acceso, confirmación idempotente, bloqueo de cambios tras confirmar y separación de preferencia de uso/rol administrativo. PostGIS y Flutter no están disponibles localmente: integración, análisis, pruebas Flutter y APK deben pasar en GitHub Actions.

Probar con dos cuentas: crear pasajero sin licencia; habilitar conductor posteriormente; recorrer Ofrecer viaje y comprobar que las ediciones se encuentran en Perfil; cambiar foto, reabrir perfil y compararla con un viaje; subir QR propio válido; aceptar reserva; seleccionar efectivo, luego QR; confirmar recepción solo tras comprobar el pago real. No hacer pagos reales solo para comprobar los botones.

## Propuesta para próxima etapa: Comunidades
No implementada en esta versión. Grupos privados por empresa, zona, barrio, urbanización o familias de colegio, por invitación/aprobación, con viajes públicos o exclusivos. Definir por separado filtro de conductoras mujeres frente a comunidad exclusiva de mujeres. En colegios, empezar con cuentas de padres/tutores; no se habilitan cuentas ni transporte de menores sin acompañamiento como parte de esta propuesta.
