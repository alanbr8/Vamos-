# Vamos 1.8.7 — Recorrido estimado por calles

## Instalación

1. Conserva ORS_API_KEY en Render → Vamos-api → Environment. No publiques la clave en GitHub ni la copies al código Android.
2. Renombra este ZIP como Vamos_MVP_Fullstack_1.8.0.zip y reemplaza el anterior en GitHub.
3. Espera el despliegue correcto del nuevo commit en Vamos-api.
4. Ejecuta Compilar Vamos Android e instala la APK 1.8.7 en conductor y pasajero.

No se necesita una migración SQL nueva ni cambiar el workflow de 1.8.5. Se usan la geometría y las preferencias existentes. Conserva Firebase y las demás claves.

## Uso

Al elegir origen y destino, Vamos solicita una ruta de automóvil a OpenRouteService. Revisa la línea azul, kilómetros y minutos en el paso del recorrido antes de continuar. Si falla, puedes cambiar los puntos o pulsar CALCULAR RECORRIDO. La app no sustituye un fallo por una línea recta presentada como recorrido por calles.

La distancia alimenta la calculadora del conductor. El aporte sigue siendo editable, así como kilómetros manuales, desgaste y peajes. Los peajes continúan siendo de ingreso manual; no se detectan en esta entrega.

El recorrido se guarda con el viaje y se muestra en el detalle de resultados, en Mis viajes y junto al Punto Vamos! de cada reserva. Elegir el Punto Vamos! no cambia automáticamente el recorrido del conductor ni implica aceptar un desvío: deben coordinarlo por chat.

Los viajes antiguos conservan sus extremos y muestran que no tienen ruta por calles calculada. Para una prueba completa publica un viaje nuevo. Un viaje editable sin solicitudes puede recalcularse al editarlo; no se modifican rutas históricas automáticamente.

## Alcance y disponibilidad

Es una ruta estimada, sin tráfico en tiempo real ni seguimiento de la ubicación del conductor. OpenRouteService puede ajustar los extremos a una calle próxima (hasta 150 metros); los pequeños accesos desde los puntos seleccionados no se incluyen en el tiempo ni en los kilómetros del proveedor.

Se envían al proveedor las coordenadas de partida y destino para calcular, sin nombres, documentos, teléfonos ni códigos. La clave se usa solamente en Render mediante Authorization. Endpoint: https://api.heigit.org/openrouteservice/v2/directions/driving-car/geojson

La caché en memoria dura una hora y conserva hasta 200 recorridos. Las consultas idénticas simultáneas se agrupan. Cada instancia permite como máximo 35 consultas nuevas por minuto, pero el proveedor mantiene sus propias cuotas. No hay reintentos automáticos ilimitados.

## Pruebas

El servidor compiló y pasaron 47 pruebas locales, incluyendo formato del proveedor, orden de coordenadas, extremos, caché y errores sin filtración de la clave. Flutter y PostgreSQL/PostGIS quedan pendientes en GitHub Actions. La petición real con ORS_API_KEY debe comprobarse en los teléfonos; la clave no estuvo disponible en esta sesión.

Prueba con dos puntos de Santa Cruz cercanos a calles: revisa la línea azul, publica, abre el detalle desde otra cuenta, solicita asiento con Punto Vamos! y confirma que los extremos y el recorrido sean los mismos. Revisa también el aporte sugerido antes de publicar.
