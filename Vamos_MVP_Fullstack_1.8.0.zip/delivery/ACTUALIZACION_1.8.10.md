# Vamos!! 1.8.10 — Logo y SOS

Incluye el vehículo compartido aprobado, el lema «La unión es la fuerza», logo de entrada e Inicio e iconos Android/iOS. Conserva rutas por calles, Punto Vamos!, push, fotos, documentos y seguimiento de 1.8.9.

SOS está en Inicio, Centro de seguridad, Perfil, Gestionar viaje, Mi reserva y Seguir viaje. Permite abrir Teléfono con Policía 110 o un contacto y preparar un mensaje con la ubicación propia, fecha, precisión y referencia del viaje. El usuario confirma llamada/envío. No avisa a otros ocupantes ni asegura que se haya contactado a la Policía.

El contacto se guarda cifrado por cuenta en este teléfono; no se sincroniza entre dispositivos. Puede editarse/eliminarse desde Perfil → Contacto de emergencia y SOS. Las llamadas no requieren API/GPS; dependen de cobertura telefónica. Compartir ubicación requiere permiso y una lectura reciente del GPS; el envío depende de la app elegida. Es una posición puntual. El seguimiento temporal compartido de 1.8.9 sigue en Seguir y compartir viaje.

## Instalar
1. Renombrar el ZIP descargado a Vamos_MVP_Fullstack_1.8.0.zip y reemplazar el del repositorio.
2. Ejecutar Compilar Vamos Android y esperar verificar-api y android en verde.
3. Instalar la APK como actualización conservando la firma existente.

No hay nueva migración para 1.8.10 ni nuevas claves ni cambios de main.yml. Para seguimiento sigue siendo necesaria la migración 013 de 1.8.9 si no se ejecutó antes. No ejecutar init.sql en la base existente. iOS recibe los iconos al generar la plataforma con preparar_ios.py; sigue pendiente firma/distribución y pruebas en iPhone.

## Validación
Se inspeccionaron los recursos de marca y la integridad del ZIP, los tamaños de iconos y la sintaxis del script iOS. Se añade prueba Flutter de aislamiento del contacto entre cuentas y rechazo de teléfono inválido, para ejecutar en Actions. No hay Flutter ni teléfono conectado en el entorno local: análisis, pruebas Flutter, compilación APK, marcador y GPS quedan por validar en Actions y en un teléfono.

Prueba con un contacto que haya aceptado colaborar: guardar, salir/entrar, abrir marcador sin llamar al 110 para una prueba, compartir ubicación, rechazar permiso de GPS y comprobar que se puede seguir abriendo el marcador. Verificar SOS en conductor y pasajero, y que nadie recibe mensajes sin confirmar el envío. No realizar llamadas de prueba a servicios de emergencia.

Referencia del número de Policía: https://www.policia.bo/ (consulta 15-09-2026).
