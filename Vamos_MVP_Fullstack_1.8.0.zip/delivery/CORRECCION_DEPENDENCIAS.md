# Corrección de dependencias — 1.8.12

El error en flutter pub get enfrenta win32 ^6.0.0 requerido por geolocator >=14.0.3 con win32 ^5.5.3 de share_plus 11.1.0.
Se fija geolocator exactamente en 14.0.2 (sin ^), tal como sugiere el resolvedor. No se fuerza win32 mediante dependency_overrides. El resolvedor puede elegir una versión compatible de geolocator_linux dentro del rango permitido por 14.0.2.

Reemplazar el ZIP en GitHub con el nombre Vamos_MVP_Fullstack_1.8.0.zip y ejecutar una NUEVA ejecución de Compilar Vamos Android en main. No repetir la ejecución antigua: usaría el commit anterior.
No requiere nuevas migraciones, claves ni cambios de main.yml. Conserva Comunidades, QR/efectivo, SOS y todos los cambios de 1.8.12. Si las migraciones 014 y 015 están pendientes, siguen siendo necesarias para esas funciones.

Se verificó la metadata oficial de las dependencias y la integridad del paquete. No hay Flutter local: flutter pub get y compilación deben confirmarse en GitHub Actions. Esta corrección atiende el conflicto mostrado; no constituye una compilación exitosa.
