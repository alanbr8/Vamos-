# Primera comprobación de Vamos!! para iOS desde Windows

1. Reemplaza Vamos_MVP_Fullstack_1.8.0.zip en la raíz de GitHub con este ZIP.
2. Extrae el ZIP en Windows. Abre delivery/ios.yml con Bloc de notas y copia TODO el contenido.
3. En GitHub, Code → Add file → Create new file. Nombre: .github/workflows/ios.yml
4. Pega el contenido y guarda con Commit changes en main. Conserva el workflow Android existente.
5. Actions → Comprobar Vamos iOS → Run workflow → main.
6. Si falla, abre el paso rojo y comparte el mensaje. Si termina verde, queda validada la compilación, no el funcionamiento en iPhone.

No requiere SQL en Neon, cambios en Render, certificados ni secretos Apple.
El flujo usa macOS de GitHub; revisa la cuota de Actions de tu cuenta antes de ejecutarlo.
La configuración apunta a iOS 15 o superior, Flutter 3.47.2 y com.vamoscarpool.app.
Genera iOS desde una plantilla aislada sin sobrescribir lib, tests ni Android.
Usa CocoaPods, permiso de ubicación solo al usar la app y Keychain para sesión.
El artefacto conserva el proyecto iOS generado y los archivos de dependencias
resueltas para revisar la siguiente fase. No contiene una IPA instalable.

Pendiente: ejecución real del workflow, firma con Apple Developer, TestFlight,
icono final y pruebas de mapas, ubicación, sesión y flujo completo en iPhone.
La membresía no es necesaria para esta comprobación sin firma.

Referencias de implementación:
https://docs.flutter.dev/deployment/ios
https://pub.dev/packages/geolocator
https://pub.dev/packages/flutter_secure_storage
