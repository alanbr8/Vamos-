# Actualización de documentos — app 1.8.2 — 11 de septiembre de 2026

## Qué cambia

- Al crear una cuenta se ofrece completar carnet por ambos lados y selfie con cámara. También está en Perfil → Identidad y licencia. Se puede completar después.
- Para conducir: licencia por ambos lados, con la fecha real de vencimiento.
- En Mi vehículo → Fotos y SOAT del vehículo: foto frontal con placa legible, foto lateral y SOAT con vencimiento. Cada vehículo conserva sus propios documentos.
- Fotos JPG/PNG de hasta 1 MB. La cámara comprime la imagen; se muestra antes de enviarla. Si Android interrumpe la selección, se solicita repetirla y nunca se envía automáticamente.
- Estado individual: sin cargar, en revisión, aprobado, rechazado con motivo o vencido. Reemplazar una foto anula su aprobación. Eliminarla también impide publicar hasta completarla de nuevo.
- Panel → Documentos: consulta privada, aprobación y rechazo. Al aprobar carnet y selfie se verifica la identidad. Después de aprobar todos los documentos, aprobar el vehículo desde Vehículos. Se permite revisar otra vez un vehículo rechazado.
- Publicar o editar un viaje exige documentos aprobados y vigentes para el día de salida en Bolivia, además de un vehículo aprobado. Esta comprobación ocurre en el servidor y también afecta a las APK anteriores. Los vehículos previamente aprobados deben completar los documentos.
- La revisión es manual. No incluye reconocimiento facial, prueba de vida, consulta SEGIP ni comprobación automática de autenticidad con la aseguradora. El administrador debe comprobar legibilidad, correspondencia de persona, placa y vencimiento antes de aprobar.

## Instalación sobre la base actual

1. Extraer este ZIP. En Neon → SQL Editor → la base de Vamos, ejecutar **solo** `database/migrations/009_verification_documents.sql`. Requiere las tablas actuales de usuarios y vehículos. No ejecutar `init.sql`. La migración puede repetirse y no borra registros existentes. El historial de revisión utiliza la tabla de auditoría de la migración 006, que ya usa el panel.
2. Preparar una clave privada de cifrado **una sola vez**. En una computadora Windows personal, abrir PowerShell y ejecutar:

```powershell
$vamosDocBytes = New-Object byte[] 32
$vamosDocRng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$vamosDocRng.GetBytes($vamosDocBytes)
$vamosDocRng.Dispose()
([System.BitConverter]::ToString($vamosDocBytes)).Replace('-', '').ToLowerInvariant()
```

   El resultado es una clave de 64 caracteres hexadecimales. Guardarla en un gestor de contraseñas. No subirla a GitHub ni compartirla por chat.
3. En Render → **Vamos-api → Environment**, agregar `DOCUMENT_ENCRYPTION_KEY` con ese resultado. Conservar las demás variables. **Mantener esta misma clave en futuros despliegues**: cambiarla impediría leer las fotos existentes. Una rotación futura requiere un procedimiento de recifrado; este paquete no lo automatiza.
4. Reemplazar `Vamos_MVP_Fullstack_1.8.0.zip` en GitHub y esperar el despliegue correcto de Vamos-api. Los comandos de build/start no cambian. No hace falta crear otro servicio. Si ya existe la clave, no volver a generarla.
5. Ejecutar **Compilar Vamos Android** y esperar ambos trabajos en verde. Descargar la APK e instalarla como actualización. La firma y el identificador Android se conservan.
6. Actualizar el panel con Ctrl + F5. Abrir Documentos con la cuenta administradora. La cola muestra hasta 200 documentos, pendientes primero.

El nuevo código iOS incluye permisos de cámara y biblioteca de fotos en su generador. La comprobación iOS debe volver a ejecutarse; esta entrega no firma una app para TestFlight.

## Prueba con cuentas de prueba

1. Crear cuenta: aparece Identidad y licencia; completar más tarde permite volver al inicio.
2. Cargar carnet frontal, reverso y selfie. Salir y entrar: siguen en revisión.
3. Registrar vehículo, cargar fotos y SOAT. Cargar licencia por ambos lados y sus vencimientos reales.
4. Intentar publicar antes de aprobar: el servidor lo impide.
5. Administrador: ver cada imagen, rechazar una con motivo; el usuario recibe un aviso y puede abrir el documento desde Notificaciones.
6. Reemplazar ese documento y aprobar la nueva versión. Aprobar todos y luego el vehículo: permite publicar si las fechas cubren la salida.
7. Intentar publicar un viaje posterior al vencimiento del SOAT o licencia: lo impide.
8. Eliminar un documento o reemplazarlo: vuelve a impedir publicar hasta su aprobación. No cambia retroactivamente los viajes finalizados.
9. Una segunda cuenta no puede ver ni eliminar documentos ajenos. Un usuario sin rol ADMIN no puede abrir la cola administrativa.

## Almacenamiento y límites

Las fotos se cifran con AES-256-GCM antes de almacenarse en Neon. La clave queda en Render. Las imágenes se consultan por API autenticada y no tienen enlaces públicos; la API indica no almacenar esas respuestas en caché. Se registran cargas, consultas administrativas, revisiones y eliminaciones en auditoría, sin copiar las fotos al historial. Las copias de seguridad de Neon siguen su propia retención.

Esto es almacenamiento para el piloto: hasta 1 MB por documento y sin almacenamiento externo nuevo. El crecimiento de fotos consume espacio en Neon; el paso a producción requiere dimensionarlo y definir la retención de documentos y copias de seguridad. No se añaden datos reales al ZIP.

## Validación de la entrega

Backend compilado y 18 pruebas unitarias aprobadas, incluidas validación, límite de tamaño, cifrado/descifrado, alteración de datos y falta de clave. El JavaScript administrativo y el script de integración pasan la comprobación de sintaxis. La integración incluye la migración repetible, acceso ajeno, revisión de versiones, rechazo de publicación sin documentos y vencimiento; queda pendiente ejecutarla en PostgreSQL/PostGIS en GitHub Actions. Flutter, Android e iOS no se compilaron localmente; requieren los workflows y prueba en teléfono.
