# Editar y cancelar viajes

En Gestionar viaje aparecen EDITAR VIAJE y CANCELAR VIAJE antes de iniciar.
La edición permite cambiar origen, destino, fecha, hora, vehículo, asientos, aporte y preferencias. Requiere no tener solicitudes pendientes o aceptadas. Conserva el identificador del viaje y vuelve a buscar pasajeros compatibles.
La cancelación pide confirmación, conserva el historial, cancela solicitudes pendientes y reservas aceptadas, y avisa dentro de la app a esos pasajeros. No permite iniciar ni reservar ese viaje.
Los viajes iniciados y finalizados no se editan ni cancelan con estas opciones.

## Instalación
Reemplazar el ZIP en GitHub, esperar el despliegue de Vamos-api, ejecutar Compilar Vamos Android e instalar el nuevo APK. No requiere otra migración de Neon si ya se ejecutó 008_saved_searches.sql.

## Validación
Backend compilado y ocho pruebas unitarias aprobadas. Casos de edición, permisos, reservas y cancelación añadidos a la prueba de integración de GitHub Actions. Flutter y la integración PostGIS requieren validación en Actions; no se ejecutaron localmente.

## Prueba en el celular
Publicar un viaje futuro sin solicitudes. Editarlo y volver a abrir para comprobar los datos. Pedir un asiento desde otra cuenta: la edición debe quedar bloqueada. Cancelar como conductor y comprobar la reserva cancelada y su aviso en la cuenta del pasajero.
