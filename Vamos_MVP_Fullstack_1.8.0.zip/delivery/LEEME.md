# Actualización de fotos — app 1.8.3

Para esta entrega sigue `delivery/FOTOS_DE_PERFIL_Y_VIAJES.md`: migración 010 y nueva APK, conservando la clave privada existente.

# Actualización documental — 11 de septiembre de 2026

**Para esta entrega sigue primero `delivery/DOCUMENTOS_Y_VERIFICACION.md`: incluye migración 009, clave privada en Render y nueva APK.** Las instrucciones que siguen describen la instalación anterior y no sustituyen esos pasos. La firma Android existente se conserva.

# Vamos!! — revisión 1.8.1 (7 de septiembre de 2026)

Este paquete reúne las correcciones del recorrido de pruebas. Conserva el nombre `Vamos_MVP_Fullstack_1.8.0.zip` para mantener los comandos de Render. La versión interna de la app es 1.8.1.

No se ha cambiado tu GitHub, tu servicio Render ni tu base Neon desde esta sesión. No contiene contraseñas de tu base de datos. No es una APK ya compilada: es el código que GitHub convertirá en APK.

## 1. Guardar el paquete y preparar GitHub

1. Descarga el ZIP actualizado y extrae una copia en tu computadora con el explorador de archivos. No necesitas instalar programas.
2. En el repositorio `alanbr8/Vamos-`, reemplaza el ZIP de la raíz por este ZIP, conservando su nombre exacto. GitHub permite hacerlo en **Code → Add file → Upload files → Commit changes**. No subas el contenido extraído completo a la raíz.
3. En GitHub abre `.github/workflows/main.yml`, pulsa el lápiz y reemplaza todo con el contenido de `delivery/main.yml` del ZIP. Guarda con **Commit changes**. Ese archivo agrega pruebas antes de producir la APK.
4. Crea `.github/workflows/preparar-firma.yml` con el contenido de `delivery/preparar-firma.yml`.

El repositorio actual es privado. Mantén privado el archivo de firma del paso siguiente.

## 2. Preparar una firma estable — una sola vez

Las APK anteriores se firmaban con una clave nueva en cada ejecución. Eso puede impedir actualizar una instalación anterior. Una clave constante resuelve ese conflicto para las futuras compilaciones; no elimina por sí sola los avisos de Play Protect.

1. En GitHub ve a **Actions → Preparar firma Vamos (una sola vez) → Run workflow**.
2. Al terminar, abre esa ejecución. En **Artifacts**, descarga `Firma-privada-guardar-como-secreto` y extrae `VAMOS_ANDROID_KEYSTORE.txt`.
3. Abre el TXT con Bloc de notas y copia su contenido completo.
4. En el repositorio ve a **Settings → Secrets and variables → Actions → New repository secret**.
5. Nombre: `VAMOS_ANDROID_KEYSTORE`. Valor: el contenido del TXT. Guarda el secreto. No lo pegues en el código ni lo envíes por chat.
6. Conserva una copia privada segura del TXT. Elimina el artefacto temporal de la ejecución después de guardar el secreto; también caduca al día. No vuelvas a generar ni reemplazar la clave mientras quieras mantener las actualizaciones compatibles.

Es una firma para pruebas internas, no la configuración final para publicar en Google Play. La primera APK con esta clave puede requerir desinstalar la versión anterior; eso borra los datos locales de la app. Los registros que realmente estén guardados en Neon permanecen y podrás iniciar sesión de nuevo. No desinstales hasta tener la nueva APK compilada correctamente y conocer tu contraseña.

## 3. Aplicar una migración pequeña en Neon

En **Neon → SQL Editor**, ejecuta únicamente el contenido de `database/migrations/007_zero_seats.sql`. Permite que un viaje llegue a cero asientos libres al aceptar su última reserva. No borra tablas, usuarios, vehículos ni viajes. Se puede repetir.

No vuelvas a ejecutar `database/init.sql` sobre tu base actual: ese archivo es para bases nuevas.

Esta migración NO aprueba vehículos. La aprobación debe seguir siendo una acción deliberada del administrador. Si tu vehículo sigue pendiente, el nuevo botón de actualizar mostrará ese estado real. No cambies `VEHICLE_AUTO_VERIFY` para ocultar el problema.

## 4. Actualizar Render y compilar

Al reemplazar el ZIP, Render puede redesplegar automáticamente si está activado el despliegue automático. Comprueba que terminó con éxito. Los comandos se mantienen:

Build:
```
unzip -o Vamos_MVP_Fullstack_1.8.0.zip -d proyecto && cd proyecto/backend && npm ci --include=dev && npm run build
```

Start:
```
cd proyecto/backend && node dist/main.js
```

Si no se inicia automáticamente, usa el despliegue manual del último commit en Render. Conserva tus variables de entorno actuales.

Después, en GitHub ejecuta **Actions → Compilar Vamos Android → Run workflow**. Primero corre `verificar-api` con una base PostGIS temporal; después, Android ejecuta el análisis, cuatro pruebas Flutter y compila. Si alguna prueba falla no se publica una APK. Comparte el primer error del registro para corregirlo antes de instalar.

Si ambos trabajos terminan en verde, descarga **Artifacts → Vamos-Android-Prueba**, extrae el ZIP y abre `app-debug.apk` en el teléfono. Esta compilación apunta a `https://vamos-api.onrender.com/api/v1`.

## 5. Prueba de aceptación con dos cuentas diferentes

| Paso | Resultado que debe verse |
|---|---|
| Iniciar sesión y abrir Perfil | Nombre completo, correo, celular y acceso a Mi vehículo |
| Abrir Ofrecer viaje con vehículo existente | Se consulta el vehículo; no aparece un formulario vacío si ya existe |
| Actualizar estado tras aprobación administrativa | VERIFICADO y botón para continuar a publicar |
| Publicar salida futura, un asiento y dos puntos distintos | Confirmación; el viaje aparece en Viajes del conductor |
| Buscarlo con una segunda cuenta, misma fecha, hora y puntos | Coincidencia real; no aparece para el propio conductor |
| Solicitar el asiento y aceptarlo desde el conductor | Reserva aceptada; el viaje queda sin asientos y deja de ofrecerse |
| Abrir la reserva del pasajero y pulsar actualizar | Estado y código actuales; chat disponible |
| Cancelar antes de iniciar | Se devuelve el asiento una sola vez |
| Volver a solicitar, aceptar, iniciar con código y finalizar | Estados coherentes y opción de calificar |
| Cortar conexión y buscar o actualizar | Error explícito; no aparecen viajes inventados |

Las solicitudes pendientes no apartan asientos hasta que el conductor acepta. Si inicia el viaje, se cierran las solicitudes que no fueron aceptadas. Las notificaciones se consultan dentro de la aplicación; no son notificaciones push con la app cerrada.

## Verificación de esta entrega

- Backend: compilación correcta y 8 pruebas Jest aprobadas.
- Código Dart: sintaxis y formato comprobados con el formateador.
- Scripts de integración y archivos YAML: sintaxis comprobada.
- Flutter completo: no ejecutado localmente. La revisión automática bloqueó una operación de preparación de Flutter por un intento de acceso a metadatos del entorno. No se eludió ese bloqueo.
- Integración real PostGIS y APK: pendientes de ejecutar en GitHub; se incluyen como requisitos del workflow.
- Pruebas en tus teléfonos y conexión real de tu sesión con Neon: pendientes de la prueba de aceptación anterior.

Por tanto, este es un paquete para validar en CI y en los teléfonos, no una afirmación de que toda la aplicación está lista para lanzamiento público.
