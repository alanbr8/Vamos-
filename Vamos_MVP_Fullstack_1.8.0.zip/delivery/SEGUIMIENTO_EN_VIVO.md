# Vamos 1.8.9 — Seguimiento en vivo y enlace temporal

## Actualización

1. Extrae este ZIP. En Neon → SQL Editor de la base de Vamos-api ejecuta únicamente **database/migrations/013_live_tracking.sql**. No ejecutes init.sql. Requiere las migraciones anteriores hasta 012 ya instaladas.
2. Renombra el ZIP como **Vamos_MVP_Fullstack_1.8.0.zip** y reemplázalo en GitHub.
3. Espera el despliegue exitoso del nuevo commit en Render → Vamos-api.
4. Ejecuta Compilar Vamos Android e instala la APK **1.8.9 en conductor y pasajero**. Conserva las claves Firebase, ORS y firma actuales. No requiere otro workflow.

## Conductor

Pulsa **AVISAR QUE ESTOY SALIENDO**. Se abre Seguir viaje: pulsa **ACTIVAR / REANUDAR UBICACIÓN**, lee y acepta el aviso de quién puede verla, y permite la ubicación precisa mientras usas la aplicación. Inicia el servicio con la app visible. Android muestra una notificación permanente y mantiene el servicio de ubicación al pasar a segundo plano.

Puedes regresar a Gestionar viaje → **UBICACIÓN EN VIVO** para detener o reanudar. Solo hay un viaje transmitiendo por teléfono. Finalizar, cancelar o cerrar sesión detiene la transmisión local; el servidor también bloquea el acceso al finalizar o cancelar. Después de cerrar forzosamente la app o reiniciar el teléfono hay que volver a abrirla y reanudar expresamente.

Esta entrega habilita el envío en Android. El envío desde iOS en segundo plano no está habilitado; requiere configuración nativa y validación separadas. No promete seguimiento si el sistema cierra la app, no hay GPS o no hay conexión.

## Pasajero

Desde una reserva aceptada y con salida avisada, pulsa **SEGUIR Y COMPARTIR VIAJE**. El mapa consulta aproximadamente cada 15 segundos, mostrando última ubicación, hora y precisión. Más de dos minutos sin una posición nueva se identifica como señal sin actualizar.

**COMPARTIR VIAJE** abre el menú de compartir del teléfono: elige WhatsApp u otra app y al destinatario. No se envía ningún mensaje automáticamente. La persona abre un enlace en el navegador; no necesita instalar Vamos.

Quien tenga el enlace puede ver la ruta y ubicación del conductor. No se muestran documentos, fotos, nombres, teléfonos, códigos de encuentro ni la ubicación del pasajero. La ruta y la posición siguen siendo datos sensibles: compártelos solo con alguien de confianza. El receptor puede reenviar el enlace.

**REVOCAR ENLACE COMPARTIDO** lo invalida. Generar otro enlace invalida el anterior. Vence al finalizar o cancelar el viaje, cuando la reserva deja de estar aceptada o, como máximo, 24 horas después de la salida. Pausar la ubicación borra el último punto disponible; el enlace puede seguir mostrando el recorrido mientras el viaje continúe activo. El servidor guarda solo la última posición, no un historial GPS.

## Prueba necesaria antes de depender de la función

- Crea un viaje de prueba, solicita y acepta una reserva y avisa salida.
- Activa ubicación con el conductor detenido. Comprueba que el pasajero y el navegador de un tercero reciban la misma posición.
- Bloquea la pantalla del conductor durante al menos cinco minutos y comprueba actualizaciones; cualquier desplazamiento de prueba debe hacerlo otra persona o sin manipular el teléfono mientras conduces.
- Quita temporalmente la conexión y verifica que se indique la antigüedad de la señal. Reconecta y verifica una posición nueva.
- Prueba detener/reanudar, revocar enlace, generar otro, finalizar y cancelar; el enlace anterior debe dejar de funcionar.
- Comprueba que un usuario sin reserva aceptada no pueda consultar ni compartir ese viaje.

Se incluyen pruebas unitarias y de integración para autorización, claves aleatorias, revocación, fin de viaje y descarte de posiciones antiguas. El servidor compiló. Las pruebas PostgreSQL/PostGIS y Flutter quedan pendientes en GitHub Actions; el funcionamiento real en segundo plano requiere los teléfonos. La ubicación compartida ayuda a coordinar, pero no sustituye el contacto directo ni garantiza la recepción en una emergencia.

El visor web usa Leaflet 1.9.4 y teselas OpenStreetMap. Los tokens se pasan en el fragmento del enlace y se consultan mediante POST; la base almacena únicamente su hash. La información se consulta sin caché.
