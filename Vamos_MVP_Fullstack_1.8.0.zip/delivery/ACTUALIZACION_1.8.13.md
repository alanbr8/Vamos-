# Vamos!! 1.8.13

1. Ejecutar database/migrations/016_vehicle_accounts_tracking.sql en Neon, production / neondb. No ejecutar init.sql. La migración es repetible y conserva los datos. Retira la unicidad global de placa; mantiene unicidad por cuenta y completa los objetos de seguimiento de 013.
2. Renombrar el ZIP a Vamos_MVP_Fullstack_1.8.0.zip y reemplazarlo en GitHub.
3. Esperar despliegue exitoso de Vamos-api en Render.
4. Ejecutar un nuevo Compilar Vamos Android en main e instalar el APK como actualización. No cambiar main.yml ni secretos.

## Cambios
- Las notificaciones CHAT_MESSAGE abren el chat de su reserva, también las anteriores, previa comprobación del acceso.
- Selector de uno a los asientos disponibles (máximo siete), con total por todos los acompañantes. El servidor vuelve a comprobar cupos al solicitar y aceptar.
- La misma placa puede registrarse en distintas cuentas. Cada registro queda pendiente de revisión y tiene documentos propios; no hereda aprobación ni acceso a documentos ajenos.
- Compartir viaje ya no depende de que cargue la consulta del mapa. El servidor sigue exigiendo una reserva aceptada y un viaje iniciado y activo. Reintento visible y diagnóstico específico si faltan objetos de seguimiento.

## Pruebas
Backend compilado; 59 pruebas unitarias pasan. Se añadieron pruebas de integración para migración repetible, placa en cuentas distintas, rechazo de duplicados propios y reserva de dos asientos con restauración al cancelar. Integración PostgreSQL y Flutter pendientes de GitHub Actions; no se ejecutó Flutter localmente.

## Verificación en los teléfonos
- En ambas cuentas, tocar notificaciones de mensajes y comprobar el chat correcto.
- Solicitar dos asientos en un viaje de tres, aceptar y comprobar que queda uno; cancelar antes de salir y comprobar que vuelven tres.
- Registrar una placa existente desde otra cuenta: queda pendiente; no muestra documentos de la primera cuenta.
- Con reserva aceptada, avisar salida, activar ubicación en conductor y compartir desde pasajero. Abrir enlace, revocarlo y comprobar cierre.

El error Internal server error mostrado no permite confirmar su causa sin registros de Render. La migración soluciona objetos faltantes; si persiste, recoger el error de Vamos-api → Logs correspondiente al intento, sin credenciales ni tokens. No se ha comprobado el seguimiento en el servidor desplegado.
