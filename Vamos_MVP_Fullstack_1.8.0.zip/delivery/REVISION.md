# Revisión funcional de Vamos!!

## Corregido en el código de esta entrega

| Área | Problema observado en el código | Cambio |
|---|---|---|
| Vehículos | Ofrecer viaje volvía al registro; estados distintos se mostraban como revisión | Carga del vehículo existente, error con reintento y actualización de estado; rechazado y suspendido se distinguen |
| Registro de vehículo | Placa duplicada podía terminar en error genérico | Mensaje específico sin crear otra fila |
| Perfil e inicio | Perfil incompleto y tarjeta fija que decía que no había viajes | Correo, celular, nombre completo, Mi vehículo y cierre de sesión; acceso a la lista real de viajes |
| Búsqueda | SQL con paréntesis incorrectos; resultados ficticios ante errores; horas sin zona | Consulta corregida, fechas UTC y errores reales con reintento |
| Coincidencias | Datos genéricos de conductor, vehículo y estimaciones de trayecto | Datos reales de vehículo y reputación; se eliminan minutos ficticios; se explica la aproximación geométrica |
| Disponibilidad | Podían aparecer viajes propios, pasados o con conductor/vehículo inhabilitado | Filtros de disponibilidad, dirección geométrica, propietario y estado |
| Publicación | No se comprobaban fecha futura, coordenadas completas ni capacidad del vehículo | Validación en servidor y validación final del formulario |
| Último asiento | La restricción de la base prohibía cero asientos | Migración que admite cero; prueba de aceptación simultánea incluida |
| Reservas | Acciones incoherentes con el estado del viaje | No aceptar viajes vencidos; no cancelar tras iniciar; ausencia solo durante viaje; cierre de pendientes al iniciar |
| Reserva del pasajero | La pantalla conservaba una copia desactualizada | Botón de actualización del estado y código; etiquetas de estado en español |
| Chat | Tras 300 mensajes dejaban de verse los últimos | Se recuperan los 300 mensajes más recientes en orden cronológico |
| Conexión | Esperas sin límite y respuestas HTML mal interpretadas | Tiempo límite, mensajes de error y retorno al inicio de sesión tras 401 autenticado |
| Sesiones | Una cuenta suspendida conservaba acceso con un token emitido | Se comprueba el estado de la cuenta; una caída de base no se presenta como token vencido |
| Funciones incompletas | Recuperación prometía correo inexistente; fotos y seguridad mostraban acciones simuladas | Mensajes honestos de función pendiente, sin simulaciones de bloqueo o SOS |
| Actualizaciones | Firma de depuración distinta en cada ejecución | Workflow de clave privada persistente como secreto de GitHub |

## Pendiente antes de abrirlo a usuarios externos

| Prioridad | Trabajo pendiente | Alcance |
|---|---|---|
| Alta | Completar prueba con dos cuentas y dos teléfonos | Conductor y pasajero deben cerrar un recorrido completo con datos persistidos |
| Alta | Procedimiento de revisión administrativa | Panel disponible para el responsable; aprobación y rechazo con motivo y auditoría, sin editar estados rutinariamente por SQL |
| Alta | Recuperación real de cuenta | Proveedor de correo, enlaces, control de intentos y prueba de entrega; hoy está deshabilitada en producción |
| Alta | Documentos e identidad | Carga privada, acceso autorizado, límites, revisión y eliminación; hoy no hay carga |
| Alta | Seguridad funcional | Bloqueo efectivo, contacto de emergencia y compartir viaje; SOS no está conectado y no debe presentarse como operativo |
| Alta | Operación y acceso | Revisión de permisos completa, límites de solicitudes, privacidad, borrado de cuenta y textos reales de términos antes de publicación |
| Media | Rutas por calles | Elegir servicio de rutas y puntos de encuentro; hoy solo se comparan líneas directas |
| Media | Gestión de viajes | Edición/cancelación por conductor, reprogramación y caducidad explícita de solicitudes/viajes vencidos |
| Media | Recurrencia | Crear salidas futuras separadas y resolver horarios; actualmente solo se guardan días habituales |
| Media | Notificaciones push | Avisos cuando la aplicación esté cerrada; actualmente la consulta es interna |
| Posterior | Distribución pública | Firma de lanzamiento, proceso de tienda y versión optimizada; la actual sigue siendo una APK interna de depuración |

No se agregaron servicios con facturación ni proveedores nuevos. La revisión no constituye una auditoría completa de seguridad ni una comprobación legal. Las funciones pendientes requieren decisiones y pruebas específicas; agrupar la entrega no sustituye probar cada recorrido.

## Corrección posterior: calificaciones (8 de septiembre de 2026)

La ejecución real de GitHub llegó a la calificación y detectó `operator does not exist: uuid = text`. La comparación entre los parámetros de autor y destinatario permitía inferir texto antes de compararlos con columnas UUID. Se declararon explícitamente los tres identificadores como UUID en la consulta de calificaciones. Se amplió la prueba de integración para rechazar autocalificaciones, usuarios sin reserva completada y calificaciones duplicadas. La integración completa debe volver a ejecutarse en GitHub sobre el nuevo commit. No se necesita otra migración en Neon ni cambiar la firma.
