# Punto Vamos! — versión 1.8.4

## Incluye

- Detalle del viaje encontrado: mapa con partida y destino del conductor, marcadores distintos y coordenadas. No inventa nombres ni dibuja una ruta por calles que no se haya calculado.
- Antes de solicitar un asiento, el pasajero elige su Punto Vamos! en el mapa. Puede escribir una referencia de hasta 200 caracteres.
- El punto propuesto se guarda con la solicitud y aparece al conductor en Gestionar viaje → Solicitudes, antes de aceptarla.
- El pasajero vuelve a ver su punto en el detalle de la reserva. Ambos coordinan mediante el chat existente, habilitado después de aceptar la solicitud.
- El punto no es una aceptación automática de un desvío. No modifica partida, destino ni precio del viaje.
- Las solicitudes antiguas sin punto siguen funcionando; el conductor ve que no se indicó un punto.
- La app 1.8.4 requiere seleccionar un punto para las nuevas solicitudes. Las APK antiguas siguen pudiendo solicitar sin punto durante la actualización.

## Instalación

No hay nueva migración SQL: se utilizan meeting_point y meeting_point_label, ya existentes en bookings. Deben mantenerse las migraciones 009 y 010 de las actualizaciones anteriores.

1. Descargar `Vamos_1.8.4_Punto_Vamos.zip` y conservar una copia.
2. Renombrar la copia que se subirá a GitHub a `Vamos_MVP_Fullstack_1.8.0.zip`, reemplazando el ZIP anterior. Render sigue usando ese nombre.
3. Esperar el despliegue correcto de Vamos-api. Conservar DOCUMENT_ENCRYPTION_KEY y las demás variables.
4. Ejecutar Compilar Vamos Android. Esperar verificar-api y android en verde; descargar el artefacto de esa ejecución e instalar la APK como actualización.
5. Comprobar versión 1.8.4 en Información de la aplicación. Actualizar ambos teléfonos.

## Prueba

1. Publicar un viaje con dos puntos diferentes desde la cuenta del conductor.
2. Buscarlo desde la cuenta del pasajero y abrir su detalle: verificar partida y destino en el mapa.
3. Pulsar Elige tu Punto Vamos!, marcar el lugar y confirmar. Escribir una referencia y solicitar asiento.
4. Abrir el viaje como conductor: la solicitud debe mostrar el mismo punto y referencia.
5. Aceptar la solicitud; abrir la reserva desde el pasajero y comprobar que conserva el punto. Coordinar mediante el chat.
6. Salir y volver a entrar en ambas cuentas: el punto debe persistir.

Los mapas necesitan conexión para cargar las imágenes de OpenStreetMap. Las coordenadas y referencias se muestran también como texto. Los nombres que antes eran “Punto seleccionado” siguen siéndolo; esta entrega añade los marcadores, no una conversión automática de coordenadas a direcciones.

## Verificación

Servidor compilado y 27 pruebas unitarias aprobadas. Se añadieron comprobaciones de coordenadas incompletas, fuera de rango y no numéricas. El script de integración incluye persistencia del Punto Vamos! y lectura desde ambas cuentas; pasó la comprobación de sintaxis. PostgreSQL/PostGIS y Flutter quedan pendientes de los workflows. No se compiló APK ni iOS localmente.
