# Aporte sugerido

Fórmula: ((km × 0,70) × (1 + desgaste / 100) + peajes) / (asientos ofrecidos + 1).
El conductor comparte el gasto. Se supone ocupación completa y recorrido igual
para todos. Gasolina Bs 7/litro, consumo 10 L/100 km. Desgaste inicial de prueba
20%, editable de 0 a 100. Peajes totales ingresados manualmente, sin detección.

Los kilómetros se rellenan con distancia directa aproximada, identificada como
tal. El conductor puede ingresar los kilómetros reales por calles o carretera.
Cambiar los puntos del mapa reinicia esa distancia estimada.

En viajes nuevos, la sugerencia se actualiza con distancia, asientos, desgaste
y peajes hasta que el conductor escriba un aporte propio. USAR APORTE SUGERIDO
vuelve al cálculo automático. Al editar un viaje se conserva su precio guardado.
Solo se envía al servidor el aporte final; no se persiste el desglose y no se
expone al pasajero. No cambia el precio por nuevas reservas o cancelaciones.
Las restricciones existentes de edición con reservas se mantienen.
Importes mostrados con dos decimales para evitar ocultar centavos.

Subir ZIP, ejecutar Compilar Vamos Android e instalar APK nueva. No requiere
migración SQL. Compatible con el flujo Comprobar Vamos iOS.
Pruebas Flutter incluidas; pendientes de ejecución en GitHub Actions.
