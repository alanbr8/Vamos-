# Vamos 1.8.5: salida, encuentro individual, push e incidentes

## Qué cambia

1. El conductor pulsa **AVISAR QUE ESTOY SALIENDO** al salir del origen. Se avisa a los pasajeros aceptados para que se preparen y vayan al Punto Vamos! acordado. Es un aviso manual, no seguimiento GPS.
2. La salida cierra solicitudes pendientes y nuevas reservas. El conductor aún puede cancelar antes del primer encuentro confirmado.
3. Al encontrarse, cada pasajero muestra su código individual de seis dígitos. El conductor selecciona su reserva y pulsa **CONFIRMAR ENCUENTRO**. Confirmar uno no confirma a los demás. El código confirma la reserva; no sustituye la revisión de identidad.
4. El primer encuentro confirmado pasa el viaje a En curso. Para finalizar, debe confirmar a los demás pasajeros aceptados o marcarlos ausentes. Repetir el aviso no duplica la notificación.
5. Al resolver o desestimar un incidente, el administrador debe escribir el motivo (10 a 2000 caracteres). El autor lo consulta en Centro de seguridad. El texto privado no se envía en la notificación push.

## Actualización de la instalación existente

- Descarga y conserva este ZIP. Renombra la copia que subirás a GitHub como **Vamos_MVP_Fullstack_1.8.0.zip**.
- En Neon, SQL Editor, en la base utilizada por Vamos-api, ejecuta primero el contenido completo de `database/migrations/011_push_incident_resolution.sql` y después `012_departure_and_boarding.sql`. No ejecutes `init.sql`. Se presupone que ya aplicaste 009 y 010 de las actualizaciones anteriores.
- Reemplaza el ZIP en la raíz del repositorio GitHub.
- Reemplaza también **.github/workflows/main.yml** en GitHub con el contenido de **delivery/main.yml** de este ZIP. Subir solo el ZIP no actualiza el workflow.
- Comprueba que Render **Vamos-api** despliegue ese commit correctamente.
- Compila Android e instala la nueva APK **1.8.5 en ambos teléfonos**. Las versiones anteriores no permiten el nuevo inicio: mostrarán un mensaje para actualizar.
- Conserva las claves existentes DOCUMENT_ENCRYPTION_KEY, JWT_SECRET y VAMOS_ANDROID_KEYSTORE. No vuelvas a generar la firma Android.

## Activar push Android con Firebase

El código está preparado, pero las notificaciones push requieren tu configuración Firebase. Sin ella siguen funcionando los avisos dentro de la aplicación.

1. En tu proyecto Firebase, registra una aplicación Android cuyo paquete sea **com.vamoscarpool.app**. Descarga su archivo **google-services.json**.
2. En GitHub, Settings → Secrets and variables → Actions, crea el secreto **VAMOS_FIREBASE_ANDROID_JSON**. Pega el contenido completo de ese archivo como JSON, sin convertir a Base64.
3. En Firebase, configura Firebase Cloud Messaging y genera una clave privada de cuenta de servicio con permisos para enviar mensajes FCM. Es un archivo distinto del anterior. No lo subas al repositorio ni lo envíes por chat.
4. En Render → Vamos-api → Environment, añade **FIREBASE_SERVICE_ACCOUNT_JSON**, con el contenido completo del JSON privado de cuenta de servicio, y **PUSH_ENABLED=true**. Guarda y despliega. Ambos archivos deben corresponder al mismo proyecto Firebase.
5. Con el secreto Android guardado, ejecuta Compilar Vamos Android. Instala la APK en ambos teléfonos.
6. En cada cuenta abre **Mi perfil → Notificaciones push**, actívalas y acepta el permiso del teléfono.

Para iOS, esta entrega no configura APNs ni la firma de Apple: requiere configuración y pruebas adicionales. La comprobación iOS no demuestra que push funcione en un iPhone.

## Prueba de aceptación

- Crea un viaje y acepta dos reservas. Desde el conductor avisa la salida antes de ingresar códigos.
- Con la aplicación del pasajero en segundo plano, comprueba el aviso push. Tócalo y verifica que abre el viaje de la cuenta correcta.
- Confirma el código de un pasajero; el otro debe seguir pendiente. Prueba un código incorrecto: no debe confirmar. Cinco fallos bloquean temporalmente los intentos de esa reserva.
- Confirma al segundo pasajero y finaliza. Comprueba las calificaciones.
- Cierra sesión en un teléfono compartido y entra con otra cuenta: las notificaciones de la anterior no deben abrir sus viajes.
- Resuelve un incidente con una explicación y comprueba que su autor pueda consultarla en Centro de seguridad.

Los permisos del teléfono, la conexión y la disponibilidad del servidor afectan la entrega. No uses push como garantía de recepción: mantén el estado consultable dentro de la app y la coordinación por chat. Los avisos de salida pendientes caducan a los 15 minutos para evitar avisar de una salida antigua.

## Validación de esta entrega

Backend compilado y pruebas unitarias locales ejecutadas. Se incluyen pruebas de integración para PostgreSQL/PostGIS, encuentros por reserva y cola push. Flutter, integración con base real, compilación Android y entrega FCM real quedan pendientes de GitHub Actions y pruebas en teléfonos con Firebase configurado.
