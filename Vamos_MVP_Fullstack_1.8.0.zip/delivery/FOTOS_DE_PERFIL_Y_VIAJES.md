# Fotos de perfil y de viajes — versión 1.8.3

## Actualizar

1. En Neon ejecutar `database/migrations/010_display_photos.sql`. Si aún no se ejecutó la migración 009 de documentos, ejecutar primero `009_verification_documents.sql`. No ejecutar `init.sql` en la base existente.
2. Conservar `DOCUMENT_ENCRYPTION_KEY` en Render: se reutiliza la clave guardada. No generar otra.
3. Reemplazar el ZIP en GitHub y esperar el despliegue correcto de Vamos-api.
4. Ejecutar Compilar Vamos Android y esperar ambos trabajos en verde. Descargar e instalar la nueva APK como actualización. No basta con actualizar Render. La versión de la app ahora es 1.8.3; el nombre del ZIP y la firma Android se mantienen.

## Uso

- Perfil → Cambiar foto de perfil: tomar o elegir foto, revisar y guardar. También permite eliminarla.
- Perfil → Mi vehículo → Foto visible en los viajes: elegir una foto del vehículo correspondiente. Cada vehículo tiene su propia foto.
- Los pasajeros ven foto del conductor y del vehículo en los resultados de búsqueda y detalle del viaje, y en el detalle de su reserva.
- El conductor ve las fotos de los pasajeros en las solicitudes del viaje.
- Sin foto o sin conexión se muestra el ícono predeterminado. Volver a abrir la pantalla carga la foto actual.
- Las cuentas antiguas tienen los mismos botones. Perfil conserva Identidad y licencia; Mi vehículo conserva Fotos y SOAT del vehículo. No es necesario volver a registrar una cuenta ni un vehículo.

Las fotos de perfil y las visibles del vehículo se cargan expresamente para mostrarlas a otros usuarios autenticados. No se copian ni se publican automáticamente carnet, selfie de verificación, licencia o SOAT. Las fotos se guardan cifradas en una tabla separada, con la misma clave privada ya configurada. Cambiar una foto visible no modifica la aprobación documental. La app muestra un aviso de visibilidad antes de guardarla.

## Comprobar en los teléfonos

1. Con la cuenta antigua, cambiar la foto de perfil. Cerrar y volver a abrir Perfil: debe mantenerse.
2. Agregar foto visible al vehículo. Buscar su viaje desde otra cuenta: deben aparecer conductor y vehículo.
3. Agregar foto al pasajero y solicitar asiento. Abrir la solicitud como conductor: debe verse el pasajero.
4. Reemplazar o eliminar una foto y volver a abrir el viaje: debe mostrar el cambio o el ícono predeterminado.
5. Confirmar que siguen disponibles Identidad y licencia y Fotos y SOAT del vehículo.

## Verificación

Backend compilado y 21 pruebas unitarias aprobadas. Pruebas nuevas cubren consentimiento, cifrado, separación respecto a documentos privados y bloqueo de edición de vehículos ajenos. El script de integración incluye persistencia, migración repetible, eliminación y permisos; su sintaxis pasa. PostgreSQL/PostGIS y Flutter quedan pendientes de ejecutar en GitHub Actions. Android e iOS no se compilaron localmente.
