# Vamos 1.8.8 — Inicio e identidad visual

Primera etapa del rediseño: verde profundo, blanco y fondos verdes suaves; inicio centrado en compartir gastos, compañía y aprovechamiento de asientos. Buscar un viaje es la acción principal y ofrecer conserva su acceso al registro/verificación de vehículo. Se mantienen seguridad, perfil y salida de sesión. La navegación inferior agrega Alertas.

El ejemplo de Bs 40 entre cuatro personas está identificado como ilustrativo y no representa una tarifa ni ahorro real de la cuenta. No se muestran cifras inventadas de emisiones ni usuarios.

## Actualizar

Renombra el ZIP como Vamos_MVP_Fullstack_1.8.0.zip, reemplázalo en GitHub y ejecuta Compilar Vamos Android. Instala la APK 1.8.8 al terminar en verde. No requiere nueva migración, cambios de claves ni workflow. Incluye las rutas por calles de 1.8.7 y las correcciones anteriores.

## Revisar en el teléfono

Comprueba el inicio con texto normal y ampliado, desplazamiento, búsqueda, ofrecer, Mis viajes, Alertas, perfil y seguridad. El cambio del tema también afecta botones y colores en las otras pantallas; conviene revisar publicación, diálogo de encuentro y chat.

No se ejecutó Flutter ni se produjo una captura de la APK localmente. La compilación y pruebas Flutter quedan pendientes de GitHub Actions; la revisión visual final requiere el teléfono. Esta entrega aplica el inicio y el tema, no constituye un rediseño individual de todas las pantallas.
