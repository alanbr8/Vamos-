# Comunidades Vamos!! — 1.8.12

## Actualizar
1. Si no instalaste 1.8.11, ejecutar primero database/migrations/014_payments_usage.sql en Neon. Luego ejecutar database/migrations/015_communities.sql. No ejecutar init.sql en una base existente.
2. Renombrar el ZIP a Vamos_MVP_Fullstack_1.8.0.zip y reemplazarlo en GitHub.
3. Esperar despliegue correcto de Vamos-api en Render; compilar Android en Actions e instalar la APK como actualización. No hay nuevas claves ni cambios de workflow.

## Uso
Inicio → Comunidades Vamos!! → Crear comunidad. El creador es administrador solo del grupo; no recibe permisos del panel global. Categorías: general, empresa, zona/barrio, urbanización, familias de colegio y mujeres.

El administrador copia el código y lo entrega por un medio elegido por él. Quien lo usa solicita ingreso; no accede a ofertas privadas hasta su aprobación. El administrador revisa solicitudes, aprueba o rechaza/retira miembros y puede renovar el código. El código viejo deja de funcionar. Una solicitud rechazada permanece rechazada aunque vuelva a usar el código; el administrador puede aprobarla después.

Los miembros aprobados ven ofertas de otros miembros, proponen Punto Vamos! y solicitan asientos mediante el flujo existente. Sus ofertas y reservas también aparecen en Mis viajes. Al publicar se elige Público o una comunidad en la vista previa. Desde el grupo se preselecciona esa comunidad. Las aprobaciones de identidad, licencia, vehículo y SOAT siguen vigentes.

## Privacidad y límites
Las búsquedas normales y coincidencias guardadas respetan la pertenencia al grupo. El servidor comprueba el acceso también al reservar por ID. Las ofertas públicas siguen disponibles. Editar desde una APK antigua conserva la comunidad cuando el cliente no envía ese campo. La edición con reservas activas sigue bloqueada.

No se permite retirar al administrador creador ni a miembros con ofertas o solicitudes/reservas activas; primero deben resolver esos compromisos. No se incluyen aún transferencia de administración, salida voluntaria ni eliminación del grupo. El historial de reservas se conserva. Compartir un enlace temporal de seguimiento sigue siendo una decisión explícita del pasajero para seguridad.

Mujeres es una categoría de admisión revisada manualmente por el administrador; no representa certificación ni verificación automática de género. No es un filtro automatizado de género de conductores públicos. Empresas y colegios tampoco se presentan como organizaciones acreditadas por Vamos!!. Los grupos escolares están dirigidos a padres/tutores adultos; no habilitan cuentas de menores ni transporte de niños sin acompañamiento.

## Validación
Backend compilado y 58 pruebas unitarias locales aprobadas. Sintaxis de integración comprobada. Se agregan pruebas PostGIS de privacidad de búsquedas, acceso directo, aprobación, código renovado, retiro con compromisos activos y conservación de privacidad al editar con cliente antiguo. Flutter y PostGIS no disponibles localmente; integración y APK pendientes en GitHub Actions.

Prueba con tres cuentas: creador, miembro y externo. Crear grupo, copiar código, solicitar ingreso, comprobar que no se ven viajes antes de aprobar, aprobar y publicar privado; confirmar que el tercero no lo ve en búsqueda. Solicitar asiento como miembro. Mantener una oferta pública como comparación. Repetir el flujo habitual de chat, encuentro y finalización.
