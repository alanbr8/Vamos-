# Búsquedas guardadas y alertas

## Instalar esta actualización
1. Extraer este ZIP en la computadora.
2. En Neon SQL Editor, ejecutar el contenido completo de database/migrations/008_saved_searches.sql sobre la base que usa Vamos-api. Es una migración aditiva y repetible; no borra viajes ni usuarios. No ejecutar de nuevo database/init.sql sobre producción.
3. Reemplazar Vamos_MVP_Fullstack_1.8.0.zip en la raíz de GitHub manteniendo ese nombre. Render debe desplegar el nuevo commit en el servicio Vamos-api (Node).
4. Ejecutar el workflow existente Compilar Vamos Android. Deben pasar verificar-api y android. La prueba de integración comprueba búsquedas persistentes, coincidencias, sentido de ruta, duplicados, expiración, cancelación y acceso por propietario.
5. Instalar la APK del nuevo artifact. Esta función no aparece en la APK anterior.

## Comportamiento
Al buscar, se guarda el origen, destino y ventana horaria automáticamente. Una búsqueda sin resultados también se conserva en Mis viajes > Como pasajero > Búsquedas guardadas. Repetir los mismos criterios reutiliza la búsqueda. Al editar y buscar con otros criterios se crea otra alerta; se puede cancelar la anterior.

Cuando se publica un viaje compatible se crea una notificación persistente dentro de la misma transacción. También se comprueban coincidencias al consultar las búsquedas o notificaciones, para detectar asientos liberados y coincidencias existentes. No se crean alertas repetidas para la misma búsqueda y viaje. Un mismo viaje puede coincidir con distintas búsquedas del usuario.

La compatibilidad usa las reglas actuales de búsqueda: hasta 1500 metros de la línea de ruta, origen antes del destino, ventana horaria, conductor distinto, vehículo verificado, salida futura y asientos libres. Sigue siendo una aproximación geométrica, no un cálculo por calles.

Al tocar la alerta se abre la búsqueda guardada y se consultan los viajes actualmente disponibles. Si el viaje original se llenó o finalizó, puede dejar de aparecer. El pasajero elige un viaje y solicita el asiento manualmente. No se reserva automáticamente.

Las alertas se muestran dentro de la aplicación; no incluye notificaciones push con la aplicación cerrada. La notificación queda almacenada y se puede consultar al volver a abrir la app. El contador actual se consulta cada 30 segundos desde Inicio.

Al vencer la ventana horaria la búsqueda muestra Horario vencido. Cancelar la alerta detiene futuras coincidencias, pero no cancela una reserva existente. Las búsquedas antiguas hechas antes de esta versión no pueden recuperarse porque no se guardaron.

## Registro de vehículo
Un vehículo nuevo requiere aprobación del administrador. Se agregó un mensaje explícito y el botón CONSULTAR APROBACIÓN. Al estar VERIFICADO aparece CONTINUAR A PUBLICAR VIAJE. No se eliminó el requisito de verificación.

## Validación
TypeScript compila y las 8 pruebas unitarias locales pasan. No hay Flutter ni PostgreSQL/PostGIS disponibles en este entorno: la compilación móvil y las nuevas pruebas de integración quedan pendientes en GitHub Actions. No considerar esta versión validada en el teléfono hasta completar esa comprobación.

## Prueba manual
- Buscar una ruta futura sin coincidencias, salir y comprobar que queda guardada.
- Publicar un viaje coincidente desde otra cuenta y abrir Notificaciones del pasajero.
- Tocar la alerta, revisar el viaje y solicitar un asiento.
- Repetir la consulta: no debe duplicarse la misma alerta.
- Cancelar una búsqueda y publicar otra coincidencia: no debe llegar una alerta nueva por esa búsqueda.
- Registrar un vehículo nuevo: debe quedar en revisión; una vez aprobado, CONSULTAR APROBACIÓN debe habilitar la publicación.
