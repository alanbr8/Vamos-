# Vamos!! — MVP Flutter

Android 1.8.0: consulta ANDROID_SETUP.md antes de ejecutar. Estructura preparada,
pendiente de compilacion real con Flutter; no incluye APK.

Primera base navegable de la aplicación de carpool Vamos!!.

## Incluye

- Inicio de sesión simulado.
- Registro con validaciones.
- Pantalla principal.
- Registro de vehículo con validaciones.
- Vista del estado de verificación.
- Flujo de publicación de viaje en seis pasos y confirmación final.
- Origen, destino, resumen de ruta, fecha, hora y recurrencia.
- Asientos, aporte sugerido y preferencias del viaje.
- Búsqueda por origen, destino, fecha, hora y flexibilidad.
- Búsqueda real por coordenadas, horario y radio mediante la API/PostGIS.
- Respaldo con resultados demostrativos cuando la API no está disponible.
- Detalle del conductor, vehículo y punto de encuentro recomendado.
- Solicitud de asiento con estado pendiente.
- Gestión separada de viajes como conductor y pasajero.
- Aceptación o rechazo de solicitudes y control de asientos.
- Código de encuentro, inicio, finalización, cancelación y ausencia.
- Centro de seguridad con contacto de emergencia y viaje compartido.
- Flujo SOS demostrativo con confirmación y advertencia visible.
- Reporte, bloqueo y registro local de incidentes.
- Calificación mutua después de un viaje completado.
- Categorías de puntualidad, amabilidad, seguridad y conducción.
- Comentarios, promedio general e historial de reputación.
- Backend NestJS y esquema PostgreSQL/PostGIS incluidos en el paquete raíz.
- API para autenticación, vehículos, viajes, matching, reservas, calificaciones e incidentes.
- Cliente HTTP sin dependencias externas y configuración mediante `API_BASE_URL`.
- Registro, inicio de sesión y vehículo conectados con JWT a la API.
- Métodos preparados para viajes, reservas, calificaciones e incidentes.
- Mapa OpenStreetMap, GPS y selección táctil de coordenadas.
- Trazado preliminar entre puntos y cálculo de distancia geográfica.
- Constructor del payload de publicación con coordenadas GeoJSON `[longitud, latitud]`.
- Selector de vehículos verificados obtenido desde la API.
- Límite de asientos según la capacidad del vehículo.
- Publicación real del viaje y código de encuentro devuelto por el backend.
- Solicitud real de asiento desde los resultados de búsqueda.
- Listado real de viajes del conductor y reservas del pasajero.
- Aceptación, rechazo, cancelación y ausencia conectados con la API.
- Actualización segura de cupos y código visible solo tras la aceptación.
- Calificación real entre participantes después de completar el viaje.
- Perfil y promedios de reputación obtenidos desde la API.
- Reportes de seguridad persistentes con historial y estado.
- Validación para impedir calificar o reportar a usuarios ajenos al viaje.
- Sesión persistente mediante almacenamiento seguro del dispositivo.
- Restauración automática, detección de token vencido y cierre de sesión.
- Recuperación de contraseña con token temporal de un solo uso.
- Bandeja interna de notificaciones conectada a la API.
- Contador de avisos sin leer y actualización periódica cada 30 segundos.
- Lectura individual, lectura masiva y recarga manual.
- Chat privado por reserva aceptada.
- Mensajes persistentes, confirmación de lectura y actualización cada 10 segundos.
- Aviso visible para no compartir contraseñas ni datos bancarios.
- Navegación preparada para los próximos módulos.

Consulta `AUTH_SETUP.md` para configurar las pruebas de recuperación y los
requisitos previos al lanzamiento.

Algunos flujos posteriores al matching todavía mantienen datos demostrativos. El
mapa usa teselas públicas de OpenStreetMap para validar el MVP; no están destinadas
a tráfico masivo, descarga offline ni una operación con SLA. La línea mostrada entre
origen y destino es preliminar: el enrutamiento por calles se integrará después.

## Ejecutar

1. Instala Flutter y verifica el entorno con `flutter doctor`.
2. Desde esta carpeta ejecuta `flutter create .` para generar las carpetas nativas.
3. Ejecuta `flutter pub get`.
4. Inicia un emulador o conecta un teléfono.
5. Ejecuta `flutter run`.

Con la API iniciada, puedes crear una cuenta con correo válido y contraseña de ocho o más caracteres.
Consulta `MAPS_SETUP.md` antes de probar el GPS en Android o iOS.
