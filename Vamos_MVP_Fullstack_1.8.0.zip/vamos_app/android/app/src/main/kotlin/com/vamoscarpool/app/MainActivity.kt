package com.vamoscarpool.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
