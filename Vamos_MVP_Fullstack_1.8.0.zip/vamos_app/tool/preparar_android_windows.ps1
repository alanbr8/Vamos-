$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw 'Instala Flutter y agrega su carpeta bin al PATH antes de continuar.'
}
$seedRoot = Join-Path ([IO.Path]::GetTempPath()) ('vamos_seed_' + [guid]::NewGuid().ToString('N'))
flutter create --platforms=android --org com.vamoscarpool --project-name vamos_seed $seedRoot
if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear la plantilla Android.' }
# Conservar juntos las versiones de plugins y Wrapper del SDK instalado.
# No reemplazar Activity, manifiestos, recursos, lib ni pubspec del proyecto.
$settings = Join-Path $seedRoot 'android/settings.gradle.kts'
if (-not (Test-Path $settings)) { throw 'Plantilla no compatible: requiere revision manual. No se modifico el proyecto.' }
Copy-Item (Join-Path $seedRoot 'android/gradle') (Join-Path $projectRoot 'android') -Recurse -Force
foreach ($name in @('gradlew', 'gradlew.bat', 'settings.gradle.kts', 'local.properties')) {
    $source = Join-Path $seedRoot ('android/' + $name)
    if (Test-Path $source) { Copy-Item $source (Join-Path $projectRoot ('android/' + $name)) -Force }
}
Push-Location $projectRoot
try {
    flutter pub get
    if ($LASTEXITCODE -ne 0) { throw 'Fallo al resolver dependencias.' }
    flutter analyze
    if ($LASTEXITCODE -ne 0) { throw 'Revisar los avisos del analizador antes de compilar.' }
    flutter doctor
    Write-Host 'Preparacion terminada. Conecta Android y ejecuta flutter devices.'
} finally { Pop-Location }
Write-Host "Plantilla temporal conservada en: $seedRoot"
