"""Copy and configure only iOS from a clean Flutter template; preserve app code."""
from pathlib import Path
import plistlib
import re
import shutil
import sys

app = Path(__file__).resolve().parents[1]
source = Path(sys.argv[1]) / 'ios'
destination = app / 'ios'
if destination.exists():
    raise SystemExit('Ya existe ios; revisa su configuración antes de regenerarla.')
if not (source / 'Runner/Info.plist').is_file():
    raise SystemExit('La plantilla no contiene un proyecto iOS válido.')
shutil.copytree(source, destination)
plist_path = destination / 'Runner/Info.plist'
with plist_path.open('rb') as stream:
    info = plistlib.load(stream)
info['CFBundleDisplayName'] = 'Vamos!!'
info['CFBundleName'] = 'Vamos'
info['NSCameraUsageDescription'] = 'Vamos usa la cámara para tu selfie y las fotos de tus documentos y vehículo.'
info['NSPhotoLibraryUsageDescription'] = 'Vamos permite seleccionar fotos de documentos y del vehículo para revisión.'
info['NSLocationWhenInUseUsageDescription'] = (
    'Vamos!! usa tu ubicación mientras utilizas la app para elegir el origen '
    'y el destino de tus viajes.'
)
with plist_path.open('wb') as stream:
    plistlib.dump(info, stream)
entitlements = destination / 'Runner/Runner.entitlements'
with entitlements.open('wb') as stream:
    plistlib.dump({'keychain-access-groups': ['$(AppIdentifierPrefix)$(CFBundleIdentifier)']}, stream)
project = destination / 'Runner.xcodeproj/project.pbxproj'
content = project.read_text()
content = content.replace('com.vamoscarpool.vamosApp', 'com.vamoscarpool.app')
content = re.sub(r'IPHONEOS_DEPLOYMENT_TARGET = ([0-9.]+);',
    lambda m: 'IPHONEOS_DEPLOYMENT_TARGET = ' +
    (m[1] if float(m[1]) >= 15 else '15.0') + ';', content)
anchor = 'INFOPLIST_FILE = Runner/Info.plist;'
if content.count(anchor) != 3:
    raise SystemExit('La plantilla Xcode cambió; revisar las configuraciones de Runner.')
content = content.replace(anchor, anchor + '\n\t\t\t\tCODE_SIGN_ENTITLEMENTS = Runner/Runner.entitlements;')
if 'PRODUCT_BUNDLE_IDENTIFIER = com.vamoscarpool.app;' not in content:
    raise SystemExit('No se pudo configurar el identificador iOS.')
project.write_text(content)
(destination / 'Podfile').write_text('''platform :ios, '15.0'
ENV['COCOAPODS_DISABLE_STATS'] = 'true'
project 'Runner', {
  'Debug' => :debug,
  'Profile' => :release,
  'Release' => :release,
}
def flutter_root
  generated = File.expand_path(File.join('..', 'Flutter', 'Generated.xcconfig'), __FILE__)
  raise "Ejecuta flutter pub get primero" unless File.exist?(generated)
  File.foreach(generated) do |line|
    matches = line.match(/FLUTTER_ROOT\\=(.*)/)
    return matches[1].strip if matches
  end
  raise "No se encontró FLUTTER_ROOT"
end
require File.expand_path(File.join('packages', 'flutter_tools', 'bin', 'podhelper'), flutter_root)
flutter_ios_podfile_setup
target 'Runner' do
  use_frameworks!
  flutter_install_all_ios_pods File.dirname(File.realpath(__FILE__))
  target 'RunnerTests' do
    inherit! :search_paths
  end
end
post_install do |installer|
  installer.pods_project.targets.each do |target|
    flutter_additional_ios_build_settings(target)
    target.build_configurations.each do |config|
      if config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'].to_f < 15.0
        config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0'
      end
      if target.name == 'geolocator_apple'
        config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] ||= ['$(inherited)']
        config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] << 'BYPASS_PERMISSION_LOCATION_ALWAYS=1'
      end
    end
  end
end
''')
print('iOS preparado: Vamos!!, ubicación al usar la app y Keychain; mínimo iOS 15.')

# Apply the approved Vamos!! artwork after creating the platform.
shutil.copytree(app / "brand_ios/AppIcon.appiconset", destination / "Runner/Assets.xcassets/AppIcon.appiconset", dirs_exist_ok=True)
