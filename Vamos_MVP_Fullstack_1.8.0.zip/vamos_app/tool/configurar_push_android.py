"""Configura Firebase Android desde un secreto de GitHub, sin imprimir su contenido."""
import json
import os
from pathlib import Path
app = Path(__file__).resolve().parents[1]
raw = os.environ.get('VAMOS_FIREBASE_ANDROID_JSON','').strip()
if not raw:
    print('Push sin configurar: falta el secreto VAMOS_FIREBASE_ANDROID_JSON. La APK conserva notificaciones internas y muestra la configuración pendiente en Perfil.')
    raise SystemExit(0)
try:
    data = json.loads(raw)
    clients = [c for c in data['client'] if c['client_info']['android_client_info']['package_name'] == 'com.vamoscarpool.app']
    assert clients and data['project_info']['project_id'] and data['project_info']['project_number']
except (ValueError,KeyError,AssertionError,TypeError):
    raise SystemExit('El secreto no es un google-services.json válido para com.vamoscarpool.app. No uses aquí la clave de cuenta de servicio.')
settings = app/'android/settings.gradle.kts'
build = app/'android/app/build.gradle.kts'
for path, declaration in [(settings,'id("com.google.gms.google-services") version "4.4.4" apply false'),(build,'id("com.google.gms.google-services")')]:
    text=path.read_text()
    if 'com.google.gms.google-services' not in text:
        if 'plugins {' not in text: raise SystemExit('Cambió la plantilla Gradle; revisar el bloque plugins.')
        path.write_text(text.replace('plugins {','plugins {\n    '+declaration,1))
(app/'android/app/google-services.json').write_text(json.dumps(data))
print('Firebase Android configurado para Vamos; configuración omitida del registro.')
