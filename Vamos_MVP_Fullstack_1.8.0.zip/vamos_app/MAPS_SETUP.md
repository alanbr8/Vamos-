# Configuración de mapas y ubicación

El MVP usa OpenStreetMap con `flutter_map`. No necesita clave ni cuenta de facturación.

## Android

Después de ejecutar `flutter create .`, agrega en `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
```

## iOS

Agrega en `ios/Runner/Info.plist`:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>Vamos!! utiliza tu ubicación para seleccionar puntos de viaje.</string>
```

## Producción

Las teselas públicas de OpenStreetMap son solamente para uso interactivo moderado.
No implementar descarga masiva, precarga ni mapas offline. Antes de escalar,
configura un proveedor de teselas con capacidad y condiciones comerciales adecuadas.
