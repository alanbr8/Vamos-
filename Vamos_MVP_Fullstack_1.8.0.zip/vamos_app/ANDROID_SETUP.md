# Vamos!! Android: primera prueba

Estado: estructura fuente preparada; NO se ha compilado ni probado en un celular.
El entorno de esta entrega no tiene Flutter, Android SDK ni PowerShell.
Identificador provisional: com.vamoscarpool.app (confirmar antes de publicar).

## Preparacion en Windows

Instala Flutter SDK, Git y Android Studio con Android SDK. Agrega Flutter al PATH.
Abre PowerShell en vamos_app y ejecuta:

```powershell
flutter doctor
flutter doctor --android-licenses
.\tool\preparar_android_windows.ps1
```

Si Windows bloquea scripts, no cambies una politica administrada: consulta al
administrador del equipo. El script requiere permiso para ejecutarse.
Genera el Wrapper y selecciona los plugins de Gradle desde el Flutter instalado,
sin reemplazar las pantallas ni los manifiestos. La compatibilidad final del
proyecto debe comprobarse con el analizador y la primera compilacion.
No ejecutes flutter create . sobre el proyecto: usa el script y conserva respaldo.

## Primera ejecucion por USB

Activa depuracion USB en Android, conecta el cable y acepta la autorizacion.
Inicia la base de datos y API segun backend/README.md (incluye configurar .env).
En una base NUEVA init.sql ya incluye las migraciones; en una existente aplica
solo las pendientes en orden. No borres el volumen de datos.

```powershell
flutter devices
adb reverse tcp:3000 tcp:3000
flutter run --dart-define=API_BASE_URL=http://127.0.0.1:3000/api/v1
```

Si adb no esta en PATH, utiliza platform-tools del Android SDK. Selecciona un
solo telefono para estos comandos. El tunel USB evita abrir el firewall a la red.
Para emulador, la URL por defecto es http://10.0.2.2:3000/api/v1.

## APK de prueba

```powershell
flutter build apk --debug --dart-define=API_BASE_URL=http://127.0.0.1:3000/api/v1
```

Salida esperada: build/app/outputs/flutter-apk/app-debug.apk.
Esta URL requiere el tunel USB activo; no sirve para distribuir a otros usuarios.
HTTP se permite SOLO en debug. Release necesita API HTTPS y firma propia:
la firma debug del archivo Gradle es temporal, NO apta para Play Store.
No se incluye ningun APK en esta entrega.

## Validacion pendiente en dispositivo

- Abrir app, registrar cuenta e iniciar sesion con API activa.
- Ver mapa y atribucion, conceder/denegar ubicacion sin bloquear la app.
- Publicar con vehiculo aprobado, buscar y reservar con otra cuenta.
- Probar cierre/reapertura y desconexion del servidor.
- Guardar salida de flutter doctor, flutter analyze y flutter run para corregir errores.

Los permisos son Internet y ubicacion en primer plano; no hay rastreo en segundo
plano. La copia de seguridad Android esta desactivada para proteger la sesion.
