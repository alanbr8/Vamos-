import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';

import 'core/routes/app_routes.dart';
import 'core/theme/app_theme.dart';
import 'services/session_store.dart';
import 'services/api_client.dart';

final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  bool interruptedPhoto = false;
  if (Platform.isAndroid) {
    try {
      // Una foto recuperada nunca se envía sin confirmar su tipo y propietario.
      final lost = await ImagePicker().retrieveLostData();
      interruptedPhoto = !lost.isEmpty;
    } catch (_) { interruptedPhoto = true; }
  }
  final restored = await SessionStore.instance.restore();
  ApiClient.instance.onSessionExpired = () {
    navigatorKey.currentState?.pushNamedAndRemoveUntil(
      AppRoutes.login,
      (_) => false,
    );
  };
  runApp(VamosApp(sessionRestored: restored));
  if (interruptedPhoto) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final context = navigatorKey.currentContext;
      if (context != null) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Se interrumpió la selección de foto. No se envió. Vuelve a Documentos para tomarla o elegirla nuevamente.'),
        duration: Duration(seconds: 8),
      ));
    });
  }
}

class VamosApp extends StatelessWidget {
  const VamosApp({super.key, required this.sessionRestored});
  final bool sessionRestored;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Vamos!!',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: sessionRestored ? AppRoutes.home : AppRoutes.welcome,
      routes: AppRoutes.routes,
    );
  }
}
