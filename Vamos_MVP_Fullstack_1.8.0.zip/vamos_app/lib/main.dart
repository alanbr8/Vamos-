import 'package:flutter/material.dart';

import 'core/routes/app_routes.dart';
import 'core/theme/app_theme.dart';
import 'services/session_store.dart';
import 'services/api_client.dart';

final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final restored = await SessionStore.instance.restore();
  ApiClient.instance.onSessionExpired = () {
    navigatorKey.currentState?.pushNamedAndRemoveUntil(
      AppRoutes.login,
      (_) => false,
    );
  };
  runApp(VamosApp(sessionRestored: restored));
}

class VamosApp extends StatelessWidget {
  const VamosApp({super.key, required this.sessionRestored});
  final bool sessionRestored;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Vamos!!',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: sessionRestored ? AppRoutes.home : AppRoutes.welcome,
      routes: AppRoutes.routes,
    );
  }
}
