import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EncounterCodeDialog extends StatefulWidget {
  const EncounterCodeDialog({super.key, required this.passenger});
  final String passenger;

  @override
  State<EncounterCodeDialog> createState() => _EncounterCodeDialogState();
}

class _EncounterCodeDialogState extends State<EncounterCodeDialog> {
  final _input = TextEditingController();
  bool _closing = false;

  void _close([String? code]) {
    if (_closing) return;
    _closing = true;
    Navigator.of(context).pop(code);
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text('Confirmar encuentro · ${widget.passenger}'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Pide el código de esta reserva cuando estén juntos en el Punto Vamos!.'),
      TextField(
        controller: _input,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        maxLength: 6,
        decoration: const InputDecoration(labelText: 'Código de seis dígitos'),
        onChanged: (_) => setState(() {}),
      ),
    ]),
    actions: [
      TextButton(onPressed: () => _close(), child: const Text('Cancelar')),
      FilledButton(
        onPressed: _input.text.length == 6 ? () => _close(_input.text) : null,
        child: const Text('Confirmar'),
      ),
    ],
  );
}
