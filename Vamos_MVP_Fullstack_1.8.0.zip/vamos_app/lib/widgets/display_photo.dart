import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_client.dart';

class DisplayPhoto extends StatefulWidget {
  const DisplayPhoto({super.key,required this.id,this.vehicle=false,this.size=52,this.revision=0});
  final String? id;
  final bool vehicle;
  final double size;
  final int revision;
  @override
  State<DisplayPhoto> createState()=>_DisplayPhotoState();
}
class _DisplayPhotoState extends State<DisplayPhoto> {
  Uint8List? bytes;
  bool failed=false;
  int generation=0;
  @override
  void initState(){super.initState();load();}
  @override
  void didUpdateWidget(covariant DisplayPhoto old){super.didUpdateWidget(old);if(old.id!=widget.id||old.vehicle!=widget.vehicle||old.revision!=widget.revision)load();}
  Future<void> load()async{
    final current=++generation;
    setState(() {bytes=null;failed=false;});
    if(widget.id==null)return;
    try{
      final image=await ApiClient.instance.displayPhoto(widget.id!,vehicle:widget.vehicle);
      if(mounted&&current==generation)setState(()=>bytes=base64Decode(image['base64'] as String));
    }catch(e){if(mounted&&current==generation)setState(()=>failed=e is! ApiException || e.statusCode != 404);}
  }
  @override
  Widget build(BuildContext context)=>Semantics(label:widget.vehicle?'Foto del vehículo':'Foto de perfil',child:ClipRRect(
    borderRadius:BorderRadius.circular(widget.vehicle?12:widget.size),child:SizedBox(
      width:widget.vehicle?double.infinity:widget.size,height:widget.size,
      child:bytes==null?(failed?IconButton(tooltip:'No se pudo cargar la foto. Reintentar',onPressed:load,icon:const Icon(Icons.refresh)):placeholder()):Image.memory(bytes!,fit:BoxFit.cover,errorBuilder:(_,e,s)=>placeholder()),
    )));
  Widget placeholder()=>ColoredBox(color:Theme.of(context).colorScheme.surfaceContainerHighest,child:Center(child:Icon(widget.vehicle?Icons.directions_car:Icons.person,size:widget.size.clamp(24,56).toDouble())));
}

class PhotoEditor extends StatefulWidget {
  const PhotoEditor({super.key,required this.id,this.vehicle=false});
  final String id;
  final bool vehicle;
  @override
  State<PhotoEditor> createState()=>_PhotoEditorState();
}
class _PhotoEditorState extends State<PhotoEditor>{
  bool busy=false;
  int revision=0;
  String? error;
  Future<void> change(ImageSource source)async{
    setState((){busy=true;error=null;});
    XFile? file;
    try{
      file=await ImagePicker().pickImage(source:source,maxWidth:1200,maxHeight:1200,imageQuality:75,requestFullMetadata:false,preferredCameraDevice:widget.vehicle?CameraDevice.rear:CameraDevice.front);
      if(file==null||!mounted)return;
      final bytes=await file.readAsBytes();
      if(bytes.length>1048576)throw const ApiException('La foto debe pesar como máximo 1 MB. Elige otra o toma una foto más pequeña.');
      if(!mounted)return;
      final consent=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Foto visible en los viajes'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        Image.memory(bytes,height:220,fit:BoxFit.contain),
        Text(widget.vehicle?'Esta foto se mostrará a los usuarios al consultar tus viajes. Usa una foto del vehículo, sin documentos personales.':'Esta foto se mostrará a otros usuarios en viajes y solicitudes. Usa una foto tuya, sin documentos personales.'),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Guardar foto'))]));
      if(consent!=true)return;
      await ApiClient.instance.saveDisplayPhoto({'base64':base64Encode(bytes),'consent':true,if(widget.vehicle)'vehicleId':widget.id});
      if(mounted){setState(()=>revision++);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Foto guardada')));}
    }catch(e){if(mounted)setState(()=>error=e is ApiException?e.message:'No se pudo cargar la foto. Revisa el permiso de cámara o fotos e intenta nuevamente.');}
    finally{if(source==ImageSource.camera&&file!=null){try{await File(file.path).delete();}catch(_){}}if(mounted)setState(()=>busy=false);}
  }
  Future<void> remove()async{
    final accepted=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Eliminar esta foto?'),content:const Text('En los viajes aparecerá el ícono predeterminado.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Eliminar'))]));
    if(accepted!=true||!mounted)return;
    setState(()=>busy=true);
    try{await ApiClient.instance.deleteDisplayPhoto(vehicleId:widget.vehicle?widget.id:null);if(mounted)setState(()=>revision++);}
    catch(e){if(mounted)setState(()=>error=e.toString());}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.vehicle?'Foto para los viajes':'Foto de perfil')),body:ListView(padding:const EdgeInsets.all(24),children:[
    Center(child:DisplayPhoto(id:widget.id,vehicle:widget.vehicle,size:220,revision:revision)),
    const SizedBox(height:16),const Text('Esta foto será visible para otros usuarios de Vamos. Puedes cambiarla o eliminarla cuando quieras.'),
    if(busy)const LinearProgressIndicator(),if(error!=null)Text(error!,style:TextStyle(color:Theme.of(context).colorScheme.error)),
    FilledButton.icon(onPressed:busy?null:()=>change(ImageSource.camera),icon:const Icon(Icons.camera_alt),label:const Text('Tomar foto')),
    OutlinedButton.icon(onPressed:busy?null:()=>change(ImageSource.gallery),icon:const Icon(Icons.photo_library),label:const Text('Elegir foto')),
    TextButton(onPressed:busy?null:remove,child:const Text('Eliminar foto')),
  ]));
}
