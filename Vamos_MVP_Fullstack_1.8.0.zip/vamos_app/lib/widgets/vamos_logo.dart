import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';

class VamosLogo extends StatelessWidget {
  const VamosLogo({super.key, this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.route_rounded,
            size: compact ? 42 : 68, color: AppColors.green),
        Text(
          'Vamos!!',
          style: TextStyle(
            color: AppColors.darkBlue,
            fontSize: compact ? 28 : 42,
            fontWeight: FontWeight.w900,
          ),
        ),
        if (!compact)
          const Text(
            'Tu ruta, nuestra ruta.',
            style: TextStyle(fontSize: 16, color: Colors.black54),
          ),
      ],
    );
  }
}
