import 'package:flutter/material.dart';

class VamosLogo extends StatelessWidget {
  const VamosLogo({super.key, this.compact = false});
  final bool compact;
  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/brand/vamos_logo.png',
    width: compact ? 180 : 290,
    fit: BoxFit.contain,
    semanticLabel: 'Vamos!! — La unión es la fuerza. Personas compartiendo un vehículo.',
  );
}
