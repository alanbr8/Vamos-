import 'package:flutter/material.dart';

class StarSelector extends StatelessWidget {
  const StarSelector({super.key, required this.value, required this.onChanged, this.size = 34});
  final int value;
  final ValueChanged<int> onChanged;
  final double size;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(5, (index) {
          final rating = index + 1;
          return IconButton(
            visualDensity: VisualDensity.compact,
            onPressed: () => onChanged(rating),
            icon: Icon(rating <= value ? Icons.star : Icons.star_border, color: Colors.amber.shade700, size: size),
          );
        }),
      );
}
