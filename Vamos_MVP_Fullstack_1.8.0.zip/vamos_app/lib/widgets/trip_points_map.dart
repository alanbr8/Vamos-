import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class TripPointsMap extends StatelessWidget {
  const TripPointsMap({super.key,required this.data,this.meeting});
  final Map<String,dynamic> data;
  final Map<String,dynamic>? meeting;
  LatLng? point(Map<String,dynamic> d,String prefix){
    final lat=double.tryParse('${d['${prefix}Lat']}');
    final lng=double.tryParse('${d['${prefix}Lng']}');
    if(lat==null||lng==null||!lat.isFinite||!lng.isFinite||lat.abs()>90||lng.abs()>180)return null;
    return LatLng(lat,lng);
  }
  @override
  Widget build(BuildContext context){
    final start=point(data,'origin'),end=point(data,'destination'),pick=point(meeting??data,'meeting');
    final estimate=data['routeEstimate'] is Map ? data['routeEstimate'] as Map : null;
    final road=<LatLng>[];
    if(estimate?['provider']=='openrouteservice' && data['route'] is List){
      for(final p in data['route'] as List){
        if(p is List && p.length>=2 && p[0] is num && p[1] is num){
          final lat=(p[1] as num).toDouble(),lng=(p[0] as num).toDouble();
          if(lat.isFinite&&lng.isFinite&&lat.abs()<=90&&lng.abs()<=180)road.add(LatLng(lat,lng));
        }
      }
    }
    final livePoint=point(data,'driver');
    final points=[if(livePoint!=null)livePoint,...road,if(start!=null)start,if(end!=null)end,if(pick!=null)pick];
    if(points.isEmpty)return const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('No hay coordenadas disponibles. Vuelve a abrir el viaje para actualizar.')));
    final markers=<Marker>[];
    void add(LatLng? p,String label,Color color){if(p!=null)markers.add(Marker(point:p,width:110,height:64,child:Column(children:[Container(padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),color:Colors.white,child:Text(label,style:TextStyle(color:color,fontWeight:FontWeight.bold))),Icon(Icons.location_on,color:color,size:32)])));}
    add(livePoint,data['stale']==true?'Última posición':'Conductor',data['stale']==true?Colors.grey:Colors.blue);
    add(start,'Partida',Colors.green.shade800);add(end,'Destino',Colors.red.shade800);add(pick,'Punto Vamos!',Colors.blue.shade800);
    final distinct=points.map((p)=>'${p.latitude},${p.longitude}').toSet().length;
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Partida y destino',style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:8),SizedBox(height:260,child:FlutterMap(
        key:ValueKey(points.map((p)=>'${p.latitude},${p.longitude}').join('|')),
        options:MapOptions(initialCenter:points.first,initialZoom:15,initialCameraFit:distinct>1?CameraFit.bounds(bounds:LatLngBounds.fromPoints(points),padding:const EdgeInsets.all(46),maxZoom:16):null),
        children:[TileLayer(urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',userAgentPackageName:'com.vamoscarpool.app'),if(road.length>=2)PolylineLayer(polylines:[Polyline(points:road,color:Colors.blue.shade700,strokeWidth:5)]),MarkerLayer(markers:markers)],
      )),
      if(road.length>=2)...[
        Text('${((double.tryParse("${estimate?['distanceMeters']}")??0)/1000).toStringAsFixed(1)} km · ${((double.tryParse("${estimate?['durationSeconds']}")??0)/60).ceil()} min estimados'),
        const Text('Ruta estimada · sin tráfico en tiempo real. Los extremos pueden tener un acceso corto hasta la calle.'),
        const Text('Ruta: © openrouteservice.org by HeiGIT',style:TextStyle(fontSize:11)),
      ] else const Text('Este viaje no tiene un recorrido por calles calculado.'),
      const Text('© OpenStreetMap contributors',style:TextStyle(fontSize:11)),
      if(start!=null)Text('Partida: ${data['origin']??''} (${start.latitude.toStringAsFixed(5)}, ${start.longitude.toStringAsFixed(5)})'),
      if(end!=null)Text('Destino: ${data['destination']??''} (${end.latitude.toStringAsFixed(5)}, ${end.longitude.toStringAsFixed(5)})'),
      if(pick!=null)...[const SizedBox(height:8),Text('Punto Vamos!: ${(meeting??data)['meetingLabel']??'Propuesto por el pasajero'}'),const Text('Punto propuesto. Coordina los detalles por el chat cuando se acepte la solicitud.')],
    ])));
  }
}
