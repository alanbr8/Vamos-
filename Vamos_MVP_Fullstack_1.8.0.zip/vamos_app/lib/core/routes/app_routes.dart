import 'package:flutter/material.dart';
import '../../screens/verification/verification_screen.dart';

import '../../screens/auth/login_screen.dart';
import '../../screens/auth/forgot_password_screen.dart';
import '../../screens/auth/register_screen.dart';
import '../../screens/home/home_screen.dart';
import '../../screens/notifications/notifications_screen.dart';
import '../../screens/profile/profile_screen.dart';
import '../../screens/rating/rating_screen.dart';
import '../../screens/safety/safety_screen.dart';
import '../../screens/trips/my_trips_screen.dart';
import '../../screens/trips/publish_trip_screen.dart';
import '../../screens/trips/search_trip_screen.dart';
import '../../screens/vehicle/vehicle_screen.dart';
import '../../screens/welcome/welcome_screen.dart';

class AppRoutes {
  static const welcome = '/';
  static const login = '/login';
  static const register = '/register';
  static const forgotPassword = '/forgot-password';
  static const home = '/home';
  static const vehicle = '/vehicle';
  static const offerVehicle = '/offer-vehicle';
  static const publishTrip = '/publish-trip';
  static const searchTrip = '/search-trip';
  static const myTrips = '/my-trips';
  static const verification = '/verification';
  static const profile = '/profile';
  static const notifications = '/notifications';
  static const safety = '/safety';
  static const rating = '/rating';

  static Map<String, WidgetBuilder> get routes => {
        welcome: (_) => const WelcomeScreen(),
        login: (_) => const LoginScreen(),
        register: (_) => const RegisterScreen(),
        forgotPassword: (_) => const ForgotPasswordScreen(),
        home: (_) => const HomeScreen(),
        vehicle: (_) => const VehicleScreen(),
        offerVehicle: (_) => const VehicleScreen(forOffering: true),
        publishTrip: (_) => const PublishTripScreen(),
        searchTrip: (_) => const SearchTripScreen(),
        myTrips: (_) => const MyTripsScreen(),
        safety: (_) => const SafetyScreen(),
        verification: (_) => const VerificationScreen(),
        profile: (_) => const ProfileScreen(),
        notifications: (_) => const NotificationsScreen(),
        rating: (_) => const RatingScreen(),
      };
}
