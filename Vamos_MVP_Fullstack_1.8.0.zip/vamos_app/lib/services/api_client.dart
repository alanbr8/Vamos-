import 'dart:convert';
import 'dart:io';

import '../core/config/app_config.dart';
import 'session_store.dart';

class ApiException implements Exception {
  const ApiException(this.message, [this.statusCode]);
  final String message;
  final int? statusCode;
  @override
  String toString() => message;
}

class ApiClient {
  ApiClient._();
  static final instance = ApiClient._();
  final HttpClient _http = HttpClient();

  Future<Map<String, dynamic>> register({required String firstName, required String lastName, required String email, required String phone, required String password}) async {
    final response = await _request('POST', '/auth/register', body: {'firstName': firstName, 'lastName': lastName, 'email': email, 'phone': phone, 'password': password}, authenticated: false);
    await SessionStore.instance.save(response);
    return response;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await _request('POST', '/auth/login', body: {'email': email, 'password': password}, authenticated: false);
    await SessionStore.instance.save(response);
    return response;
  }

  Future<Map<String, dynamic>> forgotPassword(String email) => _request(
        'POST',
        '/auth/forgot-password',
        body: {'email': email},
        authenticated: false,
      );

  Future<Map<String, dynamic>> resetPassword(String token, String password) =>
      _request(
        'POST',
        '/auth/reset-password',
        body: {'token': token, 'password': password},
        authenticated: false,
      );

  Future<Map<String, dynamic>> profile() => _request('GET', '/users/me');

  Future<List<dynamic>> vehicles() async => (await _requestList('GET', '/vehicles/me'));

  Future<Map<String, dynamic>> createVehicle(Map<String, dynamic> vehicle) => _request('POST', '/vehicles', body: vehicle);

  Future<Map<String, dynamic>> createTrip(Map<String, dynamic> trip) => _request('POST', '/trips', body: trip);

  Future<List<dynamic>> searchTrips(Map<String, dynamic> criteria) => _requestList('POST', '/trips/search', body: criteria);

  Future<Map<String, dynamic>> createBooking(String tripId, {int seats = 1}) => _request('POST', '/bookings', body: {'tripId': tripId, 'seats': seats});

  Future<List<dynamic>> driverTrips() => _requestList('GET', '/trips/me/driver');

  Future<List<dynamic>> passengerBookings() => _requestList('GET', '/bookings/me');

  Future<Map<String, dynamic>> bookingAction(String bookingId, String action) => _request('PATCH', '/bookings/$bookingId/$action');

  Future<Map<String, dynamic>> startTrip(String tripId, String code) => _request('PATCH', '/trips/$tripId/start', body: {'code': code});

  Future<Map<String, dynamic>> completeTrip(String tripId) => _request('PATCH', '/trips/$tripId/complete');

  Future<Map<String, dynamic>> createRating(Map<String, dynamic> rating) => _request('POST', '/ratings', body: rating);

  Future<List<dynamic>> ratings() => _requestList('GET', '/ratings/me');

  Future<Map<String, dynamic>> createIncident(Map<String, dynamic> incident) => _request('POST', '/incidents', body: incident);

  Future<List<dynamic>> incidents() => _requestList('GET', '/incidents/me');

  Future<List<dynamic>> notifications() => _requestList('GET', '/notifications');

  Future<int> unreadNotificationCount() async {
    final response = await _request('GET', '/notifications/unread-count');
    return int.tryParse(response['count']?.toString() ?? '') ?? 0;
  }

  Future<Map<String, dynamic>> readNotification(String id) =>
      _request('PATCH', '/notifications/$id/read');

  Future<Map<String, dynamic>> readAllNotifications() =>
      _request('PATCH', '/notifications/read-all');

  Future<List<dynamic>> messages(String bookingId) =>
      _requestList('GET', '/bookings/$bookingId/messages');

  Future<Map<String, dynamic>> sendMessage(String bookingId, String body) =>
      _request('POST', '/bookings/$bookingId/messages', body: {'body': body});

  Future<Map<String, dynamic>> _request(String method, String path, {Map<String, dynamic>? body, bool authenticated = true}) async {
    final decoded = await _send(method, path, body: body, authenticated: authenticated);
    if (decoded is Map<String, dynamic>) return decoded;
    throw const ApiException('La respuesta del servidor no tiene el formato esperado');
  }

  Future<List<dynamic>> _requestList(String method, String path, {Map<String, dynamic>? body}) async {
    final decoded = await _send(method, path, body: body);
    if (decoded is List<dynamic>) return decoded;
    throw const ApiException('La respuesta del servidor no contiene una lista');
  }

  Future<dynamic> _send(String method, String path, {Map<String, dynamic>? body, bool authenticated = true}) async {
    try {
      final request = await _http.openUrl(method, Uri.parse('${AppConfig.apiBaseUrl}$path'));
      request.headers.contentType = ContentType.json;
      if (authenticated) {
        final token = SessionStore.instance.accessToken;
        if (token == null) throw const ApiException('Debes iniciar sesión', 401);
        request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      }
      if (body != null) request.write(jsonEncode(body));
      final response = await request.close();
      final text = await utf8.decoder.bind(response).join();
      final decoded = text.isEmpty ? <String, dynamic>{} : jsonDecode(text);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        if (response.statusCode == 401 && authenticated) {
          await SessionStore.instance.clear();
        }
        final message = decoded is Map<String, dynamic> ? decoded['message'] : null;
        throw ApiException(message is List ? message.join(', ') : (message?.toString() ?? 'Error del servidor'), response.statusCode);
      }
      return decoded;
    } on SocketException {
      throw const ApiException('No se pudo conectar con la API. Verifica que el servidor esté encendido.');
    } on FormatException {
      throw const ApiException('El servidor devolvió una respuesta inválida.');
    }
  }
}
