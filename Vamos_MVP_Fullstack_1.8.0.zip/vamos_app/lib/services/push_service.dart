import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_client.dart';
import 'session_store.dart';

@pragma('vm:entry-point')
Future<void> vamosBackgroundMessage(RemoteMessage message) async {
  await Firebase.initializeApp();
  // FCM muestra el aviso del sistema. No se consulta ni se guarda contenido privado aquí.
}
class PushService {
  PushService._();
  static final instance=PushService._();
  final storage=const FlutterSecureStorage();
  Future<bool>? initializing;
  Future<void> serial=Future.value();
  String? token;
  String? tokenUser;
  void Function(String)? onOpen;
  void Function(String)? onForeground;
  String status='Pulsa para activar los avisos en este teléfono';
  Future<bool> initialize()=>initializing??=_initialize();
  Future<bool> _initialize()async{
    try{
      await Firebase.initializeApp();
      FirebaseMessaging.onBackgroundMessage(vamosBackgroundMessage);
      FirebaseMessaging.onMessageOpenedApp.listen(open);
      FirebaseMessaging.onMessage.listen((m){
        if(m.data['userId']==SessionStore.instance.user?['id'])onForeground?.call(m.data['notificationId']??'');
      });
      FirebaseMessaging.instance.onTokenRefresh.listen((_){unawaited(sync());});
      final initial=await FirebaseMessaging.instance.getInitialMessage();
      if(initial!=null)open(initial);
      return true;
    }catch(_){status='Falta configurar Firebase para esta compilación';return false;}
  }
  void open(RemoteMessage m){
    final id=m.data['notificationId'];
    if(SessionStore.instance.isAuthenticated&&m.data['userId']==SessionStore.instance.user?['id']&&id!=null)onOpen?.call(id);
  }
  Future<void> ordered(Future<void> Function() action){
    final next=serial.then((_)=>action());
    serial=next.catchError((_){ });return next;
  }
  Future<void> sync()=>ordered(()async{
    try{
      if(!SessionStore.instance.isAuthenticated||!await initialize())return;
      if(await storage.read(key:'vamos_push_disabled')=='true'){status='Avisos desactivados en este teléfono';return;}
      final settings=await FirebaseMessaging.instance.getNotificationSettings();
      if(settings.authorizationStatus!=AuthorizationStatus.authorized&&settings.authorizationStatus!=AuthorizationStatus.provisional){status='Activa el permiso de notificaciones para recibir avisos';return;}
      final user=SessionStore.instance.user?['id']?.toString();
      if(user==null)return;
      final fresh=await FirebaseMessaging.instance.getToken();
      if(fresh==null){status='No se pudo registrar este teléfono. Reintenta.';return;}
      if(SessionStore.instance.user?['id']!=user)return;
      await ApiClient.instance.registerPush(fresh);
      token=fresh;tokenUser=user;status='Avisos activados en este teléfono';
    }catch(_){status='No se pudo activar. Revisa la conexión y vuelve a intentarlo.';}
  });
  Future<String> enable()async{
    if(!await initialize())return status;
    try{
      await FirebaseMessaging.instance.requestPermission(alert:true,badge:true,sound:true);
      await storage.delete(key:'vamos_push_disabled');
      await sync();
    }catch(_){status='No se pudo activar. Revisa el permiso en Ajustes del teléfono.';}
    return status;
  }
  Future<void> logout()=>ordered(()async{
    try{
      if(token!=null&&tokenUser==SessionStore.instance.user?['id'])await ApiClient.instance.unregisterPush(token!);
    }catch(_){ }
    try{if(initializing!=null&&await initializing!)await FirebaseMessaging.instance.deleteToken();}catch(_){ }
    token=null;tokenUser=null;
  });
  Future<String> disable()async{
    await storage.write(key:'vamos_push_disabled',value:'true');
    await logout();status='Avisos desactivados en este teléfono';return status;
  }
}
