import '../models/map_point.dart';

/// Traduce el formulario móvil al contrato de `POST /trips`.
///
/// GeoJSON utiliza el orden [longitud, latitud], distinto al orden habitual
/// mostrado en interfaces de mapas.
class TripPayloadBuilder {
  const TripPayloadBuilder._();

  static Map<String, dynamic> build({
    required String vehicleId,
    required String originLabel,
    required MapPoint origin,
    required String destinationLabel,
    required MapPoint destination,
    required DateTime departure,
    required int availableSeats,
    required double contribution,
    List<int> recurringDays = const [],
    Map<String, dynamic> preferences = const {},
    List<MapPoint>? routePoints,
  }) {
    final route = routePoints ?? [origin, destination];

    return {
      'vehicleId': vehicleId,
      'originLabel': originLabel,
      'originLat': origin.latitude,
      'originLng': origin.longitude,
      'destinationLabel': destinationLabel,
      'destinationLat': destination.latitude,
      'destinationLng': destination.longitude,
      'route': route.map((point) => point.geoJsonCoordinate).toList(),
      'departureAt': departure.toUtc().toIso8601String(),
      'availableSeats': availableSeats,
      'contribution': contribution,
      'recurringDays': recurringDays,
      'preferences': preferences,
    };
  }
}
