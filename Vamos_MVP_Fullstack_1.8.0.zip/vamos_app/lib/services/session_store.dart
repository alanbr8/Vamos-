import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SessionStore {
  SessionStore._();
  static final instance = SessionStore._();

  String? accessToken;
  Map<String, dynamic>? user;
  static const _tokenKey = 'vamos_access_token';
  static const _userKey = 'vamos_user';
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  bool get isAuthenticated => accessToken != null;

  Future<void> save(Map<String, dynamic> response) async {
    accessToken = response['accessToken'] as String?;
    user = response['user'] as Map<String, dynamic>?;
    if (accessToken != null) await _storage.write(key: _tokenKey, value: accessToken);
    if (user != null) await _storage.write(key: _userKey, value: jsonEncode(user));
  }

  Future<bool> restore() async {
    accessToken = await _storage.read(key: _tokenKey);
    final rawUser = await _storage.read(key: _userKey);
    if (rawUser != null) {
      try {
        user = Map<String, dynamic>.from(jsonDecode(rawUser) as Map);
      } catch (_) {
        await clear();
      }
    }
    if (_tokenIsExpired(accessToken)) await clear();
    return isAuthenticated;
  }

  bool _tokenIsExpired(String? token) {
    if (token == null) return true;
    try {
      final parts = token.split('.');
      if (parts.length != 3) return true;
      final payload = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      ) as Map<String, dynamic>;
      final expiresAt = int.tryParse(payload['exp']?.toString() ?? '');
      if (expiresAt == null) return true;
      return DateTime.now().millisecondsSinceEpoch >= expiresAt * 1000;
    } catch (_) {
      return true;
    }
  }

  Future<void> clear() async {
    accessToken = null;
    user = null;
    await Future.wait([
      _storage.delete(key: _tokenKey),
      _storage.delete(key: _userKey),
    ]);
  }
}
