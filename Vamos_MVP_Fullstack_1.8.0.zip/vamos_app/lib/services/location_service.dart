import 'package:geolocator/geolocator.dart';
import '../models/map_point.dart';

class LocationService {
  static Future<MapPoint> currentPosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw Exception('Activa la ubicación del dispositivo');
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      throw Exception('Vamos!! necesita permiso de ubicación para seleccionar el punto actual');
    }
    final position = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)),
    );
    return MapPoint(latitude: position.latitude, longitude: position.longitude, label: 'Mi ubicación actual');
  }

  static double distanceMeters(MapPoint start, MapPoint end) => Geolocator.distanceBetween(start.latitude, start.longitude, end.latitude, end.longitude);
}
