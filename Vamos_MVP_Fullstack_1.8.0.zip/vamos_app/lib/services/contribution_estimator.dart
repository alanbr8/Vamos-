class ContributionEstimate {
  const ContributionEstimate(this.fuel, this.wear, this.tolls, this.occupants);
  final double fuel;
  final double wear;
  final double tolls;
  final int occupants;
  double get total => fuel + wear + tolls;
  double get perPerson => total / occupants;
}

class ContributionEstimator {
  static ContributionEstimate? calculate({
    required double kilometers,
    required double wearPercent,
    required double tolls,
    required int passengers,
  }) {
    if (!kilometers.isFinite || kilometers <= 0 ||
        !wearPercent.isFinite || wearPercent < 0 || wearPercent > 100 ||
        !tolls.isFinite || tolls < 0 || passengers < 1 || passengers > 7) {
      return null;
    }
    final fuel = kilometers * 0.7;
    final result = ContributionEstimate(fuel, fuel * wearPercent / 100,
        tolls, passengers + 1);
    return result.total.isFinite ? result : null;
  }
}
