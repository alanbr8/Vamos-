enum IncidentType { unsafeDriving, harassment, noShow, routeProblem, other }

class SafetyIncident {
  const SafetyIncident({
    this.id,
    this.resolutionDetail,
    this.resolvedAt,
    required this.type,
    required this.description,
    required this.createdAt,
    this.tripReference = 'VIAJE-DEMO-001',
    this.status = 'RECEIVED',
  });

  final String? id;
  final String? resolutionDetail;
  final DateTime? resolvedAt;
  final IncidentType type;
  final String description;
  final DateTime createdAt;
  final String tripReference;
  final String status;
}
