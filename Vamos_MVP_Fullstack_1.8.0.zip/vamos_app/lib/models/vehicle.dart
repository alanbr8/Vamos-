enum VehicleStatus { draft, pending, verified, rejected, suspended }

class Vehicle {
  const Vehicle({
    this.id,
    required this.brand,
    required this.model,
    required this.year,
    required this.color,
    required this.licensePlate,
    required this.passengerSeats,
    this.status = VehicleStatus.pending,
  });

  final String? id;
  final String brand;
  final String model;
  final int year;
  final String color;
  final String licensePlate;
  final int passengerSeats;
  final VehicleStatus status;

  bool get isVerified => status == VehicleStatus.verified;

  factory Vehicle.fromJson(Map<String, dynamic> json) => Vehicle(
        id: json['id']?.toString(),
        brand: json['brand']?.toString() ?? '',
        model: json['model']?.toString() ?? '',
        year: int.tryParse(json['year']?.toString() ?? '') ?? 0,
        color: json['color']?.toString() ?? '',
        licensePlate: json['licensePlate']?.toString() ?? '',
        passengerSeats:
            int.tryParse(json['passengerSeats']?.toString() ?? '') ?? 1,
        status: _statusFromApi(json['status']?.toString()),
      );

  Map<String, dynamic> toJson() => {
        'brand': brand,
        'model': model,
        'year': year,
        'color': color,
        'licensePlate': licensePlate,
        'passengerSeats': passengerSeats,
      };
}

VehicleStatus _statusFromApi(String? value) {
  switch (value?.toUpperCase()) {
    case 'VERIFIED':
      return VehicleStatus.verified;
    case 'REJECTED':
      return VehicleStatus.rejected;
    case 'SUSPENDED':
      return VehicleStatus.suspended;
    case 'DRAFT':
      return VehicleStatus.draft;
    default:
      return VehicleStatus.pending;
  }
}
