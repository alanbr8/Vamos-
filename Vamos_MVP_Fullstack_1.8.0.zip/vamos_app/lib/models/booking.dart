enum BookingStatus { pending, accepted, rejected, cancelled, noShow, completed }
enum RideStatus { published, reserved, inProgress, completed, cancelled }

class Booking {
  const Booking({
    required this.passenger,
    required this.rating,
    required this.seats,
    required this.meetingPoint,
    this.status = BookingStatus.pending,
  });

  final String passenger;
  final double rating;
  final int seats;
  final String meetingPoint;
  final BookingStatus status;

  Booking copyWith({BookingStatus? status}) => Booking(
        passenger: passenger,
        rating: rating,
        seats: seats,
        meetingPoint: meetingPoint,
        status: status ?? this.status,
      );
}
