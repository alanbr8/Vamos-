enum RatedRole { driver, passenger }

class UserRating {
  const UserRating({
    required this.fromUser,
    required this.toUser,
    required this.role,
    required this.overall,
    required this.categories,
    required this.comment,
    required this.createdAt,
  });

  final String fromUser;
  final String toUser;
  final RatedRole role;
  final int overall;
  final Map<String, int> categories;
  final String comment;
  final DateTime createdAt;
}
