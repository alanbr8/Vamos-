enum TripStatus { draft, published, reserved, inProgress, completed, cancelled }

class TripPreferences {
  const TripPreferences({
    this.music = 'Sin preferencia',
    this.conversation = 'Sin preferencia',
    this.pets = 'No permitidas',
    this.luggage = 'Pequeño',
  });

  final String music;
  final String conversation;
  final String pets;
  final String luggage;

  Map<String, dynamic> toJson() => {
        'music': music,
        'conversation': conversation,
        'pets': pets,
        'luggage': luggage,
      };
}

class TripDraft {
  const TripDraft({
    required this.origin,
    required this.destination,
    required this.departure,
    required this.availableSeats,
    required this.suggestedContribution,
    required this.preferences,
    this.recurringDays = const [],
    this.status = TripStatus.draft,
  });

  final String origin;
  final String destination;
  final DateTime departure;
  final int availableSeats;
  final double suggestedContribution;
  final TripPreferences preferences;
  final List<int> recurringDays;
  final TripStatus status;

  bool get isRecurring => recurringDays.isNotEmpty;

  Map<String, dynamic> toJson() => {
        'origin': origin,
        'destination': destination,
        'departureDatetime': departure.toIso8601String(),
        'availableSeats': availableSeats,
        'suggestedContribution': suggestedContribution,
        'recurring': isRecurring,
        'recurringDays': recurringDays,
        'preferences': preferences.toJson(),
        'status': status.name.toUpperCase(),
      };
}
