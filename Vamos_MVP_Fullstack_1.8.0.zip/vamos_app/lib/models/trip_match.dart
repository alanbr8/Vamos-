class TripMatch {
  const TripMatch({
    this.route, this.routeEstimate,
    this.id,
    this.originLat, this.originLng, this.destinationLat, this.destinationLng,
    this.driverId,
    this.vehicleId,
    required this.driver,
    required this.rating,
    required this.trips,
    required this.vehicle,
    required this.origin,
    required this.destination,
    required this.time,
    required this.seats,
    required this.price,
    required this.compatibility,
    required this.meetingPoint,
    required this.walkMinutes,
    required this.detourMinutes,
  });

  final String? id;
  final List<dynamic>? route;
  final Map<String,dynamic>? routeEstimate;
  final double? originLat, originLng, destinationLat, destinationLng;
  final String? driverId;
  final String? vehicleId;
  final String driver;
  final double rating;
  final int trips;
  final String vehicle;
  final String origin;
  final String destination;
  final String time;
  final int seats;
  final double price;
  final int compatibility;
  final String meetingPoint;
  final int walkMinutes;
  final int detourMinutes;
}
