class MapPoint {
  const MapPoint({required this.latitude, required this.longitude, required this.label});
  final double latitude;
  final double longitude;
  final String label;

  List<double> get geoJsonCoordinate => [longitude, latitude];
}
