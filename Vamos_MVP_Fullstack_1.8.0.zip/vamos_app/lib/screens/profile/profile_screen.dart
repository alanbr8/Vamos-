import '../../services/push_service.dart';
import '../../widgets/display_photo.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../core/routes/app_routes.dart';
import '../../services/session_store.dart';
import '../../services/api_client.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int photoRevision = 0;
  bool configuringPush = false;
  bool loading = true;
  String? error;
  Map<String, dynamic> profile = {};
  List<Map<String, dynamic>> ratings = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final results = await Future.wait([
        ApiClient.instance.profile(),
        ApiClient.instance.ratings(),
      ]);
      if (!mounted) return;
      setState(() {
        profile = Map<String, dynamic>.from(results[0] as Map);
        ratings = (results[1] as List)
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
      });
    } on ApiException catch (apiError) {
      if (mounted) setState(() => error = apiError.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  double average(String key) {
    final values = ratings
        .map((rating) => double.tryParse(rating[key]?.toString() ?? ''))
        .whereType<double>()
        .toList();
    if (values.isEmpty) return 0;
    return values.reduce((a, b) => a + b) / values.length;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Mi perfil'),
      actions: [
        IconButton(
          onPressed: loading ? null : load,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : error != null
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(error!, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: load,
                    child: const Text('REINTENTAR'),
                  ),
                ],
              ),
            ),
          )
        : content(context),
  );

  Widget content(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Center(child: DisplayPhoto(id:profile['id']?.toString(),size:88,revision:photoRevision)),
      TextButton.icon(
        icon:const Icon(Icons.edit),label:const Text('CAMBIAR FOTO DE PERFIL'),
        onPressed: profile['id'] == null ? null : () async {
          await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>PhotoEditor(id:profile['id'].toString())));
          if(mounted)setState(()=>photoRevision++);
        },
      ),
      const SizedBox(height: 10),
      Text(
        '${profile['firstName'] ?? ''} ${profile['lastName'] ?? ''}'.trim(),
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.headlineSmall,
      ),
      Center(
        child: Chip(
          avatar: Icon(
            profile['identityVerified'] == true
                ? Icons.verified
                : Icons.info_outline,
            size: 18,
            color: AppColors.green,
          ),
          label: Text(
            profile['identityVerified'] == true
                ? 'Identidad verificada'
                : 'Identidad pendiente',
          ),
        ),
      ),
      const SizedBox(height: 12),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          ProfileStat(
            value: (double.tryParse(profile['rating']?.toString() ?? '') ?? 0)
                .toStringAsFixed(1),
            label: 'Calificación',
          ),
          ProfileStat(
            value: profile['ratingCount']?.toString() ?? '0',
            label: 'Opiniones',
          ),
        ],
      ),
      const SizedBox(height: 22),
      ListTile(
        leading: const Icon(Icons.email_outlined),
        title: Text(profile['email']?.toString() ?? 'Sin correo'),
      ),
      ListTile(
        leading: const Icon(Icons.phone_outlined),
        title: Text(profile['phone']?.toString() ?? 'Sin celular'),
      ),
      ListTile(
        leading: const Icon(Icons.badge_outlined),
        title: const Text('Identidad y licencia'),
        subtitle: const Text('Carnet, selfie y documentos para conducir'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () async { await Navigator.pushNamed(context,AppRoutes.verification); if (mounted) await load(); },
      ),
      ListTile(
        leading: const Icon(Icons.directions_car_outlined),
        title: const Text('Mi vehículo'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.pushNamed(context, AppRoutes.vehicle),
      ),
      ListTile(
        leading:const Icon(Icons.notifications_active_outlined),title:const Text('Notificaciones push'),
        subtitle:Text(PushService.instance.status),
        onTap:configuringPush?null:() async {
          setState(()=>configuringPush=true);
          try{final message=await PushService.instance.enable();if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));}
          finally{if(mounted)setState(()=>configuringPush=false);}
        },
      ),
      TextButton(onPressed:configuringPush?null:() async {setState(()=>configuringPush=true);try{await PushService.instance.disable();}finally{if(mounted)setState(()=>configuringPush=false);}},child:const Text('Desactivar avisos en este teléfono')),
      TextButton(
        onPressed: () async {
          await SessionStore.instance.clear();
          if (context.mounted)
            Navigator.pushNamedAndRemoveUntil(
              context,
              AppRoutes.welcome,
              (_) => false,
            );
        },
        child: const Text('CERRAR SESIÓN'),
      ),
      Text('Reputación', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 10),
      ReputationRow(label: 'Puntualidad', value: average('punctuality')),
      ReputationRow(label: 'Amabilidad', value: average('kindness')),
      ReputationRow(label: 'Seguridad', value: average('safety')),
      ReputationRow(label: 'Conducción', value: average('driving')),
      const SizedBox(height: 20),
      Text(
        'Comentarios recientes',
        style: Theme.of(context).textTheme.titleLarge,
      ),
      if (ratings
          .where((rating) => (rating['comment']?.toString() ?? '').isNotEmpty)
          .isEmpty)
        const Card(
          child: ListTile(
            leading: Icon(Icons.chat_bubble_outline),
            title: Text('Aún no tienes comentarios.'),
          ),
        ),
      ...ratings
          .where((rating) => (rating['comment']?.toString() ?? '').isNotEmpty)
          .take(5)
          .map(
            (rating) => ReviewCard(
              author: rating['author']?.toString() ?? 'Usuario',
              text: rating['comment'].toString(),
              rating: int.tryParse(rating['overall']?.toString() ?? '') ?? 0,
            ),
          ),
    ],
  );
}

class ProfileStat extends StatelessWidget {
  const ProfileStat({super.key, required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Text(
        value,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: AppColors.green,
        ),
      ),
      Text(label, style: const TextStyle(color: Colors.black54)),
    ],
  );
}

class ReputationRow extends StatelessWidget {
  const ReputationRow({super.key, required this.label, required this.value});
  final String label;
  final double value;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(
      children: [
        SizedBox(width: 100, child: Text(label)),
        Expanded(
          child: LinearProgressIndicator(
            value: value / 5,
            minHeight: 8,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        const SizedBox(width: 10),
        Text(value.toStringAsFixed(1)),
      ],
    ),
  );
}

class ReviewCard extends StatelessWidget {
  const ReviewCard({
    super.key,
    required this.author,
    required this.text,
    required this.rating,
  });
  final String author;
  final String text;
  final int rating;
  @override
  Widget build(BuildContext context) {
    final stars = List.filled(rating, '★').join();
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Text(author[0])),
        title: Text('$author  $stars'),
        subtitle: Text(text),
      ),
    );
  }
}
