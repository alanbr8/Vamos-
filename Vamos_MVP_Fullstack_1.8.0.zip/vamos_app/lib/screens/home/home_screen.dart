import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';
import '../../services/session_store.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int unread = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    loadUnread();
    timer = Timer.periodic(const Duration(seconds: 30), (_) => loadUnread());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> loadUnread() async {
    try {
      final count = await ApiClient.instance.unreadNotificationCount();
      if (mounted) setState(() => unread = count);
    } on ApiException {
      // La pantalla principal permanece utilizable si el contador falla.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vamos!!',
            style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          Badge(
            isLabelVisible: unread > 0,
            label: Text(unread > 99 ? '99+' : '$unread'),
            child: IconButton(
              tooltip: 'Notificaciones',
              onPressed: () async {
                await Navigator.pushNamed(context, AppRoutes.notifications);
                await loadUnread();
              },
              icon: const Icon(Icons.notifications_none),
            ),
          ),
          IconButton(
            tooltip: 'Seguridad',
            onPressed: () => Navigator.pushNamed(context, AppRoutes.safety),
            icon: const Icon(Icons.shield_outlined),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle_outlined),
            onSelected: (value) async {
              if (value == 'profile') {
                Navigator.pushNamed(context, AppRoutes.profile);
              } else if (value == 'logout') {
                await SessionStore.instance.clear();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    AppRoutes.welcome,
                    (_) => false,
                  );
                }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('Mi perfil')),
              PopupMenuItem(value: 'logout', child: Text('Cerrar sesión')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Hola, viajero 👋',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 4),
          const Text('¿Qué quieres hacer hoy?'),
          const SizedBox(height: 24),
          _ActionCard(
            icon: Icons.directions_car_outlined,
            title: 'OFRECER UN VIAJE',
            subtitle: 'Comparte tu ruta',
            onTap: () => Navigator.pushNamed(context, AppRoutes.vehicle),
          ),
          const SizedBox(height: 14),
          _ActionCard(
            icon: Icons.person_search_outlined,
            title: 'BUSCAR UN VIAJE',
            subtitle: 'Encuentra una ruta',
            onTap: () => Navigator.pushNamed(context, AppRoutes.searchTrip),
          ),
          const SizedBox(height: 28),
          Text('Próximos viajes',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('No tienes viajes próximos')),
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (index) {
          if (index == 1) Navigator.pushNamed(context, AppRoutes.myTrips);
          if (index == 2) {
            Navigator.pushNamed(context, AppRoutes.profile);
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.route_outlined), label: 'Viajes'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Perfil'),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: const Color(0xFFE4F6EE),
                child: Icon(icon,
                    color: AppColors.green, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(subtitle),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}
