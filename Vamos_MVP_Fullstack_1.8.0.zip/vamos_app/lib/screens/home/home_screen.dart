import '../communities/communities_screen.dart';
import '../safety/sos_screen.dart';
import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';
import '../../services/session_store.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int unread = 0;
  Timer? timer;
  bool counting = false;

  @override
  void initState() {
    super.initState();
    loadUnread();
    timer = Timer.periodic(const Duration(seconds: 30), (_) => loadUnread());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> loadUnread() async {
    if (counting || !mounted || !SessionStore.instance.isAuthenticated) return;
    counting = true;
    try {
      final count = await ApiClient.instance.unreadNotificationCount();
      if (mounted) setState(() => unread = count);
    } on ApiException {
      // La pantalla principal permanece utilizable si el contador falla.
    } finally {
      counting = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Vamos!!',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          const SosButton(),
          Badge(
            isLabelVisible: unread > 0,
            label: Text(unread > 99 ? '99+' : '$unread'),
            child: IconButton(
              tooltip: 'Notificaciones',
              onPressed: () async {
                await Navigator.pushNamed(context, AppRoutes.notifications);
                await loadUnread();
              },
              icon: const Icon(Icons.notifications_none),
            ),
          ),
          IconButton(
            tooltip: 'Seguridad',
            onPressed: () => Navigator.pushNamed(context, AppRoutes.safety),
            icon: const Icon(Icons.shield_outlined),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.account_circle_outlined),
            onSelected: (value) async {
              if (value == 'profile') {
                Navigator.pushNamed(context, AppRoutes.profile);
              } else if (value == 'logout') {
                await SessionStore.instance.clear();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    AppRoutes.welcome,
                    (_) => false,
                  );
                }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('Mi perfil')),
              PopupMenuItem(value: 'logout', child: Text('Cerrar sesión')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(child:ListTile(leading:const Icon(Icons.groups),title:const Text('Comunidades Vamos!!'),subtitle:const Text('Tu empresa, barrio o grupo'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>const CommunitiesScreen())))),
          Center(child: Image.asset('assets/brand/vamos_logo.png', height: 165, semanticLabel: 'Vamos!! — La unión es la fuerza')),
          Text(
            'Hola, ${SessionStore.instance.user?['firstName'] ?? 'viajero'} 👋',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 4),
          const Text('Tu ciudad. Tu gente. Tu próxima ruta.'),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF075C36), Color(0xFF087C48)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Icon(Icons.favorite_outline, color: Color(0xFFCBF4DB), size: 18), SizedBox(width: 8), Expanded(child: Text('LA UNIÓN ES LA FUERZA', style: TextStyle(color: Color(0xFFCBF4DB), fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1)))]),
              const SizedBox(height: 18),
              const Text('Comparte el viaje.\nDivide los gastos.', style: TextStyle(color: Colors.white, fontSize: 30, height: 1.12, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              const Text('Conecta con personas que van por tu camino y aprovechen juntos cada asiento.', style: TextStyle(color: Colors.white, fontSize: 16, height: 1.45)),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF075C36)),
                onPressed: () => Navigator.pushNamed(context, AppRoutes.searchTrip),
                icon: const Icon(Icons.search), label: const Text('BUSCAR UN VIAJE'),
              )),
            ]),
          ),
          const SizedBox(height: 16),
          _ActionCard(
            icon: Icons.directions_car_outlined,
            title: '¿VAS A CONDUCIR?',
            subtitle: 'Ofrece un viaje y comparte los gastos de tu ruta.',
            onTap: () => Navigator.pushNamed(context, AppRoutes.offerVehicle),
          ),
          const SizedBox(height: 24),
          Text('Más motivos para ir juntos', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          const _Benefit(icon: Icons.savings_outlined, title: 'Gastos compartidos', text: 'El conductor propone el aporte y tú lo revisas antes de solicitar un asiento.'),
          const _Benefit(icon: Icons.groups_outlined, title: 'Un camino, más compañía', text: 'Coordina por el chat y encuéntrate en tu Punto Vamos!.'),
          const _Benefit(icon: Icons.eco_outlined, title: 'Aprovecha los asientos', text: 'Compartir un auto puede evitar que cada persona haga el mismo trayecto en otro vehículo.'),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: const Color(0xFFE4F3E8), borderRadius: BorderRadius.circular(20)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Así se comparten los gastos', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.darkBlue)),
              SizedBox(height: 8),
              Text('Bs 40 ÷ 4 personas = Bs 10 por persona', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.darkBlue)),
              SizedBox(height: 6),
              Text('Ejemplo ilustrativo: conductor y 3 pasajeros comparten por igual el mismo recorrido. El aporte real depende del viaje.', style: TextStyle(fontSize: 13, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 28),
          Text('Tus viajes', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.route),
              title: const Text('Ver viajes y reservas'),
              subtitle: const Text(
                'Retoma tus reservas, publicaciones y búsquedas guardadas.',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.pushNamed(context, AppRoutes.myTrips),
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (index) {
          if (index == 1) Navigator.pushNamed(context, AppRoutes.myTrips);
          if (index == 2) {
            Navigator.pushNamed(context, AppRoutes.notifications).then((_) => loadUnread());
          }
          if (index == 3) Navigator.pushNamed(context, AppRoutes.profile);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            label: 'Inicio',
          ),
          NavigationDestination(
            icon: Icon(Icons.route_outlined),
            label: 'Viajes',
          ),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), label: 'Alertas'),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: const Color(0xFFE4F6EE),
                child: Icon(icon, color: AppColors.green, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(subtitle),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title, text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: AppColors.green)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 3), Text(text, style: const TextStyle(height: 1.4)),
      ])),
    ]),
  );
}
