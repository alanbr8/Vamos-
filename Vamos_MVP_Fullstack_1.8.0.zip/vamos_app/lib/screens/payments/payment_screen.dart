import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/api_client.dart';

class PaymentScreen extends StatefulWidget {
 const PaymentScreen({super.key,this.bookingId});
 final String? bookingId;
 @override State<PaymentScreen> createState()=>_PaymentScreenState();
}
class _PaymentScreenState extends State<PaymentScreen>{
 Map<String,dynamic>? data;
 String? qr,error;
 bool busy=false;
 bool get managing=>widget.bookingId==null;
 String get path=>managing?'qr':'booking/${widget.bookingId}';
 @override void initState(){super.initState();load();}
 Future<void> load()async{
  setState(()=>busy=true);
  try{
   final result=await ApiClient.instance.payment(path);
   if(!mounted)return;
   setState((){error=null;if(managing){qr=result['base64'] as String?;}else{data=result;}});
  }catch(e){if(mounted)setState(()=>error=e is ApiException?e.message:'No se pudo cargar. Reintenta.');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> upload()async{
  setState(()=>busy=true);
  try{
   final file=await ImagePicker().pickImage(source:ImageSource.gallery,requestFullMetadata:false);
   if(file==null||!mounted)return;
   final bytes=await file.readAsBytes();
   if(bytes.length>1048576)throw const ApiException('Usa la imagen original del QR de tu banco, de hasta 1 MB.');
   if(!mounted)return;
   final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Publicar mi QR bancario'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[Image.memory(bytes,height:200),const Text('Confirma que pertenece a tu cuenta. Será visible a tus pasajeros con reserva aceptada. Usa un QR vigente, preferentemente sin importe fijo. Vamos!! no verifica el banco ni recibe el dinero.')])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Guardar'))]));
   if(yes!=true)return;
   await ApiClient.instance.payment('qr',method:'POST',body:{'base64':base64Encode(bytes),'consent':true});
   if(mounted)await load();
  }catch(e){if(mounted)setState(()=>error=e is ApiException?e.message:'No se pudo guardar el QR.');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> action(String suffix,{Map<String,dynamic>? body})async{
  setState(()=>busy=true);
  try{await ApiClient.instance.payment('$path/$suffix',method:'POST',body:body);if(mounted)await load();}
  catch(e){if(mounted)setState(()=>error=e is ApiException?e.message:'No se pudo actualizar el pago.');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> showQr()async{
  setState(()=>busy=true);
  try{final r=await ApiClient.instance.payment('$path/qr');if(mounted)setState(()=>qr=r['base64'] as String?);}
  catch(e){if(mounted)setState(()=>error=e is ApiException?e.message:'No se pudo cargar el QR.');}
  finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(managing?'Mi QR bancario':'Pago del aporte'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
  if(busy)const LinearProgressIndicator(),
  if(error!=null)Text(error!,style:TextStyle(color:Theme.of(context).colorScheme.error)),
  if(managing)...[
   const Text('Tus pasajeros pueden pagar en efectivo. También pueden usar tu QR si lo cargas aquí.'),
   OutlinedButton.icon(onPressed:busy?null:upload,icon:const Icon(Icons.qr_code),label:const Text('CARGAR O REEMPLAZAR QR')),
   if(qr!=null)TextButton(onPressed:busy?null:()async{
    final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Retirar el QR?'),content:const Text('Seguirá disponible el pago en efectivo.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Retirar'))]));
    if(yes!=true||!mounted)return;
    setState(()=>busy=true);
    try{await ApiClient.instance.payment('qr',method:'DELETE');if(mounted)setState((){qr=null;error=null;});}catch(_){if(mounted)setState(()=>error='No se pudo retirar el QR.');}finally{if(mounted)setState(()=>busy=false);}
   },child:const Text('RETIRAR QR')),
  ],
  if(!managing&&data!=null)...[
   Text('Total de la reserva: Bs ${data!['total']}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
   Text('Método elegido: ${data!['method']=='QR'?'QR bancario':'Efectivo'}'),
   Text(data!['confirmedAt']==null?'Pendiente de confirmación del conductor':'Recibido: confirmado manualmente por el conductor'),
   if(data!['confirmedAt']!=null)Text('Fecha: ${data!['confirmedAt']}'),
   if(data!['driver']!=true&&data!['confirmedAt']==null)...[
    OutlinedButton(onPressed:busy?null:()=>action('method',body:{'method':'CASH'}),child:const Text('PAGAR EN EFECTIVO')),
    if(data!['qrAvailable']==true)OutlinedButton(onPressed:busy?null:()=>action('method',body:{'method':'QR'}),child:const Text('PAGAR POR QR')),
   ],
   if(data!['qrAvailable']==true)OutlinedButton.icon(onPressed:busy?null:showQr,icon:const Icon(Icons.qr_code),label:const Text('VER QR DEL CONDUCTOR')),
   const Text('Verifica destinatario e importe en tu banco antes de pagar. Mostrar el QR o elegir un método no confirma ni ejecuta un pago.'),
   if(data!['driver']==true&&data!['confirmedAt']==null)FilledButton(onPressed:busy?null:()async{
    final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Recibiste el aporte completo?'),content:const Text('Confirma solo después de comprobar el dinero en tu cuenta o recibir el efectivo. Es un registro manual.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Sí, recibido'))]));
    if(yes==true&&mounted)await action('confirm');
   },child:const Text('CONFIRMAR APORTE RECIBIDO')),
  ],
  if(qr!=null)Padding(padding:const EdgeInsets.symmetric(vertical:20),child:Image.memory(base64Decode(qr!),fit:BoxFit.contain,errorBuilder:(_,e,s)=>const Text('Imagen no compatible. Reemplaza el QR.'))),
 ]));
}
