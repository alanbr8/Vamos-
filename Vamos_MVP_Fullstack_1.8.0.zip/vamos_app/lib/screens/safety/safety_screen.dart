import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../models/safety_incident.dart';
import '../../services/api_client.dart';

class SafetyScreen extends StatefulWidget {
  const SafetyScreen({
    super.key,
    this.tripId,
    this.reportedUserId,
    this.reportedUserName,
  });

  final String? tripId;
  final String? reportedUserId;
  final String? reportedUserName;

  @override
  State<SafetyScreen> createState() => _SafetyScreenState();
}

class _SafetyScreenState extends State<SafetyScreen> {
  final incidents = <SafetyIncident>[];
  bool loadingIncidents = true;
  String? incidentError;

  @override
  void initState() {
    super.initState();
    loadIncidents();
  }

  Future<void> loadIncidents() async {
    setState(() {
      loadingIncidents = true;
      incidentError = null;
    });
    try {
      final response = await ApiClient.instance.incidents();
      if (!mounted) return;
      setState(() {
        incidents
          ..clear()
          ..addAll(
            response.map((item) {
              final data = Map<String, dynamic>.from(item as Map);
              return SafetyIncident(
                id: data['id']?.toString(),
                resolutionDetail:data['resolutionDetail']?.toString(),
                resolvedAt:DateTime.tryParse('${data['resolvedAt']}'),
                type: incidentTypeFromApi(data['type']?.toString()),
                description: data['description']?.toString() ?? '',
                createdAt:
                    DateTime.tryParse(data['createdAt']?.toString() ?? '') ??
                    DateTime.now(),
                tripReference: data['tripId']?.toString() ?? 'REPORTE GENERAL',
                status: data['status']?.toString() ?? 'RECEIVED',
              );
            }),
          );
      });
    } on ApiException catch (error) {
      if (mounted) setState(() => incidentError = error.message);
    } finally {
      if (mounted) setState(() => loadingIncidents = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Centro de seguridad')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFE4F6EE),
            borderRadius: BorderRadius.circular(18),
          ),
          child: const Row(
            children: [
              Icon(Icons.shield_outlined, size: 38, color: AppColors.green),
              SizedBox(width: 14),
              Expanded(
                child: Text(
                  'Puedes registrar problemas para su revisión. Las funciones de emergencia todavía no están disponibles.',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        SafetyOption(
          icon: Icons.report_outlined,
          title: 'Reportar un problema',
          subtitle: widget.reportedUserName == null
              ? 'Registra un incidente o problema general'
              : 'Relacionado con ${widget.reportedUserName}',
          onTap: reportIncident,
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('Funciones pendientes'),
            subtitle: Text(
              'Contacto de emergencia, compartir ubicación, bloqueo de usuarios y SOS todavía no están disponibles. La aplicación no envía alertas ni llama a servicios de emergencia.',
            ),
          ),
        ),
        if (loadingIncidents) ...[
          const SizedBox(height: 24),
          const Center(child: CircularProgressIndicator()),
        ],
        if (incidentError != null) ...[
          const SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: const Icon(Icons.cloud_off),
              title: const Text('No pudimos cargar tus reportes'),
              subtitle: Text(incidentError!),
              trailing: IconButton(
                onPressed: loadIncidents,
                icon: const Icon(Icons.refresh),
              ),
            ),
          ),
        ],
        if (!loadingIncidents && incidents.isNotEmpty) ...[
          const SizedBox(height: 26),
          Text(
            'Incidentes registrados',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          ...incidents.map(
            (incident) => Card(
              child: ListTile(
                leading: const Icon(Icons.assignment_outlined),
                title: Text(incidentLabel(incident.type)),
                subtitle: Text('${incident.description}${incident.resolutionDetail == null ? '' : '\n\nRespuesta: ${incident.resolutionDetail}'}${incident.resolvedAt == null ? '' : '\nFecha: ${incident.resolvedAt!.toLocal()}'}'),
                trailing: Chip(label: Text(incident.status)),
              ),
            ),
          ),
        ],
      ],
    ),
  );

  Future<void> reportIncident() async {
    IncidentType type = IncidentType.unsafeDriving;
    final description = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Reportar problema'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<IncidentType>(
                  initialValue: type,
                  decoration: const InputDecoration(
                    labelText: 'Tipo de incidente',
                  ),
                  items: IncidentType.values
                      .map(
                        (item) => DropdownMenuItem(
                          value: item,
                          child: Text(incidentLabel(item)),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setDialogState(() => type = value);
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: description,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Cuéntanos qué ocurrió',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('CANCELAR'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('ENVIAR REPORTE'),
            ),
          ],
        ),
      ),
    );
    final detail = description.text.trim();
    if (submitted == true && detail.length < 10 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Describe el incidente con al menos 10 caracteres'),
        ),
      );
    } else if (submitted == true) {
      try {
        final response = await ApiClient.instance.createIncident({
          if (widget.tripId != null) 'tripId': widget.tripId,
          if (widget.reportedUserId != null)
            'reportedUserId': widget.reportedUserId,
          'type': type.name,
          'description': detail,
        });
        if (mounted) {
          setState(
            () => incidents.insert(
              0,
              SafetyIncident(
                id: response['id']?.toString(),
                type: type,
                description: detail,
                createdAt:
                    DateTime.tryParse(
                      response['createdAt']?.toString() ?? '',
                    ) ??
                    DateTime.now(),
                tripReference: widget.tripId ?? 'REPORTE GENERAL',
                status: response['status']?.toString() ?? 'RECEIVED',
              ),
            ),
          );
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Reporte recibido por Vamos!!')),
          );
        }
      } on ApiException catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(error.message)));
        }
      }
    }
    description.dispose();
  }
}

class SafetyOption extends StatelessWidget {
  const SafetyOption({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(icon, color: AppColors.green),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}

String incidentLabel(IncidentType type) => switch (type) {
  IncidentType.unsafeDriving => 'Conducción insegura',
  IncidentType.harassment => 'Acoso o comportamiento inapropiado',
  IncidentType.noShow => 'Usuario ausente',
  IncidentType.routeProblem => 'Problema con la ruta',
  IncidentType.other => 'Otro problema',
};

IncidentType incidentTypeFromApi(String? value) => IncidentType.values
    .firstWhere((type) => type.name == value, orElse: () => IncidentType.other);
