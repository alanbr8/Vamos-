import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../models/safety_incident.dart';
import '../../services/api_client.dart';

class SafetyScreen extends StatefulWidget {
  const SafetyScreen({
    super.key,
    this.tripId,
    this.reportedUserId,
    this.reportedUserName,
  });

  final String? tripId;
  final String? reportedUserId;
  final String? reportedUserName;

  @override
  State<SafetyScreen> createState() => _SafetyScreenState();
}

class _SafetyScreenState extends State<SafetyScreen> {
  String? emergencyName;
  String? emergencyPhone;
  bool tripShared = false;
  bool userBlocked = false;
  final incidents = <SafetyIncident>[];
  bool loadingIncidents = true;
  String? incidentError;

  @override
  void initState() {
    super.initState();
    loadIncidents();
  }

  Future<void> loadIncidents() async {
    setState(() {
      loadingIncidents = true;
      incidentError = null;
    });
    try {
      final response = await ApiClient.instance.incidents();
      if (!mounted) return;
      setState(() {
        incidents
          ..clear()
          ..addAll(response.map((item) {
            final data = Map<String, dynamic>.from(item as Map);
            return SafetyIncident(
              id: data['id']?.toString(),
              type: incidentTypeFromApi(data['type']?.toString()),
              description: data['description']?.toString() ?? '',
              createdAt: DateTime.tryParse(data['createdAt']?.toString() ?? '') ?? DateTime.now(),
              tripReference: data['tripId']?.toString() ?? 'REPORTE GENERAL',
              status: data['status']?.toString() ?? 'RECEIVED',
            );
          }));
      });
    } on ApiException catch (error) {
      if (mounted) setState(() => incidentError = error.message);
    } finally {
      if (mounted) setState(() => loadingIncidents = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Centro de seguridad')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFE4F6EE),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(children: [
                Icon(Icons.shield_outlined, size: 38, color: AppColors.green),
                SizedBox(width: 14),
                Expanded(child: Text('Tu seguridad es prioridad. Configura estas opciones antes de viajar.')),
              ]),
            ),
            const SizedBox(height: 18),
            SafetyOption(
              icon: Icons.contact_emergency_outlined,
              title: 'Contacto de emergencia',
              subtitle: emergencyName == null ? 'Todavía no configurado' : '$emergencyName · $emergencyPhone',
              onTap: configureContact,
            ),
            SafetyOption(
              icon: Icons.share_location_outlined,
              title: 'Compartir mi viaje',
              subtitle: tripShared ? 'Enlace demostrativo preparado' : 'Ruta, vehículo y conductor',
              onTap: shareTrip,
            ),
            SafetyOption(
              icon: Icons.report_outlined,
              title: 'Reportar un problema',
              subtitle: widget.reportedUserName == null
                  ? 'Registra un incidente o problema general'
                  : 'Relacionado con ${widget.reportedUserName}',
              onTap: reportIncident,
            ),
            SafetyOption(
              icon: Icons.block,
              title: userBlocked ? 'Bloqueo simulado' : 'Simular bloqueo de usuario',
              subtitle: userBlocked ? 'No se aplicó fuera de este dispositivo' : 'Demostración; aún no modifica coincidencias reales',
              onTap: toggleBlock,
            ),
            const SizedBox(height: 24),
            SosButton(onPressed: showSosConfirmation),
            const SizedBox(height: 10),
            const Text(
              'DEMOSTRACIÓN: este botón todavía no llama a la Policía, ambulancia ni otros servicios de emergencia.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
            if (loadingIncidents) ...[
              const SizedBox(height: 24),
              const Center(child: CircularProgressIndicator()),
            ],
            if (incidentError != null) ...[
              const SizedBox(height: 20),
              Card(child: ListTile(
                leading: const Icon(Icons.cloud_off),
                title: const Text('No pudimos cargar tus reportes'),
                subtitle: Text(incidentError!),
                trailing: IconButton(onPressed: loadIncidents, icon: const Icon(Icons.refresh)),
              )),
            ],
            if (!loadingIncidents && incidents.isNotEmpty) ...[
              const SizedBox(height: 26),
              Text('Incidentes registrados', style: Theme.of(context).textTheme.titleLarge),
              ...incidents.map((incident) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.assignment_outlined),
                      title: Text(incidentLabel(incident.type)),
                      subtitle: Text(incident.description),
                      trailing: Chip(label: Text(incident.status)),
                    ),
                  )),
            ],
          ],
        ),
      );

  Future<void> configureContact() async {
    final name = TextEditingController(text: emergencyName);
    final phone = TextEditingController(text: emergencyPhone);
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Contacto de emergencia'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nombre')),
          const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Celular')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCELAR')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('GUARDAR')),
        ],
      ),
    );
    if (saved == true && name.text.trim().isNotEmpty && phone.text.trim().isNotEmpty) {
      setState(() {
        emergencyName = name.text.trim();
        emergencyPhone = phone.text.trim();
      });
    }
    name.dispose();
    phone.dispose();
  }

  void shareTrip() {
    setState(() => tripShared = true);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Compartir viaje'),
        content: const Text('Se preparó una vista demostrativa con ruta, conductor, vehículo y horario. La conexión con WhatsApp se añadirá posteriormente.'),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('ENTENDIDO'))],
      ),
    );
  }

  Future<void> toggleBlock() async {
    if (userBlocked) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('¿Bloquear a ${widget.reportedUserName ?? 'este usuario'}?'),
        content: const Text('No podrá enviarte mensajes ni aparecer en futuras coincidencias.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('VOLVER')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('BLOQUEAR')),
        ],
      ),
    );
    if (confirmed == true) setState(() => userBlocked = true);
  }

  Future<void> reportIncident() async {
    IncidentType type = IncidentType.unsafeDriving;
    final description = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Reportar problema'),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<IncidentType>(
              initialValue: type,
              decoration: const InputDecoration(labelText: 'Tipo de incidente'),
              items: IncidentType.values.map((item) => DropdownMenuItem(value: item, child: Text(incidentLabel(item)))).toList(),
              onChanged: (value) { if (value != null) setDialogState(() => type = value); },
            ),
            const SizedBox(height: 12),
            TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Cuéntanos qué ocurrió')),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCELAR')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ENVIAR REPORTE')),
          ],
        ),
      ),
    );
    final detail = description.text.trim();
    if (submitted == true && detail.length < 10 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Describe el incidente con al menos 10 caracteres'),
      ));
    } else if (submitted == true) {
      try {
        final response = await ApiClient.instance.createIncident({
          if (widget.tripId != null) 'tripId': widget.tripId,
          if (widget.reportedUserId != null) 'reportedUserId': widget.reportedUserId,
          'type': type.name,
          'description': detail,
        });
        if (mounted) {
          setState(() => incidents.insert(0, SafetyIncident(
            id: response['id']?.toString(),
            type: type,
            description: detail,
            createdAt: DateTime.tryParse(response['createdAt']?.toString() ?? '') ?? DateTime.now(),
            tripReference: widget.tripId ?? 'REPORTE GENERAL',
            status: response['status']?.toString() ?? 'RECEIVED',
          )));
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Reporte recibido por Vamos!!')),
          );
        }
      } on ApiException catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(error.message)));
        }
      }
    }
    description.dispose();
  }

  Future<void> showSosConfirmation() async {
    final activate = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.sos, size: 48, color: Colors.red),
        title: const Text('Modo SOS de demostración'),
        content: Text(emergencyName == null
            ? 'Primero configura un contacto. Esta versión no contacta servicios de emergencia reales.'
            : 'Simularemos una alerta para $emergencyName ($emergencyPhone). No se enviará ningún mensaje real.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCELAR')),
          if (emergencyName != null) FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('SIMULAR ALERTA')),
        ],
      ),
    );
    if (activate == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Alerta simulada. No se envió información fuera de la aplicación.')));
    }
  }
}

class SafetyOption extends StatelessWidget {
  const SafetyOption({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: AppColors.green), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: onTap));
}

class SosButton extends StatelessWidget {
  const SosButton({super.key, required this.onPressed});
  final VoidCallback onPressed;
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 64,
        child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: Colors.red),
          onPressed: onPressed,
          icon: const Icon(Icons.sos, size: 30),
          label: const Text('SOS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ),
      );
}

String incidentLabel(IncidentType type) => switch (type) {
      IncidentType.unsafeDriving => 'Conducción insegura',
      IncidentType.harassment => 'Acoso o comportamiento inapropiado',
      IncidentType.noShow => 'Usuario ausente',
      IncidentType.routeProblem => 'Problema con la ruta',
      IncidentType.other => 'Otro problema',
    };

IncidentType incidentTypeFromApi(String? value) => IncidentType.values.firstWhere(
      (type) => type.name == value,
      orElse: () => IncidentType.other,
    );
