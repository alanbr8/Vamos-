import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/session_store.dart';

class SosScreen extends StatefulWidget {
  const SosScreen({super.key, this.tripId});
  final String? tripId;
  @override
  State<SosScreen> createState() => _SosScreenState();
}

class _SosScreenState extends State<SosScreen> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final storage = const FlutterSecureStorage();
  late final String? userId;
  bool loading = true, saving = false, locating = false;
  String? error;
  String get key => 'vamos_emergency_$userId';
  @override
  void initState() {
    super.initState();
    userId = SessionStore.instance.user?['id']?.toString();
    load();
  }
  Future<void> load() async {
    try {
      if (userId == null) throw StateError('Sin sesión');
      final raw = await storage.read(key: key);
      if (!mounted) return;
      if (raw != null) {
        final data = jsonDecode(raw) as Map;
        name.text = data['name'] as String? ?? '';
        phone.text = data['phone'] as String? ?? '';
      }
    } catch (_) { if (mounted) error = 'No pudimos leer tu contacto. Puedes volver a guardarlo.'; }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override
  void dispose() { name.dispose(); phone.dispose(); super.dispose(); }
  void message(String text) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }
  String get number => phone.text.replaceAll(RegExp(r'[\s()-]'), '');
  bool get validNumber => RegExp(r'^\+?[0-9]{7,15}$').hasMatch(number);
  Future<void> save() async {
    if (userId == null || SessionStore.instance.user?['id']?.toString() != userId) return;
    if (!validNumber || name.text.trim().isEmpty) { message('Ingresa un nombre y un teléfono válido.'); return; }
    setState(() => saving = true);
    try {
      await storage.write(key: key, value: jsonEncode({'name': name.text.trim(), 'phone': number}));
      if (mounted) setState(() => error = null);
      message('Contacto guardado en este teléfono para tu cuenta.');
    } catch (_) { message('No se pudo guardar el contacto. Intenta nuevamente.'); }
    finally { if (mounted) setState(() => saving = false); }
  }
  Future<void> dial(String value) async {
    try {
      if (!await launchUrl(Uri(scheme: 'tel', path: value))) message('Abre Teléfono y marca $value.');
    } catch (_) { message('Abre Teléfono y marca $value.'); }
  }
  Future<void> shareLocation() async {
    setState(() => locating = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) { message('Activa la ubicación del teléfono para compartirla.'); return; }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        message('Sin permiso de ubicación. Puedes llamar igualmente.'); return;
      }
      final position = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
      if (!mounted) return;
      final age = DateTime.now().difference(position.timestamp).inSeconds;
      if (age > 120 || age < -30) { message('No se obtuvo una ubicación reciente. Intenta nuevamente.'); return; }
      final text = 'Necesito ayuda. Estoy usando Vamos!!.'
          '${widget.tripId == null ? '' : '\nViaje: ${widget.tripId}'}'
          '\nMi ubicación: https://www.google.com/maps?q=${position.latitude},${position.longitude}'
          '\nFecha y hora: ${position.timestamp.toLocal()}'
          '\nPrecisión aproximada: ${position.accuracy.round()} m.'
          '\nEs una ubicación puntual, no un seguimiento en vivo.';
      final box = context.findRenderObject() as RenderBox?;
      await SharePlus.instance.share(ShareParams(text: text, subject: 'Vamos!! — Solicitud de ayuda', sharePositionOrigin: box == null ? null : box.localToGlobal(Offset.zero) & box.size));
    } catch (_) { message('No se pudo compartir la ubicación. Puedes llamar a tu contacto o al 110.'); }
    finally { if (mounted) setState(() => locating = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SOS · Ayuda')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('¿Necesitas ayuda?', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.red.shade800), onPressed: () => dial('110'), icon: const Icon(Icons.phone), label: const Text('POLICÍA · 110')),
      const Text('Se abrirá la aplicación Teléfono. Confirma allí la llamada. No requiere conexión con Vamos!!; depende de la red telefónica.'),
      const SizedBox(height: 24),
      const Text('Mi contacto de emergencia', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const Text('Se guarda en este teléfono para tu cuenta. No se comparte con el conductor ni con otros pasajeros.'),
      if (loading) const LinearProgressIndicator(),
      if (error != null) Text(error!),
      TextField(controller: name, enabled: !loading && !saving, maxLength: 80, decoration: const InputDecoration(labelText: 'Nombre del contacto')),
      TextField(controller: phone, enabled: !loading && !saving, keyboardType: TextInputType.phone, maxLength: 24, decoration: const InputDecoration(labelText: 'Teléfono, con código de país si corresponde')),
      OutlinedButton(onPressed: loading || saving ? null : save, child: const Text('GUARDAR CONTACTO')),
      FilledButton.icon(onPressed: loading ? null : () { if (validNumber) { dial(number); } else { message('Ingresa el teléfono de tu contacto.'); } }, icon: const Icon(Icons.call), label: const Text('LLAMAR A MI CONTACTO')),
      TextButton(onPressed: loading || saving ? null : () async {
        setState(() => saving = true);
        try { await storage.delete(key: key); if (mounted) { name.clear(); phone.clear(); message('Contacto eliminado.'); } }
        catch (_) { message('No se pudo eliminar el contacto.'); }
        finally { if (mounted) setState(() => saving = false); }
      }, child: const Text('Eliminar contacto guardado')),
      const Divider(height: 32),
      OutlinedButton.icon(onPressed: locating ? null : shareLocation, icon: const Icon(Icons.share_location), label: Text(locating ? 'OBTENIENDO UBICACIÓN…' : 'COMPARTIR MI UBICACIÓN')),
      const Text('Elige a una persona de confianza y confirma el envío en la aplicación que selecciones. Vamos!! no avisa automáticamente a la Policía ni a otros ocupantes del vehículo.'),
    ]),
  );
}

class SosButton extends StatelessWidget {
  const SosButton({super.key, this.tripId});
  final String? tripId;
  @override
  Widget build(BuildContext context) => TextButton(
    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SosScreen(tripId: tripId))),
    child: const Text('SOS', style: TextStyle(color: Color(0xFFB71C1C), fontWeight: FontWeight.w900)),
  );
}
