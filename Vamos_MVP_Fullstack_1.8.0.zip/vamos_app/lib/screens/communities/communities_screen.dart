import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/api_client.dart';
import '../trips/search_trip_screen.dart';
import '../trips/publish_trip_screen.dart';

const communityCategories={'GENERAL':'General','WOMEN':'Mujeres','COMPANY':'Empresa','NEIGHBORHOOD':'Zona o barrio','RESIDENTIAL':'Urbanización','SCHOOL':'Familias de colegio'};
String memberStatus(dynamic s)=>{'PENDING':'En revisión','APPROVED':'Miembro aprobado','REJECTED':'No aprobado'}[s]??'$s';
class CommunitiesScreen extends StatefulWidget {
 const CommunitiesScreen({super.key});
 @override State<CommunitiesScreen> createState()=>_CommunitiesScreenState();
}
class _CommunitiesScreenState extends State<CommunitiesScreen>{
 List<dynamic> groups=[];bool busy=false;String? error;
 @override void initState(){super.initState();load();}
 Future<void> load()async{setState(()=>busy=true);try{final r=await ApiClient.instance.communities();if(mounted)setState((){groups=r;error=null;});}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> form(bool create)async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>CommunityForm(create:create)));if(mounted)await load();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Comunidades Vamos!!'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
 const Text('Comparte viajes con tu comunidad',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
 const Text('Ingresa con un código y espera la aprobación del administrador. Los viajes del grupo solo se ofrecen a miembros aprobados.'),
 FilledButton.icon(onPressed:busy?null:()=>form(false),icon:const Icon(Icons.group_add),label:const Text('INGRESAR CON CÓDIGO')),
 OutlinedButton(onPressed:busy?null:()=>form(true),child:const Text('CREAR COMUNIDAD')),
 if(busy)const LinearProgressIndicator(),if(error!=null)Text(error!),
 if(!busy&&groups.isEmpty)const Text('Aún no tienes comunidades.'),
 ...groups.map((g)=>Card(child:ListTile(title:Text(g['name']),subtitle:Text('${communityCategories[g['category']]} · ${memberStatus(g['status'])}${g['admin']==true?' · Administrador':''}'),trailing:const Icon(Icons.chevron_right),onTap:()async{await Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>CommunityDetail(id:g['id'])));if(mounted)await load();}))),
 ]));
}
class CommunityForm extends StatefulWidget {
 const CommunityForm({super.key,required this.create});final bool create;
 @override State<CommunityForm> createState()=>_CommunityFormState();
}
class _CommunityFormState extends State<CommunityForm>{
 final name=TextEditingController(),description=TextEditingController();String category='GENERAL';bool busy=false;String? error;
 @override void dispose(){name.dispose();description.dispose();super.dispose();}
 Future<void> save()async{setState(()=>busy=true);try{await ApiClient.instance.community(widget.create?'':'/join',method:'POST',body:widget.create?{'name':name.text.trim(),'description':description.text.trim(),'category':category}:{'code':name.text.trim().toLowerCase()});if(mounted)Navigator.pop(context);}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.create?'Crear comunidad':'Ingresar con código')),body:ListView(padding:const EdgeInsets.all(20),children:[
 TextField(controller:name,maxLength:widget.create?80:32,decoration:InputDecoration(labelText:widget.create?'Nombre de la comunidad':'Código de invitación')),
 if(widget.create)...[
 DropdownButtonFormField<String>(initialValue:category,items:communityCategories.entries.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:busy?null:(v)=>setState(()=>category=v??'GENERAL')),
 TextField(controller:description,maxLength:500,maxLines:3,decoration:const InputDecoration(labelText:'Descripción y condiciones de ingreso')),
 const Text('Como administrador debes revisar las solicitudes y la pertenencia al grupo. El nombre o la categoría no acreditan una afiliación oficial.'),
 if(category=='WOMEN')const Text('Comunidad de mujeres: el administrador revisa el ingreso de conductoras y pasajeras. Vamos!! no verifica el género automáticamente.'),
 if(category=='SCHOOL')const Text('Para cuentas de padres o tutores adultos. No crea cuentas de menores ni habilita viajes de niños sin acompañamiento.'),
 ],
 if(error!=null)Text(error!),FilledButton(onPressed:busy?null:save,child:Text(busy?'GUARDANDO…':widget.create?'CREAR':'SOLICITAR INGRESO')),
 ]));
}
class CommunityDetail extends StatefulWidget{
 const CommunityDetail({super.key,required this.id});final String id;
 @override State<CommunityDetail> createState()=>_CommunityDetailState();
}
class _CommunityDetailState extends State<CommunityDetail>{
 Map<String,dynamic>? group;List<dynamic> members=[],trips=[];bool busy=false;String? error;
 @override void initState(){super.initState();load();}
 Future<void> load()async{
 setState(()=>busy=true);
 try{
  final g=await ApiClient.instance.community('/${widget.id}');
  final m=g['admin']==true?await ApiClient.instance.communities('/${widget.id}/members'):<dynamic>[];
  final t=g['status']=='APPROVED'?await ApiClient.instance.communities('/${widget.id}/trips'):<dynamic>[];
  if(mounted)setState((){group=g;members=m;trips=t;error=null;});
 }catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 Future<void> action(String suffix,{Map<String,dynamic>? body})async{
 setState(()=>busy=true);try{await ApiClient.instance.community('/${widget.id}/$suffix',method:'POST',body:body);if(mounted)await load();}catch(e){if(mounted)setState(()=>error=e.toString());}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(group?['name']??'Comunidad'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
 if(busy)const LinearProgressIndicator(),if(error!=null)Text(error!),
 if(group!=null)...[
 Text(group!['description']??''),Text(memberStatus(group!['status'])),
 if(group!['admin']==true)...[
 const Text('Código de invitación (ingreso sujeto a aprobación):'),SelectableText(group!['code']??''),
 TextButton(onPressed:()=>Clipboard.setData(ClipboardData(text:group!['code']??'')),child:const Text('COPIAR CÓDIGO')),
 TextButton(onPressed:busy?null:()async{final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Renovar el código?'),content:const Text('El código anterior dejará de aceptar nuevas solicitudes. Los miembros actuales conservan su acceso.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Renovar'))]));if(yes==true&&mounted)await action('rotate');},child:const Text('RENOVAR CÓDIGO')),
 const Text('Miembros y solicitudes',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 ...members.map((m)=>Card(child:Column(children:[ListTile(title:Text('${m['name']} ${m['surname']}'),subtitle:Text(memberStatus(m['status']))),Wrap(children:[TextButton(onPressed:busy?null:()=>action('members/${m['id']}',body:{'status':'APPROVED'}),child:const Text('Aprobar')),TextButton(onPressed:busy?null:()async{final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('¿Rechazar o retirar miembro?'),content:Text('${m['name']} perderá el acceso a los nuevos viajes del grupo.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Retirar'))]));if(yes==true&&mounted)await action('members/${m['id']}',body:{'status':'REJECTED'});},child:const Text('Rechazar / retirar'))])]))),
 ],
 if(group!['status']=='APPROVED')...[
 FilledButton.icon(onPressed:busy?null:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>PublishTripScreen(communityId:widget.id))),icon:const Icon(Icons.add_road),label:const Text('OFRECER A ESTA COMUNIDAD')),
 const Text('Viajes disponibles',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
 const Text('Tus propias ofertas están en Mis viajes. Las reservas de la comunidad también se guardan allí.'),
 if(trips.isEmpty&&!busy)const Text('No hay ofertas disponibles de otros miembros.'),
 ...trips.map((t)=>Card(child:ListTile(title:Text('${t['origin']} → ${t['destination']}'),subtitle:Text('${DateTime.tryParse(t['departureAt'].toString())?.toLocal()} · Bs ${t['contribution']} · ${t['seats']} asientos'),onTap:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>MatchDetailScreen(fromCommunity:true,match:tripMatchFromApi(Map<String,dynamic>.from(t),''))))))),
 ],
 ],
 ]));
}
