import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../services/api_client.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final email = TextEditingController();
  final token = TextEditingController();
  final password = TextEditingController();
  final confirmation = TextEditingController();
  bool requested = false;
  bool completed = false;
  bool loading = false;
  bool hidePassword = true;
  String? devToken;

  @override
  void dispose() {
    email.dispose();
    token.dispose();
    password.dispose();
    confirmation.dispose();
    super.dispose();
  }

  Future<void> requestReset() async {
    if (!email.text.contains('@')) {
      _message('Ingresa un correo válido');
      return;
    }
    setState(() => loading = true);
    try {
      final response = await ApiClient.instance.forgotPassword(email.text.trim());
      if (!mounted) return;
      setState(() {
        requested = true;
        devToken = response['devToken']?.toString();
        if (devToken != null) token.text = devToken!;
      });
    } on ApiException catch (error) {
      if (mounted) _message(error.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> resetPassword() async {
    if (token.text.trim().length < 20) {
      _message('Ingresa el token de recuperación');
      return;
    }
    if (password.text.length < 8) {
      _message('La contraseña debe tener al menos 8 caracteres');
      return;
    }
    if (password.text != confirmation.text) {
      _message('Las contraseñas no coinciden');
      return;
    }
    setState(() => loading = true);
    try {
      await ApiClient.instance.resetPassword(token.text.trim(), password.text);
      if (mounted) setState(() => completed = true);
    } on ApiException catch (error) {
      if (mounted) _message(error.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _message(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) {
    if (completed) {
      return Scaffold(
        body: SafeArea(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.lock_reset, size: 92, color: Colors.green),
            Text('Contraseña actualizada', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            const Text('Ya puedes iniciar sesión con tu nueva contraseña.'),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pushNamedAndRemoveUntil(context, AppRoutes.login, (_) => false),
              child: const Text('INICIAR SESIÓN'),
            ),
          ]),
        )),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Recuperar contraseña')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Text(requested ? 'Crea una nueva contraseña' : 'Recupera tu cuenta', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        Text(requested
            ? 'Ingresa el token recibido. En el entorno local aparece automáticamente.'
            : 'Te enviaremos instrucciones si el correo pertenece a una cuenta.'),
        const SizedBox(height: 24),
        if (!requested) ...[
          TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Correo electrónico', prefixIcon: Icon(Icons.email_outlined))),
          const SizedBox(height: 18),
          ElevatedButton(onPressed: loading ? null : requestReset, child: Text(loading ? 'ENVIANDO…' : 'SOLICITAR RECUPERACIÓN')),
        ] else ...[
          if (devToken != null)
            const Card(child: ListTile(leading: Icon(Icons.science_outlined), title: Text('Modo local de pruebas'), subtitle: Text('El token fue completado automáticamente. Esto debe desactivarse en producción.'))),
          TextField(controller: token, decoration: const InputDecoration(labelText: 'Token de recuperación', prefixIcon: Icon(Icons.key_outlined))),
          const SizedBox(height: 12),
          TextField(
            controller: password,
            obscureText: hidePassword,
            decoration: InputDecoration(labelText: 'Nueva contraseña', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => hidePassword = !hidePassword), icon: Icon(hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined))),
          ),
          const SizedBox(height: 12),
          TextField(controller: confirmation, obscureText: hidePassword, decoration: const InputDecoration(labelText: 'Confirmar contraseña', prefixIcon: Icon(Icons.lock_outline))),
          const SizedBox(height: 18),
          ElevatedButton(onPressed: loading ? null : resetPassword, child: Text(loading ? 'ACTUALIZANDO…' : 'CAMBIAR CONTRASEÑA')),
        ],
      ]),
    );
  }
}
