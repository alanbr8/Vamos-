import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../models/map_point.dart';
import '../../models/trip_match.dart';
import '../map/location_picker_screen.dart';
import '../../services/location_service.dart';
import '../../services/api_client.dart';

class SearchTripScreen extends StatefulWidget {
  const SearchTripScreen({super.key});

  @override
  State<SearchTripScreen> createState() => _SearchTripScreenState();
}

class _SearchTripScreenState extends State<SearchTripScreen> {
  final origin = TextEditingController();
  final destination = TextEditingController();
  DateTime date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay time = const TimeOfDay(hour: 7, minute: 0);
  double flexibility = 30;
  bool searched = false;
  MapPoint? originPoint;
  MapPoint? destinationPoint;
  bool loading = false;
  bool usingDemoResults = false;
  List<TripMatch> liveMatches = [];

  static const matches = [
    TripMatch(driver: 'Carlos M.', rating: 4.9, trips: 84, vehicle: 'Toyota Corolla · Blanco', origin: 'Av. Banzer, 5.º Anillo', destination: 'Parque Industrial', time: '07:00', seats: 3, price: 8, compatibility: 96, meetingPoint: 'Gasolinera del 4.º Anillo', walkMinutes: 3, detourMinutes: 1),
    TripMatch(driver: 'María R.', rating: 4.8, trips: 52, vehicle: 'Suzuki Swift · Gris', origin: 'Av. Cristo Redentor', destination: 'Parque Industrial', time: '07:15', seats: 2, price: 9, compatibility: 91, meetingPoint: 'Farmacia del 4.º Anillo', walkMinutes: 6, detourMinutes: 2),
    TripMatch(driver: 'Diego A.', rating: 4.7, trips: 31, vehicle: 'Nissan Versa · Azul', origin: 'Av. Alemana', destination: 'Zona Industrial', time: '06:50', seats: 1, price: 7, compatibility: 84, meetingPoint: 'Plaza del barrio', walkMinutes: 8, detourMinutes: 3),
  ];

  @override
  void dispose() {
    origin.dispose();
    destination.dispose();
    super.dispose();
  }

  Future<void> search() async {
    if (origin.text.trim().isEmpty || destination.text.trim().isEmpty || originPoint == null || destinationPoint == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingresa y selecciona el origen y destino en el mapa')),
      );
      return;
    }
    setState(() => loading = true);
    final center = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    try {
      final response = await ApiClient.instance.searchTrips({
        'originLat': originPoint!.latitude,
        'originLng': originPoint!.longitude,
        'destinationLat': destinationPoint!.latitude,
        'destinationLng': destinationPoint!.longitude,
        'departureFrom': center.subtract(Duration(minutes: flexibility.round())).toIso8601String(),
        'departureTo': center.add(Duration(minutes: flexibility.round())).toIso8601String(),
        'maxDistanceMeters': 1500,
      });
      liveMatches = response.map((item) => tripMatchFromApi(item as Map<String, dynamic>, time.format(context))).toList();
      usingDemoResults = false;
    } on ApiException {
      liveMatches = matches;
      usingDemoResults = true;
    } finally {
      if (mounted) setState(() { loading = false; searched = true; });
    }
  }

  Future<void> pickPoint(bool isOrigin) async {
    final point = await Navigator.push<MapPoint>(
      context,
      MaterialPageRoute(builder: (_) => LocationPickerScreen(title: isOrigin ? '¿Dónde te recogemos?' : 'Seleccionar destino', initialPoint: isOrigin ? originPoint : destinationPoint, routePoints: [if (!isOrigin && originPoint != null) originPoint!])),
    );
    if (point == null) return;
    setState(() {
      if (isOrigin) {
        originPoint = point;
        if (origin.text.trim().isEmpty) origin.text = point.label;
      } else {
        destinationPoint = point;
        if (destination.text.trim().isEmpty) destination.text = point.label;
      }
    });
  }

  Future<void> pickDate() async {
    final value = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (value != null) setState(() => date = value);
  }

  Future<void> pickTime() async {
    final value = await showTimePicker(context: context, initialTime: time);
    if (value != null) setState(() => time = value);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(searched ? 'Viajes encontrados' : 'Buscar un viaje')),
        body: searched ? results() : form(),
      );

  Widget form() => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('¿A dónde vamos?', style: Theme.of(context).textTheme.headlineSmall),
          const Text('Buscaremos conductores cuya ruta pase cerca de ti.'),
          const SizedBox(height: 22),
          TextField(
            controller: origin,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: '¿Dónde te recogemos?', hintText: 'Ej.: Av. Banzer, 5.º Anillo', prefixIcon: Icon(Icons.trip_origin)),
          ),
          TextButton.icon(onPressed: () => pickPoint(true), icon: const Icon(Icons.map_outlined), label: Text(originPoint == null ? 'MARCAR ORIGEN EN EL MAPA' : 'CAMBIAR ORIGEN')),
          const SizedBox(height: 12),
          TextField(
            controller: destination,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: '¿A dónde vas?', hintText: 'Ej.: Parque Industrial', prefixIcon: Icon(Icons.location_on_outlined)),
          ),
          TextButton.icon(onPressed: () => pickPoint(false), icon: const Icon(Icons.map_outlined), label: Text(destinationPoint == null ? 'MARCAR DESTINO EN EL MAPA' : 'CAMBIAR DESTINO')),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: PickerCard(icon: Icons.calendar_today_outlined, label: 'Fecha', value: formatDate(date), onTap: pickDate)),
            const SizedBox(width: 10),
            Expanded(child: PickerCard(icon: Icons.schedule, label: 'Hora ideal', value: time.format(context), onTap: pickTime)),
          ]),
          const SizedBox(height: 20),
          Text('Flexibilidad: ± ${flexibility.round()} minutos'),
          Slider(min: 0, max: 90, divisions: 6, label: '${flexibility.round()} min', value: flexibility, onChanged: (value) => setState(() => flexibility = value)),
          MapBox(label: originPoint == null || destinationPoint == null
              ? 'Selecciona ambos puntos para buscar'
              : 'Distancia directa: ${(LocationService.distanceMeters(originPoint!, destinationPoint!) / 1000).toStringAsFixed(1)} km'),
          const SizedBox(height: 20),
          ElevatedButton.icon(onPressed: loading ? null : search, icon: const Icon(Icons.search), label: Text(loading ? 'BUSCANDO…' : 'BUSCAR VIAJES')),
        ],
      );

  Widget results() => Column(
        children: [
          if (usingDemoResults)
            const MaterialBanner(content: Text('La API no está disponible. Mostramos resultados de demostración.'), actions: [SizedBox.shrink()]),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              const Icon(Icons.route, color: AppColors.green),
              const SizedBox(width: 10),
              Expanded(child: Text('${origin.text.trim()} → ${destination.text.trim()}\n${formatDate(date)} · ${time.format(context)}')),
              TextButton(onPressed: () => setState(() => searched = false), child: const Text('Editar')),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
            child: Row(children: [Text('${liveMatches.length} coincidencias', style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), const Icon(Icons.tune, size: 19), const Text(' Mejor ruta')]),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 6, 20, 20),
              itemCount: liveMatches.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, index) => MatchCard(
                match: liveMatches[index],
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetailScreen(match: liveMatches[index]))),
              ),
            ),
          ),
        ],
      );
}

class PickerCard extends StatelessWidget {
  const PickerCard({super.key, required this.icon, required this.label, required this.value, required this.onTap});
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [Icon(icon, color: AppColors.green), Text(label, style: const TextStyle(color: Colors.black54)), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]),
          ),
        ),
      );
}

class MapBox extends StatelessWidget {
  const MapBox({super.key, required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        height: 180,
        decoration: BoxDecoration(color: const Color(0xFFE4F6EE), borderRadius: BorderRadius.circular(18)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.map_outlined, size: 54, color: AppColors.green), const SizedBox(height: 8), Text(label)]),
      );
}

class MatchCard extends StatelessWidget {
  const MatchCard({super.key, required this.match, required this.onTap});
  final TripMatch match;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Row(children: [
                CircleAvatar(child: Text(match.driver[0])),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(match.driver, style: const TextStyle(fontWeight: FontWeight.bold)), Text('★ ${match.rating} · ${match.trips} viajes')])),
                Chip(label: Text('${match.compatibility}%'), backgroundColor: const Color(0xFFE4F6EE), labelStyle: const TextStyle(color: AppColors.green, fontWeight: FontWeight.bold)),
              ]),
              const Divider(),
              InfoRow(icon: Icons.schedule, text: match.time),
              InfoRow(icon: Icons.directions_car_outlined, text: match.vehicle),
              InfoRow(icon: Icons.place_outlined, text: match.meetingPoint),
              const SizedBox(height: 8),
              Row(children: [Text('${match.seats} asientos'), const Spacer(), Text('Bs ${match.price.toStringAsFixed(0)}', style: Theme.of(context).textTheme.titleLarge)]),
            ]),
          ),
        ),
      );
}

class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [Icon(icon, size: 19, color: Colors.black54), const SizedBox(width: 8), Expanded(child: Text(text))]),
      );
}

class MatchDetailScreen extends StatefulWidget {
  const MatchDetailScreen({super.key, required this.match});
  final TripMatch match;

  @override
  State<MatchDetailScreen> createState() => _MatchDetailScreenState();
}

class _MatchDetailScreenState extends State<MatchDetailScreen> {
  bool requested = false;
  bool requesting = false;
  String? bookingId;

  Future<void> requestSeat() async {
    final tripId = widget.match.id;
    if (tripId == null) {
      setState(() => requested = true);
      return;
    }
    setState(() => requesting = true);
    try {
      final response = await ApiClient.instance.createBooking(tripId);
      if (mounted) {
        setState(() {
          bookingId = response['id']?.toString();
          requested = true;
        });
      }
    } on ApiException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => requesting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final match = widget.match;
    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del viaje')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(child: Column(children: [CircleAvatar(radius: 36, child: Text(match.driver[0], style: const TextStyle(fontSize: 28))), const SizedBox(height: 8), Text(match.driver, style: Theme.of(context).textTheme.titleLarge), Text('★ ${match.rating} · ${match.trips} viajes realizados')])),
        const SizedBox(height: 18),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [InfoRow(icon: Icons.route, text: '${match.origin} → ${match.destination}'), InfoRow(icon: Icons.schedule, text: 'Salida ${match.time}'), InfoRow(icon: Icons.directions_car, text: match.vehicle), InfoRow(icon: Icons.event_seat, text: '${match.seats} asientos disponibles')]))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Punto de encuentro recomendado', style: Theme.of(context).textTheme.titleMedium), InfoRow(icon: Icons.place, text: match.meetingPoint), InfoRow(icon: Icons.directions_walk, text: '${match.walkMinutes} min caminando para ti'), InfoRow(icon: Icons.alt_route, text: '${match.detourMinutes} min de desvío para el conductor')]))),
        Card(color: const Color(0xFFE4F6EE), child: ListTile(leading: const Icon(Icons.auto_awesome, color: AppColors.green), title: Text('${match.compatibility}% compatible'), subtitle: const Text('Según ruta, horario y cercanía al encuentro.'))),
        const SizedBox(height: 18),
        if (!requested)
          ElevatedButton(
            onPressed: requesting ? null : requestSeat,
            child: Text(requesting
                ? 'ENVIANDO SOLICITUD…'
                : 'SOLICITAR ASIENTO · Bs ${match.price.toStringAsFixed(0)}'),
          )
        else ...[
          Card(child: ListTile(leading: const Icon(Icons.hourglass_top, color: Colors.orange), title: const Text('Solicitud enviada'), subtitle: Text(bookingId == null ? 'Resultado demostrativo.' : 'Te avisaremos cuando el conductor responda.'))),
          TextButton(onPressed: () => Navigator.pushNamedAndRemoveUntil(context, AppRoutes.home, (_) => false), child: const Text('VOLVER AL INICIO')),
        ],
      ]),
    );
  }
}

String formatDate(DateTime date) => '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

TripMatch tripMatchFromApi(Map<String, dynamic> data, String fallbackTime) {
  final parsed = DateTime.tryParse(data['departureAt']?.toString() ?? '');
  final local = parsed?.toLocal();
  final departure = local == null
      ? fallbackTime
      : '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';

  return TripMatch(
    id: data['id']?.toString(),
    driver: data['driver']?.toString() ?? 'Conductor',
    rating: 0,
    trips: 0,
    vehicle: 'Vehículo verificado',
    origin: data['origin']?.toString() ?? 'Origen',
    destination: data['destination']?.toString() ?? 'Destino',
    time: departure,
    seats: int.tryParse(data['seats']?.toString() ?? '') ?? 1,
    price: double.tryParse(data['contribution']?.toString() ?? '') ?? 0,
    compatibility:
        double.tryParse(data['compatibility']?.toString() ?? '')?.round() ?? 0,
    meetingPoint: 'Se sugerirá al confirmar',
    walkMinutes: 0,
    detourMinutes: 0,
  );
}
