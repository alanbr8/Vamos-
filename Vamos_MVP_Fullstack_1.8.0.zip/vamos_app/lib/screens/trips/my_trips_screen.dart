import '../payments/payment_screen.dart';
import '../safety/sos_screen.dart';
import 'live_tracking_screen.dart';
import '../../services/live_tracking_service.dart';
import '../../widgets/encounter_code_dialog.dart';
import '../../widgets/trip_points_map.dart';
import '../../widgets/display_photo.dart';
import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';
import '../chat/chat_screen.dart';
import 'search_trip_screen.dart';
import 'publish_trip_screen.dart';
import '../rating/rating_screen.dart';
import '../safety/safety_screen.dart';

class MyTripsScreen extends StatefulWidget {
  const MyTripsScreen({super.key});
  @override
  State<MyTripsScreen> createState() => _MyTripsScreenState();
}

class _MyTripsScreenState extends State<MyTripsScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> driverTrips = [];
  List<Map<String, dynamic>> passengerBookings = [];
  List<Map<String, dynamic>> savedSearches = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final results = await Future.wait([
        ApiClient.instance.driverTrips(),
        ApiClient.instance.passengerBookings(),
        ApiClient.instance.savedSearches(),
      ]);
      if (!mounted) return;
      setState(() {
        savedSearches = results[2].map((item) => Map<String, dynamic>.from(item as Map)).toList();
        driverTrips = results[0]
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        passengerBookings = results[1]
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
      });
    } on ApiException catch (apiError) {
      if (mounted) setState(() => error = apiError.message);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 2,
    child: Scaffold(
      appBar: AppBar(
        title: const Text('Mis viajes'),
        actions: [
          IconButton(
            onPressed: loading ? null : load,
            icon: const Icon(Icons.refresh),
          ),
        ],
        bottom: const TabBar(
          tabs: [
            Tab(text: 'COMO CONDUCTOR'),
            Tab(text: 'COMO PASAJERO'),
          ],
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? _ErrorView(message: error!, onRetry: load)
          : TabBarView(
              children: [
                _DriverTrips(items: driverTrips, onChanged: load),
                _PassengerTrips(items: passengerBookings, searches: savedSearches, onChanged: load),
              ],
            ),
    ),
  );
}

class _DriverTrips extends StatelessWidget {
  const _DriverTrips({required this.items, required this.onChanged});
  final List<Map<String, dynamic>> items;
  final Future<void> Function() onChanged;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text('Viajes publicados', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      if (items.isEmpty)
        const _EmptyCard(text: 'Todavía no publicaste ningún viaje.'),
      ...items.map((trip) {
        final bookings = (trip['bookings'] as List? ?? const [])
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        final pending = bookings
            .where((item) => item['status'] == 'PENDING')
            .length;
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _TripTile(
            title: '${trip['origin']} → ${trip['destination']}',
            subtitle:
                '${_dateTime(trip['departureAt'])} · ${trip['availableSeats']} cupos',
            badge: pending == 0
                ? trip['status'].toString()
                : '$pending SOLICITUD${pending == 1 ? '' : 'ES'}',
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => DriverTripScreen(trip: trip)),
              );
              await onChanged();
            },
          ),
        );
      }),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => Navigator.pushNamed(context, AppRoutes.publishTrip),
        icon: const Icon(Icons.add),
        label: const Text('PUBLICAR OTRO VIAJE'),
      ),
    ],
  );
}

class _PassengerTrips extends StatelessWidget {
  const _PassengerTrips({required this.items, required this.searches, required this.onChanged});
  final List<Map<String, dynamic>> searches;
  final List<Map<String, dynamic>> items;
  final Future<void> Function() onChanged;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Text('Búsquedas guardadas', style: Theme.of(context).textTheme.titleLarge),
      if (searches.isEmpty) const Text('Tus próximas búsquedas aparecerán aquí, incluso si aún no hay conductores.'),
      ...searches.map((search) => Card(child: ListTile(
        title: Text('${search['origin']} → ${search['destination']}'),
        subtitle: Text('${_dateTime((search['criteria'] as Map)['departureFrom'])} — ${_dateTime((search['criteria'] as Map)['departureTo'])}\n${search['status'] == 'ACTIVE' ? 'Alerta activa' : search['status'] == 'EXPIRED' ? 'Horario vencido' : 'Alerta cancelada'}'),
        isThreeLine: true,
        onTap: search['status'] != 'ACTIVE' ? null : () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => SearchTripScreen(savedSearch: search)));
          await onChanged();
        },
        trailing: search['status'] != 'ACTIVE' ? null : IconButton(
          tooltip: 'Cancelar alerta', icon: const Icon(Icons.notifications_off_outlined),
          onPressed: () async {
            try {
              await ApiClient.instance.cancelSearch(search['id'].toString());
              await onChanged();
            } on ApiException catch (error) {
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
            }
          },
        ),
      ))),
      const SizedBox(height: 24),
      Text('Mis reservas', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      if (items.isEmpty)
        const _EmptyCard(text: 'Todavía no solicitaste ningún asiento.'),
      ...items.map(
        (booking) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _TripTile(
            title: '${booking['origin']} → ${booking['destination']}',
            subtitle:
                '${_dateTime(booking['departureAt'])} · ${booking['driver']}',
            badge: booking['status']?.toString() ?? 'PENDIENTE',
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PassengerBookingScreen(booking: booking),
                ),
              );
              await onChanged();
            },
          ),
        ),
      ),
    ],
  );
}

class DriverTripScreen extends StatefulWidget {
  const DriverTripScreen({super.key, required this.trip});
  final Map<String, dynamic> trip;
  @override
  State<DriverTripScreen> createState() => _DriverTripScreenState();
}

class _DriverTripScreenState extends State<DriverTripScreen> {
  late List<Map<String, dynamic>> bookings;
  late String tripStatus;
  bool busy = false;
  bool departed = false;

  @override
  void initState() {
    super.initState();
    bookings = (widget.trip['bookings'] as List? ?? const [])
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
    tripStatus = widget.trip['status']?.toString() ?? 'PUBLISHED';
    departed=widget.trip['routeDepartedAt']!=null || tripStatus=='IN_PROGRESS';
  }

  Future<void> bookingAction(
    Map<String, dynamic> booking,
    String action,
  ) async {
    setState(() => busy = true);
    try {
      final response = await ApiClient.instance.bookingAction(
        booking['id'].toString(),
        action,
      );
      if (mounted)
        setState(() {
          booking['status'] = response['status'];
          if (action == 'accept' && response['seatsAvailable'] == 0) {
            tripStatus = 'RESERVED';
          }
        });
    } on ApiException catch (apiError) {
      if (mounted) _message(apiError.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> editTrip() async {
    final changed = await Navigator.push<bool>(context, MaterialPageRoute(
      builder: (_) => PublishTripScreen(editTrip: widget.trip)));
    if (changed == true && mounted) Navigator.pop(context);
  }

  Future<void> cancelTrip() async {
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('¿Cancelar viaje?'),
      content: const Text('Se cancelarán las solicitudes y reservas, y se avisará a los pasajeros.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('VOLVER')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('CANCELAR VIAJE'))]));
    if (confirmed != true || !mounted) return;
    setState(() => busy = true);
    try {
      await ApiClient.instance.cancelTrip(widget.trip['id'].toString());
      if(LiveTrackingService.instance.tripId==widget.trip['id'].toString())await LiveTrackingService.instance.stop();
      if (mounted) setState(() {
        tripStatus = 'CANCELLED';
        for (final booking in bookings) {
          if (['PENDING', 'ACCEPTED'].contains(booking['status'])) booking['status'] = 'CANCELLED';
        }
      });
    } on ApiException catch (error) {
      if (mounted) _message(error.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> departTrip() async {
    if(!await _confirm(context,'Avisar que estoy saliendo. Los pasajeros aceptados recibirán el aviso; las solicitudes pendientes se cerrarán y no se recibirán nuevas.'))return;
    if(!mounted)return;
    setState(()=>busy=true);
    try{
      await ApiClient.instance.departTrip(widget.trip['id'].toString());
      if(mounted)setState((){departed=true;for(final b in bookings){if(b['status']=='PENDING')b['status']='REJECTED';}});
      if(mounted)await Navigator.push(context,MaterialPageRoute(builder:(_)=>LiveTrackingScreen(tripId:widget.trip['id'].toString(),driver:true)));
    }on ApiException catch(e){if(mounted)_message(e.message);}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> confirmEncounter(Map<String,dynamic> booking)async{
    final entered=await showDialog<String>(
      context:context,
      builder:(_)=>EncounterCodeDialog(passenger:booking['passenger']?.toString()??'Pasajero'),
    );
    if(entered==null||!mounted)return;
    setState(()=>busy=true);
    try{
      final result=await ApiClient.instance.verifyEncounter(booking['id'].toString(),entered);
      if(mounted)setState((){booking['encounterVerifiedAt']=result['encounterVerifiedAt'];tripStatus=result['status'].toString();});
    }on ApiException catch(e){if(mounted)_message(e.message);}
    finally{if(mounted)setState(()=>busy=false);}
  }

  Future<void> completeTrip() async {
    setState(() => busy = true);
    try {
      final response = await ApiClient.instance.completeTrip(
        widget.trip['id'].toString(),
      );
      if(LiveTrackingService.instance.tripId==widget.trip['id'].toString())await LiveTrackingService.instance.stop();
      if (mounted)
        setState(() {
          tripStatus = response['status'].toString();
          for (final booking in bookings) {
            if (booking['status'] == 'ACCEPTED')
              booking['status'] = 'COMPLETED';
          }
        });
    } on ApiException catch (apiError) {
      if (mounted) _message(apiError.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _message(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Gestionar viaje'), actions: [SosButton(tripId: widget.trip['id']?.toString())]),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _StatusHeader(status: tripStatus),
        if(departed&&['PUBLISHED','RESERVED','IN_PROGRESS'].contains(tripStatus))OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LiveTrackingScreen(tripId:widget.trip['id'].toString(),driver:true))),icon:const Icon(Icons.my_location),label:const Text('UBICACIÓN EN VIVO')),
        if(departed)const Card(child:ListTile(leading:Icon(Icons.directions_car),title:Text('Salida avisada'),subtitle:Text('Confirma a cada pasajero con su código al llegar al Punto Vamos!.'))),
        _RouteCard(data: widget.trip),
        TripPointsMap(data:widget.trip),
        DisplayPhoto(id:widget.trip['vehicleId']?.toString(),vehicle:true,size:180),
        if (['PUBLISHED', 'RESERVED'].contains(tripStatus)) ...[
          OutlinedButton.icon(onPressed: busy || departed ? null : () {
            if (bookings.any((b) => ['PENDING', 'ACCEPTED'].contains(b['status']))) {
              _message('Hay solicitudes pendientes o aceptadas. Cancela el viaje si necesitas cambiar sus condiciones.');
            } else {
              editTrip();
            }
          }, icon: const Icon(Icons.edit), label: const Text('EDITAR VIAJE')),
          TextButton.icon(onPressed: busy ? null : cancelTrip,
            icon: const Icon(Icons.cancel_outlined), label: const Text('CANCELAR VIAJE')),
        ],
        const SizedBox(height: 16),
        Text('Solicitudes', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        if (bookings.isEmpty)
          const _EmptyCard(text: 'Aún no hay solicitudes para este viaje.'),
        ...bookings.map(
          (booking) => Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  if(booking['meetingLat']!=null && booking['meetingLng']!=null)
                    TripPointsMap(data:widget.trip,meeting:booking)
                  else const Text('Punto Vamos! no indicado en esta solicitud. Coordina por el chat al aceptarla.'),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: DisplayPhoto(id:booking['passengerId']?.toString()),
                    title: Text(booking['passenger']?.toString() ?? 'Pasajero'),
                    subtitle: Text('${booking['seats']} asiento(s)'),
                    trailing: Chip(label: Text(booking['status'].toString())),
                  ),
                  if (['ACCEPTED','COMPLETED'].contains(booking['status'])) OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>PaymentScreen(bookingId:booking['id'].toString()))),icon:const Icon(Icons.payments_outlined),label:const Text('APORTE: EFECTIVO / QR')),
                  if (booking['status'] == 'PENDING')
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: busy
                                ? null
                                : () => bookingAction(booking, 'reject'),
                            child: const Text('RECHAZAR'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: busy
                                ? null
                                : () => bookingAction(booking, 'accept'),
                            child: const Text('ACEPTAR'),
                          ),
                        ),
                      ],
                    ),
                  if(booking['status']=='ACCEPTED' && departed && booking['encounterVerifiedAt']==null)
                    FilledButton.icon(onPressed:busy?null:()=>confirmEncounter(booking),icon:const Icon(Icons.password),label:const Text('CONFIRMAR ENCUENTRO')),
                  if(booking['encounterVerifiedAt']!=null)const Text('Encuentro confirmado ✓'),
                  if (booking['status'] == 'ACCEPTED' && booking['encounterVerifiedAt']==null &&
                      tripStatus == 'IN_PROGRESS')
                    TextButton(
                      onPressed: busy
                          ? null
                          : () => bookingAction(booking, 'no_show'),
                      child: const Text('MARCAR AUSENTE'),
                    ),
                  if (['ACCEPTED', 'COMPLETED'].contains(booking['status']))
                    ElevatedButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChatScreen(
                            bookingId: booking['id'].toString(),
                            otherUserName:
                                booking['passenger']?.toString() ?? 'Pasajero',
                          ),
                        ),
                      ),
                      icon: const Icon(Icons.chat_bubble_outline),
                      label: const Text('CHAT'),
                    ),
                  if (tripStatus == 'COMPLETED' &&
                      booking['status'] == 'COMPLETED')
                    OutlinedButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RatingScreen(
                            tripId: widget.trip['id']?.toString(),
                            toUserId: booking['passengerId']?.toString(),
                            toUserName:
                                booking['passenger']?.toString() ??
                                'el pasajero',
                          ),
                        ),
                      ),
                      icon: const Icon(Icons.star_outline),
                      label: const Text('CALIFICAR PASAJERO'),
                    ),
                  TextButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SafetyScreen(
                          tripId: widget.trip['id']?.toString(),
                          reportedUserId: booking['passengerId']?.toString(),
                          reportedUserName: booking['passenger']?.toString(),
                        ),
                      ),
                    ),
                    icon: const Icon(Icons.shield_outlined),
                    label: const Text('SEGURIDAD Y REPORTE'),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (['PUBLISHED','RESERVED'].contains(tripStatus) && !departed)
          FilledButton.icon(onPressed:busy?null:departTrip,icon:const Icon(Icons.directions_car),label:const Text('AVISAR QUE ESTOY SALIENDO')),
        if (tripStatus == 'IN_PROGRESS')
          ElevatedButton.icon(
            onPressed: busy ? null : completeTrip,
            icon: const Icon(Icons.flag_outlined),
            label: const Text('FINALIZAR VIAJE'),
          ),
        if (tripStatus == 'COMPLETED') ...[
          const _SuccessCard(text: 'Viaje completado. Ya pueden calificarse.'),
        ],
      ],
    ),
  );
}

class PassengerBookingScreen extends StatefulWidget {
  const PassengerBookingScreen({super.key, required this.booking});
  final Map<String, dynamic> booking;
  @override
  State<PassengerBookingScreen> createState() => _PassengerBookingScreenState();
}

class _PassengerBookingScreenState extends State<PassengerBookingScreen> {
  late String status;
  late Map<String, dynamic> booking;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    booking = Map<String, dynamic>.from(widget.booking);
    status = booking['status']?.toString() ?? 'PENDING';
  }

  Future<void> refresh() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final bookings = await ApiClient.instance.passengerBookings();
      final updated = bookings.where((item) => item['id'] == booking['id']);
      if (!mounted) return;
      if (updated.isEmpty)
        throw const ApiException('La reserva ya no está disponible.');
      setState(() {
        booking = Map<String, dynamic>.from(updated.first as Map);
        status = booking['status'].toString();
      });
    } on ApiException catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> cancel() async {
    if (!await _confirm(context, 'Cancelar reserva')) return;
    setState(() => busy = true);
    try {
      final response = await ApiClient.instance.bookingAction(
        booking['id'].toString(),
        'cancel',
      );
      if (mounted) setState(() => status = response['status'].toString());
    } on ApiException catch (apiError) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(apiError.message)));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Mi reserva'),
      actions: [
        SosButton(tripId: booking['tripId']?.toString()),
        IconButton(
          onPressed: busy ? null : refresh,
          icon: const Icon(Icons.refresh),
          tooltip: 'Actualizar reserva',
        ),
        IconButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => SafetyScreen(
                tripId: booking['tripId']?.toString(),
                reportedUserId: booking['driverId']?.toString(),
                reportedUserName: booking['driver']?.toString(),
              ),
            ),
          ),
          icon: const Icon(Icons.shield_outlined),
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if(booking['status']=='ACCEPTED'&&booking['routeDepartedAt']!=null)FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LiveTrackingScreen(tripId:booking['tripId'].toString(),bookingId:booking['id'].toString()))),icon:const Icon(Icons.location_searching),label:const Text('SEGUIR Y COMPARTIR VIAJE')),
        if (['ACCEPTED','COMPLETED'].contains(booking['status'])) OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>PaymentScreen(bookingId:booking['id'].toString()))),icon:const Icon(Icons.payments_outlined),label:const Text('PAGAR APORTE: EFECTIVO / QR')),
        _StatusHeader(status: status),
        _RouteCard(data: booking),
        TripPointsMap(data:booking),
        DisplayPhoto(id:booking['vehicleId']?.toString(),vehicle:true,size:180),
        Card(
          child: ListTile(
            leading: DisplayPhoto(id:booking['driverId']?.toString()),
            title: Text(booking['driver']?.toString() ?? 'Conductor'),
            subtitle: Text(
              '${booking['seats']} asiento(s) · Bs ${booking['contribution']}',
            ),
          ),
        ),
        if(status=='ACCEPTED' && booking['routeDepartedAt']!=null && booking['encounterVerifiedAt']==null)
          const Card(child:ListTile(leading:Icon(Icons.directions_car),title:Text('¡Tu conductor está saliendo!'),subtitle:Text('Dirígete a tu Punto Vamos! y coordina por el chat.'))),
        if (status == 'ACCEPTED')
          Card(
            color: const Color(0xFFE4F6EE),
            child: ListTile(
              leading: const Icon(Icons.pin_outlined, color: AppColors.green),
              title: Text(booking['encounterVerifiedAt']!=null?'Encuentro confirmado':'Código de encuentro'),
              subtitle: Text(booking['encounterVerifiedAt']!=null?'El conductor confirmó tu reserva en el Punto Vamos!.':'${booking['meetingCode']??'Pendiente'}\nMuéstralo al conductor al encontrarse en el Punto Vamos!.'),
            ),
          ),
        if (['ACCEPTED', 'COMPLETED'].contains(status))
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatScreen(
                  bookingId: booking['id'].toString(),
                  otherUserName: booking['driver']?.toString() ?? 'Conductor',
                ),
              ),
            ),
            icon: const Icon(Icons.chat_bubble_outline),
            label: const Text('ABRIR CHAT'),
          ),
        if (['PENDING', 'ACCEPTED'].contains(status))
          OutlinedButton(
            onPressed: busy ? null : cancel,
            child: Text(busy ? 'CANCELANDO…' : 'CANCELAR RESERVA'),
          ),
        if (status == 'CANCELLED')
          const _SuccessCard(
            text: 'La reserva fue cancelada y los cupos fueron actualizados.',
          ),
        if (status == 'COMPLETED')
          ElevatedButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => RatingScreen(
                  tripId: booking['tripId']?.toString(),
                  toUserId: booking['driverId']?.toString(),
                  toUserName: booking['driver']?.toString() ?? 'el conductor',
                  rateDriving: true,
                ),
              ),
            ),
            icon: const Icon(Icons.star_outline),
            label: const Text('CALIFICAR CONDUCTOR'),
          ),
      ],
    ),
  );
}

class _TripTile extends StatelessWidget {
  const _TripTile({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.onTap,
  });
  final String title;
  final String subtitle;
  final String badge;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      onTap: onTap,
      leading: const Icon(Icons.route, color: AppColors.green),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: Chip(label: Text(_statusLabel(badge))),
    ),
  );
}

class _RouteCard extends StatelessWidget {
  const _RouteCard({required this.data});
  final Map<String, dynamic> data;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.trip_origin, color: AppColors.green),
            title: Text(data['origin']?.toString() ?? 'Origen'),
          ),
          ListTile(
            leading: const Icon(Icons.location_on, color: AppColors.green),
            title: Text(data['destination']?.toString() ?? 'Destino'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.schedule),
            title: Text(_dateTime(data['departureAt'])),
            trailing: Text('Bs ${data['contribution'] ?? 0}'),
          ),
        ],
      ),
    ),
  );
}

class _StatusHeader extends StatelessWidget {
  const _StatusHeader({required this.status});
  final String status;
  @override
  Widget build(BuildContext context) => Center(
    child: Chip(
      label: Text(_statusLabel(status)),
      backgroundColor: AppColors.green.withValues(alpha: .14),
    ),
  );
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(leading: const Icon(Icons.info_outline), title: Text(text)),
  );
}

class _SuccessCard extends StatelessWidget {
  const _SuccessCard({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFFE4F6EE),
    child: ListTile(
      leading: const Icon(Icons.check_circle, color: AppColors.green),
      title: Text(text),
    ),
  );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off, size: 54),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: onRetry, child: const Text('REINTENTAR')),
        ],
      ),
    ),
  );
}

String _dateTime(dynamic value) {
  final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
  if (date == null) return 'Fecha pendiente';
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')} · ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
}

Future<bool> _confirm(BuildContext context, String title) async =>
    await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: const Text(
          'Esta acción actualizará la disponibilidad del viaje.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VOLVER'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('CONFIRMAR'),
          ),
        ],
      ),
    ) ??
    false;

String _statusLabel(String value) =>
    const {
      'PENDING': 'Pendiente',
      'ACCEPTED': 'Aceptada',
      'REJECTED': 'Rechazada',
      'CANCELLED': 'Cancelada',
      'NO_SHOW': 'Ausencia',
      'COMPLETED': 'Finalizado',
      'PUBLISHED': 'Publicado',
      'RESERVED': 'Sin asientos',
      'IN_PROGRESS': 'En curso',
    }[value] ??
    value;
