import '../../widgets/trip_points_map.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../models/map_point.dart';
import '../../models/trip.dart';
import '../../models/vehicle.dart';
import '../../screens/map/location_picker_screen.dart';
import '../../services/api_client.dart';
import '../../services/location_service.dart';
import '../../services/contribution_estimator.dart';
import '../../services/trip_payload_builder.dart';

class PublishTripScreen extends StatefulWidget {
  const PublishTripScreen({super.key, this.editTrip, this.communityId});
  final String? communityId;
  final Map<String, dynamic>? editTrip;

  @override
  State<PublishTripScreen> createState() => _PublishTripScreenState();
}

class _PublishTripScreenState extends State<PublishTripScreen> {
  final _origin = TextEditingController();
  final _destination = TextEditingController();
  final _contribution = TextEditingController();
  final _kilometers = TextEditingController();
  final _wearPercent = TextEditingController(text: '20');
  final _tolls = TextEditingController(text: '0');
  bool _manualContribution = false;
  bool _manualDistance = false;
  static double? _number(String value) => double.tryParse(value.replaceAll(',', '.'));
  ContributionEstimate? get _estimate => ContributionEstimator.calculate(
    kilometers: _number(_kilometers.text) ?? double.nan,
    wearPercent: _number(_wearPercent.text) ?? double.nan,
    tolls: _number(_tolls.text) ?? double.nan,
    passengers: _seats,
  );
  void _refreshEstimate() {
    final estimate = _estimate;
    if (!_manualContribution) {
      _contribution.text = estimate?.perPerson.toStringAsFixed(2) ?? '';
    }
  }
  Map<String,dynamic>? _roadRoute;
  String? _routeError;
  bool _routing = false;
  int _routeRequest = 0;
  Map<String,dynamic> get _mapData => {
    'origin':_origin.text,'destination':_destination.text,
    'originLat':_originPoint?.latitude,'originLng':_originPoint?.longitude,
    'destinationLat':_destinationPoint?.latitude,'destinationLng':_destinationPoint?.longitude,
    'route':_roadRoute?['route'],'routeEstimate':_roadRoute,
  };
  void _refreshDistance() {
    _roadRoute=null; _routeError=null; _routeRequest++;
    _routing=false; _kilometers.clear(); _manualDistance=false; _refreshEstimate();
  }
  Future<void> _calculateRoute() async {
    if(_originPoint==null||_destinationPoint==null)return;
    final request=++_routeRequest;
    setState((){_routing=true;_routeError=null;});
    try {
      final result=await ApiClient.instance.estimateRoute({
        'originLat':_originPoint!.latitude,'originLng':_originPoint!.longitude,
        'destinationLat':_destinationPoint!.latitude,'destinationLng':_destinationPoint!.longitude,
      });
      if(!mounted||request!=_routeRequest)return;
      setState((){
        _roadRoute=result;
        _kilometers.text=((result['distanceMeters'] as num)/1000).toStringAsFixed(2);
        _manualDistance=false; _refreshEstimate();
      });
    }on ApiException catch(e){if(mounted&&request==_routeRequest)setState(()=>_routeError=e.message);}
    finally{if(mounted&&request==_routeRequest)setState(()=>_routing=false);}
  }
  Widget _roadPreview() => Column(children:[
    TripPointsMap(data:_mapData),
    if(_routing)const LinearProgressIndicator(),
    if(_routeError!=null)Text(_routeError!),
    OutlinedButton(onPressed:_routing?null:_calculateRoute,child:Text(_roadRoute==null?'CALCULAR RECORRIDO':'RECALCULAR RECORRIDO')),
  ]);
  int _step = 0;
  int _seats = 3;
  DateTime _date = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _time = const TimeOfDay(hour: 7, minute: 0);
  bool _recurring = false;
  final Set<int> _days = {};
  String _music = 'Sin preferencia';
  String _conversation = 'Sin preferencia';
  String _pets = 'No permitidas';
  String _luggage = 'Pequeño';
  bool _published = false;
  bool _loadingVehicles = true;
  bool _publishing = false;
  String? _vehicleError;
  List<Vehicle> _verifiedVehicles = [];
  Vehicle? _selectedVehicle;
  Map<String, dynamic>? _publishedResponse;
  MapPoint? _originPoint;
  MapPoint? _destinationPoint;

  static const _dayLabels = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

  String? _communityId;
  List<dynamic> _communities=[];
  String? _communityError;
  Future<void> _loadCommunities() async {
    try {final groups=await ApiClient.instance.communities();if(mounted)setState((){_communities=groups.where((g)=>g['status']=='APPROVED').toList();_communityError=null;});}
    catch(_){if(mounted)setState(()=>_communityError='No se pudieron cargar tus comunidades. Reintenta antes de publicar un viaje privado.');}
  }
  @override
  void initState() {
    super.initState();
    _communityId=widget.editTrip?['communityId']?.toString() ?? widget.communityId;
    _loadCommunities();
    final t = widget.editTrip;
    if (t != null) {
      _origin.text = t['origin'].toString();
      _destination.text = t['destination'].toString();
      _originPoint = MapPoint(latitude: (t['originLat'] as num).toDouble(), longitude: (t['originLng'] as num).toDouble(), label: _origin.text);
      _destinationPoint = MapPoint(latitude: (t['destinationLat'] as num).toDouble(), longitude: (t['destinationLng'] as num).toDouble(), label: _destination.text);
      _date = DateTime.parse(t['departureAt'].toString()).toLocal();
      _time = TimeOfDay.fromDateTime(_date);
      _seats = (t['availableSeats'] as num).toInt();
      _contribution.text = t['contribution'].toString();
      _manualContribution = true;
      _days.addAll((t['recurringDays'] as List? ?? []).map((e) => (e as num).toInt()));
      _recurring = _days.isNotEmpty;
      final prefs = t['preferences'] as Map? ?? {};
      _music = prefs['music']?.toString() ?? _music;
      _conversation = prefs['conversation']?.toString() ?? _conversation;
      _pets = prefs['pets']?.toString() ?? _pets;
      _luggage = prefs['luggage']?.toString() ?? _luggage;
    }
    _refreshDistance();
    _loadVehicles();
    if(widget.editTrip!=null)WidgetsBinding.instance.addPostFrameCallback((_){if(mounted)_calculateRoute();});
  }

  @override
  void dispose() {
    _origin.dispose();
    _destination.dispose();
    _contribution.dispose();
    _kilometers.dispose();
    _wearPercent.dispose();
    _tolls.dispose();
    super.dispose();
  }

  DateTime get _departure =>
      DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);

  TripDraft get _trip => TripDraft(
    origin: _origin.text.trim(),
    destination: _destination.text.trim(),
    departure: _departure,
    availableSeats: _seats,
    suggestedContribution: _number(_contribution.text) ?? 0,
    recurringDays: _recurring ? (_days.toList()..sort()) : const [],
    preferences: TripPreferences(
      music: _music,
      conversation: _conversation,
      pets: _pets,
      luggage: _luggage,
    ),
  );

  String? _stepError() {
    if (_step == 0 && (_origin.text.trim().isEmpty || _originPoint == null))
      return 'Selecciona el origen en el mapa';
    if (_step == 1 &&
        (_destination.text.trim().isEmpty || _destinationPoint == null)) {
      return 'Selecciona el destino en el mapa';
    }
    if (_step == 2 && (_routing || _roadRoute == null)) return 'Calcula y revisa el recorrido antes de continuar';
    if (_step == 3 && _departure.isBefore(DateTime.now())) {
      return 'La salida debe estar en el futuro';
    }
    if (_step == 3 && _recurring && _days.isEmpty) {
      return 'Selecciona al menos un día recurrente';
    }
    if (_step == 4 && (!(_number(_contribution.text) ?? double.nan).isFinite || (_number(_contribution.text) ?? -1) < 0)) {
      return 'Ingresa un aporte válido';
    }
    if (_step == 4 && _selectedVehicle == null) {
      return 'Necesitas un vehículo verificado para publicar';
    }
    return null;
  }

  void _continue() {
    final error = _stepError();
    if (error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    if (_step < 5) setState(() => _step++);
  }

  Future<void> _pickDate() async {
    final result = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (result != null) setState(() => _date = result);
  }

  Future<void> _pickTime() async {
    final result = await showTimePicker(context: context, initialTime: _time);
    if (result != null) setState(() => _time = result);
  }

  Future<void> _loadVehicles() async {
    setState(() {
      _loadingVehicles = true;
      _vehicleError = null;
    });
    try {
      final response = await ApiClient.instance.vehicles();
      final verified = response
          .map((item) => Vehicle.fromJson(item as Map<String, dynamic>))
          .where((vehicle) => vehicle.isVerified && vehicle.id != null)
          .toList();
      if (!mounted) return;
      setState(() {
        _verifiedVehicles = verified;
        _selectedVehicle = verified.isEmpty ? null : verified.first;
        for (final vehicle in verified) {
          if (vehicle.id == widget.editTrip?['vehicleId']) _selectedVehicle = vehicle;
        }
        if (_selectedVehicle != null &&
            _seats > _selectedVehicle!.passengerSeats) {
          _seats = _selectedVehicle!.passengerSeats;
          _refreshEstimate();
        }
      });
    } on ApiException catch (error) {
      if (mounted) setState(() => _vehicleError = error.message);
    } finally {
      if (mounted) setState(() => _loadingVehicles = false);
    }
  }

  Future<void> _publishTrip() async {
    if (_selectedVehicle?.id == null ||
        _originPoint == null ||
        _destinationPoint == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Completa el viaje y selecciona un vehículo verificado',
          ),
        ),
      );
      return;
    }

    final amount = _number(_contribution.text);
    if (!_departure.isAfter(DateTime.now()) ||
        amount == null ||
        !amount.isFinite ||
        amount < 0 ||
        LocationService.distanceMeters(_originPoint!, _destinationPoint!) <
            10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Revisa la fecha futura, el aporte y que origen y destino sean diferentes.',
          ),
        ),
      );
      return;
    }
    if(_roadRoute==null||_routing){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Calcula el recorrido antes de publicar')));return;}
    setState(() => _publishing = true);
    try {
      final trip = _trip;
      final payload = TripPayloadBuilder.build(
        vehicleId: _selectedVehicle!.id!,
        originLabel: trip.origin,
        origin: _originPoint!,
        destinationLabel: trip.destination,
        destination: _destinationPoint!,
        departure: trip.departure,
        availableSeats: trip.availableSeats,
        contribution: trip.suggestedContribution,
        recurringDays: trip.recurringDays,
        preferences: {...trip.preferences.toJson(),'routeEstimate':{'provider':'openrouteservice','distanceMeters':_roadRoute!['distanceMeters'],'durationSeconds':_roadRoute!['durationSeconds']}},
        routePoints: (_roadRoute!['route'] as List).map((p)=>MapPoint(latitude:(p[1] as num).toDouble(),longitude:(p[0] as num).toDouble(),label:'')).toList(),
      );
      payload['communityId']=_communityId;
      final editing = widget.editTrip;
      if (editing != null) {
        await ApiClient.instance.updateTrip(editing['id'].toString(), payload);
        if (mounted) Navigator.pop(context, true);
        return;
      }
      final response = await ApiClient.instance.createTrip(payload);
      if (mounted) {
        setState(() {
          _publishedResponse = response;
          _published = true;
        });
      }
    } on ApiException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_published) {
      return _PublishedView(
        trip: _trip,
        response: _publishedResponse ?? const {},
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.editTrip == null ? 'Publicar un viaje' : 'Editar viaje')),
      body: Column(
        children: [
          LinearProgressIndicator(value: (_step + 1) / 6),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Paso ${_step + 1} de 6'),
                Text(
                  _stepTitle,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: KeyedSubtree(key: ValueKey(_step), child: _stepBody()),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  if (_step > 0)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => setState(() => _step--),
                        child: const Text('ATRÁS'),
                      ),
                    ),
                  if (_step > 0) const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _publishing
                          ? null
                          : (_step == 5 ? _publishTrip : _continue),
                      child: Text(
                        _step == 5
                            ? (_publishing ? 'GUARDANDO…' : widget.editTrip == null ? 'PUBLICAR VIAJE' : 'GUARDAR CAMBIOS')
                            : 'CONTINUAR',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String get _stepTitle => const [
    'Origen',
    'Destino',
    'Ruta',
    'Fecha y hora',
    'Detalles',
    'Vista previa',
  ][_step];

  Widget _stepBody() {
    switch (_step) {
      case 0:
        return _LocationStep(
          title: '¿De dónde sales?',
          controller: _origin,
          icon: Icons.trip_origin,
          hint: 'Ej.: Av. Banzer, 5.º Anillo',
          selected: _originPoint,
          onPick: () => _pickLocation(true),
        );
      case 1:
        return _LocationStep(
          title: '¿A dónde vas?',
          controller: _destination,
          icon: Icons.location_on_outlined,
          hint: 'Ej.: Parque Industrial',
          selected: _destinationPoint,
          onPick: () => _pickLocation(false),
        );
      case 2:
        return _roadPreview();
      case 3:
        return _scheduleStep();
      case 4:
        return _detailsStep();
      default:
        return _preview();
    }
  }

  Future<void> _pickLocation(bool isOrigin) async {
    final point = await Navigator.push<MapPoint>(
      context,
      MaterialPageRoute(
        builder: (_) => LocationPickerScreen(
          title: isOrigin ? 'Seleccionar origen' : 'Seleccionar destino',
          initialPoint: isOrigin ? _originPoint : _destinationPoint,
          routePoints: [if (!isOrigin && _originPoint != null) _originPoint!],
        ),
      ),
    );
    if (point == null || !mounted) return;
    setState(() {
      if (isOrigin) {
        _originPoint = point;
        if (_origin.text.trim().isEmpty) _origin.text = point.label;
      } else {
        _destinationPoint = point;
        if (_destination.text.trim().isEmpty) _destination.text = point.label;
      }
      _refreshDistance();
    });
    await _calculateRoute();
  }

  Widget _scheduleStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '¿Cuándo sales?',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 18),
        ListTile(
          tileColor: Colors.white,
          leading: const Icon(Icons.calendar_today_outlined),
          title: const Text('Fecha'),
          subtitle: Text(_formatDate(_date)),
          trailing: const Icon(Icons.chevron_right),
          onTap: _pickDate,
        ),
        const SizedBox(height: 10),
        ListTile(
          tileColor: Colors.white,
          leading: const Icon(Icons.schedule),
          title: const Text('Hora de salida'),
          subtitle: Text(_time.format(context)),
          trailing: const Icon(Icons.chevron_right),
          onTap: _pickTime,
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Guardar días habituales'),
          subtitle: const Text(
            'Solo se publicará la fecha elegida. Los demás días no se crean automáticamente.',
          ),
          value: _recurring,
          onChanged: (value) => setState(() => _recurring = value),
        ),
        if (_recurring)
          Wrap(
            spacing: 8,
            children: List.generate(7, (index) {
              final day = index + 1;
              return FilterChip(
                label: Text(_dayLabels[index]),
                selected: _days.contains(day),
                onSelected: (selected) => setState(() {
                  selected ? _days.add(day) : _days.remove(day);
                }),
              );
            }),
          ),
      ],
    );
  }

  Widget _contributionCalculator() {
    final estimate = _estimate;
    Widget input(TextEditingController controller, String label, {bool distance = false}) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
        decoration: InputDecoration(labelText: label),
        onChanged: (_) => setState(() {
          if (distance) _manualDistance = true;
          _refreshEstimate();
        }),
      ),
    );
    return Card(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Calculadora del conductor'),
        const SizedBox(height: 8),
        Text(_manualDistance
          ? 'Distancia ingresada por ti. Comprueba el recorrido por calles o carretera.'
          : 'Distancia estimada por calles. Puedes ajustar los kilómetros y el aporte.'),
        const SizedBox(height: 12),
        input(_kilometers, 'Kilómetros del recorrido', distance: true),
        input(_wearPercent, 'Desgaste adicional (%) · de 0 a 100'),
        input(_tolls, 'Peajes totales (Bs) · ingreso manual'),
        const Text('Gasolina: Bs 7/litro · consumo: 10 litros/100 km. El 20 % inicial de desgaste es ajustable.'),
        Text('Reparto entre ${_seats + 1} personas: conductor + $_seats pasajeros, suponiendo todos los asientos ocupados y el mismo recorrido.'),
        if (estimate != null) ...[
          const SizedBox(height: 8),
          Text('Gasolina Bs ${estimate.fuel.toStringAsFixed(2)} + desgaste Bs ${estimate.wear.toStringAsFixed(2)} + peajes Bs ${estimate.tolls.toStringAsFixed(2)}'),
          Text('Sugerido por asiento: Bs ${estimate.perPerson.toStringAsFixed(2)}'),
          TextButton(onPressed: () => setState(() {
            _manualContribution = false;
            _refreshEstimate();
          }), child: const Text('USAR APORTE SUGERIDO')),
        ] else
          const Text('Para calcular, ingresa kilómetros mayores a cero, desgaste de 0 a 100 y peajes no negativos.'),
        if (_manualContribution)
          const Text('Se conserva tu aporte final. Cambiar esta estimación no lo reemplaza.'),
        const Text('Solo el aporte final se publica. Este desglose es una ayuda de cálculo y no se guarda al salir.'),
      ]),
    ));
  }

  Widget _detailsStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Detalles del viaje',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 18),
        _vehicleSelector(),
        const SizedBox(height: 18),
        Row(
          children: [
            const Expanded(child: Text('Asientos disponibles')),
            IconButton(
              onPressed: _seats > 1 ? () => setState(() { _seats--; _refreshEstimate(); }) : null,
              icon: const Icon(Icons.remove_circle_outline),
            ),
            Text('$_seats', style: Theme.of(context).textTheme.titleLarge),
            IconButton(
              onPressed: _seats < (_selectedVehicle?.passengerSeats ?? 7)
                  ? () => setState(() { _seats++; _refreshEstimate(); })
                  : null,
              icon: const Icon(Icons.add_circle_outline),
            ),
          ],
        ),
        _contributionCalculator(),
        TextField(
          controller: _contribution,
          onChanged: (_) => setState(() => _manualContribution = true),
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
          ],
          decoration: const InputDecoration(
            labelText: 'Aporte final por asiento',
            prefixText: 'Bs ',
            helperText: 'Editable. Incluye los peajes; este es el importe que verá el pasajero.',
            helperMaxLines: 3,
          ),
        ),
        const SizedBox(height: 18),
        _Dropdown(
          label: 'Música',
          value: _music,
          items: const ['Sí', 'No', 'Sin preferencia'],
          onChanged: (value) => setState(() => _music = value),
        ),
        _Dropdown(
          label: 'Conversación',
          value: _conversation,
          items: const [
            'Me gusta conversar',
            'Prefiero tranquilidad',
            'Sin preferencia',
          ],
          onChanged: (value) => setState(() => _conversation = value),
        ),
        _Dropdown(
          label: 'Mascotas',
          value: _pets,
          items: const ['Permitidas', 'No permitidas'],
          onChanged: (value) => setState(() => _pets = value),
        ),
        _Dropdown(
          label: 'Equipaje',
          value: _luggage,
          items: const ['Pequeño', 'Mediano', 'No disponible'],
          onChanged: (value) => setState(() => _luggage = value),
        ),
      ],
    );
  }

  Widget _vehicleSelector() {
    if (_loadingVehicles) {
      return const Card(
        child: ListTile(
          leading: CircularProgressIndicator(),
          title: Text('Cargando tus vehículos…'),
        ),
      );
    }
    if (_vehicleError != null) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.cloud_off, color: Colors.orange),
          title: const Text('No pudimos cargar tus vehículos'),
          subtitle: Text(_vehicleError!),
          trailing: IconButton(
            onPressed: _loadVehicles,
            icon: const Icon(Icons.refresh),
          ),
        ),
      );
    }
    if (_verifiedVehicles.isEmpty) {
      return Card(
        child: Column(
          children: [
            const ListTile(
              leading: Icon(Icons.car_crash_outlined, color: Colors.orange),
              title: Text('No tienes vehículos verificados'),
              subtitle: Text(
                'Registra uno y espera su aprobación antes de ofrecer viajes.',
              ),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, AppRoutes.vehicle),
              child: const Text('REGISTRAR VEHÍCULO'),
            ),
          ],
        ),
      );
    }
    return DropdownButtonFormField<String>(
      value: _selectedVehicle?.id,
      decoration: const InputDecoration(
        labelText: 'Vehículo verificado',
        prefixIcon: Icon(Icons.directions_car_outlined),
      ),
      items: _verifiedVehicles
          .map(
            (vehicle) => DropdownMenuItem(
              value: vehicle.id,
              child: Text(
                '${vehicle.brand} ${vehicle.model} · ${vehicle.licensePlate}',
              ),
            ),
          )
          .toList(),
      onChanged: (id) => setState(() {
        _selectedVehicle = _verifiedVehicles.firstWhere(
          (vehicle) => vehicle.id == id,
        );
        if (_seats > _selectedVehicle!.passengerSeats) {
          _seats = _selectedVehicle!.passengerSeats;
          _refreshEstimate();
        }
      }),
    );
  }

  Widget _preview() {
    final trip = _trip;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if(_communityError!=null)Text(_communityError!),
        if(_communityError!=null)TextButton(onPressed:_loadCommunities,child:const Text('REINTENTAR COMUNIDADES')),
        DropdownButtonFormField<String>(
          key:ValueKey('${_communityId}_${_communities.length}'),
          initialValue:_communityId??'PUBLIC',
          decoration:const InputDecoration(labelText:'¿Quién puede ver y solicitar este viaje?'),
          items:[const DropdownMenuItem(value:'PUBLIC',child:Text('Público · todos los usuarios')),
            ..._communities.map((g)=>DropdownMenuItem<String>(value:g['id'] as String,child:Text(g['name'] as String))),
            if(_communityId!=null&&!_communities.any((g)=>g['id']==_communityId))DropdownMenuItem(value:_communityId,child:const Text('Comunidad seleccionada · verificar acceso'))],
          onChanged:(v)=>setState(()=>_communityId=v=='PUBLIC'?null:v),
        ),
        Text(_communityId==null?'Viaje público':'Exclusivo para miembros aprobados de la comunidad'),
        Text('Tu viaje', style: Theme.of(context).textTheme.headlineSmall),
        TripPointsMap(data:_mapData),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _SummaryRow(icon: Icons.trip_origin, label: trip.origin),
                const Padding(
                  padding: EdgeInsets.only(left: 11),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('│'),
                  ),
                ),
                _SummaryRow(icon: Icons.location_on, label: trip.destination),
                const Divider(height: 28),
                _SummaryRow(
                  icon: Icons.calendar_today,
                  label: _formatDate(trip.departure),
                ),
                _SummaryRow(icon: Icons.schedule, label: _time.format(context)),
                _SummaryRow(
                  icon: Icons.event_repeat,
                  label: trip.isRecurring
                      ? 'Una salida con días habituales guardados'
                      : 'Viaje único',
                ),
                _SummaryRow(
                  icon: Icons.directions_car_outlined,
                  label: _selectedVehicle == null
                      ? 'Sin vehículo verificado'
                      : '${_selectedVehicle!.brand} ${_selectedVehicle!.model} · ${_selectedVehicle!.licensePlate}',
                ),
                _SummaryRow(
                  icon: Icons.event_seat,
                  label: '${trip.availableSeats} asientos',
                ),
                _SummaryRow(
                  icon: Icons.payments_outlined,
                  label:
                      'Bs ${trip.suggestedContribution.toStringAsFixed(2)} por asiento',
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'El aporte puede pagarse en efectivo o por QR si lo cargas en Mi perfil.\n\nAl publicar confirmas que la información es correcta y que respetarás las reglas de convivencia de Vamos!!',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.black54),
        ),
      ],
    );
  }
}

class _LocationStep extends StatelessWidget {
  const _LocationStep({
    required this.title,
    required this.controller,
    required this.icon,
    required this.hint,
    required this.selected,
    required this.onPick,
  });
  final String title;
  final TextEditingController controller;
  final IconData icon;
  final String hint;
  final MapPoint? selected;
  final VoidCallback onPick;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Text(title, style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 18),
      TextField(
        controller: controller,
        textCapitalization: TextCapitalization.sentences,
        decoration: InputDecoration(
          labelText: 'Dirección',
          hintText: hint,
          prefixIcon: Icon(icon),
        ),
      ),
      const SizedBox(height: 12),
      OutlinedButton.icon(
        onPressed: onPick,
        icon: const Icon(Icons.map_outlined),
        label: Text(selected == null ? 'ELEGIR EN EL MAPA' : 'CAMBIAR PUNTO'),
      ),
      const SizedBox(height: 18),
      _MapPlaceholder(
        label: selected == null
            ? 'Selecciona un punto para continuar'
            : '${selected!.latitude.toStringAsFixed(5)}, ${selected!.longitude.toStringAsFixed(5)}',
      ),
    ],
  );
}

class _MapPlaceholder extends StatelessWidget {
  const _MapPlaceholder({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => Container(
    height: 240,
    decoration: BoxDecoration(
      color: const Color(0xFFE4F6EE),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: AppColors.green.withValues(alpha: .35)),
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.map_outlined, size: 58, color: AppColors.green),
        const SizedBox(height: 8),
        Text(label, textAlign: TextAlign.center),
      ],
    ),
  );
}

class _RouteSummary extends StatelessWidget {
  const _RouteSummary({
    required this.origin,
    required this.destination,
    required this.originPoint,
    required this.destinationPoint,
  });
  final String origin;
  final String destination;
  final MapPoint originPoint;
  final MapPoint destinationPoint;

  @override
  Widget build(BuildContext context) {
    final distanceKm =
        LocationService.distanceMeters(originPoint, destinationPoint) / 1000;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Resumen de ruta',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 16),
        const _MapPlaceholder(
          label: 'Referencia directa entre origen y destino',
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _SummaryRow(icon: Icons.trip_origin, label: origin),
                _SummaryRow(icon: Icons.location_on, label: destination),
                const Divider(),
                Text(
                  'Distancia directa aproximada: ${distanceKm.toStringAsFixed(1)} km',
                ),
                const Text(
                  'Esta versión no calcula rutas por calles ni tiempos de viaje.',
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Dropdown extends StatelessWidget {
  const _Dropdown({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });
  final String label;
  final String value;
  final List<String> items;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: DropdownButtonFormField<String>(
      initialValue: value,
      decoration: InputDecoration(labelText: label),
      items: items
          .map((item) => DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: (newValue) {
        if (newValue != null) onChanged(newValue);
      },
    ),
  );
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      children: [
        Icon(icon, color: AppColors.green, size: 22),
        const SizedBox(width: 12),
        Expanded(child: Text(label)),
      ],
    ),
  );
}

class _PublishedView extends StatelessWidget {
  const _PublishedView({required this.trip, required this.response});
  final TripDraft trip;
  final Map<String, dynamic> response;

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, size: 92, color: AppColors.green),
            const SizedBox(height: 18),
            Text(
              '¡Viaje publicado!',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            const Text(
              'Tu viaje ya está disponible para encontrar pasajeros compatibles.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 22),
            Card(
              child: ListTile(
                leading: const Icon(Icons.route, color: AppColors.green),
                title: Text('${trip.origin} → ${trip.destination}'),
                subtitle: Text(
                  '${trip.availableSeats} asientos · Bs ${trip.suggestedContribution.toStringAsFixed(2)}',
                ),
              ),
            ),
            if (response['meetingCode'] != null) ...[
              const SizedBox(height: 10),
              Card(
                color: const Color(0xFFE4F6EE),
                child: ListTile(
                  leading: const Icon(
                    Icons.pin_outlined,
                    color: AppColors.green,
                  ),
                  title: const Text('Código de encuentro'),
                  subtitle: Text(
                    response['meetingCode'].toString(),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                    ),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 22),
            ElevatedButton(
              onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context,
                AppRoutes.home,
                (_) => false,
              ),
              child: const Text('VOLVER AL INICIO'),
            ),
          ],
        ),
      ),
    ),
  );
}

String _formatDate(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
