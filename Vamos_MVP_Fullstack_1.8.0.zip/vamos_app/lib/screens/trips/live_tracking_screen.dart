import '../safety/sos_screen.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/config/app_config.dart';
import '../../services/api_client.dart';
import '../../services/live_tracking_service.dart';
import '../../widgets/trip_points_map.dart';

class LiveTrackingScreen extends StatefulWidget {
 const LiveTrackingScreen({super.key,required this.tripId,this.bookingId,this.driver=false});
 final String tripId;
 final String? bookingId;
 final bool driver;
 @override State<LiveTrackingScreen> createState()=>_LiveTrackingScreenState();
}
class _LiveTrackingScreenState extends State<LiveTrackingScreen>{
 Map<String,dynamic>? data;
 String? error;
 Timer? timer;
 bool loading=false,busy=false;
 @override void initState(){super.initState();refresh();timer=Timer.periodic(const Duration(seconds:15),(_)=>refresh());}
 @override void dispose(){timer?.cancel();super.dispose();}
 void message(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 Future<void> refresh()async{
  if(loading)return;loading=true;
  try{final result=await ApiClient.instance.tracking(widget.tripId);if(mounted)setState((){data=result;error=null;});}
  on ApiException catch(e){if(mounted)setState((){error=e.message;data=null;});if([401,403,404].contains(e.statusCode))timer?.cancel();}
  finally{loading=false;}
 }
 Future<void> enable()async{
  final accepted=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
   title:const Text('Compartir ubicación durante el viaje'),
   content:const Text('Vamos enviará tu ubicación mientras este viaje esté activo, incluso con la app en segundo plano. La verán los pasajeros aceptados y quienes reciban sus enlaces privados. Android mostrará una notificación permanente. Puedes detenerla aquí; al finalizar o cancelar se cierra el acceso.'),
   actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Ahora no')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('ACTIVAR'))]));
  if(accepted!=true||!mounted)return;setState(()=>busy=true);
  try{await LiveTrackingService.instance.start(widget.tripId);await refresh();}
  catch(e){message(e.toString());}finally{if(mounted)setState(()=>busy=false);}
 }
 Future<void> share()async{
  final accepted=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Compartir viaje'),content:const Text('Quien tenga el enlace podrá ver el recorrido y la última ubicación del conductor durante el viaje. Envíalo solo a alguien de confianza. Un enlace nuevo invalida el anterior.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('CONTINUAR'))]));
  if(accepted!=true||!mounted)return;setState(()=>busy=true);
  try{
   final result=await ApiClient.instance.shareTracking(widget.bookingId!);
   final base=Uri.parse(AppConfig.apiBaseUrl);
   final link=base.replace(path:'/seguimiento',query:null,fragment:result['token'].toString()).toString();
   await SharePlus.instance.share(ShareParams(text:'Sigue mi viaje en Vamos! Este enlace es temporal y privado: $link',subject:'Mi viaje en Vamos!'));
  }catch(e){message(e.toString());}finally{if(mounted)setState(()=>busy=false);}
 }
 @override Widget build(BuildContext context){
  final d=data;
  final time=DateTime.tryParse('${d?['recordedAt']}');
  final server=DateTime.tryParse('${d?['serverTime']}');
  final stale=time==null||server==null||server.difference(time).inSeconds>120;
  return Scaffold(appBar:AppBar(title:const Text('Seguir viaje'),actions:[SosButton(tripId:widget.tripId)]),body:ListView(padding:const EdgeInsets.all(20),children:[
   if(error!=null)Text(error!) else if(d==null)const LinearProgressIndicator(),
   if(d!=null)...[
    Text(d['enabled']!=true?'Ubicación pausada':time==null?'Esperando ubicación del conductor':stale?'Señal sin actualizar · última posición conocida':'Ubicación reciente del conductor',style:Theme.of(context).textTheme.titleLarge),
    if(time!=null)Text('Última ubicación: ${time.toLocal()} · precisión aproximada ${d['accuracy']} m'),
    TripPointsMap(data:{...d,if(d['latitude']!=null)'driverLat':d['latitude'],if(d['longitude']!=null)'driverLng':d['longitude'],'stale':stale}),
   ],
   const Text('La actualización depende del GPS y la conexión. Si se interrumpe, coordina directamente por el chat.'),
   const SizedBox(height:16),
   if(widget.driver)...[
    ValueListenableBuilder<String>(valueListenable:LiveTrackingService.instance.status,builder:(_,value,__)=>Text(value)),
    FilledButton(onPressed:busy?null:enable,child:const Text('ACTIVAR / REANUDAR UBICACIÓN')),
    OutlinedButton(onPressed:busy?null:()async{setState(()=>busy=true);try{await LiveTrackingService.instance.stop();await ApiClient.instance.trackingAction(widget.tripId,'stop');await refresh();}catch(e){message(e.toString());}finally{if(mounted)setState(()=>busy=false);}},child:const Text('DETENER UBICACIÓN')),
   ],
   if(widget.bookingId!=null)...[
    FilledButton.icon(onPressed:busy||d==null?null:share,icon:const Icon(Icons.share),label:const Text('COMPARTIR VIAJE')),
    TextButton(onPressed:busy?null:()async{setState(()=>busy=true);try{await ApiClient.instance.revokeTracking(widget.bookingId!);message('Enlace revocado');}catch(e){message(e.toString());}finally{if(mounted)setState(()=>busy=false);}},child:const Text('REVOCAR ENLACE COMPARTIDO')),
   ],
  ]));
 }
}
