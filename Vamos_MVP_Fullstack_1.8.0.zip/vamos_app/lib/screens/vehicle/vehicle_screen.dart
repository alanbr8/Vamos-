import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/routes/app_routes.dart';
import '../../models/vehicle.dart';
import '../../services/api_client.dart';

class VehicleScreen extends StatefulWidget {
  const VehicleScreen({super.key});

  @override
  State<VehicleScreen> createState() => _VehicleScreenState();
}

class _VehicleScreenState extends State<VehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _brand = TextEditingController();
  final _model = TextEditingController();
  final _year = TextEditingController();
  final _color = TextEditingController();
  final _plate = TextEditingController();
  int _seats = 3;
  bool _authorized = false;
  Vehicle? _registeredVehicle;
  List<Vehicle> _vehicles = [];
  bool _addingVehicle = false;
  bool _loading = false;
  bool _checkingVehicles = true;
  String? _vehicleLoadError;

  @override
  void initState() {
    super.initState();
    _loadExistingVehicle();
  }

  Future<void> _loadExistingVehicle() async {
    setState(() {
      _checkingVehicles = true;
      _vehicleLoadError = null;
    });
    try {
      final response = await ApiClient.instance.vehicles();
      final vehicles = response
          .map(
            (item) => Vehicle.fromJson(Map<String, dynamic>.from(item as Map)),
          )
          .toList();
      Vehicle? selected;
      for (final vehicle in vehicles) {
        if (vehicle.id == _registeredVehicle?.id) selected = vehicle;
      }
      if (selected == null) {
        for (final vehicle in vehicles) {
          selected ??= vehicle;
          if (vehicle.isVerified) {
            selected = vehicle;
            break;
          }
        }
      }
      if (!mounted) return;
      setState(() {
        _vehicles = vehicles;
        _registeredVehicle = selected;
      });
    } on ApiException catch (error) {
      if (!mounted) return;
      setState(() => _vehicleLoadError = error.message);
    } catch (_) {
      if (!mounted) return;
      setState(
        () => _vehicleLoadError =
            'No pudimos cargar tu vehículo. Intenta de nuevo.',
      );
    } finally {
      if (mounted) setState(() => _checkingVehicles = false);
    }
  }

  @override
  void dispose() {
    for (final controller in [_brand, _model, _year, _color, _plate]) {
      controller.dispose();
    }
    super.dispose();
  }

  String? _required(String? value) => (value == null || value.trim().isEmpty)
      ? 'Este campo es obligatorio'
      : null;

  Future<void> _submit() async {
    if (_loading) return;
    if (!_authorized) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Confirma que puedes utilizar este vehículo'),
        ),
      );
      return;
    }
    if (!_formKey.currentState!.validate()) return;

    final vehicle = Vehicle(
      brand: _brand.text.trim(),
      model: _model.text.trim(),
      year: int.parse(_year.text),
      color: _color.text.trim(),
      licensePlate: _plate.text.trim().toUpperCase(),
      passengerSeats: _seats,
    );
    setState(() => _loading = true);
    try {
      final response = await ApiClient.instance.createVehicle(vehicle.toJson());
      if (mounted) {
        final registered = Vehicle.fromJson(response);
        setState(() {
          _registeredVehicle = registered;
          _vehicles = [..._vehicles, registered];
          _addingVehicle = false;
        });
      }
    } on ApiException catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_checkingVehicles || _vehicleLoadError != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Mi vehículo')),
        body: Center(
          child: _checkingVehicles
              ? const CircularProgressIndicator()
              : Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_vehicleLoadError!, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadExistingVehicle,
                        child: const Text('REINTENTAR'),
                      ),
                    ],
                  ),
                ),
        ),
      );
    }
    if (_registeredVehicle != null && !_addingVehicle) {
      return _VehicleRegistered(
        vehicle: _registeredVehicle!,
        vehicles: _vehicles,
        onSelect: (vehicle) => setState(() => _registeredVehicle = vehicle),
        onAdd: () {
          for (final controller in [_brand, _model, _year, _color, _plate]) {
            controller.clear();
          }
          setState(() {
            _seats = 3;
            _authorized = false;
            _addingVehicle = true;
          });
        },
        onRefresh: _loadExistingVehicle,
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Registrar vehículo')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Cuéntanos sobre tu vehículo',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 6),
              const Text(
                'Estos datos ayudarán a que tus pasajeros puedan identificarte.',
              ),
              const SizedBox(height: 22),
              TextFormField(
                controller: _brand,
                decoration: const InputDecoration(labelText: 'Marca'),
                validator: _required,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _model,
                decoration: const InputDecoration(labelText: 'Modelo'),
                validator: _required,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _year,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(labelText: 'Año'),
                validator: (value) {
                  final year = int.tryParse(value ?? '');
                  final current = DateTime.now().year;
                  return year != null && year >= 1950 && year <= current
                      ? null
                      : 'Ingresa un año válido';
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _color,
                decoration: const InputDecoration(labelText: 'Color'),
                validator: _required,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _plate,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'Placa'),
                validator: (value) => (value?.trim().length ?? 0) >= 4
                    ? null
                    : 'Ingresa una placa válida',
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Expanded(child: Text('Asientos disponibles')),
                  IconButton(
                    onPressed: _seats > 1
                        ? () => setState(() => _seats--)
                        : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Text(
                    '$_seats',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  IconButton(
                    onPressed: _seats < 7
                        ? () => setState(() => _seats++)
                        : null,
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'La carga de fotos y documentos todavía no está disponible en esta versión de pruebas.',
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: _authorized,
                onChanged: (value) =>
                    setState(() => _authorized = value ?? false),
                title: const Text(
                  'Declaro que soy propietario o estoy autorizado para usarlo',
                ),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              ElevatedButton(
                onPressed: _loading ? null : _submit,
                child: Text(_loading ? 'GUARDANDO…' : 'REGISTRAR VEHÍCULO'),
              ),
              if (_registeredVehicle != null)
                TextButton(
                  onPressed: _loading
                      ? null
                      : () => setState(() => _addingVehicle = false),
                  child: const Text('CANCELAR REGISTRO'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _VehicleRegistered extends StatelessWidget {
  const _VehicleRegistered({
    required this.vehicle,
    required this.vehicles,
    required this.onSelect,
    required this.onAdd,
    required this.onRefresh,
  });
  final VoidCallback onRefresh;
  final VoidCallback onAdd;
  final List<Vehicle> vehicles;
  final ValueChanged<Vehicle> onSelect;

  final Vehicle vehicle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mi vehículo'),
        actions: [
          IconButton(
            onPressed: onRefresh,
            icon: const Icon(Icons.refresh),
            tooltip: 'Actualizar estado',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (vehicles.length > 1) ...[
                DropdownButton<Vehicle>(
                  value: vehicle,
                  isExpanded: true,
                  items: vehicles.map((item) => DropdownMenuItem(
                    value: item,
                    child: Text(
                      '${item.brand} ${item.model} · ${item.licensePlate}',
                      overflow: TextOverflow.ellipsis,
                    ),
                  )).toList(),
                  onChanged: (item) {
                    if (item != null) onSelect(item);
                  },
                ),
                const SizedBox(height: 16),
              ],
              const Icon(
                Icons.verified_outlined,
                size: 80,
                color: Colors.orange,
              ),
              const SizedBox(height: 16),
              Text(
                vehicle.isVerified
                    ? '¡Vehículo listo para viajar!'
                    : '¡Vehículo registrado!',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                vehicle.isVerified
                    ? 'Tu vehículo está aprobado para ofrecer viajes.'
                    : (vehicle.status == VehicleStatus.rejected
                          ? 'El vehículo fue rechazado. Contacta al administrador de la prueba.'
                          : vehicle.status == VehicleStatus.suspended
                          ? 'El vehículo está suspendido. Contacta al administrador de la prueba.'
                          : 'Registro guardado. Para ofrecer viajes, el administrador debe aprobar tu vehículo. Consulta la aprobación aquí; no necesitas registrarlo otra vez.'),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.directions_car),
                  title: Text('${vehicle.brand} ${vehicle.model}'),
                  subtitle: Text(
                    '${vehicle.color} · ${vehicle.licensePlate} · ${vehicle.passengerSeats} asientos',
                  ),
                  trailing: Chip(
                    label: Text(
                      vehicle.isVerified
                          ? 'VERIFICADO'
                          : vehicle.status == VehicleStatus.rejected
                          ? 'RECHAZADO'
                          : vehicle.status == VehicleStatus.suspended
                          ? 'SUSPENDIDO'
                          : 'EN REVISIÓN',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              if (!vehicle.isVerified)
                OutlinedButton.icon(
                  onPressed: onRefresh,
                  icon: const Icon(Icons.refresh),
                  label: const Text('CONSULTAR APROBACIÓN'),
                ),
              if (vehicle.isVerified)
                ElevatedButton(
                  onPressed: () => Navigator.pushReplacementNamed(
                    context,
                    AppRoutes.publishTrip,
                  ),
                  child: const Text('CONTINUAR A PUBLICAR VIAJE'),
                ),
              TextButton(
                onPressed: onAdd,
                child: const Text('REGISTRAR OTRO VEHÍCULO'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Volver al inicio'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
