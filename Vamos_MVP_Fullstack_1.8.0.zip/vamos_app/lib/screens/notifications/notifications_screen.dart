import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  String? error;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 30), (_) => load(silent: true));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) setState(() { loading = true; error = null; });
    try {
      final response = await ApiClient.instance.notifications();
      if (!mounted) return;
      setState(() {
        items = response.map((item) => Map<String, dynamic>.from(item as Map)).toList();
        error = null;
      });
    } on ApiException catch (apiError) {
      if (!silent && mounted) setState(() => error = apiError.message);
    } finally {
      if (!silent && mounted) setState(() => loading = false);
    }
  }

  Future<void> markRead(Map<String, dynamic> item) async {
    if (item['readAt'] != null) return;
    try {
      final response = await ApiClient.instance.readNotification(item['id'].toString());
      if (mounted) setState(() => item['readAt'] = response['readAt']);
    } on ApiException catch (apiError) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiError.message)));
    }
  }

  Future<void> markAllRead() async {
    try {
      await ApiClient.instance.readAllNotifications();
      if (mounted) setState(() {
        for (final item in items) { item['readAt'] ??= DateTime.now().toIso8601String(); }
      });
    } on ApiException catch (apiError) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiError.message)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Notificaciones'),
      actions: [
        if (items.any((item) => item['readAt'] == null))
          TextButton(onPressed: markAllRead, child: const Text('LEER TODAS')),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : error != null
            ? _ErrorState(message: error!, retry: () => load())
            : RefreshIndicator(
                onRefresh: load,
                child: items.isEmpty
                    ? ListView(children: const [SizedBox(height: 180), Center(child: Text('No tienes notificaciones todavía.'))])
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, index) {
                          final item = items[index];
                          final unread = item['readAt'] == null;
                          return Card(
                            color: unread ? const Color(0xFFE4F6EE) : null,
                            child: ListTile(
                              onTap: () => markRead(item),
                              leading: CircleAvatar(
                                backgroundColor: unread ? AppColors.green : Colors.black12,
                                child: Icon(_icon(item['type']?.toString()), color: unread ? Colors.white : Colors.black54),
                              ),
                              title: Text(item['title']?.toString() ?? 'Notificación', style: TextStyle(fontWeight: unread ? FontWeight.bold : FontWeight.normal)),
                              subtitle: Text('${item['body'] ?? ''}\n${_relativeDate(item['createdAt'])}'),
                              isThreeLine: true,
                              trailing: unread ? const Icon(Icons.circle, size: 10, color: AppColors.green) : null,
                            ),
                          );
                        },
                      ),
              ),
  );
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.retry});
  final String message;
  final VoidCallback retry;
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.cloud_off, size: 54),
    const SizedBox(height: 12),
    Text(message),
    const SizedBox(height: 12),
    ElevatedButton(onPressed: retry, child: const Text('REINTENTAR')),
  ]));
}

IconData _icon(String? type) => switch (type) {
  'BOOKING_REQUEST' => Icons.person_add_alt,
  'BOOKING_ACCEPTED' => Icons.check_circle_outline,
  'BOOKING_REJECTED' => Icons.cancel_outlined,
  'BOOKING_CANCELLED' => Icons.event_busy_outlined,
  'TRIP_STARTED' => Icons.play_circle_outline,
  'TRIP_COMPLETED' => Icons.flag_outlined,
  'NO_SHOW' => Icons.person_off_outlined,
  'CHAT_MESSAGE' => Icons.chat_bubble_outline,
  _ => Icons.notifications_none,
};

String _relativeDate(dynamic value) {
  final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
  if (date == null) return '';
  final difference = DateTime.now().difference(date);
  if (difference.inMinutes < 1) return 'Ahora';
  if (difference.inHours < 1) return 'Hace ${difference.inMinutes} min';
  if (difference.inDays < 1) return 'Hace ${difference.inHours} h';
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}
