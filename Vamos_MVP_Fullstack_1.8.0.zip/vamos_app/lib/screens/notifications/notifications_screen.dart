import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';
import '../trips/my_trips_screen.dart';
import '../trips/search_trip_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  String? error;
  Timer? timer;
  bool fetching = false;
  bool opening = false;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => load(silent: true),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load({bool silent = false}) async {
    if (fetching || !mounted) return;
    fetching = true;
    if (!silent)
      setState(() {
        loading = true;
        error = null;
      });
    try {
      final response = await ApiClient.instance.notifications();
      if (!mounted) return;
      setState(() {
        items = response
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        error = null;
      });
    } on ApiException catch (apiError) {
      if (!silent && mounted) setState(() => error = apiError.message);
    } finally {
      fetching = false;
      if (!silent && mounted) setState(() => loading = false);
    }
  }

  Future<void> markRead(Map<String, dynamic> item) async {
    if (item['readAt'] != null) return;
    try {
      final response = await ApiClient.instance.readNotification(
        item['id'].toString(),
      );
      if (mounted) setState(() => item['readAt'] = response['readAt']);
    } on ApiException catch (apiError) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(apiError.message)));
    }
  }

  bool canOpenTrip(Map<String, dynamic> item) {
    final data = item['data'];
    return data is Map && data['tripId'] is String &&
        (data['tripId'] as String).isNotEmpty;
  }

  Future<void> openNotification(Map<String, dynamic> item) async {
    if (opening) return;
    if (!canOpenTrip(item)) {
      await markRead(item);
      return;
    }
    setState(() => opening = true);
    try {
      final data = item['data'] as Map;
      if (item['type'] == 'SEARCH_MATCH') {
        final searches = await ApiClient.instance.savedSearches();
        Map<String, dynamic>? found;
        for (final search in searches) {
          if (search is Map && search['id'] == data['searchId']) found = Map<String, dynamic>.from(search);
        }
        if (!mounted) return;
        if (found == null || found['status'] != 'ACTIVE') {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Esta búsqueda venció o fue cancelada. Crea una nueva búsqueda.')));
          return;
        }
        await markRead(item);
        if (!mounted) return;
        await Navigator.push(context, MaterialPageRoute(builder: (_) => SearchTripScreen(savedSearch: found)));
        return;
      }

      final tripId = data['tripId'];
      final asDriver = item['type'] == 'BOOKING_REQUEST' ||
          item['type'] == 'BOOKING_CANCELLED';
      final records = asDriver
          ? await ApiClient.instance.driverTrips()
          : await ApiClient.instance.passengerBookings();
      Map<String, dynamic>? selected;
      for (final record in records) {
        if (record is! Map) continue;
        final matches = asDriver
            ? record['id'] == tripId
            : record['tripId'] == tripId &&
                (data['bookingId'] == null || record['id'] == data['bookingId']);
        if (matches) {
          selected = Map<String, dynamic>.from(record);
          break;
        }
      }
      if (!mounted) return;
      if (selected == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Este viaje o reserva ya no está disponible.')),
        );
        return;
      }
      final record = selected;
      await markRead(item);
      if (!mounted) return;
      await Navigator.push(context, MaterialPageRoute<void>(
        builder: (_) => asDriver
            ? DriverTripScreen(trip: record)
            : PassengerBookingScreen(booking: record),
      ));
      if (mounted) await load(silent: true);
    } on ApiException catch (apiError) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(apiError.message)),
      );
    } finally {
      if (mounted) setState(() => opening = false);
    }
  }

  Future<void> markAllRead() async {
    try {
      await ApiClient.instance.readAllNotifications();
      if (mounted)
        setState(() {
          for (final item in items) {
            item['readAt'] ??= DateTime.now().toIso8601String();
          }
        });
    } on ApiException catch (apiError) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(apiError.message)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Notificaciones'),
      actions: [
        if (items.any((item) => item['readAt'] == null))
          TextButton(onPressed: markAllRead, child: const Text('LEER TODAS')),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : error != null
        ? _ErrorState(message: error!, retry: () => load())
        : RefreshIndicator(
            onRefresh: load,
            child: items.isEmpty
                ? ListView(
                    children: const [
                      SizedBox(height: 180),
                      Center(child: Text('No tienes notificaciones todavía.')),
                    ],
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, index) {
                      final item = items[index];
                      final unread = item['readAt'] == null;
                      return Card(
                        color: unread ? const Color(0xFFE4F6EE) : null,
                        child: ListTile(
                          onTap: opening ? null : () => openNotification(item),
                          leading: CircleAvatar(
                            backgroundColor: unread
                                ? AppColors.green
                                : Colors.black12,
                            child: Icon(
                              _icon(item['type']?.toString()),
                              color: unread ? Colors.white : Colors.black54,
                            ),
                          ),
                          title: Text(
                            item['title']?.toString() ?? 'Notificación',
                            style: TextStyle(
                              fontWeight: unread
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                          subtitle: Text(
                            '${item['body'] ?? ''}\n${_relativeDate(item['createdAt'])}',
                          ),
                          isThreeLine: true,
                          trailing: canOpenTrip(item)
                              ? const Icon(Icons.chevron_right)
                              : unread
                              ? const Icon(
                                  Icons.circle,
                                  size: 10,
                                  color: AppColors.green,
                                )
                              : null,
                        ),
                      );
                    },
                  ),
          ),
  );
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.retry});
  final String message;
  final VoidCallback retry;
  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.cloud_off, size: 54),
        const SizedBox(height: 12),
        Text(message),
        const SizedBox(height: 12),
        ElevatedButton(onPressed: retry, child: const Text('REINTENTAR')),
      ],
    ),
  );
}

IconData _icon(String? type) => switch (type) {
  'SEARCH_MATCH' => Icons.travel_explore,
  'BOOKING_REQUEST' => Icons.person_add_alt,
  'BOOKING_ACCEPTED' => Icons.check_circle_outline,
  'BOOKING_REJECTED' => Icons.cancel_outlined,
  'BOOKING_CANCELLED' => Icons.event_busy_outlined,
  'TRIP_STARTED' => Icons.play_circle_outline,
  'TRIP_COMPLETED' => Icons.flag_outlined,
  'NO_SHOW' => Icons.person_off_outlined,
  'CHAT_MESSAGE' => Icons.chat_bubble_outline,
  _ => Icons.notifications_none,
};

String _relativeDate(dynamic value) {
  final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
  if (date == null) return '';
  final difference = DateTime.now().difference(date);
  if (difference.inMinutes < 1) return 'Ahora';
  if (difference.inHours < 1) return 'Hace ${difference.inMinutes} min';
  if (difference.inDays < 1) return 'Hace ${difference.inHours} h';
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}
