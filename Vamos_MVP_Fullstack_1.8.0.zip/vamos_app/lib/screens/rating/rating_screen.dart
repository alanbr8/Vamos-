import 'package:flutter/material.dart';

import '../../core/routes/app_routes.dart';
import '../../core/theme/app_theme.dart';
import '../../services/api_client.dart';
import '../../widgets/star_selector.dart';

class RatingScreen extends StatefulWidget {
  const RatingScreen({
    super.key,
    this.tripId,
    this.toUserId,
    this.toUserName = 'otro viajero',
    this.rateDriving = false,
  });

  final String? tripId;
  final String? toUserId;
  final String toUserName;
  final bool rateDriving;

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int overall = 0;
  final categories = <String, int>{
    'Puntualidad': 0,
    'Amabilidad': 0,
    'Respeto y seguridad': 0,
  };
  final comment = TextEditingController();
  bool submitted = false;
  bool submitting = false;

  @override
  void initState() {
    super.initState();
    if (widget.rateDriving) categories['Conducción'] = 0;
  }

  @override
  void dispose() {
    comment.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (overall == 0 || categories.values.any((rating) => rating == 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa todas las calificaciones')),
      );
      return;
    }
    if (widget.tripId == null || widget.toUserId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Abre un viaje completado para enviar una calificación real'),
      ));
      return;
    }
    setState(() => submitting = true);
    try {
      await ApiClient.instance.createRating({
        'tripId': widget.tripId,
        'toUserId': widget.toUserId,
        'overall': overall,
        'punctuality': categories['Puntualidad'],
        'kindness': categories['Amabilidad'],
        'safety': categories['Respeto y seguridad'],
        if (widget.rateDriving) 'driving': categories['Conducción'],
        if (comment.text.trim().isNotEmpty) 'comment': comment.text.trim(),
      });
      if (mounted) setState(() => submitted = true);
    } on ApiException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (submitted) return const RatingSuccessScreen();
    return Scaffold(
      appBar: AppBar(title: const Text('Calificar viaje')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Center(child: CircleAvatar(radius: 38, child: Text('M', style: TextStyle(fontSize: 30)))),
          const SizedBox(height: 10),
          Text('¿Cómo fue viajar con ${widget.toUserName}?', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 6),
          const Text('Tu opinión ayuda a construir una comunidad confiable.', textAlign: TextAlign.center),
          const SizedBox(height: 18),
          StarSelector(value: overall, size: 42, onChanged: (value) => setState(() => overall = value)),
          Center(child: Text(overallLabel(overall), style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.green))),
          const SizedBox(height: 24),
          ...categories.keys.map((name) => RatingCategory(
                name: name,
                value: categories[name]!,
                onChanged: (value) => setState(() => categories[name] = value),
              )),
          const SizedBox(height: 12),
          TextField(
            controller: comment,
            maxLines: 4,
            maxLength: 300,
            decoration: const InputDecoration(labelText: 'Comentario opcional', hintText: 'Cuéntanos algo útil y respetuoso'),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: submitting ? null : submit,
            child: Text(submitting ? 'ENVIANDO…' : 'ENVIAR CALIFICACIÓN'),
          ),
          const SizedBox(height: 8),
          const Text('Las calificaciones se publicarán sin mostrar datos sensibles del viaje.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}

class RatingCategory extends StatelessWidget {
  const RatingCategory({super.key, required this.name, required this.value, required this.onChanged});
  final String name;
  final int value;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
            StarSelector(value: value, size: 28, onChanged: onChanged),
          ]),
        ),
      );
}

class RatingSuccessScreen extends StatelessWidget {
  const RatingSuccessScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.star_rounded, size: 96, color: Colors.amber),
              Text('¡Gracias por calificar!', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              const Text('Tu opinión fue registrada y ayudará a futuros viajeros.', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: () => Navigator.pushNamedAndRemoveUntil(context, AppRoutes.home, (_) => false), child: const Text('VOLVER AL INICIO')),
            ]),
          ),
        ),
      );
}

String overallLabel(int value) => switch (value) {
      1 => 'Muy mala experiencia',
      2 => 'Podría mejorar',
      3 => 'Buena experiencia',
      4 => 'Muy buena experiencia',
      5 => '¡Excelente experiencia!',
      _ => 'Selecciona una calificación',
    };
