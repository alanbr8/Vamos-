import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../core/theme/app_theme.dart';
import '../../models/map_point.dart';
import '../../services/location_service.dart';

class LocationPickerScreen extends StatefulWidget {
  const LocationPickerScreen({
    super.key,
    required this.title,
    this.initialPoint,
    this.routePoints = const [],
  });
  final String title;
  final MapPoint? initialPoint;
  final List<MapPoint> routePoints;

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  final controller = MapController();
  MapPoint? selected;
  bool locating = false;
  static const santaCruz = LatLng(-17.7833, -63.1821);

  @override
  void initState() {
    super.initState();
    selected = widget.initialPoint;
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> useCurrentLocation() async {
    setState(() => locating = true);
    try {
      final point = await LocationService.currentPosition();
      if (!mounted) return;
      setState(() => selected = point);
      controller.move(LatLng(point.latitude, point.longitude), 16);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error.toString().replaceFirst('Exception: ', '')),
          ),
        );
    } finally {
      if (mounted) setState(() => locating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final initial = widget.initialPoint == null
        ? santaCruz
        : LatLng(widget.initialPoint!.latitude, widget.initialPoint!.longitude);
    final route = widget.routePoints
        .map((point) => LatLng(point.latitude, point.longitude))
        .toList();
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(
        children: [
          FlutterMap(
            mapController: controller,
            options: MapOptions(
              initialCenter: initial,
              initialZoom: 13,
              onTap: (_, point) => setState(
                () => selected = MapPoint(
                  latitude: point.latitude,
                  longitude: point.longitude,
                  label: 'Punto seleccionado',
                ),
              ),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.vamoscarpool.app',
              ),
              if (route.length > 1)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: route,
                      color: AppColors.green,
                      strokeWidth: 5,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  ...widget.routePoints.map(
                    (point) => Marker(
                      point: LatLng(point.latitude, point.longitude),
                      width: 44,
                      height: 44,
                      child: const Icon(
                        Icons.circle,
                        color: AppColors.green,
                        size: 18,
                      ),
                    ),
                  ),
                  if (selected != null)
                    Marker(
                      point: LatLng(selected!.latitude, selected!.longitude),
                      width: 54,
                      height: 54,
                      child: const Icon(
                        Icons.location_pin,
                        color: Colors.red,
                        size: 48,
                      ),
                    ),
                ],
              ),
            ],
          ),
          Positioned(
            left: 8,
            bottom: 82,
            child: Container(
              color: Colors.white.withValues(alpha: .9),
              padding: const EdgeInsets.all(4),
              child: const Text(
                '© OpenStreetMap contributors',
                style: TextStyle(fontSize: 11),
              ),
            ),
          ),
          Positioned(
            right: 16,
            top: 16,
            child: FloatingActionButton.small(
              onPressed: locating ? null : useCurrentLocation,
              child: locating
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.my_location),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: ElevatedButton(
              onPressed: selected == null
                  ? null
                  : () => Navigator.pop(context, selected),
              child: const Text('CONFIRMAR PUNTO'),
            ),
          ),
        ],
      ),
    );
  }
}
