import '../../services/session_store.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../services/api_client.dart';

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({super.key, this.vehicleId, this.driver});
  final bool? driver;
  final String? vehicleId;
  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}
class _VerificationScreenState extends State<VerificationScreen> {
  static const labels = {
    'CI_FRONT':'Carnet · anverso', 'CI_BACK':'Carnet · reverso',
    'SELFIE':'Selfie tomada con la cámara',
    'LICENSE_FRONT':'Licencia · anverso', 'LICENSE_BACK':'Licencia · reverso',
    'VEHICLE_FRONT':'Vehículo de frente, con placa visible',
    'VEHICLE_SIDE':'Vehículo de costado', 'SOAT':'SOAT vigente',
  };
  List<Map<String,dynamic>> docs = [];
  bool busy = false;
  String? error;
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    setState(() { busy = true; error = null; });
    try {
      final rows = await ApiClient.instance.documents();
      if (mounted) setState(() => docs = rows.map((r) => Map<String,dynamic>.from(r as Map)).toList());
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<bool> confirm(String title, String text) async => await showDialog<bool>(
    context: context, builder: (c) => AlertDialog(title: Text(title),content: Text(text),actions: [
      TextButton(onPressed: () => Navigator.pop(c,false), child: const Text('Cancelar')),
      FilledButton(onPressed: () => Navigator.pop(c,true), child: const Text('Continuar')),
    ])) ?? false;
  Future<void> upload(String kind) async {
    if (!await confirm('Revisión de documentos', 'Autorizo el uso de esta foto para revisar mi identidad o habilitar mis viajes. Se almacena cifrada y solo mi cuenta y los administradores pueden consultarla. Puedo eliminarla aquí; eso impedirá publicar hasta completar la revisión. Esta revisión es manual.')) return;
    if (!mounted) return;
    ImageSource? source = ImageSource.camera;
    if (kind != 'SELFIE') {
      source = await showModalBottomSheet<ImageSource>(context: context,builder: (c) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min,children: [
        ListTile(leading: const Icon(Icons.camera_alt),title: const Text('Tomar foto'),onTap: () => Navigator.pop(c,ImageSource.camera)),
        ListTile(leading: const Icon(Icons.photo_library),title: const Text('Elegir foto JPG o PNG'),onTap: () => Navigator.pop(c,ImageSource.gallery)),
      ])));
    }
    if (source == null || !mounted) return;
    setState(() { busy = true; error = null; });
    XFile? file;
    try {
      file = await ImagePicker().pickImage(source: source,preferredCameraDevice: kind == 'SELFIE' ? CameraDevice.front : CameraDevice.rear,maxWidth:1600,maxHeight:1600,imageQuality:75,requestFullMetadata:false);
      if (file == null || !mounted) return;
      final bytes = await file.readAsBytes();
      if (bytes.length > 1048576) throw const ApiException('La foto supera 1 MB. Toma otra foto o elige una más pequeña.');
      if (!mounted) return;
      final accepted = await showDialog<bool>(context: context,builder: (c) => AlertDialog(
        title: Text(labels[kind]!), content: SingleChildScrollView(child: Column(mainAxisSize:MainAxisSize.min,children:[
          Image.memory(bytes, height:280,fit:BoxFit.contain,errorBuilder: (_,e,st) => const Text('Formato no compatible. Usa JPG o PNG.')),
          const Text('Comprueba que la imagen sea nítida, completa y corresponda a este documento.'),
        ])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Volver')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Enviar a revisión'))]));
      if (accepted != true || !mounted) return;
      String? expiration;
      if (kind.startsWith('LICENSE_') || kind == 'SOAT') {
        final now = DateTime.now();
        final date = await showDatePicker(context:context,helpText:'Vencimiento que figura en el documento',initialDate:now,firstDate:DateTime(now.year,now.month,now.day),lastDate:DateTime(now.year+20,12,31));
        if (date == null || !mounted) return;
        expiration = '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
      }
      await ApiClient.instance.uploadDocument({
        'kind':kind, 'base64':base64Encode(bytes), 'consent':true,
        if (widget.vehicleId != null) 'vehicleId':widget.vehicleId,
        if (expiration != null) 'expiresOn':expiration,
      });
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Documento enviado a revisión'))); await load(); }
    } catch (e) { if (mounted) setState(() => error = e is ApiException ? e.message : 'No se pudo cargar la foto. Revisa los permisos de cámara y fotos e intenta nuevamente.'); }
    finally {
      // Solo elimina la copia temporal de cámara creada por el selector.
      if (source == ImageSource.camera && file != null) { try { await File(file.path).delete(); } catch (_) {} }
      if (mounted) setState(() => busy = false);
    }
  }
  Future<void> view(Map<String,dynamic> doc) async {
    setState(() => busy = true);
    try {
      final data = await ApiClient.instance.documentImage(doc['id'] as String);
      if (!mounted) return;
      await showDialog<void>(context:context,builder:(c)=>AlertDialog(title:Text(labels[doc['kind']] ?? 'Documento'),content:Image.memory(base64Decode(data['base64'] as String)),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cerrar'))]));
    } catch (e) { if(mounted)setState(()=>error=e.toString()); }
    finally {if(mounted)setState(()=>busy=false);}
  }
  Future<void> remove(Map<String,dynamic> doc) async {
    if (!await confirm('Eliminar documento','Se eliminará la foto guardada. Tendrás que cargarla y obtener aprobación otra vez para ofrecer viajes.')) return;
    if (!mounted) return;
    setState(()=>busy=true);
    try { await ApiClient.instance.deleteDocument(doc['id'] as String); if(mounted)await load(); }
    catch(e) {if(mounted)setState(()=>error=e.toString());}
    finally {if(mounted)setState(()=>busy=false);}
  }
  @override
  Widget build(BuildContext context) {
    final isDriver = widget.driver ?? (SessionStore.instance.user?['usageMode'] == 'DRIVER');
    final kinds = widget.vehicleId == null ? ['CI_FRONT','CI_BACK','SELFIE', if(isDriver) ...['LICENSE_FRONT','LICENSE_BACK']] : ['VEHICLE_FRONT','VEHICLE_SIDE','SOAT'];
    return Scaffold(appBar:AppBar(title:Text(widget.vehicleId == null ? (isDriver ? 'Identidad y licencia' : 'Mi identidad') : 'Documentos del vehículo'),actions:[IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))]),body:ListView(padding:const EdgeInsets.all(20),children:[
      const Text('Puedes completar los documentos por etapas. Para ofrecer viajes, todos los documentos requeridos deben estar aprobados y vigentes, y el administrador debe aprobar el vehículo.'),
      if(widget.vehicleId == null) const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('Identidad: carnet por ambos lados y selfie. La licencia por ambos lados es necesaria si vas a conducir. No se realiza validación biométrica automática.')),
      if(busy)const LinearProgressIndicator(),
      if(error != null)Padding(padding:const EdgeInsets.all(12),child:Text(error!,style:TextStyle(color:Theme.of(context).colorScheme.error))),
      ...kinds.map((kind){
        final matches=docs.where((d)=>d['kind']==kind && d['vehicleId']==widget.vehicleId);
        final doc=matches.isEmpty?null:matches.first;
        final expires=doc?['expiresOn']?.toString();
        final today=DateTime.now();
        final expired=expires != null && DateTime.parse(expires).isBefore(DateTime(today.year,today.month,today.day));
        final status=doc == null?'Sin cargar':expired?'Vencido':({'PENDING':'En revisión','APPROVED':'Aprobado','REJECTED':'Rechazado'}[doc['status']] ?? 'En revisión');
        return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(labels[kind]!,style:Theme.of(context).textTheme.titleMedium),Text(status),
          if(expires != null)Text('Vence: $expires'),if(doc?['reason'] != null)Text('Motivo: ${doc!['reason']}'),
          Wrap(spacing:8,children:[
            FilledButton.tonal(onPressed:busy?null:()=>upload(kind),child:Text(doc == null?'Cargar':'Reemplazar')),
            if(doc != null)TextButton(onPressed:busy?null:()=>view(doc),child:const Text('Ver')),
            if(doc != null)TextButton(onPressed:busy?null:()=>remove(doc),child:const Text('Eliminar')),
          ]),
        ])));
      }),
      TextButton(onPressed:busy?null:()=>Navigator.pop(context),child:const Text('Completar más tarde')),
      if(widget.vehicleId != null)TextButton(onPressed:busy?null:()=>Navigator.push(context,MaterialPageRoute<void>(builder:(_)=>const VerificationScreen())),child:const Text('Completar identidad y licencia')),
    ]));
  }
}
