# Sesión y recuperación de contraseña

## Sesión móvil

El token JWT y los datos mínimos del usuario se guardan con
`flutter_secure_storage`. Ejecuta `flutter pub get` después de generar las
carpetas nativas. La aplicación elimina el token local al cerrar sesión o al
detectar que su fecha `exp` venció.

## Recuperación local sin correo

1. Aplica `database/migrations/002_password_reset.sql` si conservas un volumen
   de base de datos creado antes de la versión 1.3.0.
2. En `backend/.env`, usa `PASSWORD_RESET_RETURN_TOKEN=true`.
3. Desde “¿Olvidaste tu contraseña?”, solicita la recuperación.
4. La aplicación completará automáticamente el token devuelto por la API.

## Antes de producción

- Configura `PASSWORD_RESET_RETURN_TOKEN=false`.
- Integra un proveedor de correo transaccional para enviar el enlace.
- Añade límites de frecuencia por IP y cuenta.
- Usa HTTPS y un `JWT_SECRET` largo y aleatorio.
- Implementa revocación o rotación de sesiones si se requiere cerrar otros
  dispositivos desde el servidor.
