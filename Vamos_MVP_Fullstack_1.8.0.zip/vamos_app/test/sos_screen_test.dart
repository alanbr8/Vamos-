import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/screens/safety/sos_screen.dart';
import 'package:vamos_app/services/session_store.dart';

void main() {
  testWidgets('El contacto se aísla por cuenta y un teléfono inválido no se guarda', (tester) async {
    FlutterSecureStorage.setMockInitialValues({
      'vamos_emergency_a': '{"name":"Contacto A","phone":"+59170000001"}',
    });
    SessionStore.instance.user = {'id': 'a'};
    await tester.pumpWidget(const MaterialApp(home: SosScreen()));
    await tester.pumpAndSettle();
    expect(find.text('Contacto A'), findsOneWidget);
    // Desmontar evita reutilizar el estado de la cuenta anterior.
    await tester.pumpWidget(const SizedBox());
    SessionStore.instance.user = {'id': 'b'};
    await tester.pumpWidget(const MaterialApp(home: SosScreen()));
    await tester.pumpAndSettle();
    expect(find.text('Contacto A'), findsNothing);
    await tester.enterText(find.byType(TextField).first, 'Contacto B');
    await tester.enterText(find.byType(TextField).last, '*123#');
    await tester.ensureVisible(find.text('GUARDAR CONTACTO'));
    await tester.tap(find.text('GUARDAR CONTACTO'));
    await tester.pumpAndSettle();
    expect(await const FlutterSecureStorage().read(key: 'vamos_emergency_b'), isNull);
    await tester.enterText(find.byType(TextField).last, '+59170000002');
    await tester.ensureVisible(find.text('GUARDAR CONTACTO'));
    await tester.tap(find.text('GUARDAR CONTACTO'));
    await tester.pumpAndSettle();
    expect(await const FlutterSecureStorage().read(key: 'vamos_emergency_b'), contains('Contacto B'));
    expect(await const FlutterSecureStorage().read(key: 'vamos_emergency_a'), contains('Contacto A'));
    await tester.pumpWidget(const SizedBox());
    SessionStore.instance.user = null;
  });
}
