import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/services/api_client.dart';

void main() {
  late HttpServer server;
  late ApiClient api;
  setUp(() async {
    server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    api = ApiClient.forTesting(
      baseUrl: 'http://127.0.0.1:${server.port}',
      requestTimeout: const Duration(milliseconds: 100),
    );
  });
  tearDown(() async {
    api.close();
    await server.close(force: true);
  });
  test(
    'una página HTML de error conserva el estado 503 y permite reintentar',
    () async {
      server.listen((request) {
        request.response.statusCode = 503;
        request.response.write('<html>Service unavailable</html>');
        request.response.close();
      });
      await expectLater(
        api.forgotPassword('test@example.invalid'),
        throwsA(
          isA<ApiException>()
              .having((e) => e.statusCode, 'statusCode', 503)
              .having(
                (e) => e.message,
                'message',
                contains('no está disponible'),
              ),
        ),
      );
    },
  );
  test('una respuesta que no llega termina con un error visible', () async {
    server.listen((request) {});
    await expectLater(
      api.forgotPassword('test@example.invalid'),
      throwsA(
        isA<ApiException>().having(
          (e) => e.message,
          'message',
          contains('tardando demasiado'),
        ),
      ),
    );
  });
  test('muestra el error de validación que devuelve el servidor', () async {
    server.listen((request) {
      request.response.statusCode = 400;
      request.response.headers.contentType = ContentType.json;
      request.response.write('{"message":["Correo inválido"]}');
      request.response.close();
    });
    await expectLater(
      api.forgotPassword('invalid'),
      throwsA(
        isA<ApiException>().having(
          (e) => e.message,
          'message',
          'Correo inválido',
        ),
      ),
    );
  });
}
