import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/widgets/encounter_code_dialog.dart';

void main() {
  for (final confirm in [true, false]) {
    testWidgets('Cerrar encuentro con teclado activo: confirmar=$confirm', (tester) async {
      String? result;
      await tester.pumpWidget(MaterialApp(home: Builder(builder: (context) =>
        Scaffold(body: TextButton(onPressed: () async {
          result = await showDialog<String>(context: context,
            builder: (_) => const EncounterCodeDialog(passenger: 'Prueba'));
        }, child: const Text('Abrir'))))));
      // Reabrir comprueba que no quedan controladores ni rutas dañadas.
      for (var i = 0; i < 2; i++) {
        await tester.tap(find.text('Abrir'));
        await tester.pumpAndSettle();
        expect(tester.widget<FilledButton>(find.byType(FilledButton)).onPressed, isNull);
        await tester.enterText(find.byType(TextField), '012345');
        await tester.pump();
        await tester.tap(find.text(confirm ? 'Confirmar' : 'Cancelar'));
        await tester.pump();
        expect(tester.takeException(), isNull);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
        expect(find.byType(EncounterCodeDialog), findsNothing);
        expect(result, confirm ? '012345' : isNull);
      }
    });
  }
}
