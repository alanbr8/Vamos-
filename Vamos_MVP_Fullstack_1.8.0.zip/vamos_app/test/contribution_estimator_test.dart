import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/services/contribution_estimator.dart';

void main() {
  test('50 km, 20% desgaste, 10 Bs peaje, conductor y 3 pasajeros', () {
    final estimate = ContributionEstimator.calculate(
      kilometers: 50, wearPercent: 20, tolls: 10, passengers: 3)!;
    expect(estimate.fuel, 35);
    expect(estimate.wear, 7);
    expect(estimate.total, 52);
    expect(estimate.perPerson, 13);
  });
  test('sin desgaste ni peaje, el conductor comparte el gasto', () {
    final estimate = ContributionEstimator.calculate(
      kilometers: 10, wearPercent: 0, tolls: 0, passengers: 1)!;
    expect(estimate.perPerson, 3.5);
  });
  test('más kilómetros elevan la sugerencia sin alterar el reparto', () {
    final short = ContributionEstimator.calculate(
      kilometers: 10, wearPercent: 20, tolls: 0, passengers: 3)!;
    final long = ContributionEstimator.calculate(
      kilometers: 20, wearPercent: 20, tolls: 0, passengers: 3)!;
    expect(long.perPerson, closeTo(short.perPerson * 2, 0.000001));
  });
  test('rechaza distancias y cantidades no válidas', () {
    for (final km in [0.0, -1.0, double.nan, double.infinity]) {
      expect(ContributionEstimator.calculate(kilometers: km,
        wearPercent: 20, tolls: 0, passengers: 3), isNull);
    }
    expect(ContributionEstimator.calculate(kilometers: 10,
      wearPercent: 101, tolls: 0, passengers: 3), isNull);
    expect(ContributionEstimator.calculate(kilometers: 10,
      wearPercent: 20, tolls: -1, passengers: 3), isNull);
    expect(ContributionEstimator.calculate(kilometers: 10,
      wearPercent: 20, tolls: 0, passengers: 0), isNull);
  });
}
