import 'package:flutter_test/flutter_test.dart';
import 'package:vamos_app/models/map_point.dart';
import 'package:vamos_app/services/trip_payload_builder.dart';

void main() {
  test(
    'el contrato conserva el instante con zona horaria y el orden GeoJSON',
    () {
      final departure = DateTime.parse('2030-01-02T07:00:00-04:00');
      final payload = TripPayloadBuilder.build(
        vehicleId: 'vehicle',
        originLabel: 'A',
        origin: const MapPoint(latitude: -17.78, longitude: -63.18, label: 'A'),
        destinationLabel: 'B',
        destination: const MapPoint(
          latitude: -17.70,
          longitude: -63.10,
          label: 'B',
        ),
        departure: departure,
        availableSeats: 1,
        contribution: 8,
      );
      expect(payload['departureAt'], '2030-01-02T11:00:00.000Z');
      expect(payload['route'], [
        [-63.18, -17.78],
        [-63.10, -17.70],
      ]);
    },
  );
}
