CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TYPE user_status AS ENUM ('ACTIVE', 'SUSPENDED', 'BLOCKED');
CREATE TYPE user_role AS ENUM ('USER', 'ADMIN');
CREATE TYPE verification_status AS ENUM ('DRAFT', 'PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED');
CREATE TYPE trip_status AS ENUM ('DRAFT', 'PUBLISHED', 'RESERVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
CREATE TYPE booking_status AS ENUM ('PENDING', 'ACCEPTED', 'REJECTED', 'CANCELLED', 'NO_SHOW', 'COMPLETED');
CREATE TYPE incident_status AS ENUM ('RECEIVED', 'REVIEWING', 'RESOLVED', 'DISMISSED');

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name varchar(80) NOT NULL,
  last_name varchar(80) NOT NULL,
  email varchar(180) UNIQUE NOT NULL,
  phone varchar(30) UNIQUE NOT NULL,
  password_hash text NOT NULL,
  photo_url text,
  status user_status NOT NULL DEFAULT 'ACTIVE',
  role user_role NOT NULL DEFAULT 'USER',
  identity_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES users(id),
  brand varchar(50) NOT NULL,
  model varchar(50) NOT NULL,
  year smallint NOT NULL CHECK (year BETWEEN 1950 AND 2100),
  color varchar(30) NOT NULL,
  license_plate varchar(20) UNIQUE NOT NULL,
  passenger_seats smallint NOT NULL CHECK (passenger_seats BETWEEN 1 AND 7),
  front_photo_url text,
  side_photo_url text,
  document_url text,
  verification_status verification_status NOT NULL DEFAULT 'PENDING',
  rejection_reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES users(id),
  vehicle_id uuid NOT NULL REFERENCES vehicles(id),
  origin_label text NOT NULL,
  origin geography(Point, 4326) NOT NULL,
  destination_label text NOT NULL,
  destination geography(Point, 4326) NOT NULL,
  route geography(LineString, 4326) NOT NULL,
  departure_at timestamptz NOT NULL,
  available_seats smallint NOT NULL CHECK (available_seats BETWEEN 1 AND 7),
  contribution numeric(8,2) NOT NULL CHECK (contribution >= 0),
  recurring_days smallint[] NOT NULL DEFAULT '{}',
  preferences jsonb NOT NULL DEFAULT '{}',
  status trip_status NOT NULL DEFAULT 'PUBLISHED',
  meeting_code char(4) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id),
  passenger_id uuid NOT NULL REFERENCES users(id),
  seats smallint NOT NULL DEFAULT 1 CHECK (seats > 0),
  meeting_point_label text,
  meeting_point geography(Point, 4326),
  status booking_status NOT NULL DEFAULT 'PENDING',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, passenger_id)
);

CREATE TABLE ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES trips(id),
  from_user_id uuid NOT NULL REFERENCES users(id),
  to_user_id uuid NOT NULL REFERENCES users(id),
  overall smallint NOT NULL CHECK (overall BETWEEN 1 AND 5),
  punctuality smallint CHECK (punctuality BETWEEN 1 AND 5),
  kindness smallint CHECK (kindness BETWEEN 1 AND 5),
  safety smallint CHECK (safety BETWEEN 1 AND 5),
  driving smallint CHECK (driving BETWEEN 1 AND 5),
  comment varchar(300),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, from_user_id, to_user_id)
);

CREATE TABLE incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid REFERENCES trips(id),
  reporter_id uuid NOT NULL REFERENCES users(id),
  reported_user_id uuid REFERENCES users(id),
  type varchar(50) NOT NULL,
  description text NOT NULL,
  status incident_status NOT NULL DEFAULT 'RECEIVED',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE emergency_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES users(id),
  name varchar(120) NOT NULL,
  phone varchar(30) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash char(64) UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type varchar(50) NOT NULL,
  title varchar(140) NOT NULL,
  body text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id),
  recipient_id uuid NOT NULL REFERENCES users(id),
  body varchar(1000) NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 1000),
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (sender_id <> recipient_id)
);

CREATE TABLE admin_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL REFERENCES users(id),
  action varchar(80) NOT NULL,
  entity_type varchar(40) NOT NULL,
  entity_id uuid NOT NULL,
  previous_data jsonb NOT NULL DEFAULT '{}',
  new_data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX trips_origin_gix ON trips USING GIST (origin);
CREATE INDEX trips_destination_gix ON trips USING GIST (destination);
CREATE INDEX trips_route_gix ON trips USING GIST (route);
CREATE INDEX bookings_meeting_point_gix ON bookings USING GIST (meeting_point);
CREATE INDEX trips_departure_status_idx ON trips (departure_at, status);
CREATE INDEX bookings_trip_status_idx ON bookings (trip_id, status);
CREATE INDEX password_reset_user_idx ON password_reset_tokens (user_id, expires_at DESC);
CREATE INDEX notifications_user_created_idx ON notifications (user_id, created_at DESC);
CREATE INDEX notifications_unread_idx ON notifications (user_id) WHERE read_at IS NULL;
CREATE INDEX messages_booking_created_idx ON messages (booking_id, created_at);
CREATE INDEX messages_recipient_unread_idx ON messages (recipient_id) WHERE read_at IS NULL;
CREATE INDEX admin_audit_created_idx ON admin_audit_logs (created_at DESC);
CREATE INDEX admin_audit_entity_idx ON admin_audit_logs (entity_type, entity_id);
