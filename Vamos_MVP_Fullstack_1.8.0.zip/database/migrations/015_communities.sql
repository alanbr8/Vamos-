CREATE TABLE IF NOT EXISTS communities (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES users(id),
 name varchar(80) NOT NULL, description varchar(500) NOT NULL DEFAULT '',
 category varchar(20) NOT NULL CHECK(category IN ('GENERAL','WOMEN','COMPANY','NEIGHBORHOOD','RESIDENTIAL','SCHOOL')),
 invite_code varchar(32) NOT NULL UNIQUE, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS community_members (
 community_id uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id), status varchar(12) NOT NULL CHECK(status IN ('PENDING','APPROVED','REJECTED')),
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(community_id,user_id)
);
ALTER TABLE trips ADD COLUMN IF NOT EXISTS community_id uuid REFERENCES communities(id);
CREATE INDEX IF NOT EXISTS trips_community_idx ON trips(community_id,departure_at);
CREATE INDEX IF NOT EXISTS community_members_user_idx ON community_members(user_id,status);
CREATE OR REPLACE FUNCTION vamos_community_access(cid uuid,uid uuid) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT cid IS NULL OR EXISTS(SELECT 1 FROM community_members m JOIN communities c ON c.id=m.community_id JOIN users u ON u.id=c.owner_id
 WHERE m.community_id=cid AND m.user_id=uid AND m.status='APPROVED' AND u.status='ACTIVE');
$$;
