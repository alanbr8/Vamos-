BEGIN;
CREATE TABLE IF NOT EXISTS verification_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL REFERENCES users(id),
 vehicle_id uuid REFERENCES vehicles(id),
 kind varchar(24) NOT NULL CHECK (kind IN ('CI_FRONT','CI_BACK','SELFIE','LICENSE_FRONT','LICENSE_BACK','VEHICLE_FRONT','VEHICLE_SIDE','SOAT')),
 ciphertext bytea NOT NULL,
 iv bytea NOT NULL,
 tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK (mime IN ('image/jpeg','image/png')),
 expires_on date,
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED')),
 reason varchar(300),
 version integer NOT NULL DEFAULT 1,
 consent_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 reviewed_by uuid REFERENCES users(id),
 reviewed_at timestamptz,
 CHECK ((kind IN ('VEHICLE_FRONT','VEHICLE_SIDE','SOAT')) = (vehicle_id IS NOT NULL)),
 CHECK (kind NOT IN ('LICENSE_FRONT','LICENSE_BACK','SOAT') OR expires_on IS NOT NULL),
 CHECK (octet_length(ciphertext) BETWEEN 1 AND 1048576)
);
CREATE UNIQUE INDEX IF NOT EXISTS verification_person_kind ON verification_documents(owner_id,kind) WHERE vehicle_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS verification_vehicle_kind ON verification_documents(vehicle_id,kind) WHERE vehicle_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS verification_review_status ON verification_documents(status,updated_at);
CREATE OR REPLACE FUNCTION vamos_identity_ready(person uuid, day date) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT count(*)=3 FROM verification_documents WHERE owner_id=person AND vehicle_id IS NULL
 AND kind IN ('CI_FRONT','CI_BACK','SELFIE') AND status='APPROVED' AND (expires_on IS NULL OR expires_on>=day)
$$;
CREATE OR REPLACE FUNCTION vamos_documents_ready(person uuid, car uuid, day date) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT vamos_identity_ready(person,day)
 AND (SELECT count(*)=2 FROM verification_documents WHERE owner_id=person AND vehicle_id IS NULL
 AND kind IN ('LICENSE_FRONT','LICENSE_BACK') AND status='APPROVED' AND expires_on>=day)
 AND (SELECT count(*)=3 FROM verification_documents WHERE owner_id=person AND vehicle_id=car
 AND kind IN ('VEHICLE_FRONT','VEHICLE_SIDE','SOAT') AND status='APPROVED' AND (expires_on IS NULL OR expires_on>=day))
$$;
COMMIT;
