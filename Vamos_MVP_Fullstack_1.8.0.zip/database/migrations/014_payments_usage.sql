-- Preferencia de uso; no altera permisos administrativos ni aprobaciones.
ALTER TABLE users ADD COLUMN IF NOT EXISTS usage_mode varchar(12) NOT NULL DEFAULT 'PASSENGER' CHECK (usage_mode IN ('PASSENGER','DRIVER'));
UPDATE users SET usage_mode='DRIVER' WHERE EXISTS(SELECT 1 FROM vehicles v WHERE v.owner_id=users.id);
CREATE TABLE IF NOT EXISTS payment_qrs (
 owner_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 ciphertext bytea NOT NULL, iv bytea NOT NULL, tag bytea NOT NULL, mime varchar(30) NOT NULL,
 updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_method varchar(8) NOT NULL DEFAULT 'CASH' CHECK(payment_method IN ('CASH','QR'));
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_confirmed_at timestamptz;
