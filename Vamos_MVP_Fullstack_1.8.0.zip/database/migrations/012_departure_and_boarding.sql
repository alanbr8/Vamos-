BEGIN;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS route_departed_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_code varchar(6) NOT NULL DEFAULT lpad(floor(random()*1000000)::int::text,6,'0');
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_verified_at timestamptz;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_failures integer NOT NULL DEFAULT 0;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS encounter_locked_until timestamptz;
COMMIT;
