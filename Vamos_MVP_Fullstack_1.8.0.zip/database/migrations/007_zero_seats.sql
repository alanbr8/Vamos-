-- Permite aceptar el último asiento. No modifica reservas ni usuarios.
BEGIN;
ALTER TABLE trips DROP CONSTRAINT IF EXISTS trips_available_seats_check;
ALTER TABLE trips ADD CONSTRAINT trips_available_seats_check
  CHECK (available_seats BETWEEN 0 AND 7);
COMMIT;
