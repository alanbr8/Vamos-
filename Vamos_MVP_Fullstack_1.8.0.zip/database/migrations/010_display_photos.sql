BEGIN;
CREATE TABLE IF NOT EXISTS display_photos (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL REFERENCES users(id),
 vehicle_id uuid REFERENCES vehicles(id),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 1048576),
 iv bytea NOT NULL, tag bytea NOT NULL,
 mime varchar(20) NOT NULL CHECK(mime IN ('image/jpeg','image/png')),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS display_profile_unique ON display_photos(owner_id) WHERE vehicle_id IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS display_vehicle_unique ON display_photos(vehicle_id) WHERE vehicle_id IS NOT NULL;
COMMIT;
