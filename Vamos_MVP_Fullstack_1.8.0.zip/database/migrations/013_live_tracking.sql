BEGIN;
ALTER TABLE trips ADD COLUMN IF NOT EXISTS tracking_enabled boolean NOT NULL DEFAULT false;
CREATE TABLE IF NOT EXISTS trip_live_positions (
 trip_id uuid PRIMARY KEY REFERENCES trips(id) ON DELETE CASCADE,
 latitude double precision NOT NULL CHECK(latitude BETWEEN -90 AND 90),
 longitude double precision NOT NULL CHECK(longitude BETWEEN -180 AND 180),
 accuracy double precision NOT NULL CHECK(accuracy BETWEEN 0 AND 1000),
 recorded_at timestamptz NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS trip_share_links (
 booking_id uuid PRIMARY KEY REFERENCES bookings(id) ON DELETE CASCADE,
 token_hash text UNIQUE NOT NULL,
 expires_at timestamptz NOT NULL
);
CREATE OR REPLACE FUNCTION close_vamos_tracking() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.status IN ('COMPLETED','CANCELLED') THEN
  NEW.tracking_enabled=false;
  DELETE FROM trip_live_positions WHERE trip_id=NEW.id;
  DELETE FROM trip_share_links WHERE booking_id IN (SELECT id FROM bookings WHERE trip_id=NEW.id);
 END IF;
 RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS close_vamos_tracking ON trips;
CREATE TRIGGER close_vamos_tracking BEFORE UPDATE OF status ON trips FOR EACH ROW EXECUTE FUNCTION close_vamos_tracking();
COMMIT;
