BEGIN;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolution_detail varchar(2000);
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolved_at timestamptz;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS resolved_by uuid REFERENCES users(id);
CREATE TABLE IF NOT EXISTS push_devices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES users(id),
 token text UNIQUE NOT NULL,
 binding uuid NOT NULL DEFAULT gen_random_uuid(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS push_devices_user_idx ON push_devices(user_id);
CREATE TABLE IF NOT EXISTS push_deliveries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 notification_id uuid NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
 device_id uuid NOT NULL REFERENCES push_devices(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES users(id),
 binding uuid NOT NULL,
 attempts integer NOT NULL DEFAULT 0,
 status varchar(12) NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','SENT','EXPIRED','FAILED')),
 next_at timestamptz NOT NULL DEFAULT now(),
 expires_at timestamptz NOT NULL,
 last_error varchar(80),
 UNIQUE(notification_id,device_id)
);
CREATE INDEX IF NOT EXISTS push_pending_idx ON push_deliveries(next_at) WHERE status='PENDING';
CREATE OR REPLACE FUNCTION queue_vamos_push() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 INSERT INTO push_deliveries(notification_id,device_id,user_id,binding,expires_at)
 SELECT NEW.id,d.id,NEW.user_id,d.binding,now()+CASE WHEN NEW.type='ROUTE_DEPARTED' THEN interval '15 minutes' ELSE interval '24 hours' END
 FROM push_devices d WHERE d.user_id=NEW.user_id ON CONFLICT DO NOTHING;
 RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS vamos_push_after_notification ON notifications;
CREATE TRIGGER vamos_push_after_notification AFTER INSERT ON notifications FOR EACH ROW EXECUTE FUNCTION queue_vamos_push();
COMMIT;
