CREATE TABLE IF NOT EXISTS saved_searches (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 criteria jsonb NOT NULL,
 origin_label text NOT NULL,
 destination_label text NOT NULL,
 active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id,criteria)
);
CREATE INDEX IF NOT EXISTS saved_searches_user_idx ON saved_searches(user_id);
CREATE TABLE IF NOT EXISTS saved_search_matches (
 search_id uuid NOT NULL REFERENCES saved_searches(id) ON DELETE CASCADE,
 trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
 PRIMARY KEY(search_id,trip_id)
);
