DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('USER', 'ADMIN');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS role user_role NOT NULL DEFAULT 'USER';

CREATE INDEX IF NOT EXISTS users_role_status_idx ON users (role, status);
CREATE INDEX IF NOT EXISTS vehicles_verification_created_idx ON vehicles (verification_status, created_at DESC);
CREATE INDEX IF NOT EXISTS incidents_status_created_idx ON incidents (status, created_at DESC);
