CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES users(id),
  recipient_id uuid NOT NULL REFERENCES users(id),
  body varchar(1000) NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 1000),
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (sender_id <> recipient_id)
);

CREATE INDEX IF NOT EXISTS messages_booking_created_idx
  ON messages (booking_id, created_at);
CREATE INDEX IF NOT EXISTS messages_recipient_unread_idx
  ON messages (recipient_id) WHERE read_at IS NULL;
