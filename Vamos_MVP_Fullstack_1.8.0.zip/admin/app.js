const defaultApi=location.pathname.startsWith('/admin')?`${location.origin}/api/v1`:'http://localhost:3000/api/v1';
const state={token:sessionStorage.getItem('vamosAdminToken'),api:sessionStorage.getItem('vamosApiUrl')||defaultApi,view:'overview'};
const $=id=>document.getElementById(id);
const labels={overview:'Resumen',vehicles:'Vehículos',incidents:'Incidentes',users:'Usuarios',audit:'Auditoría'};
const statusText={PENDING:'Pendiente',VERIFIED:'Aprobado',REJECTED:'Rechazado',SUSPENDED:'Suspendido',BLOCKED:'Bloqueado',ACTIVE:'Activo',RECEIVED:'Recibido',REVIEWING:'En revisión',RESOLVED:'Resuelto',DISMISSED:'Descartado',ADMIN:'Administrador',USER:'Usuario'};

async function request(path,options={}){const response=await fetch(`${state.api}${path}`,{...options,headers:{'Content-Type':'application/json','Authorization':`Bearer ${state.token}`,...options.headers}});let data={};try{data=await response.json()}catch{}if(!response.ok)throw new Error(data.message||`Error ${response.status}`);return data}
function node(tag,text,className){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el}
function badge(status){return node('span',statusText[status]||status,`badge ${status}`)}
function button(text,action,className=''){const el=node('button',text,className);el.type='button';el.addEventListener('click',action);return el}
function emptyRow(cols,text){const tr=node('tr');const td=node('td',text,'empty');td.colSpan=cols;tr.append(td);return tr}
function showMessage(text='',error=false){$('globalMessage').textContent=text;$('globalMessage').classList.toggle('error-state',error)}
function formatDate(value){return new Intl.DateTimeFormat('es',{dateStyle:'medium',timeStyle:'short'}).format(new Date(value))}
function auditAction(value){return ({VEHICLE_STATUS_CHANGED:'Estado de vehículo',INCIDENT_STATUS_CHANGED:'Estado de incidente',USER_STATUS_CHANGED:'Estado de usuario'})[value]||value}

async function login(event){event.preventDefault();$('loginError').textContent='';state.api=$('apiUrl').value.replace(/\/$/,'');try{const auth=await fetch(`${state.api}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:$('email').value,password:$('password').value})});const data=await auth.json();if(!auth.ok)throw new Error(data.message||'No se pudo iniciar sesión');state.token=data.accessToken;await request('/admin/summary');sessionStorage.setItem('vamosAdminToken',state.token);sessionStorage.setItem('vamosApiUrl',state.api);openApp()}catch(error){state.token=null;$('loginError').textContent=error.message==='Forbidden resource'?'Tu cuenta no tiene permisos administrativos.':error.message}}
function logout(){sessionStorage.removeItem('vamosAdminToken');sessionStorage.removeItem('vamosApiUrl');state.token=null;$('appView').hidden=true;$('loginView').hidden=false}
function openApp(){$('loginView').hidden=true;$('appView').hidden=false;setView('overview')}
async function setView(view){state.view=view;document.querySelectorAll('.panel-view').forEach(el=>el.hidden=el.id!==`${view}Panel`);document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.view===view));$('pageTitle').textContent=labels[view];await loadCurrent()}
async function loadCurrent(){showMessage('Actualizando…');try{if(state.view==='overview')await loadSummary();if(state.view==='vehicles')await loadVehicles();if(state.view==='incidents')await loadIncidents();if(state.view==='users')await loadUsers();if(state.view==='audit')await loadAudit();showMessage('Datos actualizados')}catch(error){showMessage(error.message,true);if(/401|Unauthorized/.test(error.message))logout()}}
async function loadAudit(){const rows=await request('/admin/audit-logs');const body=$('auditRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const entity=node('td');entity.append(node('strong',item.entityType),node('small',item.entityId));const change=node('td');change.append(node('small',`${statusText[item.previousData?.status]||item.previousData?.status||'—'} → ${statusText[item.newData?.status]||item.newData?.status||'—'}`));tr.append(node('td',auditAction(item.action)),entity,node('td',item.administrator),node('td',formatDate(item.createdAt)),change);return tr}));if(!rows.length)body.append(emptyRow(5,'Todavía no existen acciones registradas.'))}
async function loadSummary(){const data=await request('/admin/summary');const cards=[['Usuarios',data.users],['Viajes publicados',data.trips],['Vehículos pendientes',data.pendingVehicles],['Incidentes abiertos',data.openIncidents]];$('metrics').replaceChildren(...cards.map(([name,value])=>{const card=node('article',undefined,'metric');card.append(node('p',name),node('strong',String(value)));return card}))}
async function loadVehicles(){const filter=$('vehicleFilter').value;const rows=await request(`/admin/vehicles${filter?`?status=${filter}`:''}`);const body=$('vehicleRows');body.replaceChildren(...rows.map(vehicle=>{const tr=node('tr');const info=node('td');info.append(node('strong',`${vehicle.brand} ${vehicle.model}`),node('small',`${vehicle.year} · ${vehicle.color} · ${vehicle.passengerSeats} asientos`));const owner=node('td');owner.append(node('span',vehicle.owner),node('small',vehicle.email));const actions=node('td',undefined,'actions');if(vehicle.status==='PENDING'){actions.append(button('Aprobar',()=>updateVehicle(vehicle.id,'VERIFIED')),button('Rechazar',()=>rejectVehicle(vehicle.id),'danger'))}else actions.append(node('small','Sin acciones pendientes'));const status=node('td');status.append(badge(vehicle.status));tr.append(info,owner,node('td',vehicle.licensePlate),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay vehículos para este filtro.'))}
const vehicleUpdates=new Set();
async function updateVehicle(id,status,rejectionReason){
  if(vehicleUpdates.has(id))return;
  vehicleUpdates.add(id);
  showMessage('Guardando decisión…');
  try{
    await request(`/admin/vehicles/${id}`,{method:'PATCH',body:JSON.stringify({status,rejectionReason})});
  }catch(error){
    vehicleUpdates.delete(id);
    showMessage(`No se pudo confirmar el cambio: ${error.message}. Actualiza la lista para comprobar el estado antes de reintentar.`,true);
    return;
  }
  try{
    await loadVehicles();
    showMessage(status==='REJECTED'?'Vehículo rechazado. Puedes consultarlo con el filtro Rechazado.':'Vehículo aprobado.');
  }catch(error){showMessage(`La decisión se guardó, pero no se pudo actualizar la lista: ${error.message}. Pulsa Actualizar.`,true);}
  finally{vehicleUpdates.delete(id);}
}
function rejectVehicle(id){
  const reason=prompt('Motivo del rechazo (máximo 300 caracteres):');
  if(reason===null)return;
  if(!reason.trim()){showMessage('Escribe el motivo para rechazar el vehículo.',true);return;}
  if(reason.trim().length>300){showMessage('El motivo debe tener como máximo 300 caracteres.',true);return;}
  return updateVehicle(id,'REJECTED',reason.trim());
}
async function loadIncidents(){const filter=$('incidentFilter').value;const rows=await request(`/admin/incidents${filter?`?status=${filter}`:''}`);const body=$('incidentRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const report=node('td');report.append(node('strong',item.type),node('small',item.description));const people=node('td');people.append(node('span',`Reporta: ${item.reporter}`),node('small',`Reportado: ${item.reportedUser||'No indicado'}`));const status=node('td');status.append(badge(item.status));const actions=node('td',undefined,'actions');if(item.status==='RECEIVED')actions.append(button('Revisar',()=>updateIncident(item.id,'REVIEWING')));if(['RECEIVED','REVIEWING'].includes(item.status))actions.append(button('Resolver',()=>updateIncident(item.id,'RESOLVED')),button('Descartar',()=>updateIncident(item.id,'DISMISSED'),'muted'));tr.append(report,people,node('td',formatDate(item.createdAt)),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay incidentes para este filtro.'))}
async function updateIncident(id,status){await request(`/admin/incidents/${id}`,{method:'PATCH',body:JSON.stringify({status})});showMessage('Incidente actualizado');await loadIncidents()}
async function loadUsers(){const filter=$('userFilter').value;const rows=await request(`/admin/users${filter?`?status=${filter}`:''}`);const body=$('userRows');body.replaceChildren(...rows.map(user=>{const tr=node('tr');const name=node('td');name.append(node('strong',`${user.firstName} ${user.lastName}`),node('small',user.email));const role=node('td');role.append(badge(user.role));const status=node('td');status.append(badge(user.status));const actions=node('td',undefined,'actions');if(user.status!=='ACTIVE')actions.append(button('Reactivar',()=>updateUser(user.id,'ACTIVE')));if(user.status==='ACTIVE')actions.append(button('Suspender',()=>confirmUser(user.id,'SUSPENDED'),'muted'),button('Bloquear',()=>confirmUser(user.id,'BLOCKED'),'danger'));tr.append(name,role,node('td',String(user.tripCount)),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay usuarios para este filtro.'))}
function confirmUser(id,status){if(confirm(`¿Confirmas cambiar el estado a ${statusText[status]}?`))updateUser(id,status).catch(error=>showMessage(error.message,true))}
async function updateUser(id,status){await request(`/admin/users/${id}/status`,{method:'PATCH',body:JSON.stringify({status})});showMessage('Usuario actualizado');await loadUsers()}

$('loginForm').addEventListener('submit',login);$('logout').addEventListener('click',logout);$('refresh').addEventListener('click',loadCurrent);$('vehicleFilter').addEventListener('change',loadVehicles);$('incidentFilter').addEventListener('change',loadIncidents);$('userFilter').addEventListener('change',loadUsers);document.querySelectorAll('.nav-item').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.view)));document.querySelectorAll('[data-jump]').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.jump)));$('apiUrl').value=state.api;if(state.token)request('/admin/summary').then(openApp).catch(logout);
