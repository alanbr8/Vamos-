const defaultApi=location.pathname.startsWith('/admin')?`${location.origin}/api/v1`:'http://localhost:3000/api/v1';
const state={token:sessionStorage.getItem('vamosAdminToken'),api:sessionStorage.getItem('vamosApiUrl')||defaultApi,view:'overview'};
const $=id=>document.getElementById(id);
const labels={documents:'Documentos',overview:'Resumen',vehicles:'Vehículos',incidents:'Incidentes',users:'Usuarios',communities:'Comunidades',audit:'Auditoría'};
const statusText={APPROVED:'Aprobado',PENDING:'Pendiente',VERIFIED:'Aprobado',REJECTED:'Rechazado',SUSPENDED:'Suspendido',BLOCKED:'Bloqueado',ACTIVE:'Activo',RECEIVED:'Recibido',REVIEWING:'En revisión',RESOLVED:'Resuelto',DISMISSED:'Descartado',ADMIN:'Administrador',USER:'Usuario'};

async function request(path,options={}){const response=await fetch(`${state.api}${path}`,{...options,headers:{'Content-Type':'application/json','Authorization':`Bearer ${state.token}`,...options.headers}});let data={};try{data=await response.json()}catch{}if(!response.ok)throw new Error(data.message||`Error ${response.status}`);return data}
function node(tag,text,className){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el}
function badge(status){return node('span',statusText[status]||status,`badge ${status}`)}
function button(text,action,className=''){const el=node('button',text,className);el.type='button';el.addEventListener('click',async()=>{if(el.disabled)return;el.disabled=true;try{await action()}catch(error){showMessage(error.message,true)}finally{el.disabled=false}});return el}
function emptyRow(cols,text){const tr=node('tr');const td=node('td',text,'empty');td.colSpan=cols;tr.append(td);return tr}
function showMessage(text='',error=false){$('globalMessage').textContent=text;$('globalMessage').classList.toggle('error-state',error)}
function formatDate(value){return new Intl.DateTimeFormat('es',{dateStyle:'medium',timeStyle:'short'}).format(new Date(value))}
function auditAction(value){return ({VEHICLE_STATUS_CHANGED:'Estado de vehículo',INCIDENT_STATUS_CHANGED:'Estado de incidente',USER_STATUS_CHANGED:'Estado de usuario',COMMUNITY_REQUEST_DECIDED:'Solicitud de ingreso',COMMUNITY_CREATION_DECIDED:'Creación de comunidad'})[value]||value}

async function login(event){event.preventDefault();$('loginError').textContent='';state.api=$('apiUrl').value.replace(/\/$/,'');try{const auth=await fetch(`${state.api}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:$('email').value,password:$('password').value})});const data=await auth.json();if(!auth.ok)throw new Error(data.message||'No se pudo iniciar sesión');state.token=data.accessToken;await request('/admin/summary');sessionStorage.setItem('vamosAdminToken',state.token);sessionStorage.setItem('vamosApiUrl',state.api);openApp()}catch(error){state.token=null;$('loginError').textContent=error.message==='Forbidden resource'?'Tu cuenta no tiene permisos administrativos.':error.message}}
function logout(){closeDocument();$('documentRows').replaceChildren();sessionStorage.removeItem('vamosAdminToken');sessionStorage.removeItem('vamosApiUrl');state.token=null;$('appView').hidden=true;$('loginView').hidden=false}
function openApp(){$('loginView').hidden=true;$('appView').hidden=false;setView('overview')}
async function setView(view){state.view=view;document.querySelectorAll('.panel-view').forEach(el=>el.hidden=el.id!==`${view}Panel`);document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.view===view));$('pageTitle').textContent=labels[view];await loadCurrent()}
async function loadCurrent(){showMessage('Actualizando…');try{if(state.view==='overview')await loadSummary();if(state.view==='vehicles')await loadVehicles();if(state.view==='incidents')await loadIncidents();if(state.view==='users')await loadUsers();if(state.view==='communities')await loadCommunities();if(state.view==='audit')await loadAudit();if(state.view==='documents')await loadDocuments();showMessage('Datos actualizados')}catch(error){showMessage(error.message,true);if(/401|Unauthorized/.test(error.message))logout()}}
async function loadAudit(){const rows=await request('/admin/audit-logs');const body=$('auditRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const entity=node('td');entity.append(node('strong',item.entityType),node('small',item.entityId));const change=node('td');change.append(node('small',`${statusText[item.previousData?.status]||item.previousData?.status||'—'} → ${statusText[item.newData?.status]||item.newData?.status||'—'}`));tr.append(node('td',auditAction(item.action)),entity,node('td',item.administrator),node('td',formatDate(item.createdAt)),change);return tr}));if(!rows.length)body.append(emptyRow(5,'Todavía no existen acciones registradas.'))}
async function loadSummary(){const data=await request('/admin/summary');const cards=[['Usuarios',data.users],['Viajes publicados',data.trips],['Vehículos pendientes',data.pendingVehicles],['Incidentes abiertos',data.openIncidents],['Comunidades por aprobar',data.pendingCommunityCreations],['Ingresos a comunidades',data.pendingCommunityRequests]];$('metrics').replaceChildren(...cards.map(([name,value])=>{const card=node('article',undefined,'metric');card.append(node('p',name),node('strong',String(value)));return card}))}
async function loadVehicles(){const filter=$('vehicleFilter').value;const rows=await request(`/admin/vehicles${filter?`?status=${filter}`:''}`);const body=$('vehicleRows');body.replaceChildren(...rows.map(vehicle=>{const tr=node('tr');const info=node('td');info.append(node('strong',`${vehicle.brand} ${vehicle.model}`),node('small',`${vehicle.year} · ${vehicle.color} · ${vehicle.passengerSeats} asientos`));const owner=node('td');owner.append(node('span',vehicle.owner),node('small',vehicle.email));const actions=node('td',undefined,'actions');if(['PENDING','REJECTED'].includes(vehicle.status)){actions.append(button('Aprobar',()=>updateVehicle(vehicle.id,'VERIFIED')),button('Rechazar',()=>rejectVehicle(vehicle.id),'danger'))}else actions.append(node('small','Sin acciones pendientes'));const status=node('td');status.append(badge(vehicle.status));tr.append(info,owner,node('td',vehicle.licensePlate),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay vehículos para este filtro.'))}
const vehicleUpdates=new Set();
async function updateVehicle(id,status,rejectionReason){
  if(vehicleUpdates.has(id))return;
  vehicleUpdates.add(id);
  showMessage('Guardando decisión…');
  try{
    await request(`/admin/vehicles/${id}`,{method:'PATCH',body:JSON.stringify({status,rejectionReason})});
  }catch(error){
    vehicleUpdates.delete(id);
    showMessage(`No se pudo confirmar el cambio: ${error.message}. Actualiza la lista para comprobar el estado antes de reintentar.`,true);
    return;
  }
  try{
    await loadVehicles();
    showMessage(status==='REJECTED'?'Vehículo rechazado. Puedes consultarlo con el filtro Rechazado.':'Vehículo aprobado.');
  }catch(error){showMessage(`La decisión se guardó, pero no se pudo actualizar la lista: ${error.message}. Pulsa Actualizar.`,true);}
  finally{vehicleUpdates.delete(id);}
}
function rejectVehicle(id){
  const reason=prompt('Motivo del rechazo (máximo 300 caracteres):');
  if(reason===null)return;
  if(!reason.trim()){showMessage('Escribe el motivo para rechazar el vehículo.',true);return;}
  if(reason.trim().length>300){showMessage('El motivo debe tener como máximo 300 caracteres.',true);return;}
  return updateVehicle(id,'REJECTED',reason.trim());
}
async function loadIncidents(){const filter=$('incidentFilter').value;const rows=await request(`/admin/incidents${filter?`?status=${filter}`:''}`);const body=$('incidentRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const report=node('td');report.append(node('strong',item.type),node('small',item.description));if(item.resolutionDetail)report.append(node('strong','Respuesta al usuario'),node('p',item.resolutionDetail));const people=node('td');people.append(node('span',`Reporta: ${item.reporter}`),node('small',`Reportado: ${item.reportedUser||'No indicado'}`));const status=node('td');status.append(badge(item.status));const actions=node('td',undefined,'actions');if(item.status==='RECEIVED')actions.append(button('Revisar',()=>updateIncident(item.id,'REVIEWING')));if(['RECEIVED','REVIEWING'].includes(item.status))actions.append(button('Resolver',()=>updateIncident(item.id,'RESOLVED')),button('Descartar',()=>updateIncident(item.id,'DISMISSED'),'muted'));if(['RESOLVED','DISMISSED'].includes(item.status))actions.append(node('small','Incidente cerrado'));tr.append(report,people,node('td',formatDate(item.createdAt)),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay incidentes para este filtro.'))}
async function updateIncident(id,status){
  let resolutionDetail;
  if(['RESOLVED','DISMISSED'].includes(status)){
    resolutionDetail=prompt(status==='RESOLVED'?'Explica cómo se resolvió el incidente. Esta respuesta será visible para quien lo reportó (10 a 2000 caracteres).':'Explica por qué se descartó. Esta respuesta será visible para quien lo reportó (10 a 2000 caracteres).');
    if(resolutionDetail===null)return;resolutionDetail=resolutionDetail.trim();
    if(resolutionDetail.length<10||resolutionDetail.length>2000){showMessage('Escribe una explicación de 10 a 2000 caracteres.',true);return;}
  }
  return saveAdminChange(`/admin/incidents/${id}`,status,loadIncidents,`Incidente: ${statusText[status]}.`,{resolutionDetail});
}
async function loadUsers(){const filter=$('userFilter').value;const rows=await request(`/admin/users${filter?`?status=${filter}`:''}`);const body=$('userRows');body.replaceChildren(...rows.map(user=>{const tr=node('tr');const name=node('td');name.append(node('strong',`${user.firstName} ${user.lastName}`),node('small',user.email));const role=node('td');role.append(badge(user.role));const status=node('td');status.append(badge(user.status));const actions=node('td',undefined,'actions');if(user.status!=='ACTIVE')actions.append(button('Reactivar',()=>updateUser(user.id,'ACTIVE')));if(user.status==='ACTIVE')actions.append(button('Suspender',()=>confirmUser(user.id,'SUSPENDED'),'muted'));if(user.status!=='BLOCKED')actions.append(button('Bloquear',()=>confirmUser(user.id,'BLOCKED'),'danger'));tr.append(name,role,node('td',String(user.tripCount)),status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay usuarios para este filtro.'))}
function confirmUser(id,status){if(confirm(`¿Confirmas cambiar el estado a ${statusText[status]}?`))return updateUser(id,status)}
async function updateUser(id,status){return saveAdminChange(`/admin/users/${id}/status`,status,loadUsers,`Usuario: ${statusText[status]}. Si salió de la lista, cambia el filtro para verlo.`)}
async function loadCommunities(){await Promise.all([loadCommunityCreations(),loadCommunityMembers()])}
async function loadCommunityCreations(){const filter=$('communityCreationFilter').value;const rows=await request(`/admin/community-creations${filter?`?status=${filter}`:''}`);const body=$('communityCreationRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const community=node('td');community.append(node('strong',item.name),node('small',item.category));const owner=node('td');owner.append(node('strong',item.owner),node('small',item.email));const description=node('td');description.append(node('p',item.description||'Sin descripción'));if(item.rejectionReason)description.append(node('small',`Motivo: ${item.rejectionReason}`));const status=node('td');status.append(badge(item.status));const actions=node('td',undefined,'actions');if(item.status==='PENDING')actions.append(button('Dar visto bueno',()=>updateCommunityCreation(item,'APPROVED')),button('Rechazar',()=>updateCommunityCreation(item,'REJECTED'),'danger'));else actions.append(node('small','Decisión registrada'));tr.append(community,owner,description,status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay creaciones para este filtro.'))}
async function loadCommunityMembers(){const filter=$('communityFilter').value;const rows=await request(`/admin/community-requests${filter?`?status=${filter}`:''}`);const body=$('communityRows');body.replaceChildren(...rows.map(item=>{const tr=node('tr');const community=node('td');community.append(node('strong',item.community),node('small',item.category));const applicant=node('td');applicant.append(node('strong',item.applicant),node('small',item.email));const info=node('td');info.append(node('strong','Motivo'),node('p',item.requestReason||'No declarado'));if(item.organizationLocation)info.append(node('small',`Ubicación: ${item.organizationLocation}`));if(item.jobTitle)info.append(node('small',`Cargo: ${item.jobTitle}`));if(item.reviewNote)info.append(node('small',`Nota de revisión: ${item.reviewNote}`));const status=node('td');status.append(badge(item.status));const actions=node('td',undefined,'actions');if(item.status==='PENDING')actions.append(button('Aprobar',()=>updateCommunity(item,'APPROVED')),button('Rechazar',()=>updateCommunity(item,'REJECTED'),'danger'));else actions.append(node('small','Decisión registrada'));tr.append(community,applicant,info,status,actions);return tr}));if(!rows.length)body.append(emptyRow(5,'No hay solicitudes para este filtro.'))}
function updateCommunityCreation(item,status){let reason='';if(status==='REJECTED'){reason=prompt('Motivo del rechazo (10 a 500 caracteres):','');if(reason===null)return;reason=reason.trim();if(reason.length<10||reason.length>500){showMessage('El motivo debe tener entre 10 y 500 caracteres.',true);return;}}return saveAdminChange(`/admin/community-creations/${item.id}`,status,loadCommunityCreations,status==='APPROVED'?'Comunidad aprobada; ya puede operar.':'Creación rechazada.',{reason})}
function updateCommunity(item,status){let note=prompt(status==='APPROVED'?'Nota opcional para la aprobación:':'Motivo del rechazo (recomendado):','');if(note===null)return;note=note.trim();if(note.length>500){showMessage('La nota debe tener como máximo 500 caracteres.',true);return;}return saveAdminChange(`/admin/community-requests/${item.communityId}/${item.userId}`,status,loadCommunityMembers,`Solicitud: ${statusText[status]}.`,{note})}
const adminChanges=new Set();
async function saveAdminChange(path,status,reload,message,extra={}){
  if(adminChanges.has(path))return;
  adminChanges.add(path);
  showMessage('Guardando cambio…');
  try{
    try{await request(path,{method:'PATCH',body:JSON.stringify({status,...extra})})}
    catch(error){showMessage(`No se pudo confirmar el cambio: ${error.message}. Actualiza la lista para comprobar su estado.`,true);return;}
    try{await reload();showMessage(message)}
    catch(error){showMessage(`El cambio se guardó, pero no se pudo actualizar la lista: ${error.message}. Pulsa Actualizar.`,true)}
  }finally{adminChanges.delete(path)}
}

$('loginForm').addEventListener('submit',login);$('logout').addEventListener('click',logout);$('refresh').addEventListener('click',loadCurrent);$('vehicleFilter').addEventListener('change',loadVehicles);$('incidentFilter').addEventListener('change',loadIncidents);$('userFilter').addEventListener('change',loadUsers);$('communityFilter').addEventListener('change',loadCommunityMembers);$('communityCreationFilter').addEventListener('change',loadCommunityCreations);document.querySelectorAll('.nav-item').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.view)));document.querySelectorAll('[data-jump]').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.jump)));$('apiUrl').value=state.api;if(state.token)request('/admin/summary').then(openApp).catch(logout);

const documentNames={CI_FRONT:'Carnet · anverso',CI_BACK:'Carnet · reverso',SELFIE:'Selfie',LICENSE_FRONT:'Licencia · anverso',LICENSE_BACK:'Licencia · reverso',VEHICLE_FRONT:'Vehículo · frente y placa',VEHICLE_SIDE:'Vehículo · costado',SOAT:'SOAT'};
function closeDocument(){$('documentDialog').close();$('documentImage').removeAttribute('src');$('documentActions').replaceChildren();$('documentInfo').textContent='';}
$('documentDialog').addEventListener('close',()=>{$('documentImage').removeAttribute('src');$('documentActions').replaceChildren();});
async function loadDocuments(){
  const rows=await request('/admin/documents');
  $('documentRows').replaceChildren(...rows.map(doc=>{
    const tr=node('tr'),person=node('td'),kind=node('td'),status=node('td'),actions=node('td');
    person.append(node('strong',doc.owner),node('small',doc.email));
    kind.append(node('strong',documentNames[doc.kind]||doc.kind),node('small',doc.plate||'Personal'));
    status.append(badge(doc.status));if(doc.reason)status.append(node('small',doc.reason));
    actions.append(button('Ver y revisar',()=>openDocument(doc)));
    tr.append(person,kind,node('td',doc.expiresOn||'No indicado'),status,actions);return tr;
  }));if(!rows.length)$('documentRows').append(emptyRow(5,'No hay documentos cargados.'));
}
async function openDocument(doc){
  const image=await request(`/admin/documents/${doc.id}/image`);
  if(image.version!==doc.version)throw new Error('El documento cambió. Actualiza la lista antes de revisarlo.');
  $('documentTitle').textContent=documentNames[doc.kind]||doc.kind;
  $('documentInfo').textContent=`${doc.owner} · ${doc.email} · ${doc.plate||'Personal'} · Vence: ${doc.expiresOn||'No indicado'}`;
  $('documentError').textContent='';
  let saved=false;
  async function review(status){
    if(saved)return;
    let reason;
    if(status==='REJECTED'){
      reason=prompt('Motivo del rechazo, hasta 300 caracteres:');if(reason===null)return;
      reason=reason.trim();if(!reason||reason.length>300){$('documentError').textContent='Escribe un motivo de 1 a 300 caracteres.';return;}
    }
    const buttons=[...$('documentActions').querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);
    try{
      await request(`/admin/documents/${doc.id}`,{method:'PATCH',body:JSON.stringify({status,version:image.version,reason})});
      saved=true;closeDocument();await loadDocuments();showMessage('Revisión guardada. Una vez aprobados todos los documentos, aprueba el vehículo en Vehículos.');
    }catch(e){$('documentError').textContent=e.message;showMessage(e.message,true);}
    finally{buttons.forEach(b=>b.disabled=false);}
  }
  const approve=button('Aprobar',()=>review('APPROVED')),reject=button('Rechazar',()=>review('REJECTED'),'danger');
  approve.disabled=true;reject.disabled=true;
  $('documentActions').replaceChildren(approve,reject,button('Cerrar',closeDocument,'secondary'));
  $('documentImage').onload=()=>{approve.disabled=false;reject.disabled=false;};
  $('documentImage').onerror=()=>{$('documentError').textContent='No se puede visualizar la imagen. Pide una nueva foto.';};
  $('documentImage').src=`data:${image.mime};base64,${image.base64}`;
  $('documentDialog').showModal();
}
