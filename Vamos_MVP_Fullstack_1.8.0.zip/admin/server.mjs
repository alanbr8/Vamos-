import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root=fileURLToPath(new URL('.',import.meta.url));
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
createServer(async(req,res)=>{try{const pathname=new URL(req.url,'http://localhost').pathname;const file=pathname==='/'?'index.html':pathname.slice(1);if(!['index.html','styles.css','app.js'].includes(file)){res.writeHead(404);return res.end('No encontrado')}const content=await readFile(join(root,file));res.writeHead(200,{'Content-Type':types[extname(file)],'Cache-Control':'no-store'});res.end(content)}catch{res.writeHead(500);res.end('Error interno')}}).listen(4173,'127.0.0.1',()=>console.log('Panel Vamos!!: http://localhost:4173'));
