# Panel administrativo Vamos!!

Panel web estático para operar el MVP sin contratar infraestructura adicional.

1. Inicia PostgreSQL y la API.
2. Convierte una cuenta existente en administradora:

```sql
UPDATE users SET role='ADMIN' WHERE email=lower('admin@ejemplo.com');
```

3. Desde la raíz ejecuta `node admin/server.mjs`.
4. Abre `http://localhost:4173` e inicia sesión con esa cuenta.

El token solo se conserva en `sessionStorage`; se elimina al cerrar la pestaña o
usar «Cerrar sesión». En producción sirve estos archivos mediante HTTPS y limita
el acceso al dominio operativo.
