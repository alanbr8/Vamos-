# Panel administrativo Vamos!!

Panel web estático para operar el MVP sin contratar infraestructura adicional.

1. Inicia PostgreSQL y la API.
2. Convierte una cuenta existente en administradora:

```sql
UPDATE users SET role='ADMIN' WHERE email=lower('admin@ejemplo.com');
```

3. Desde la raíz ejecuta `node admin/server.mjs`.
4. Abre `http://localhost:4173` e inicia sesión con esa cuenta.

El token solo se conserva en `sessionStorage`; se elimina al cerrar la pestaña o
usar «Cerrar sesión». En producción sirve estos archivos mediante HTTPS y limita
el acceso al dominio operativo.

## Acceso web en el servicio de la API

El servidor ahora sirve el panel en `/admin/`. Tras desplegar este ZIP en
Vamos-api, abre `https://vamos-api.onrender.com/admin/`.
La API se completa automáticamente con el mismo dominio y `/api/v1`.
Inicia sesión con una cuenta existente ACTIVE y ADMIN.
En Vehículos, filtra Pendiente, comprueba placa y propietario antes de aprobar.
En Android, pulsa CONSULTAR APROBACIÓN para actualizar el estado.
No requiere reinstalar APK ni una migración adicional para este cambio.
Conserva la carpeta admin junto a backend al desplegar el proyecto extraído.
Solo se sirven index.html, app.js y styles.css; las operaciones administrativas
siguen protegidas por JWT y verificación de rol ADMIN en el servidor.
