# Vamos API

API inicial de Vamos!! con NestJS, PostgreSQL y PostGIS.

## Ejecutar localmente

Desde la raíz del proyecto:

```bash
docker compose up -d database
cd backend
cp .env.example .env
npm install
npm run start:dev
```

La API queda disponible en `http://localhost:3000/api/v1`.

## Rutas principales

- `GET /health`
- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/forgot-password`
- `POST /auth/reset-password`
- `GET /users/me`
- `GET /vehicles/me`
- `POST /vehicles`
- `POST /trips`
- `POST /trips/search`
- `POST /bookings`
- `GET /trips/me/driver`
- `GET /bookings/me`
- `PATCH /bookings/:id/:action`
- `PATCH /trips/:id/start`
- `PATCH /trips/:id/complete`
- `POST /ratings`
- `GET /ratings/me`
- `POST /incidents`
- `GET /incidents/me`
- `GET /notifications`
- `GET /notifications/unread-count`
- `PATCH /notifications/:id/read`
- `PATCH /notifications/read-all`
- `GET /bookings/:id/messages`
- `POST /bookings/:id/messages`
- `GET /admin/summary`
- `GET /admin/vehicles`
- `PATCH /admin/vehicles/:id`
- `GET /admin/incidents`
- `PATCH /admin/incidents/:id`
- `GET /admin/users`
- `PATCH /admin/users/:id/status`
- `GET /admin/audit-logs`

Las rutas privadas requieren `Authorization: Bearer <token>`.

## Importante

- `synchronize` está desactivado: el esquema se crea con `database/init.sql`.
- Cambia `JWT_SECRET` antes de desplegar.
- Para validar localmente el flujo completo, `.env.example` activa
  `VEHICLE_AUTO_VERIFY=true`. En producción debe configurarse como `false` y la
  aprobación documental debe realizarse mediante un proceso administrativo.
- El endpoint de matching usa PostGIS para filtrar rutas cercanas al origen y destino.

## Recuperación de contraseña

Para una base ya creada, ejecuta la migración:

```bash
psql "$DATABASE_URL" -f ../database/migrations/002_password_reset.sql
```

Los tokens duran 30 minutos y se almacenan como hash SHA-256. En desarrollo,
`PASSWORD_RESET_RETURN_TOKEN=true` devuelve el token para probar sin correo. En
producción debe ser `false` y el token debe enviarse mediante un proveedor de
correo. También deberán añadirse límites de solicitudes por IP y por cuenta.

## Notificaciones internas

Para una base creada antes de la versión 1.4.0, ejecuta:

```bash
psql "$DATABASE_URL" -f ../database/migrations/003_notifications.sql
```

Los avisos se crean en las mismas transacciones que las reservas y los cambios
de estado. La aplicación consulta novedades cada 30 segundos; las notificaciones
push con el programa cerrado requerirán integrar posteriormente FCM o APNs.

## Chat interno

Para una base creada antes de la versión 1.5.0, ejecuta:

```bash
psql "$DATABASE_URL" -f ../database/migrations/004_messages.sql
```

Cada conversación pertenece a una reserva. Solo el conductor y el pasajero de
una reserva `ACCEPTED` o `COMPLETED` pueden leer y enviar mensajes. La lectura
actualiza `read_at` y cada mensaje nuevo genera una notificación interna.

## Panel administrativo

Para una base creada antes de la versión 1.6.0, ejecuta:

```bash
psql "$DATABASE_URL" -f ../database/migrations/005_admin_panel.sql
```

Después asigna de forma explícita la primera cuenta administradora:

```sql
UPDATE users SET role='ADMIN' WHERE email=lower('admin@ejemplo.com');
```

Las rutas `/admin/*` requieren un JWT válido y verifican en cada petición que
la cuenta siga `ACTIVE` y tenga rol `ADMIN`. La aprobación o rechazo de un
vehículo genera una notificación interna para su propietario.

Para habilitar la bitácora en una base existente y ejecutar las pruebas:

```bash
psql "$DATABASE_URL" -f ../database/migrations/006_admin_audit.sql
npm test -- --runInBand
```

Cada cambio administrativo de vehículo, incidente o usuario conserva el valor
anterior, el nuevo valor, la cuenta responsable y la fecha. El registro se crea
en la misma transacción que la acción: si la auditoría falla, el cambio también
se revierte.
