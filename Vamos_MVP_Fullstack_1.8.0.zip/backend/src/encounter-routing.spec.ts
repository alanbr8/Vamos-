import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { ApiController } from './api.controller';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';

describe('Rutas HTTP de encuentro', () => {
  let app: INestApplication;
  let url: string;
  const api = {
    verifyEncounter: jest.fn().mockResolvedValue({status: 'IN_PROGRESS'}),
    bookingAction: jest.fn().mockResolvedValue({status: 'ACCEPTED'}),
  };
  beforeAll(async () => {
    const module = await Test.createTestingModule({controllers: [ApiController], providers: [
      {provide: ApiService, useValue: api}, {provide: AuthService, useValue: {}},
    ]}).overrideGuard(JwtAuthGuard).useValue({canActivate: (context: any) => {
      context.switchToHttp().getRequest().userId = 'driver'; return true;
    }}).compile();
    app = module.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({whitelist: true, transform: true}));
    await app.listen(0, '127.0.0.1'); url = await app.getUrl();
  });
  beforeEach(() => jest.clearAllMocks());
  afterAll(async () => { await app?.close(); });
  it('envía el código al verificador y no a la acción genérica', async () => {
    const response = await fetch(`${url}/bookings/reservation/verify-encounter`, {
      method: 'PATCH', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({code: '012345'}),
    });
    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({status: 'IN_PROGRESS'});
    expect(api.verifyEncounter).toHaveBeenCalledWith('driver', 'reservation', '012345');
    expect(api.bookingAction).not.toHaveBeenCalled();
  });
  it('conserva la ruta de aceptación de reservas', async () => {
    const response = await fetch(`${url}/bookings/reservation/accept`, {method: 'PATCH'});
    expect(response.status).toBe(200);
    expect(api.bookingAction).toHaveBeenCalledWith('driver', 'reservation', 'accept');
    expect(api.verifyEncounter).not.toHaveBeenCalled();
  });
});
