import { BadRequestException, NotFoundException, ServiceUnavailableException } from '@nestjs/common';
import { DocumentsService, validateDocument } from './documents.service';
const photo = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1sAAAAASUVORK5CYII=';
const valid = {kind:'CI_FRONT',base64:photo,consent:true};
describe('Documentos privados',()=>{
  const previousKey=process.env.DOCUMENT_ENCRYPTION_KEY;
  afterEach(()=>{if(previousKey===undefined)delete process.env.DOCUMENT_ENCRYPTION_KEY;else process.env.DOCUMENT_ENCRYPTION_KEY=previousKey;});
  it('rechaza contenido que no es imagen y consentimiento ausente',()=>{
    expect(()=>validateDocument({...valid,base64:Buffer.from('<script>alert(1)</script>').toString('base64')})).toThrow(BadRequestException);
    expect(()=>validateDocument({...valid,consent:false})).toThrow(BadRequestException);
  });
  it('exige vehículo para SOAT y vencimiento para licencia',()=>{
    expect(()=>validateDocument({...valid,kind:'SOAT',expiresOn:'2099-01-01'})).toThrow(BadRequestException);
    expect(()=>validateDocument({...valid,kind:'LICENSE_FRONT'})).toThrow(BadRequestException);
    expect(()=>validateDocument({...valid,expiresOn:'2026-02-30'})).toThrow(BadRequestException);
    expect(()=>validateDocument({...valid,expiresOn:'2000-01-01'})).toThrow(BadRequestException);
  });
  it('acepta una foto completa dentro del límite y rechaza exceso sin procesarlo',()=>{
    const bytes=Buffer.alloc(1048576);Buffer.from([255,216,255]).copy(bytes);bytes[bytes.length-2]=255;bytes[bytes.length-1]=217;
    expect(validateDocument({...valid,base64:bytes.toString('base64')}).bytes.length).toBe(1048576);
    expect(()=>validateDocument({...valid,base64:Buffer.alloc(1048577).toString('base64')})).toThrow(BadRequestException);
  });
  it('no escribe imágenes si falta la clave privada',async()=>{
    delete process.env.DOCUMENT_ENCRYPTION_KEY;
    const transaction=jest.fn();const service=new DocumentsService({transaction} as never);
    await expect(service.upload('owner',valid)).rejects.toBeInstanceOf(ServiceUnavailableException);
    expect(transaction).not.toHaveBeenCalled();
  });
  it('cifra la foto, recupera el original y detecta alteraciones',async()=>{
    process.env.DOCUMENT_ENCRYPTION_KEY='ab'.repeat(32);
    let stored:any;
    const query=jest.fn(async(sql:string,args:any[])=>{
      if(sql.startsWith('INSERT INTO verification_documents')){stored={ciphertext:args[3],iv:args[4],tag:args[5],mime:args[6],version:1};return [{id:'doc',kind:'CI_FRONT',version:1}];}
      if(sql.startsWith('SELECT *'))return [stored];return [];
    });
    const service=new DocumentsService({query,transaction:async(fn:Function)=>fn({query})} as never);
    await service.upload('owner',valid);
    expect(stored.ciphertext.equals(Buffer.from(photo,'base64'))).toBe(false);
    expect((await service.image('owner','doc',false)).base64).toBe(photo);
    stored.ciphertext[0]^=1;
    await expect(service.image('owner','doc',false)).rejects.toThrow();
  });
  it('no entrega una imagen ajena',async()=>{
    const query=jest.fn().mockResolvedValue([]);const service=new DocumentsService({query} as never);
    await expect(service.image('stranger','document',false)).rejects.toBeInstanceOf(NotFoundException);
    expect(query.mock.calls[0][1]).toEqual(['document','stranger',false]);
  });
});
