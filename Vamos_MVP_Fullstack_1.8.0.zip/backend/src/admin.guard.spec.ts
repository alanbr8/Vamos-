import { ForbiddenException } from '@nestjs/common';
import { AdminGuard } from './admin.guard';

describe('AdminGuard', () => {
  const context = (userId = 'user-1') => ({
    switchToHttp: () => ({ getRequest: () => ({ userId }) }),
  }) as never;

  it('permite una cuenta administradora activa', async () => {
    const db = { query: jest.fn().mockResolvedValue([{ id: 'user-1' }]) } as never;
    await expect(new AdminGuard(db).canActivate(context())).resolves.toBe(true);
  });

  it('rechaza una cuenta sin rol administrativo', async () => {
    const db = { query: jest.fn().mockResolvedValue([]) } as never;
    await expect(new AdminGuard(db).canActivate(context())).rejects.toBeInstanceOf(ForbiddenException);
  });
});
