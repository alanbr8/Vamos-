import { PaymentsService, MethodDto, UsageDto } from './payments.service';
import { validate } from 'class-validator';
import { randomBytes } from 'node:crypto';
describe('Pagos manuales',()=>{
 it('rechaza método arbitrario y preferencia con privilegios',async()=>{
  expect((await validate(Object.assign(new MethodDto(),{method:'PAID'}))).length).toBeGreaterThan(0);
  expect((await validate(Object.assign(new UsageDto(),{mode:'ADMIN'}))).length).toBeGreaterThan(0);
 });
 it('sin reserva autorizada no consulta la imagen bancaria',async()=>{
  const query=jest.fn().mockResolvedValue([]),service=new PaymentsService({query} as any);
  await expect(service.bookingQr('other','booking')).rejects.toThrow();expect(query).toHaveBeenCalledTimes(1);
 });
 it('cifra y recupera exactamente la imagen sin transformarla',async()=>{
  const prior=process.env.DOCUMENT_ENCRYPTION_KEY;process.env.DOCUMENT_ENCRYPTION_KEY=randomBytes(32).toString('hex');
  try{
   let stored:any;
   const query=jest.fn(async(sql:string,p:any[])=>{if(sql.startsWith('INSERT')){stored={ciphertext:p[1],iv:p[2],tag:p[3],mime:p[4]};return [];}return [stored];});
   const s=new PaymentsService({query} as any);
   const base64='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1sAAAAASUVORK5CYII=';
   await s.saveQr('u',{base64,consent:true});expect(stored.ciphertext.toString('base64')).not.toBe(base64);expect((await s.qr('u')).base64).toBe(base64);
  }finally{if(prior===undefined)delete process.env.DOCUMENT_ENCRYPTION_KEY;else process.env.DOCUMENT_ENCRYPTION_KEY=prior;}
 });
});
