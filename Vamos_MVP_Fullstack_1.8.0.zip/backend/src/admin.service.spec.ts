import { BadRequestException } from '@nestjs/common';
import { AdminService } from './admin.service';

describe('AdminService', () => {
  it('impide que un administrador se suspenda a sí mismo', async () => {
    const db = { transaction: jest.fn(), query: jest.fn() } as never;
    const service = new AdminService(db);
    await expect(service.updateUser('admin-1', 'admin-1', { status: 'SUSPENDED' }))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('registra la aprobación del vehículo dentro de la misma transacción', async () => {
    const query = jest.fn()
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([{ ready:true }])
      .mockResolvedValueOnce([{ id: 'vehicle-1', status: 'PENDING', rejectionReason: null }])
      .mockResolvedValueOnce([{ id: 'vehicle-1', ownerId: 'owner-1', brand: 'Toyota', model: 'Yaris', status: 'VERIFIED', rejectionReason: null }])
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([]);
    const db = { transaction: jest.fn(async (callback: (manager: { query: typeof query }) => Promise<unknown>) => callback({ query })) } as never;
    const service = new AdminService(db);

    await service.updateVehicle('admin-1', 'vehicle-1', { status: 'VERIFIED' });

    expect(query).toHaveBeenCalledTimes(6);
    expect(query.mock.calls[5][0]).toContain('INSERT INTO admin_audit_logs');
    expect(query.mock.calls[5][1]).toEqual(expect.arrayContaining(['admin-1', 'VEHICLE_STATUS_CHANGED', 'VEHICLE', 'vehicle-1']));
  });
  it.each(['SUSPENDED', 'BLOCKED'] as const)('protege la propia cuenta frente a %s', async status => {
    const transaction = jest.fn();
    const service = new AdminService({ transaction } as never);
    await expect(service.updateUser('self', 'self', {status})).rejects.toBeInstanceOf(BadRequestException);
    expect(transaction).not.toHaveBeenCalled();
  });

  it('exige motivo para rechazar la creación de una comunidad', async()=>{
    const transaction=jest.fn();
    const service=new AdminService({transaction} as never);
    await expect(service.updateCommunityCreation('admin','community',{status:'REJECTED',reason:'breve'})).rejects.toBeInstanceOf(BadRequestException);
    expect(transaction).not.toHaveBeenCalled();
  });

  it('aprueba una comunidad, audita y notifica al creador',async()=>{
    const query=jest.fn()
      .mockResolvedValueOnce([{id:'community',ownerId:'owner',name:'Ruta Verde',status:'PENDING'}])
      .mockResolvedValueOnce([{id:'community',name:'Ruta Verde',status:'APPROVED',rejectionReason:null}])
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([]);
    const service=new AdminService({transaction:async(fn:Function)=>fn({query})} as never);
    await expect(service.updateCommunityCreation('admin','community',{status:'APPROVED'})).resolves.toMatchObject({status:'APPROVED'});
    expect(query.mock.calls[2][0]).toContain('INSERT INTO admin_audit_logs');
    expect(query.mock.calls[3][0]).toContain('INSERT INTO notifications');
  });

  it.each(['user', 'incident'] as const)('devuelve un objeto y audita el cambio de %s', async entity => {
    const status = entity === 'user' ? 'SUSPENDED' : 'REVIEWING';
    const row = {id: 'target', status};
    const query = jest.fn(async (sql: string) => {
      if (sql.startsWith('SELECT')) return [{id:'target',status:'ACTIVE'}];
      if (sql.startsWith('UPDATE')) return [[row], 1];
      if (sql.startsWith('WITH updated')) return [row];
      return [];
    });
    const service = new AdminService({transaction: async (fn: Function) => fn({query})} as never);
    const result = entity === 'user'
      ? await service.updateUser('admin','target',{status:'SUSPENDED'})
      : await service.updateIncident('admin','target',{status:'REVIEWING'});
    expect(result).toEqual(row);
    expect(query.mock.calls[2][0]).toContain('INSERT INTO admin_audit_logs');
  });

});
