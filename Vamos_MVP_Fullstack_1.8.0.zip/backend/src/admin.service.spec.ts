import { BadRequestException } from '@nestjs/common';
import { AdminService } from './admin.service';

describe('AdminService', () => {
  it('impide que un administrador se suspenda a sí mismo', async () => {
    const db = { transaction: jest.fn(), query: jest.fn() } as never;
    const service = new AdminService(db);
    await expect(service.updateUser('admin-1', 'admin-1', { status: 'SUSPENDED' }))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('registra la aprobación del vehículo dentro de la misma transacción', async () => {
    const query = jest.fn()
      .mockResolvedValueOnce([{ id: 'vehicle-1', status: 'PENDING', rejectionReason: null }])
      .mockResolvedValueOnce([{ id: 'vehicle-1', ownerId: 'owner-1', brand: 'Toyota', model: 'Yaris', status: 'VERIFIED', rejectionReason: null }])
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([]);
    const db = { transaction: jest.fn(async (callback: (manager: { query: typeof query }) => Promise<unknown>) => callback({ query })) } as never;
    const service = new AdminService(db);

    await service.updateVehicle('admin-1', 'vehicle-1', { status: 'VERIFIED' });

    expect(query).toHaveBeenCalledTimes(4);
    expect(query.mock.calls[3][0]).toContain('INSERT INTO admin_audit_logs');
    expect(query.mock.calls[3][1]).toEqual(expect.arrayContaining(['admin-1', 'VEHICLE_STATUS_CHANGED', 'VEHICLE', 'vehicle-1']));
  });
});
