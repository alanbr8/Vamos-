import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { AdminIncidentStatusDto, AdminUserStatusDto, AdminVehicleStatusDto } from './dtos';

@Injectable()
export class AdminService {
  constructor(private readonly db: DataSource) {}

  async summary() {
    const [row] = await this.db.query(`
      SELECT
        (SELECT count(*)::int FROM users) AS users,
        (SELECT count(*)::int FROM trips) AS trips,
        (SELECT count(*)::int FROM vehicles WHERE verification_status='PENDING') AS "pendingVehicles",
        (SELECT count(*)::int FROM incidents WHERE status IN ('RECEIVED','REVIEWING')) AS "openIncidents"
    `);
    return row;
  }

  vehicles(status?: string) {
    const allowed = ['DRAFT', 'PENDING', 'VERIFIED', 'REJECTED', 'SUSPENDED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de vehículo inválido');
    return this.db.query(
      `SELECT v.id,v.brand,v.model,v.year,v.color,v.license_plate AS "licensePlate",
       v.passenger_seats AS "passengerSeats",v.verification_status AS status,
       v.rejection_reason AS "rejectionReason",v.created_at AS "createdAt",
       u.id AS "ownerId",u.first_name || ' ' || u.last_name AS owner,u.email
       FROM vehicles v JOIN users u ON u.id=v.owner_id
       WHERE ($1::text IS NULL OR v.verification_status::text=$1)
       ORDER BY CASE WHEN v.verification_status='PENDING' THEN 0 ELSE 1 END,v.created_at DESC LIMIT 100`,
      [status || null],
    );
  }

  async updateVehicle(adminId: string, id: string, dto: AdminVehicleStatusDto) {
    return this.db.transaction(async manager => {
      const [previous] = await manager.query(
        `SELECT id,verification_status AS status,rejection_reason AS "rejectionReason"
         FROM vehicles WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Vehículo no encontrado');
      const [vehicle] = await manager.query(
        `WITH updated AS (UPDATE vehicles SET verification_status=$2,rejection_reason=$3
         WHERE id=$1 RETURNING id,owner_id AS "ownerId",brand,model,verification_status AS status,
         rejection_reason AS "rejectionReason") SELECT * FROM updated`,
        [id, dto.status, dto.status === 'REJECTED' ? dto.rejectionReason || 'Documentación no aprobada' : null],
      );
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,$2,$3,$4,$5)`,
        [vehicle.ownerId, 'VEHICLE_REVIEW', dto.status === 'VERIFIED' ? 'Vehículo aprobado' : 'Vehículo rechazado',
         dto.status === 'VERIFIED' ? `${vehicle.brand} ${vehicle.model} ya puede publicar viajes` : vehicle.rejectionReason,
         { vehicleId: vehicle.id, status: dto.status }],
      );
      await this.audit(manager, adminId, 'VEHICLE_STATUS_CHANGED', 'VEHICLE', id, previous, vehicle);
      return vehicle;
    });
  }

  incidents(status?: string) {
    const allowed = ['RECEIVED', 'REVIEWING', 'RESOLVED', 'DISMISSED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de incidente inválido');
    return this.db.query(
      `SELECT i.id,i.trip_id AS "tripId",i.type,i.description,i.status,i.created_at AS "createdAt",
       reporter.first_name || ' ' || reporter.last_name AS reporter,
       reported.first_name || ' ' || reported.last_name AS "reportedUser"
       FROM incidents i JOIN users reporter ON reporter.id=i.reporter_id
       LEFT JOIN users reported ON reported.id=i.reported_user_id
       WHERE ($1::text IS NULL OR i.status::text=$1)
       ORDER BY CASE i.status WHEN 'RECEIVED' THEN 0 WHEN 'REVIEWING' THEN 1 ELSE 2 END,i.created_at DESC LIMIT 100`,
      [status || null],
    );
  }

  async updateIncident(adminId: string, id: string, dto: AdminIncidentStatusDto) {
    return this.db.transaction(async manager => {
      const [previous] = await manager.query(`SELECT id,type,status FROM incidents WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Incidente no encontrado');
      const [incident] = await manager.query(
        `WITH updated AS (UPDATE incidents SET status=$2 WHERE id=$1
         RETURNING id,type,status,created_at AS "createdAt") SELECT * FROM updated`, [id, dto.status]);
      await this.audit(manager, adminId, 'INCIDENT_STATUS_CHANGED', 'INCIDENT', id, previous, incident);
      return incident;
    });
  }

  users(status?: string) {
    const allowed = ['ACTIVE', 'SUSPENDED', 'BLOCKED'];
    if (status && !allowed.includes(status)) throw new BadRequestException('Estado de usuario inválido');
    return this.db.query(
      `SELECT u.id,u.first_name AS "firstName",u.last_name AS "lastName",u.email,
       u.status,u.role,u.identity_verified AS "identityVerified",u.created_at AS "createdAt",
       count(DISTINCT t.id)::int AS "tripCount"
       FROM users u LEFT JOIN trips t ON t.driver_id=u.id
       WHERE ($1::text IS NULL OR u.status::text=$1)
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT 100`, [status || null]);
  }

  async updateUser(adminId: string, id: string, dto: AdminUserStatusDto) {
    if (adminId === id && dto.status !== 'ACTIVE') {
      throw new BadRequestException('No puedes suspender o bloquear tu propia cuenta');
    }
    return this.db.transaction(async manager => {
      const [previous] = await manager.query(`SELECT id,status,role FROM users WHERE id=$1 FOR UPDATE`, [id]);
      if (!previous) throw new NotFoundException('Usuario no encontrado');
      const [user] = await manager.query(
        `WITH updated AS (UPDATE users SET status=$2,updated_at=now() WHERE id=$1
         RETURNING id,first_name AS "firstName",last_name AS "lastName",status,role) SELECT * FROM updated`, [id, dto.status]);
      await this.audit(manager, adminId, 'USER_STATUS_CHANGED', 'USER', id, previous, user);
      return user;
    });
  }

  auditLogs() {
    return this.db.query(
      `SELECT l.id,l.action,l.entity_type AS "entityType",l.entity_id AS "entityId",
       l.previous_data AS "previousData",l.new_data AS "newData",l.created_at AS "createdAt",
       u.first_name || ' ' || u.last_name AS administrator
       FROM admin_audit_logs l JOIN users u ON u.id=l.admin_id
       ORDER BY l.created_at DESC LIMIT 200`,
    );
  }

  private audit(manager: { query: (sql: string, params?: unknown[]) => Promise<unknown> }, adminId: string,
    action: string, entityType: string, entityId: string, previousData: unknown, newData: unknown) {
    return manager.query(
      `INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data)
       VALUES($1,$2,$3,$4,$5,$6)`,
      [adminId, action, entityType, entityId, previousData, newData],
    );
  }
}
