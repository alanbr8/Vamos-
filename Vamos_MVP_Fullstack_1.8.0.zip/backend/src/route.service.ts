import { Body, Controller, Injectable, Post, ServiceUnavailableException, BadRequestException, UseGuards } from '@nestjs/common';
import { IsNumber, Min, Max } from 'class-validator';
import { JwtAuthGuard } from './jwt-auth.guard';

export class RouteDto {
  @IsNumber() @Min(-90) @Max(90) originLat!: number;
  @IsNumber() @Min(-180) @Max(180) originLng!: number;
  @IsNumber() @Min(-90) @Max(90) destinationLat!: number;
  @IsNumber() @Min(-180) @Max(180) destinationLng!: number;
}
@Injectable()
export class RouteService {
  private cache = new Map<string, {until:number; value:any}>();
  private pending = new Map<string, Promise<any>>();
  private calls:number[]=[];
  async estimate(dto:RouteDto) {
    const start=[dto.originLng,dto.originLat],end=[dto.destinationLng,dto.destinationLat];
    if([...start,...end].some(v=>!Number.isFinite(v)) || start[0]===end[0]&&start[1]===end[1]) throw new BadRequestException('Selecciona dos puntos diferentes y válidos.');
    const key=JSON.stringify([start,end]);
    const cached=this.cache.get(key);if(cached&&cached.until>Date.now())return cached.value;
    const active=this.pending.get(key);if(active)return active;
    const task=this.request(start,end).then(value=>{
      if(this.cache.size>=200)this.cache.delete(this.cache.keys().next().value!);
      this.cache.set(key,{until:Date.now()+3600000,value});return value;
    }).finally(()=>this.pending.delete(key));
    this.pending.set(key,task);return task;
  }
  private async request(start:number[],end:number[]) {
    const key=process.env.ORS_API_KEY?.trim();
    if(!key)throw new ServiceUnavailableException('El cálculo de rutas todavía no está configurado.');
    this.calls=this.calls.filter(t=>t>Date.now()-60000);
    if(this.calls.length>=35)throw new ServiceUnavailableException('Hay muchas consultas de rutas. Intenta en un minuto.');
    this.calls.push(Date.now());
    try {
      const response=await fetch('https://api.heigit.org/openrouteservice/v2/directions/driving-car/geojson',{
        method:'POST',headers:{Authorization:key,'Content-Type':'application/json'},
        body:JSON.stringify({coordinates:[start,end],instructions:false,radiuses:[150,150]}),signal:AbortSignal.timeout(15000),
      });
      if(!response.ok)throw new Error('provider');
      const data:any=await response.json();const feature=data.features?.[0];
      const points=feature?.geometry?.coordinates;const summary=feature?.properties?.summary;
      if(feature?.geometry?.type!=='LineString'||!Array.isArray(points)||points.length<2||points.length>30000||points.some((p:any)=>!Array.isArray(p)||p.length<2||!Number.isFinite(p[0])||!Number.isFinite(p[1])||Math.abs(p[0])>180||Math.abs(p[1])>90)||!Number.isFinite(summary?.distance)||!Number.isFinite(summary?.duration)||summary.distance<=0||summary.duration<=0)throw new Error('format');
      // Preserve selected endpoints; ORS snaps to a nearby driveable street.
      return {route:[start,...points.map((p:number[])=>p.slice(0,2)),end],distanceMeters:summary.distance,durationSeconds:summary.duration,provider:'openrouteservice'};
    }catch{throw new ServiceUnavailableException('No se pudo calcular una ruta por calles. Comprueba que ambos puntos estén cerca de una vía y vuelve a intentar.');}
  }
}
@Controller('routes')
@UseGuards(JwtAuthGuard)
export class RouteController {
  constructor(private readonly routes:RouteService){}
  @Post('estimate') estimate(@Body() dto:RouteDto){return this.routes.estimate(dto);}
}
