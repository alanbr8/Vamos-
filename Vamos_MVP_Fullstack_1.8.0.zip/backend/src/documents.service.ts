import { BadRequestException, ConflictException, Injectable, NotFoundException, ServiceUnavailableException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { Equals, IsIn, IsInt, IsOptional, IsString, IsUUID, Matches, MaxLength, Min } from 'class-validator';

const kinds = ['CI_FRONT','CI_BACK','SELFIE','LICENSE_FRONT','LICENSE_BACK','VEHICLE_FRONT','VEHICLE_SIDE','SOAT'];
const carKinds = ['VEHICLE_FRONT','VEHICLE_SIDE','SOAT'];
const datedKinds = ['LICENSE_FRONT','LICENSE_BACK','SOAT'];
export class UploadDocumentDto {
  @IsIn(kinds) kind!: string;
  @IsOptional() @IsUUID() vehicleId?: string;
  @IsString() @MaxLength(1400000) base64!: string;
  @IsOptional() @Matches(/^\d{4}-\d{2}-\d{2}$/) expiresOn?: string;
  @Equals(true) consent!: boolean;
}
export class ReviewDocumentDto {
  @IsIn(['APPROVED','REJECTED']) status!: string;
  @IsInt() @Min(1) version!: number;
  @IsOptional() @IsString() @MaxLength(300) reason?: string;
}
export function validateDocument(dto: UploadDocumentDto) {
  if (!kinds.includes(dto.kind) || dto.consent !== true || carKinds.includes(dto.kind) !== !!dto.vehicleId) throw new BadRequestException('Tipo de documento o consentimiento inválido');
  if (datedKinds.includes(dto.kind) && !dto.expiresOn) throw new BadRequestException('Indica la fecha de vencimiento');
  const today = new Intl.DateTimeFormat('en-CA', {timeZone:'America/La_Paz',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  if (dto.expiresOn && (!/^\d{4}-\d{2}-\d{2}$/.test(dto.expiresOn) || isNaN(Date.parse(dto.expiresOn)) || new Date(dto.expiresOn).toISOString().slice(0,10) !== dto.expiresOn || dto.expiresOn < today)) throw new BadRequestException('La fecha de vencimiento no es válida o ya pasó');
  if (typeof dto.base64 !== 'string' || dto.base64.length > 1398104 || !/^[A-Za-z0-9+/]*={0,2}$/.test(dto.base64)) throw new BadRequestException('Imagen inválida');
  const bytes = Buffer.from(dto.base64,'base64');
  if (bytes.toString('base64') !== dto.base64) throw new BadRequestException('Imagen inválida');
  if (!bytes.length || bytes.length>1048576) throw new BadRequestException('La foto debe pesar como máximo 1 MB');
  const png = bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const jpeg = bytes[0]===255 && bytes[1]===216 && bytes[2]===255 && bytes[bytes.length-2]===255 && bytes[bytes.length-1]===217;
  if (!png && !jpeg) throw new BadRequestException('Usa una foto JPG o PNG');
  return {bytes,mime: png?'image/png':'image/jpeg'};
}
@Injectable()
export class DocumentsService {
  constructor(private readonly db: DataSource) {}
  private key() {
    const value=process.env.DOCUMENT_ENCRYPTION_KEY || '';
    if (!/^[a-fA-F0-9]{64}$/.test(value)) throw new ServiceUnavailableException('El administrador debe configurar el almacenamiento privado de documentos');
    return Buffer.from(value,'hex');
  }
  list(userId: string) {
    return this.db.query(`SELECT id,kind,vehicle_id AS "vehicleId",status,reason,expires_on::text AS "expiresOn",version,updated_at AS "updatedAt" FROM verification_documents WHERE owner_id=$1 ORDER BY kind`,[userId]);
  }
  async upload(userId: string, dto: UploadDocumentDto) {
    const {bytes,mime}=validateDocument(dto);
    const iv=randomBytes(12), cipher=createCipheriv('aes-256-gcm',this.key(),iv);
    const ciphertext=Buffer.concat([cipher.update(bytes),cipher.final()]);
    return this.db.transaction(async m=>{
      await m.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId]);
      if (dto.vehicleId) {
        const [car]=await m.query('SELECT id FROM vehicles WHERE id=$1 AND owner_id=$2 FOR UPDATE',[dto.vehicleId,userId]);
        if (!car) throw new NotFoundException('Vehículo no encontrado');
      }
      const conflict=dto.vehicleId?'(vehicle_id,kind) WHERE vehicle_id IS NOT NULL':'(owner_id,kind) WHERE vehicle_id IS NULL';
      const [doc]=await m.query(`INSERT INTO verification_documents(owner_id,vehicle_id,kind,ciphertext,iv,tag,mime,expires_on)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT ${conflict} DO UPDATE SET
      ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,mime=EXCLUDED.mime,expires_on=EXCLUDED.expires_on,
      status='PENDING',reason=NULL,reviewed_by=NULL,reviewed_at=NULL,consent_at=now(),updated_at=now(),version=verification_documents.version+1
      RETURNING id,kind,status,version`,[userId,dto.vehicleId||null,dto.kind,ciphertext,iv,cipher.getAuthTag(),mime,dto.expiresOn||null]);
      if (dto.kind.startsWith('CI_') || dto.kind==='SELFIE') await m.query('UPDATE users SET identity_verified=false WHERE id=$1',[userId]);
      await m.query(`INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data) VALUES($1,'DOCUMENT_SUBMITTED','DOCUMENT',$2,'{}',$3)`,[userId,doc.id,{kind:doc.kind,version:doc.version}]);
      return doc;
    });
  }
  queue() {
    return this.db.query(`SELECT d.id,d.kind,d.status,d.reason,d.version,d.expires_on::text AS "expiresOn",d.updated_at AS "updatedAt",
    u.first_name||' '||u.last_name AS owner,u.email,v.license_plate AS plate
    FROM verification_documents d JOIN users u ON u.id=d.owner_id LEFT JOIN vehicles v ON v.id=d.vehicle_id
    ORDER BY (d.status='PENDING') DESC,d.updated_at DESC LIMIT 200`);
  }
  async image(userId: string, id: string, admin: boolean) {
    const [doc]=await this.db.query(`SELECT * FROM verification_documents WHERE id=$1 AND ($3::boolean OR owner_id=$2)`,[id,userId,admin]);
    if (!doc) throw new NotFoundException('Documento no encontrado');
    const decipher=createDecipheriv('aes-256-gcm',this.key(),doc.iv);decipher.setAuthTag(doc.tag);
    const bytes=Buffer.concat([decipher.update(doc.ciphertext),decipher.final()]);
    if(admin) await this.db.query(`INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data) VALUES($1,'DOCUMENT_VIEWED','DOCUMENT',$2,'{}',$3)`,[userId,id,{version:doc.version}]);
    return {base64:bytes.toString('base64'),mime:doc.mime,version:doc.version};
  }
  async review(adminId: string,id: string,dto: ReviewDocumentDto) {
    if(dto.status==='REJECTED' && !dto.reason?.trim()) throw new BadRequestException('Indica el motivo del rechazo');
    return this.db.transaction(async m=>{
      const [initial]=await m.query('SELECT owner_id FROM verification_documents WHERE id=$1',[id]);
      if(!initial)throw new NotFoundException('Documento no encontrado');
      await m.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[initial.owner_id]);
      const [doc]=await m.query('SELECT id,owner_id,kind,status,version,expires_on FROM verification_documents WHERE id=$1 FOR UPDATE',[id]);
      if(!doc)throw new NotFoundException('Documento no encontrado');
      if(doc.version!==dto.version)throw new ConflictException('El documento cambió. Actualiza y revisa la nueva foto');
      const [result]=await m.query(`WITH changed AS (UPDATE verification_documents SET status=$2,reason=$3,reviewed_by=$4,reviewed_at=now(),version=version+1
      WHERE id=$1 AND ($2<>'APPROVED' OR expires_on IS NULL OR expires_on >= (now() AT TIME ZONE 'America/La_Paz')::date)
      RETURNING id,status,version) SELECT * FROM changed`,[id,dto.status,dto.status==='REJECTED'?dto.reason!.trim():null,adminId]);
      if(!result)throw new BadRequestException('El documento está vencido');
      await m.query(`UPDATE users SET identity_verified=vamos_identity_ready(id,(now() AT TIME ZONE 'America/La_Paz')::date) WHERE id=$1`,[doc.owner_id]);
      await m.query(`INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data) VALUES($1,'DOCUMENT_REVIEWED','DOCUMENT',$2,$3,$4)`,[adminId,id,{status:doc.status,version:doc.version},{...result,reason:dto.reason||null}]);
      await m.query(`INSERT INTO notifications(user_id,type,title,body,data) VALUES($1,'DOCUMENT_REVIEW','Revisión de documento',$2,$3)`,[doc.owner_id,dto.status==='APPROVED'?'Documento aprobado':`Documento rechazado: ${dto.reason}`,{documentId:id}]);
      return result;
    });
  }
  async remove(userId: string,id: string) {
    return this.db.transaction(async m=>{
      await m.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[userId]);
      const [doc]=await m.query(`WITH removed AS (DELETE FROM verification_documents WHERE id=$1 AND owner_id=$2 RETURNING id,kind) SELECT * FROM removed`,[id,userId]);
      if(!doc)throw new NotFoundException('Documento no encontrado');
      await m.query(`UPDATE users SET identity_verified=vamos_identity_ready(id,(now() AT TIME ZONE 'America/La_Paz')::date) WHERE id=$1`,[userId]);
      await m.query(`INSERT INTO admin_audit_logs(admin_id,action,entity_type,entity_id,previous_data,new_data) VALUES($1,'DOCUMENT_DELETED','DOCUMENT',$2,'{}',$3)`,[userId,id,{kind:doc.kind}]);
      return {id};
    });
  }
}
