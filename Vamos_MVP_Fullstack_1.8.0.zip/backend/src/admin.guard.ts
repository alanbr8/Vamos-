import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { AuthRequest } from './jwt-auth.guard';

@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private readonly db: DataSource) {}

  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<AuthRequest>();
    const [admin] = await this.db.query(
      `SELECT id FROM users WHERE id=$1 AND role='ADMIN' AND status='ACTIVE'`,
      [request.userId],
    );
    if (!admin) throw new ForbiddenException('Se requieren permisos administrativos');
    return true;
  }
}
