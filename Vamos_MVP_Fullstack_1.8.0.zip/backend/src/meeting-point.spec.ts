import { ApiService } from './api.service';
describe('Punto Vamos!',()=>{
  it.each([
    {meetingLat:-17.7},
    {meetingLng:-63.1},
    {meetingLat:91,meetingLng:0},
    {meetingLat:0,meetingLng:181},
    {meetingLat:NaN,meetingLng:0},
    {meetingLabel:'Sin coordenadas'},
  ])('rechaza un punto incompleto o inválido antes de guardar: %j',async point=>{
    const transaction=jest.fn();
    await expect(new ApiService({transaction} as never).createBooking('passenger',{tripId:'trip',seats:1,...point})).rejects.toThrow('Punto Vamos!');
    expect(transaction).not.toHaveBeenCalled();
  });
});
