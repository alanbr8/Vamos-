import { PaymentsService, PaymentsController } from './payments.service';
import { TrackingService, TrackingController } from './tracking.service';
import { RouteService, RouteController } from './route.service';
import { PushService, PushController } from './push.service';
import { PhotosController, PhotosService } from './photos.controller';
import { DocumentsService } from './documents.service';
import { DocumentsController, AdminDocumentsController } from './documents.controller';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ApiController } from './api.controller';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { AdminController } from './admin.controller';
import { AdminGuard } from './admin.guard';
import { AdminService } from './admin.service';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        url: config.getOrThrow<string>('DATABASE_URL'),
        synchronize: false,
        logging: config.get('NODE_ENV') === 'development',
      }),
    }),
    JwtModule.registerAsync({
      global: true,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.getOrThrow<string>('JWT_SECRET'),
        signOptions: { expiresIn: config.get('JWT_EXPIRES_IN', '7d') },
      }),
    }),
  ],
  controllers: [PaymentsController, TrackingController, RouteController, PushController, PhotosController, ApiController, AdminController, DocumentsController, AdminDocumentsController],
  providers: [PaymentsService, TrackingService, RouteService, PushService, PhotosService, DocumentsService, ApiService, AuthService, JwtAuthGuard, AdminGuard, AdminService],
})
export class AppModule {}
