import { CommunitiesService, CommunityDto, MemberDecisionDto } from './communities.service';
import { validate } from 'class-validator';
describe('Comunidades',()=>{
 it('rechaza categorías y decisiones arbitrarias',async()=>{
 expect((await validate(Object.assign(new CommunityDto(),{name:'Grupo',description:'',category:'ADMIN'}))).length).toBeGreaterThan(0);
 expect((await validate(Object.assign(new MemberDecisionDto(),{status:'ADMIN'}))).length).toBeGreaterThan(0);
 });
 it('no consulta miembros sin administración',async()=>{
 const query=jest.fn().mockResolvedValue([]);const s=new CommunitiesService({query} as any);
 await expect(s.members('other','group')).rejects.toThrow();expect(query).toHaveBeenCalledTimes(1);
 });
 it('no entrega viajes sin aprobación',async()=>{
 const query=jest.fn().mockResolvedValue([{allowed:false}]);const s=new CommunitiesService({query} as any);
 await expect(s.trips('pending','group')).rejects.toThrow();expect(query).toHaveBeenCalledTimes(1);
 });
});
