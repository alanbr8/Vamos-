import type { INestApplication } from '@nestjs/common';
import type { Request, Response, NextFunction } from 'express';
import { resolve } from 'node:path';

// Only public UI assets are served here. Administrative API routes retain
// JwtAuthGuard and AdminGuard; no credentials or account data are embedded.
export function mountAdminPanel(app: INestApplication) {
  const root = resolve(__dirname, '../../admin');
  const assets: Record<string, string> = {
    '/': 'index.html',
    '/index.html': 'index.html',
    '/app.js': 'app.js',
    '/styles.css': 'styles.css',
  };
  app.use('/admin', (req: Request, res: Response, next: NextFunction) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (req.originalUrl.split('?')[0] === '/admin') {
      return res.redirect(302, '/admin/');
    }
    const file = Object.prototype.hasOwnProperty.call(assets, req.path)
      ? assets[req.path] : undefined;
    if (!file) return res.status(404).send('No encontrado');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.sendFile(file, { root }, (error) => {
      if (error) next(error);
    });
  });
}
