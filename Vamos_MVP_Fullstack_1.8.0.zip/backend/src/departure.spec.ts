import { ApiService } from './api.service';
describe('Salida y encuentro separados',()=>{
  it('repetir salida no crea otro aviso',async()=>{
    const query=jest.fn().mockResolvedValue([{id:'trip',status:'RESERVED',route_departed_at:new Date()}]);
    const service=new ApiService({transaction:async(fn:Function)=>fn({query})} as never);
    await service.departTrip('driver','trip');expect(query).toHaveBeenCalledTimes(1);
  });
  it('no permite validar antes de avisar la salida',async()=>{
    const query=jest.fn().mockResolvedValue([{id:'trip',status:'RESERVED',route_departed_at:null}]);
    const service=new ApiService({transaction:async(fn:Function)=>fn({query})} as never);
    await expect(service.verifyEncounter('driver','booking','123456')).rejects.toThrow('Primero avisa');
  });
  it('los intentos fallidos se guardan antes de devolver el error',async()=>{
    let committed=false;
    const query=jest.fn().mockResolvedValueOnce([{id:'trip',status:'RESERVED',route_departed_at:new Date()}]).mockResolvedValueOnce([{status:'ACCEPTED',encounter_code:'654321',encounter_verified_at:null,encounter_locked_until:null}]).mockResolvedValue([]);
    const service=new ApiService({transaction:async(fn:Function)=>{const result=await fn({query});committed=true;return result;}} as never);
    await expect(service.verifyEncounter('driver','booking','123456')).rejects.toThrow('no corresponde');
    expect(committed).toBe(true);expect(query.mock.calls[2][0]).toContain('encounter_failures');
  });
  it('no acepta el código durante el bloqueo temporal',async()=>{
    const query=jest.fn().mockResolvedValueOnce([{id:'trip',status:'RESERVED',route_departed_at:new Date()}]).mockResolvedValueOnce([{status:'ACCEPTED',encounter_code:'123456',encounter_locked_until:new Date(Date.now()+60000)}]);
    const service=new ApiService({transaction:async(fn:Function)=>fn({query})} as never);
    await expect(service.verifyEncounter('driver','booking','123456')).rejects.toThrow('15 minutos');
    expect(query).toHaveBeenCalledTimes(2);
  });
});
