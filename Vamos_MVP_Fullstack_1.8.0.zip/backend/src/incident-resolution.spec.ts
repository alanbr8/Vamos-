import { AdminService } from './admin.service';
describe('Cierre de incidentes',()=>{
  it.each(['RESOLVED','DISMISSED'] as const)('exige explicación para %s',async status=>{
    const transaction=jest.fn();const service=new AdminService({transaction} as never);
    await expect(service.updateIncident('admin','report',{status})).rejects.toThrow('Explica');
    expect(transaction).not.toHaveBeenCalled();
  });
  it('guarda el detalle, audita y avisa solo al reportante',async()=>{
    const query=jest.fn().mockResolvedValueOnce([{id:'report',status:'REVIEWING',reporterId:'reporter'}]).mockResolvedValueOnce([{id:'report',status:'RESOLVED',resolutionDetail:'Se contactó al conductor y se acordó la devolución.'}]).mockResolvedValue([]);
    const service=new AdminService({transaction:async(fn:Function)=>fn({query})} as never);
    const result=await service.updateIncident('admin','report',{status:'RESOLVED',resolutionDetail:'Se contactó al conductor y se acordó la devolución.'});
    expect(result.resolutionDetail).toContain('devolución');
    expect(query.mock.calls[2][0]).toContain('admin_audit_logs');
    expect(query.mock.calls[3][1][0]).toBe('reporter');
  });
  it('impide sobrescribir un cierre anterior',async()=>{
    const query=jest.fn().mockResolvedValue([{id:'report',status:'DISMISSED'}]);
    const service=new AdminService({transaction:async(fn:Function)=>fn({query})} as never);
    await expect(service.updateIncident('admin','report',{status:'RESOLVED',resolutionDetail:'Otra respuesta de prueba'})).rejects.toThrow('ya está cerrado');
    expect(query).toHaveBeenCalledTimes(1);
  });
});
