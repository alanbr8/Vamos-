import { IsArray, IsEmail, IsIn, IsInt, IsNumber, IsObject, IsOptional, IsString, IsUUID, Length, Max, MaxLength, Min, MinLength } from 'class-validator';

export class RegisterDto {
  @IsString() @MinLength(2) firstName!: string;
  @IsString() @MinLength(2) lastName!: string;
  @IsEmail() email!: string;
  @IsString() @MinLength(7) phone!: string;
  @IsString() @MinLength(8) password!: string;
}
export class LoginDto { @IsEmail() email!: string; @IsString() password!: string; }
export class ForgotPasswordDto { @IsEmail() email!: string; }
export class ResetPasswordDto {
  @IsString() @MinLength(20) token!: string;
  @IsString() @MinLength(8) password!: string;
}
export class VehicleDto {
  @IsString() brand!: string; @IsString() model!: string;
  @IsInt() @Min(1950) @Max(2100) year!: number;
  @IsString() color!: string; @IsString() @MinLength(4) licensePlate!: string;
  @IsInt() @Min(1) @Max(7) passengerSeats!: number;
}
export class TripDto {
  @IsUUID() vehicleId!: string;
  @IsString() originLabel!: string; @IsNumber() originLat!: number; @IsNumber() originLng!: number;
  @IsString() destinationLabel!: string; @IsNumber() destinationLat!: number; @IsNumber() destinationLng!: number;
  @IsArray() route!: [number, number][];
  @IsString() departureAt!: string;
  @IsInt() @Min(1) @Max(7) availableSeats!: number;
  @IsNumber() @Min(0) contribution!: number;
  @IsOptional() @IsArray() recurringDays?: number[];
  @IsOptional() @IsObject() preferences?: Record<string, unknown>;
}
export class SearchTripsDto {
  @IsNumber() originLat!: number; @IsNumber() originLng!: number;
  @IsNumber() destinationLat!: number; @IsNumber() destinationLng!: number;
  @IsString() departureFrom!: string; @IsString() departureTo!: string;
  @IsOptional() @IsNumber() @Min(100) @Max(10000) maxDistanceMeters = 1500;
}
export class BookingDto { @IsUUID() tripId!: string; @IsInt() @Min(1) @Max(7) seats = 1; }
export class CodeDto { @IsString() @Length(4, 4) code!: string; }
export class SendMessageDto { @IsString() @MinLength(1) @MaxLength(1000) body!: string; }
export class RatingDto {
  @IsUUID() tripId!: string; @IsUUID() toUserId!: string;
  @IsInt() @Min(1) @Max(5) overall!: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) punctuality?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) kindness?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) safety?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) driving?: number;
  @IsOptional() @IsString() @MaxLength(300) comment?: string;
}
export class IncidentDto {
  @IsOptional() @IsUUID() tripId?: string; @IsOptional() @IsUUID() reportedUserId?: string;
  @IsString() type!: string; @IsString() @MinLength(10) description!: string;
}
export class AdminVehicleStatusDto {
  @IsIn(['VERIFIED', 'REJECTED']) status!: 'VERIFIED' | 'REJECTED';
  @IsOptional() @IsString() @MaxLength(300) rejectionReason?: string;
}
export class AdminIncidentStatusDto {
  @IsIn(['REVIEWING', 'RESOLVED', 'DISMISSED']) status!: 'REVIEWING' | 'RESOLVED' | 'DISMISSED';
}
export class AdminUserStatusDto {
  @IsIn(['ACTIVE', 'SUSPENDED', 'BLOCKED']) status!: 'ACTIVE' | 'SUSPENDED' | 'BLOCKED';
}
