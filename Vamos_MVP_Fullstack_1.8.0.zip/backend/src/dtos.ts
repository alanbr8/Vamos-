import { IsArray, IsDateString, ArrayMinSize, ArrayUnique, IsEmail, IsIn, IsInt, IsNumber, IsObject, IsOptional, IsString, IsUUID, Length, Max, MaxLength, Min, MinLength } from 'class-validator';

export class RegisterDto {
  @IsOptional() @IsIn(['PASSENGER','DRIVER']) usageMode?:string;
  @IsString() @MinLength(2) @MaxLength(80) firstName!: string;
  @IsString() @MinLength(2) @MaxLength(80) lastName!: string;
  @IsEmail() @MaxLength(180) email!: string;
  @IsString() @MinLength(7) @MaxLength(30) phone!: string;
  @IsString() @MinLength(8) password!: string;
}
export class LoginDto { @IsEmail() @MaxLength(180) email!: string; @IsString() password!: string; }
export class ForgotPasswordDto { @IsEmail() @MaxLength(180) email!: string; }
export class ResetPasswordDto {
  @IsString() @MinLength(20) token!: string;
  @IsString() @MinLength(8) password!: string;
}
export class VehicleDto {
  @IsString() @MinLength(1) @MaxLength(50) brand!: string; @IsString() @MinLength(1) @MaxLength(50) model!: string;
  @IsInt() @Min(1950) @Max(2100) year!: number;
  @IsString() @MinLength(1) @MaxLength(30) color!: string; @IsString() @MinLength(4) @MaxLength(20) licensePlate!: string;
  @IsInt() @Min(1) @Max(7) passengerSeats!: number;
}
export class TripDto {
  @IsUUID() vehicleId!: string;
  @IsString() originLabel!: string; @IsNumber() @Min(-90) @Max(90) originLat!: number; @IsNumber() @Min(-180) @Max(180) originLng!: number;
  @IsString() destinationLabel!: string; @IsNumber() @Min(-90) @Max(90) destinationLat!: number; @IsNumber() @Min(-180) @Max(180) destinationLng!: number;
  @IsArray() @ArrayMinSize(2) route!: [number, number][];
  @IsDateString() departureAt!: string;
  @IsInt() @Min(1) @Max(7) availableSeats!: number;
  @IsNumber() @Min(0) @Max(999999.99) contribution!: number;
  @IsOptional() @IsArray() @ArrayUnique() @IsInt({ each: true }) @Min(1, { each: true }) @Max(7, { each: true }) recurringDays?: number[];
  @IsOptional() @IsObject() preferences?: Record<string, unknown>;
}
export class SearchTripsDto {
  @IsNumber() @Min(-90) @Max(90) originLat!: number; @IsNumber() @Min(-180) @Max(180) originLng!: number;
  @IsNumber() @Min(-90) @Max(90) destinationLat!: number; @IsNumber() @Min(-180) @Max(180) destinationLng!: number;
  @IsDateString() departureFrom!: string; @IsDateString() departureTo!: string;
  @IsOptional() @IsNumber() @Min(100) @Max(10000) maxDistanceMeters = 1500;
}
export class SaveSearchDto extends SearchTripsDto {
  @IsString() @MinLength(1) @MaxLength(200) originLabel!: string;
  @IsString() @MinLength(1) @MaxLength(200) destinationLabel!: string;
}
export class BookingDto {
  @IsUUID() tripId!: string;
  @IsInt() @Min(1) @Max(7) seats = 1;
  @IsOptional() @IsNumber() @Min(-90) @Max(90) meetingLat?: number;
  @IsOptional() @IsNumber() @Min(-180) @Max(180) meetingLng?: number;
  @IsOptional() @IsString() @MaxLength(200) meetingLabel?: string;
}
export class CodeDto { @IsString() @Length(4, 6) code!: string; }
export class SendMessageDto { @IsString() @MinLength(1) @MaxLength(1000) body!: string; }
export class RatingDto {
  @IsUUID() tripId!: string; @IsUUID() toUserId!: string;
  @IsInt() @Min(1) @Max(5) overall!: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) punctuality?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) kindness?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) safety?: number;
  @IsOptional() @IsInt() @Min(1) @Max(5) driving?: number;
  @IsOptional() @IsString() @MaxLength(300) comment?: string;
}
export class IncidentDto {
  @IsOptional() @IsUUID() tripId?: string; @IsOptional() @IsUUID() reportedUserId?: string;
  @IsString() type!: string; @IsString() @MinLength(10) description!: string;
}
export class AdminVehicleStatusDto {
  @IsIn(['VERIFIED', 'REJECTED']) status!: 'VERIFIED' | 'REJECTED';
  @IsOptional() @IsString() @MaxLength(300) rejectionReason?: string;
}
export class AdminIncidentStatusDto {
  @IsOptional() @IsString() @MaxLength(2000) resolutionDetail?: string;
  @IsIn(['REVIEWING', 'RESOLVED', 'DISMISSED']) status!: 'REVIEWING' | 'RESOLVED' | 'DISMISSED';
}
export class AdminUserStatusDto {
  @IsIn(['ACTIVE', 'SUSPENDED', 'BLOCKED']) status!: 'ACTIVE' | 'SUSPENDED' | 'BLOCKED';
}
