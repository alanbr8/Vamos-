import { BadRequestException, Body, Controller, Delete, Get, Header, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Req, ServiceUnavailableException, UseGuards } from '@nestjs/common';
import { Equals, IsIn, IsString, MaxLength } from 'class-validator';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { DataSource } from 'typeorm';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
import { validateDocument } from './documents.service';
export class QrDto { @IsString() @MaxLength(1400000) base64!:string; @Equals(true) consent!:boolean; }
export class MethodDto { @IsIn(['CASH','QR']) method!:string; }
export class UsageDto { @IsIn(['PASSENGER','DRIVER']) mode!:string; }
@Injectable()
export class PaymentsService {
 constructor(private readonly db:DataSource){}
 private key(){const k=process.env.DOCUMENT_ENCRYPTION_KEY||'';if(!/^[a-fA-F0-9]{64}$/.test(k))throw new ServiceUnavailableException('Almacenamiento no configurado');return Buffer.from(k,'hex');}
 async saveQr(owner:string,d:QrDto){
  const {bytes,mime}=validateDocument({kind:'CI_FRONT',base64:d.base64,consent:d.consent});
  const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',this.key(),iv),encrypted=Buffer.concat([c.update(bytes),c.final()]);
  await this.db.query(`INSERT INTO payment_qrs(owner_id,ciphertext,iv,tag,mime) VALUES($1,$2,$3,$4,$5)
   ON CONFLICT(owner_id) DO UPDATE SET ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,mime=EXCLUDED.mime,updated_at=now()`,[owner,encrypted,iv,c.getAuthTag(),mime]);return {saved:true};
 }
 async qr(owner:string){const [p]=await this.db.query('SELECT * FROM payment_qrs WHERE owner_id=$1',[owner]);if(!p)throw new NotFoundException('El conductor no ha cargado un QR. Puedes pagar en efectivo.');const d=createDecipheriv('aes-256-gcm',this.key(),p.iv);d.setAuthTag(p.tag);return {base64:Buffer.concat([d.update(p.ciphertext),d.final()]).toString('base64'),mime:p.mime};}
 async removeQr(owner:string){await this.db.query('DELETE FROM payment_qrs WHERE owner_id=$1',[owner]);return {removed:true};}
 private async booking(user:string,id:string){const [b]=await this.db.query(`SELECT b.*,t.driver_id,t.contribution,(t.contribution*b.seats) AS total FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1 AND (b.passenger_id=$2 OR t.driver_id=$2) AND b.status IN ('ACCEPTED','COMPLETED')`,[id,user]);if(!b)throw new NotFoundException('Reserva no disponible para pagos');return b;}
 async read(user:string,id:string){const b=await this.booking(user,id);const [q]=await this.db.query('SELECT owner_id FROM payment_qrs WHERE owner_id=$1',[b.driver_id]);return {method:b.payment_method,confirmedAt:b.payment_confirmed_at,total:b.total,qrAvailable:!!q,driver:b.driver_id===user};}
 async bookingQr(user:string,id:string){const b=await this.booking(user,id);return this.qr(b.driver_id);}
 async choose(user:string,id:string,method:string){
  const result=await this.db.query(`WITH changed AS (UPDATE bookings b SET payment_method=$3 FROM trips t WHERE b.id=$1 AND b.trip_id=t.id AND b.passenger_id=$2 AND b.status IN ('ACCEPTED','COMPLETED') AND b.payment_confirmed_at IS NULL AND ($3::varchar='CASH' OR EXISTS(SELECT 1 FROM payment_qrs q WHERE q.owner_id=t.driver_id)) RETURNING b.id) SELECT * FROM changed`,[id,user,method]);
  if(!result.length)throw new BadRequestException('No se puede cambiar el método: revisa el estado de la reserva o la disponibilidad del QR.');return {saved:true};
 }
 async confirm(user:string,id:string){const rows=await this.db.query(`WITH changed AS (UPDATE bookings b SET payment_confirmed_at=COALESCE(b.payment_confirmed_at,now()) FROM trips t WHERE b.id=$1 AND b.trip_id=t.id AND t.driver_id=$2 AND b.status IN ('ACCEPTED','COMPLETED') RETURNING b.id) SELECT * FROM changed`,[id,user]);if(!rows.length)throw new NotFoundException('Reserva no disponible');return {confirmed:true};}
 async usage(user:string,mode:string){await this.db.query('UPDATE users SET usage_mode=$2 WHERE id=$1',[user,mode]);return {usageMode:mode};}
}
@Controller('payments') @UseGuards(JwtAuthGuard)
export class PaymentsController {
 constructor(private readonly service:PaymentsService){}
 @Post('usage') usage(@Req() r:AuthRequest,@Body() d:UsageDto){return this.service.usage(r.userId,d.mode);}
 @Post('qr') save(@Req() r:AuthRequest,@Body() d:QrDto){return this.service.saveQr(r.userId,d);}
 @Get('qr') @Header('Cache-Control','no-store') qr(@Req() r:AuthRequest){return this.service.qr(r.userId);}
 @Delete('qr') remove(@Req() r:AuthRequest){return this.service.removeQr(r.userId);}
 @Get('booking/:id') @Header('Cache-Control','no-store') read(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.service.read(r.userId,id);}
 @Get('booking/:id/qr') @Header('Cache-Control','no-store') image(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.service.bookingQr(r.userId,id);}
 @Post('booking/:id/method') choose(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() d:MethodDto){return this.service.choose(r.userId,id,d.method);}
 @Post('booking/:id/confirm') confirm(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.service.confirm(r.userId,id);}
}
