import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { createHash, randomBytes } from 'crypto';
import { ForgotPasswordDto, LoginDto, RegisterDto, ResetPasswordDto } from './dtos';

@Injectable()
export class AuthService {
  constructor(private readonly db: DataSource, private readonly jwt: JwtService) {}

  async register(dto: RegisterDto) {
    const passwordHash = await bcrypt.hash(dto.password, 12);
    try {
      const [user] = await this.db.query(
        `INSERT INTO users(first_name,last_name,email,phone,password_hash)
         VALUES($1,$2,lower($3),$4,$5)
         RETURNING id,first_name AS "firstName",last_name AS "lastName",email,phone`,
        [dto.firstName, dto.lastName, dto.email, dto.phone, passwordHash],
      );
      return { user, accessToken: await this.jwt.signAsync({ sub: user.id }) };
    } catch (error: unknown) {
      if ((error as { code?: string }).code === '23505') throw new BadRequestException('Correo o celular ya registrado');
      throw error;
    }
  }

  async login(dto: LoginDto) {
    const [user] = await this.db.query('SELECT * FROM users WHERE email=lower($1) AND status=$2', [dto.email, 'ACTIVE']);
    if (!user || !(await bcrypt.compare(dto.password, user.password_hash))) throw new UnauthorizedException('Credenciales incorrectas');
    return { accessToken: await this.jwt.signAsync({ sub: user.id }), user: { id: user.id, firstName: user.first_name, lastName: user.last_name, email: user.email } };
  }

  async requestPasswordReset(dto: ForgotPasswordDto) {
    const [user] = await this.db.query(
      'SELECT id FROM users WHERE email=lower($1) AND status=$2',
      [dto.email, 'ACTIVE']);
    const response: { message: string; devToken?: string } = {
      message: 'Si el correo está registrado, recibirás instrucciones para continuar',
    };
    if (!user) return response;

    const token = randomBytes(32).toString('hex');
    const tokenHash = createHash('sha256').update(token).digest('hex');
    await this.db.transaction(async manager => {
      await manager.query(
        'UPDATE password_reset_tokens SET used_at=now() WHERE user_id=$1 AND used_at IS NULL',
        [user.id]);
      await manager.query(
        `INSERT INTO password_reset_tokens(user_id,token_hash,expires_at)
         VALUES($1,$2,now()+interval '30 minutes')`,
        [user.id, tokenHash]);
    });
    if (process.env.PASSWORD_RESET_RETURN_TOKEN === 'true') response.devToken = token;
    return response;
  }

  async resetPassword(dto: ResetPasswordDto) {
    const tokenHash = createHash('sha256').update(dto.token).digest('hex');
    const passwordHash = await bcrypt.hash(dto.password, 12);
    return this.db.transaction(async manager => {
      const [reset] = await manager.query(
        `SELECT id,user_id AS "userId" FROM password_reset_tokens
         WHERE token_hash=$1 AND used_at IS NULL AND expires_at>now()
         FOR UPDATE`, [tokenHash]);
      if (!reset) throw new BadRequestException('El enlace es inválido o expiró');
      await manager.query('UPDATE users SET password_hash=$2,updated_at=now() WHERE id=$1', [reset.userId, passwordHash]);
      await manager.query('UPDATE password_reset_tokens SET used_at=now() WHERE user_id=$1 AND used_at IS NULL', [reset.userId]);
      return { message: 'Contraseña actualizada correctamente' };
    });
  }
}
