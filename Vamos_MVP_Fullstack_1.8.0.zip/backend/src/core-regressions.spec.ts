import { JwtAuthGuard } from './jwt-auth.guard';
import { AuthService } from './auth.service';
import { ApiService } from './api.service';
import { UnauthorizedException } from '@nestjs/common';

describe('Regresiones del recorrido', () => {
  it('una cuenta suspendida pierde acceso aunque su JWT sea válido', async () => {
    const guard = new JwtAuthGuard({verifyAsync: jest.fn().mockResolvedValue({sub:'user'})} as any, {query: jest.fn().mockResolvedValue([])} as any);
    const context = {switchToHttp:()=>({getRequest:()=>({headers:{authorization:'Bearer test'}})})} as any;
    await expect(guard.canActivate(context)).rejects.toBeInstanceOf(UnauthorizedException);
  });
  it('una caída de base de datos no se confunde con una sesión vencida', async () => {
    const unavailable = new Error('database unavailable');
    const guard = new JwtAuthGuard({verifyAsync: jest.fn().mockResolvedValue({sub:'user'})} as any, {query: jest.fn().mockRejectedValue(unavailable)} as any);
    const context = {switchToHttp:()=>({getRequest:()=>({headers:{authorization:'Bearer test'}})})} as any;
    await expect(guard.canActivate(context)).rejects.toBe(unavailable);
  });
  it('no promete enviar correo ni devuelve tokens en producción', async () => {
    const previous = {...process.env};
    try {
      process.env.NODE_ENV='production';process.env.PASSWORD_RESET_RETURN_TOKEN='true';
      const query=jest.fn();const service=new AuthService({query} as any,{} as any);
      await expect(service.requestPasswordReset({email:'test@example.invalid'})).rejects.toThrow('todavía no está disponible');
      expect(query).not.toHaveBeenCalled();
    } finally { process.env=previous; }
  });
  it('rechaza una ruta cuyo destino no coincide con sus coordenadas', async () => {
    const query=jest.fn();const service=new ApiService({query} as any);
    await expect(service.createTrip('driver',{departureAt:new Date(Date.now()+3600000).toISOString(),originLat:1,originLng:1,destinationLat:2,destinationLng:2,route:[[1,1],[3,3]]} as any)).rejects.toThrow('terminar en el destino');
    expect(query).not.toHaveBeenCalled();
  });
});
