import { BadRequestException, Body, Controller, Get, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Req, UseGuards } from '@nestjs/common';
import { IsIn, IsString, Length, MaxLength } from 'class-validator';
import { randomBytes } from 'node:crypto';
import { DataSource } from 'typeorm';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
export class CommunityDto {
 @IsString() @Length(3,80) name!:string;
 @IsString() @MaxLength(500) description!:string;
 @IsIn(['GENERAL','WOMEN','COMPANY','NEIGHBORHOOD','RESIDENTIAL','SCHOOL']) category!:string;
}
export class JoinCommunityDto { @IsString() @Length(16,32) code!:string; }
export class MemberDecisionDto { @IsIn(['APPROVED','REJECTED']) status!:string; }
@Injectable()
export class CommunitiesService {
 constructor(private readonly db:DataSource){}
 list(user:string){return this.db.query(`SELECT c.id,c.name,c.description,c.category,m.status,c.owner_id=$1 AS admin FROM communities c JOIN community_members m ON m.community_id=c.id WHERE m.user_id=$1 ORDER BY c.name`,[user]);}
 async create(user:string,d:CommunityDto){return this.db.transaction(async m=>{
  const [c]=await m.query(`INSERT INTO communities(owner_id,name,description,category,invite_code) VALUES($1,$2,$3,$4,$5) RETURNING id`,[user,d.name.trim(),d.description.trim(),d.category,randomBytes(12).toString('hex')]);
  await m.query("INSERT INTO community_members(community_id,user_id,status) VALUES($1,$2,'APPROVED')",[c.id,user]);return c;
 });}
 async join(user:string,code:string){return this.db.transaction(async m=>{
  const [c]=await m.query(`SELECT c.id FROM communities c JOIN users u ON u.id=c.owner_id WHERE c.invite_code=$1 AND u.status='ACTIVE' FOR UPDATE OF c`,[code.trim().toLowerCase()]);if(!c)throw new NotFoundException('Código no válido');
  await m.query(`INSERT INTO community_members(community_id,user_id,status) VALUES($1,$2,'PENDING') ON CONFLICT DO NOTHING`,[c.id,user]);return {requested:true};
 });}
 async detail(user:string,id:string){const [c]=await this.db.query(`SELECT c.id,c.name,c.description,c.category,m.status,c.owner_id=$2 AS admin,CASE WHEN c.owner_id=$2 THEN c.invite_code END AS code FROM communities c JOIN community_members m ON m.community_id=c.id WHERE c.id=$1 AND m.user_id=$2`,[id,user]);if(!c)throw new NotFoundException('Comunidad no disponible');return c;}
 async members(user:string,id:string){await this.admin(user,id);return this.db.query(`SELECT m.user_id AS id,u.first_name AS name,u.last_name AS surname,m.status FROM community_members m JOIN users u ON u.id=m.user_id WHERE m.community_id=$1 ORDER BY m.created_at`,[id]);}
 private async admin(user:string,id:string){const [c]=await this.db.query('SELECT id FROM communities WHERE id=$1 AND owner_id=$2',[id,user]);if(!c)throw new NotFoundException('Comunidad no disponible');}
 async rotate(user:string,id:string){const [c]=await this.db.query(`WITH changed AS (UPDATE communities SET invite_code=$3 WHERE id=$1 AND owner_id=$2 RETURNING id) SELECT * FROM changed`,[id,user,randomBytes(12).toString('hex')]);if(!c)throw new NotFoundException('Comunidad no disponible');return {rotated:true};}
 async decide(user:string,id:string,target:string,status:string){return this.db.transaction(async m=>{
  const [c]=await m.query('SELECT owner_id FROM communities WHERE id=$1 AND owner_id=$2 FOR UPDATE',[id,user]);if(!c||target===c.owner_id)throw new BadRequestException('No puedes modificar este miembro');
  if(status==='REJECTED'){
   const [active]=await m.query(`SELECT t.id FROM trips t WHERE t.community_id=$1 AND t.status IN ('PUBLISHED','RESERVED','IN_PROGRESS') AND (t.driver_id=$2 OR EXISTS(SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2 AND b.status IN ('PENDING','ACCEPTED'))) LIMIT 1`,[id,target]);
   if(active)throw new BadRequestException('El miembro tiene viajes o reservas activos. Debe resolverlos antes de retirarlo.');
  }
  const rows=await m.query(`WITH changed AS (UPDATE community_members SET status=$3 WHERE community_id=$1 AND user_id=$2 RETURNING user_id) SELECT * FROM changed`,[id,target,status]);if(!rows.length)throw new NotFoundException('Solicitud no encontrada');return {updated:true};
 });}
 async trips(user:string,id:string){const [access]=await this.db.query('SELECT vamos_community_access($1,$2) AS allowed',[id,user]);if(!access?.allowed)throw new NotFoundException('Necesitas aprobación para ver los viajes');return this.db.query(`SELECT t.id,t.origin_label AS origin,t.destination_label AS destination,t.departure_at AS "departureAt",t.available_seats AS seats,t.contribution,u.first_name AS driver,u.id AS "driverId",t.vehicle_id AS "vehicleId",concat(v.brand,' ',v.model) AS vehicle,COALESCE((SELECT round(avg(overall),1) FROM ratings WHERE to_user_id=u.id),0) AS rating,(SELECT count(*)::int FROM trips WHERE driver_id=u.id AND status='COMPLETED') AS "tripCount",0 AS compatibility,ST_Y(t.origin::geometry) AS "originLat",ST_X(t.origin::geometry) AS "originLng",ST_Y(t.destination::geometry) AS "destinationLat",ST_X(t.destination::geometry) AS "destinationLng",ST_AsGeoJSON(t.route::geometry)::json->'coordinates' AS route,t.preferences->'routeEstimate' AS "routeEstimate" FROM trips t JOIN users u ON u.id=t.driver_id JOIN vehicles v ON v.id=t.vehicle_id WHERE t.community_id=$1 AND t.driver_id<>$2 AND t.status='PUBLISHED' AND t.departure_at>now() AND t.route_departed_at IS NULL AND t.available_seats>0 AND u.status='ACTIVE' AND v.verification_status='VERIFIED' AND vamos_community_access(t.community_id,$2) ORDER BY t.departure_at LIMIT 100`,[id,user]);}
}
@Controller('communities') @UseGuards(JwtAuthGuard)
export class CommunitiesController {
 constructor(private readonly s:CommunitiesService){}
 @Get() list(@Req() r:AuthRequest){return this.s.list(r.userId);}
 @Post() create(@Req() r:AuthRequest,@Body() d:CommunityDto){return this.s.create(r.userId,d);}
 @Post('join') join(@Req() r:AuthRequest,@Body() d:JoinCommunityDto){return this.s.join(r.userId,d.code);}
 @Get(':id') detail(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.detail(r.userId,id);}
 @Get(':id/members') members(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.members(r.userId,id);}
 @Get(':id/trips') trips(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.trips(r.userId,id);}
 @Post(':id/rotate') rotate(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.s.rotate(r.userId,id);}
 @Post(':id/members/:user') decide(@Req() r:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Param('user',ParseUUIDPipe) user:string,@Body() d:MemberDecisionDto){return this.s.decide(r.userId,id,user,d.status);}
}
