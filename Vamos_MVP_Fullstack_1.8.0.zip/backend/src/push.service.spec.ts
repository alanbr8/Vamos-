import { generateKeyPairSync } from 'node:crypto';
import { PushService, pushContent } from './push.service';
import { Logger } from '@nestjs/common';

describe('Cola push',()=>{
  const previous=process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const originalFetch=global.fetch;
  const privateKey=generateKeyPairSync('rsa',{modulusLength:2048}).privateKey.export({type:'pkcs8',format:'pem'}).toString();
  beforeEach(()=>{
    process.env.FIREBASE_SERVICE_ACCOUNT_JSON=JSON.stringify({project_id:'vamos-test',client_email:'test@example.invalid',private_key:privateKey});
    jest.spyOn(Logger.prototype,'warn').mockImplementation(()=>{});
  });
  afterEach(()=>{global.fetch=originalFetch;jest.restoreAllMocks();if(previous===undefined)delete process.env.FIREBASE_SERVICE_ACCOUNT_JSON;else process.env.FIREBASE_SERVICE_ACCOUNT_JSON=previous;});
  function setup(attempts=1,device=true){
    const query=jest.fn(async(sql:string)=>{
      if(sql.startsWith('WITH candidates'))return [{id:'job',device_id:'device',user_id:'user',binding:'binding',notice_id:'notice',type:'ROUTE_DEPARTED',attempts}];
      if(sql.startsWith('SELECT d.token'))return device?[{token:'device-token'}]:[];
      return [];
    });
    return {query,service:new PushService({query} as never)};
  }
  function network(status:number,body:object={}){
    const fn=jest.fn().mockResolvedValueOnce(new Response(JSON.stringify({access_token:'oauth'}),{status:200})).mockResolvedValueOnce(new Response(JSON.stringify(body),{status}));
    global.fetch=fn as typeof fetch;return fn;
  }
  it('entrega después de OAuth y marca enviado',async()=>{
    const {query,service}=setup();const fetch=network(200);
    await service.tick();
    expect(fetch).toHaveBeenCalledTimes(2);
    const message=JSON.parse(fetch.mock.calls[1][1].body).message;
    expect(message.data).toEqual({notificationId:'notice',userId:'user',type:'ROUTE_DEPARTED'});
    expect(query.mock.calls.some((c:any)=>c[1]?.[1]==='SENT')).toBe(true);
  });
  it('no envía si el dispositivo cambió de cuenta',async()=>{
    const {query,service}=setup(1,false);global.fetch=jest.fn();await service.tick();
    expect(global.fetch).not.toHaveBeenCalled();expect(query.mock.calls.some((c:any)=>c[1]?.[1]==='EXPIRED')).toBe(true);
  });
  it.each([1,6])('reintenta fallos transitorios con límite; intento %s',async attempts=>{
    const {query,service}=setup(attempts);network(503);await service.tick();
    expect(query.mock.calls.some((c:any)=>c[1]?.[1]===(attempts===6?'FAILED':'PENDING')&&c[1]?.[2]==='FCM_HTTP_503')).toBe(true);
  });
  it('elimina tokens que FCM declara no registrados',async()=>{
    const {query,service}=setup();network(404,{error:{details:[{errorCode:'UNREGISTERED'}]}});await service.tick();
    expect(query.mock.calls.some((c:any)=>c[0].startsWith('DELETE FROM push_devices')&&c[1][1]==='binding')).toBe(true);
  });
  it('los avisos sensibles tienen contenido genérico',()=>{
    const content=pushContent({id:'n',user_id:'u',type:'INCIDENT_UPDATED'});
    expect(content.notification.body).toBe('Abre Vamos para consultar la actualización.');
    expect(content.data).toEqual({notificationId:'n',userId:'u',type:'INCIDENT_UPDATED'});
  });
});
