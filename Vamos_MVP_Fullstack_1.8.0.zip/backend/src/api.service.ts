import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { BookingDto, IncidentDto, RatingDto, SearchTripsDto, SendMessageDto, TripDto, VehicleDto } from './dtos';

@Injectable()
export class ApiService {
  constructor(private readonly db: DataSource) {}

  async profile(userId: string) {
    const [user] = await this.db.query(
      `SELECT u.id,u.first_name AS "firstName",u.last_name AS "lastName",u.email,u.phone,u.identity_verified AS "identityVerified",
       COALESCE(round(avg(r.overall),1),0) AS rating,count(DISTINCT r.id)::int AS "ratingCount"
       FROM users u LEFT JOIN ratings r ON r.to_user_id=u.id WHERE u.id=$1 GROUP BY u.id`, [userId]);
    if (!user) throw new NotFoundException('Usuario no encontrado');
    return user;
  }

  vehicles(userId: string) {
    return this.db.query('SELECT id,brand,model,year,color,license_plate AS "licensePlate",passenger_seats AS "passengerSeats",verification_status AS status FROM vehicles WHERE owner_id=$1 ORDER BY created_at DESC', [userId]);
  }

  async createVehicle(userId: string, dto: VehicleDto) {
    const verificationStatus = process.env.VEHICLE_AUTO_VERIFY === 'true'
      ? 'VERIFIED'
      : 'PENDING';
    const [vehicle] = await this.db.query(
      `INSERT INTO vehicles(owner_id,brand,model,year,color,license_plate,passenger_seats,verification_status)
       VALUES($1,$2,$3,$4,$5,upper($6),$7,$8)
       ON CONFLICT (license_plate) DO NOTHING
       RETURNING id,brand,model,year,color,license_plate AS "licensePlate",
       passenger_seats AS "passengerSeats",verification_status AS status`,
      [userId, dto.brand, dto.model, dto.year, dto.color,
       dto.licensePlate, dto.passengerSeats, verificationStatus]);
    if (!vehicle) throw new ConflictException('Esta placa ya está registrada. Consulta Mi vehículo o contacta al administrador.');
    return vehicle;
  }

  async createTrip(userId: string, dto: TripDto) {
    if (new Date(dto.departureAt).getTime() <= Date.now()) {
      throw new BadRequestException('La salida debe estar en el futuro');
    }
    if (dto.originLat === dto.destinationLat && dto.originLng === dto.destinationLng) {
      throw new BadRequestException('El origen y el destino deben ser diferentes');
    }
    if (dto.route.length < 2 || dto.route.some(point => !Array.isArray(point) || point.length !== 2 ||
        !Number.isFinite(point[0]) || !Number.isFinite(point[1]) || Math.abs(point[0]) > 180 || Math.abs(point[1]) > 90)) {
      throw new BadRequestException('La ruta debe contener al menos dos coordenadas válidas');
    }
    if (dto.route[0][0] !== dto.originLng || dto.route[0][1] !== dto.originLat ||
        dto.route.at(-1)![0] !== dto.destinationLng || dto.route.at(-1)![1] !== dto.destinationLat) {
      throw new BadRequestException('La ruta debe empezar en el origen y terminar en el destino');
    }
    const routeGeoJson = JSON.stringify({ type: 'LineString', coordinates: dto.route });
    const [trip] = await this.db.query(
      `INSERT INTO trips(driver_id,vehicle_id,origin_label,origin,destination_label,destination,route,departure_at,available_seats,contribution,recurring_days,preferences,meeting_code)
       SELECT $1,$2,$3,ST_SetSRID(ST_MakePoint($4,$5),4326)::geography,$6,ST_SetSRID(ST_MakePoint($7,$8),4326)::geography,
       ST_SetSRID(ST_GeomFromGeoJSON($9),4326)::geography,$10,$11,$12,$13,$14,lpad((floor(random()*10000))::int::text,4,'0')
       FROM vehicles WHERE id=$2 AND owner_id=$1 AND verification_status='VERIFIED' AND passenger_seats >= $11 RETURNING id,status,meeting_code AS "meetingCode"`,
      [userId, dto.vehicleId, dto.originLabel, dto.originLng, dto.originLat, dto.destinationLabel, dto.destinationLng, dto.destinationLat, routeGeoJson, dto.departureAt, dto.availableSeats, dto.contribution, dto.recurringDays ?? [], dto.preferences ?? {}]);
    if (!trip) throw new ForbiddenException('El vehículo debe estar verificado, pertenecer a tu cuenta y tener suficientes asientos');
    return trip;
  }

  search(userId: string, dto: SearchTripsDto) {
    if (new Date(dto.departureFrom) > new Date(dto.departureTo)) {
      throw new BadRequestException('El intervalo de búsqueda es inválido');
    }
    return this.db.query(
      `SELECT t.id,t.origin_label AS origin,t.destination_label AS destination,t.departure_at AS "departureAt",
       t.available_seats AS seats,t.contribution,u.first_name AS driver,
       concat(v.brand,' ',v.model,' · ',v.color) AS vehicle,
       COALESCE((SELECT round(avg(overall),1) FROM ratings WHERE to_user_id=u.id),0) AS rating,
       (SELECT count(*)::int FROM trips WHERE driver_id=u.id AND status='COMPLETED') AS "tripCount",
       round((100 - LEAST(35,ST_Distance(t.route,ST_SetSRID(ST_MakePoint($1,$2),4326)::geography)/100)
                  - LEAST(35,ST_Distance(t.route,ST_SetSRID(ST_MakePoint($3,$4),4326)::geography)/100))::numeric,0) AS compatibility
       FROM trips t JOIN users u ON u.id=t.driver_id JOIN vehicles v ON v.id=t.vehicle_id
       WHERE t.status='PUBLISHED' AND t.available_seats>0 AND t.driver_id<>$8
       AND u.status='ACTIVE' AND v.verification_status='VERIFIED'
       AND t.departure_at>now() AND t.departure_at BETWEEN $5 AND $6
       AND ST_DWithin(t.route,ST_SetSRID(ST_MakePoint($1,$2),4326)::geography,$7)
       AND ST_DWithin(t.route,ST_SetSRID(ST_MakePoint($3,$4),4326)::geography,$7)
       AND ST_LineLocatePoint(t.route::geometry,ST_SetSRID(ST_MakePoint($1,$2),4326))
         < ST_LineLocatePoint(t.route::geometry,ST_SetSRID(ST_MakePoint($3,$4),4326))
       ORDER BY compatibility DESC,t.departure_at LIMIT 30`,
      [dto.originLng, dto.originLat, dto.destinationLng, dto.destinationLat, dto.departureFrom, dto.departureTo, dto.maxDistanceMeters, userId]);
  }

  async createBooking(userId: string, dto: BookingDto) {
    return this.db.transaction(async manager => {
      const [trip] = await manager.query(
        `SELECT id,driver_id AS "driverId",origin_label AS origin,
         destination_label AS destination,available_seats AS "availableSeats" FROM trips
         WHERE id=$1 AND driver_id<>$2 AND status='PUBLISHED' AND departure_at>now()
         FOR UPDATE`, [dto.tripId, userId]);
      if (!trip || trip.availableSeats < dto.seats) {
        throw new BadRequestException('Viaje sin cupos suficientes');
      }
      const [booking] = await manager.query(
        `INSERT INTO bookings(trip_id,passenger_id,seats)
         VALUES($1,$2,$3)
         ON CONFLICT (trip_id,passenger_id) DO UPDATE
         SET seats=excluded.seats,status='PENDING',created_at=now()
         WHERE bookings.status IN ('REJECTED','CANCELLED','NO_SHOW')
         RETURNING id,status,seats`, [dto.tripId, userId, dto.seats]);
      if (!booking) {
        throw new BadRequestException('Ya tienes una solicitud activa para este viaje');
      }
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         VALUES($1,'BOOKING_REQUEST','Nueva solicitud de asiento',$2,$3)`,
        [trip.driverId, `${trip.origin} → ${trip.destination}`,
         { tripId: dto.tripId, bookingId: booking.id }]);
      return booking;
    });
  }

  async bookingAction(userId: string, bookingId: string, action: string) {
    return this.db.transaction(async manager => {
      const [row] = await manager.query(
        `SELECT b.id,b.trip_id AS "tripId",b.passenger_id AS "passengerId",
         b.seats,b.status,t.driver_id AS "driverId",t.available_seats AS "availableSeats",
         t.status AS "tripStatus",t.departure_at AS "departureAt"
         FROM bookings b JOIN trips t ON t.id=b.trip_id
         WHERE b.id=$1 FOR UPDATE OF b,t`, [bookingId]);
      if (!row) throw new NotFoundException('Reserva no encontrada');

      const isDriver = row.driverId === userId;
      const isPassenger = row.passengerId === userId;
      if (!isDriver && !isPassenger) throw new ForbiddenException();

      if (action === 'accept') {
        if (!isDriver || row.status !== 'PENDING') {
          throw new BadRequestException('La solicitud ya no puede aceptarse');
        }
        if (row.tripStatus !== 'PUBLISHED' || new Date(row.departureAt).getTime() <= Date.now() || row.availableSeats < row.seats) {
          throw new BadRequestException('Ya no quedan cupos suficientes');
        }
        const remaining = row.availableSeats - row.seats;
        await manager.query(`UPDATE bookings SET status='ACCEPTED' WHERE id=$1`, [bookingId]);
        await manager.query(
          `UPDATE trips SET available_seats=$2,status=$3 WHERE id=$1`,
          [row.tripId, remaining, remaining === 0 ? 'RESERVED' : 'PUBLISHED']);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_ACCEPTED','Solicitud aceptada','Tu asiento fue confirmado',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'ACCEPTED', seatsAvailable: remaining };
      }

      if (action === 'reject') {
        if (!isDriver || row.status !== 'PENDING') {
          throw new BadRequestException('La solicitud ya no puede rechazarse');
        }
        await manager.query(`UPDATE bookings SET status='REJECTED' WHERE id=$1`, [bookingId]);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_REJECTED','Solicitud rechazada','El conductor no pudo aceptar esta solicitud',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'REJECTED', seatsAvailable: row.availableSeats };
      }

      if (action === 'cancel') {
        if (!isPassenger || !['PENDING', 'ACCEPTED'].includes(row.status)) {
          throw new BadRequestException('La reserva ya no puede cancelarse');
        }
        if (!['PUBLISHED', 'RESERVED'].includes(row.tripStatus)) {
          throw new BadRequestException('El viaje ya comenzó');
        }
        await manager.query(`UPDATE bookings SET status='CANCELLED' WHERE id=$1`, [bookingId]);
        const restored = row.status === 'ACCEPTED'
          ? row.availableSeats + row.seats
          : row.availableSeats;
        if (row.status === 'ACCEPTED') {
          await manager.query(
            `UPDATE trips SET available_seats=$2,status='PUBLISHED' WHERE id=$1`,
            [row.tripId, restored]);
        }
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'BOOKING_CANCELLED','Reserva cancelada','El pasajero canceló su solicitud',$2)`,
          [row.driverId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'CANCELLED', seatsAvailable: restored };
      }

      if (action === 'no_show') {
        if (!isDriver || row.status !== 'ACCEPTED' || row.tripStatus !== 'IN_PROGRESS') {
          throw new BadRequestException('No se puede marcar esta ausencia');
        }
        await manager.query(`UPDATE bookings SET status='NO_SHOW' WHERE id=$1`, [bookingId]);
        await manager.query(
          `INSERT INTO notifications(user_id,type,title,body,data)
           VALUES($1,'NO_SHOW','Ausencia registrada','El conductor registró tu ausencia',$2)`,
          [row.passengerId, { tripId: row.tripId, bookingId: row.id }]);
        return { id: row.id, status: 'NO_SHOW', seatsAvailable: row.availableSeats };
      }

      throw new BadRequestException('Acción inválida');
    });
  }

  driverTrips(userId: string) {
    return this.db.query(
      `SELECT t.id,t.origin_label AS origin,t.destination_label AS destination,
       t.departure_at AS "departureAt",t.available_seats AS "availableSeats",
       t.contribution,t.status,t.meeting_code AS "meetingCode",
       COALESCE(json_agg(json_build_object(
         'id',b.id,'passengerId',b.passenger_id,'passenger',u.first_name,
         'seats',b.seats,'status',b.status
       ) ORDER BY b.created_at) FILTER (WHERE b.id IS NOT NULL),'[]') AS bookings
       FROM trips t
       LEFT JOIN bookings b ON b.trip_id=t.id
       LEFT JOIN users u ON u.id=b.passenger_id
       WHERE t.driver_id=$1
       GROUP BY t.id ORDER BY t.departure_at DESC`, [userId]);
  }

  passengerBookings(userId: string) {
    return this.db.query(
      `SELECT b.id,b.seats,b.status,t.id AS "tripId",t.origin_label AS origin,
       t.destination_label AS destination,t.departure_at AS "departureAt",
       t.contribution,CASE WHEN b.status='ACCEPTED' THEN t.meeting_code END AS "meetingCode",
       u.id AS "driverId",u.first_name AS driver
       FROM bookings b JOIN trips t ON t.id=b.trip_id
       JOIN users u ON u.id=t.driver_id
       WHERE b.passenger_id=$1 ORDER BY t.departure_at DESC`, [userId]);
  }

  async startTrip(userId: string, tripId: string, code: string) {
    return this.db.transaction(async manager => {
      const [trip] = await manager.query(
        `WITH changed AS (
           UPDATE trips SET status='IN_PROGRESS' WHERE id=$1 AND driver_id=$2
           AND meeting_code=$3 AND status IN ('PUBLISHED','RESERVED') RETURNING id,status
         ) SELECT id,status FROM changed`,
        [tripId, userId, code]);
      if (!trip) throw new BadRequestException('Código o estado inválido');
      await manager.query(
        `WITH rejected AS (
           UPDATE bookings SET status='REJECTED' WHERE trip_id=$1 AND status='PENDING' RETURNING passenger_id
         ) INSERT INTO notifications(user_id,type,title,body,data)
           SELECT passenger_id,'BOOKING_REJECTED','Solicitud cerrada','El viaje comenzó sin confirmar tu solicitud',$2 FROM rejected`,
        [tripId, { tripId }]);
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         SELECT passenger_id,'TRIP_STARTED','El viaje comenzó','Tu conductor inició el viaje',$2
         FROM bookings WHERE trip_id=$1 AND status='ACCEPTED'`,
        [tripId, { tripId }]);
      return trip;
    });
  }

  async completeTrip(userId: string, tripId: string) {
    return this.db.transaction(async manager => {
      const [trip] = await manager.query(
        `WITH changed AS (
           UPDATE trips SET status='COMPLETED' WHERE id=$1 AND driver_id=$2
           AND status='IN_PROGRESS' RETURNING id,status
         ) SELECT id,status FROM changed`, [tripId, userId]);
      if (!trip) throw new BadRequestException('No se puede finalizar el viaje');
      await manager.query(`UPDATE bookings SET status='COMPLETED' WHERE trip_id=$1 AND status='ACCEPTED'`, [tripId]);
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         SELECT passenger_id,'TRIP_COMPLETED','Viaje completado','Ya puedes calificar al conductor',$2
         FROM bookings WHERE trip_id=$1 AND status='COMPLETED'`,
        [tripId, { tripId }]);
      return trip;
    });
  }

  async rate(userId: string, dto: RatingDto) {
    const [rating] = await this.db.query(
      `INSERT INTO ratings(trip_id,from_user_id,to_user_id,overall,punctuality,kindness,safety,driving,comment)
       SELECT $1::uuid,$2::uuid,$3::uuid,$4,$5,$6,$7,$8,$9 FROM trips t
       WHERE t.id=$1::uuid AND t.status='COMPLETED' AND $2::uuid<>$3::uuid
       AND (t.driver_id=$2 OR EXISTS (
         SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2 AND b.status='COMPLETED'))
       AND (t.driver_id=$3 OR EXISTS (
         SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$3 AND b.status='COMPLETED'))
       ON CONFLICT (trip_id,from_user_id,to_user_id) DO NOTHING
       RETURNING id,overall`, [dto.tripId, userId, dto.toUserId, dto.overall, dto.punctuality, dto.kindness, dto.safety, dto.driving, dto.comment]);
    if (!rating) throw new BadRequestException('No puedes calificar a este usuario o ya lo calificaste');
    return rating;
  }

  ratings(userId: string) {
    return this.db.query(
      `SELECT r.id,r.overall,r.punctuality,r.kindness,r.safety,r.driving,
       r.comment,r.created_at AS "createdAt",u.first_name AS author
       FROM ratings r JOIN users u ON u.id=r.from_user_id
       WHERE r.to_user_id=$1 ORDER BY r.created_at DESC LIMIT 50`,
      [userId]);
  }

  async incident(userId: string, dto: IncidentDto) {
    const [incident] = await this.db.query(
      `INSERT INTO incidents(trip_id,reporter_id,reported_user_id,type,description)
       SELECT $1,$2,$3,$4,$5
       WHERE ($1::uuid IS NULL AND $3::uuid IS NULL) OR EXISTS (
         SELECT 1 FROM trips t WHERE t.id=$1
         AND (t.driver_id=$2 OR EXISTS (
           SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$2))
         AND ($3::uuid IS NULL OR ($3<>$2 AND (t.driver_id=$3 OR EXISTS (
           SELECT 1 FROM bookings b WHERE b.trip_id=t.id AND b.passenger_id=$3))))
       )
       RETURNING id,type,description,status,created_at AS "createdAt"`,
      [dto.tripId, userId, dto.reportedUserId, dto.type, dto.description]);
    if (!incident) throw new ForbiddenException('No puedes reportar usuarios ajenos a este viaje');
    return incident;
  }

  incidents(userId: string) {
    return this.db.query(
      `SELECT id,trip_id AS "tripId",reported_user_id AS "reportedUserId",
       type,description,status,created_at AS "createdAt"
       FROM incidents WHERE reporter_id=$1 ORDER BY created_at DESC LIMIT 50`,
      [userId]);
  }

  notifications(userId: string) {
    return this.db.query(
      `SELECT id,type,title,body,data,read_at AS "readAt",created_at AS "createdAt"
       FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100`,
      [userId]);
  }

  async unreadNotifications(userId: string) {
    const [result] = await this.db.query(
      'SELECT count(*)::int AS count FROM notifications WHERE user_id=$1 AND read_at IS NULL',
      [userId]);
    return result;
  }

  async readNotification(userId: string, id: string) {
    const [notification] = await this.db.query(
      `UPDATE notifications SET read_at=COALESCE(read_at,now())
       WHERE id=$1 AND user_id=$2 RETURNING id,read_at AS "readAt"`,
      [id, userId]);
    if (!notification) throw new NotFoundException('Notificación no encontrada');
    return notification;
  }

  async readAllNotifications(userId: string) {
    const result = await this.db.query(
      'UPDATE notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL RETURNING id',
      [userId]);
    return { updated: result.length };
  }

  async messages(userId: string, bookingId: string) {
    return this.db.transaction(async manager => {
      const [participant] = await manager.query(
        `SELECT b.passenger_id AS "passengerId",t.driver_id AS "driverId",b.status
         FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1`,
        [bookingId]);
      if (!participant ||
          ![participant.passengerId, participant.driverId].includes(userId) ||
          !['ACCEPTED', 'COMPLETED'].includes(participant.status)) {
        throw new ForbiddenException('El chat está disponible solo para reservas aceptadas');
      }
      await manager.query(
        'UPDATE messages SET read_at=now() WHERE booking_id=$1 AND recipient_id=$2 AND read_at IS NULL',
        [bookingId, userId]);
      return manager.query(
        `SELECT m.id,m.sender_id AS "senderId",u.first_name AS "senderName",
         m.body,m.read_at AS "readAt",m.created_at AS "createdAt",
         (m.sender_id=$2) AS "isMine"
         FROM messages m JOIN users u ON u.id=m.sender_id
         WHERE m.id IN (SELECT id FROM messages WHERE booking_id=$1 ORDER BY created_at DESC,id DESC LIMIT 300) ORDER BY m.created_at ASC,m.id ASC`,
        [bookingId, userId]);
    });
  }

  async sendMessage(userId: string, bookingId: string, dto: SendMessageDto) {
    const body = dto.body.trim();
    if (!body) throw new BadRequestException('El mensaje no puede estar vacío');
    return this.db.transaction(async manager => {
      const [participant] = await manager.query(
        `SELECT b.passenger_id AS "passengerId",t.driver_id AS "driverId",b.status
         FROM bookings b JOIN trips t ON t.id=b.trip_id WHERE b.id=$1 FOR UPDATE OF b`,
        [bookingId]);
      if (!participant ||
          ![participant.passengerId, participant.driverId].includes(userId) ||
          !['ACCEPTED', 'COMPLETED'].includes(participant.status)) {
        throw new ForbiddenException('El chat está disponible solo para reservas aceptadas');
      }
      const recipientId = participant.passengerId === userId
        ? participant.driverId
        : participant.passengerId;
      const [message] = await manager.query(
        `INSERT INTO messages(booking_id,sender_id,recipient_id,body)
         VALUES($1,$2,$3,$4)
         RETURNING id,sender_id AS "senderId",body,read_at AS "readAt",
         created_at AS "createdAt",true AS "isMine"`,
        [bookingId, userId, recipientId, body]);
      await manager.query(
        `INSERT INTO notifications(user_id,type,title,body,data)
         VALUES($1,'CHAT_MESSAGE','Nuevo mensaje',$2,$3)`,
        [recipientId, body.length > 120 ? `${body.substring(0, 117)}...` : body,
         { bookingId, messageId: message.id }]);
      return message;
    });
  }
}
