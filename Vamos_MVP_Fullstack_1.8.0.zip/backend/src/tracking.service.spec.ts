import { TrackingService } from './tracking.service';
import { createHash } from 'node:crypto';
describe('Privacidad de seguimiento',()=>{
 it('informa una migración faltante sin ocultar otros errores',async()=>{
  const query=jest.fn().mockRejectedValueOnce({driverError:{code:'42703'}}).mockRejectedValueOnce(new Error('connection lost'));
  const service=new TrackingService({query} as any);
  await expect(service.read('u','t')).rejects.toThrow('migración 016');
  await expect(service.read('u','t')).rejects.toThrow('connection lost');
 });
 it('no permite activar un viaje sin autorización',async()=>{
  const query=jest.fn().mockResolvedValue([]);const service=new TrackingService({transaction:(f:any)=>f({query})} as any);
  await expect(service.toggle('outsider','trip',true)).rejects.toThrow('no está disponible');expect(query).toHaveBeenCalledTimes(1);
 });
 it('no guarda coordenadas antiguas o futuras',async()=>{
  const transaction=jest.fn();const service=new TrackingService({transaction} as any);
  for(const offset of [-300000,600000])expect(await service.position('u','t',{latitude:0,longitude:0,accuracy:5,recordedAt:new Date(Date.now()+offset).toISOString()})).toEqual({accepted:false});
  expect(transaction).not.toHaveBeenCalled();
 });
 it('el enlace usa un secreto aleatorio y solo guarda su hash',async()=>{
  const query=jest.fn().mockResolvedValue([{expiresAt:'tomorrow'}]);const service=new TrackingService({query} as any);
  const first=await service.share('passenger','booking'),second=await service.share('passenger','booking');
  expect(first.token).toMatch(/^[a-f0-9]{64}$/);expect(second.token).not.toBe(first.token);
  expect(query.mock.calls[0][1][2]).toBe(createHash('sha256').update(first.token).digest('hex'));
  expect(query.mock.calls[0][1]).not.toContain(first.token);
 });
 it('un enlace inexistente no permite consultar ubicación',async()=>{
  const query=jest.fn().mockResolvedValue([]);const service=new TrackingService({query} as any);
  await expect(service.shared('a'.repeat(64))).rejects.toThrow('venció');expect(query).toHaveBeenCalledTimes(1);
 });
 it('un usuario ajeno no recibe el recorrido ni la posición',async()=>{
  const query=jest.fn().mockResolvedValue([]);const service=new TrackingService({query} as any);
  await expect(service.read('outsider','trip')).rejects.toThrow('no disponible');expect(query).toHaveBeenCalledTimes(1);
 });
});
