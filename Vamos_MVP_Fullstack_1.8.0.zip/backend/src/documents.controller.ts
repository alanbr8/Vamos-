import { Body, Controller, Delete, Get, Header, Param, ParseUUIDPipe, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
import { AdminGuard } from './admin.guard';
import { DocumentsService, ReviewDocumentDto, UploadDocumentDto } from './documents.service';
@Controller('documents')
@UseGuards(JwtAuthGuard)
export class DocumentsController {
  constructor(private readonly docs: DocumentsService) {}
  @Get() @Header('Cache-Control','no-store') list(@Req() req: AuthRequest){return this.docs.list(req.userId);}
  @Post() upload(@Req() req: AuthRequest,@Body() dto: UploadDocumentDto){return this.docs.upload(req.userId,dto);}
  @Get(':id/image') @Header('Cache-Control','no-store') image(@Req() req: AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.docs.image(req.userId,id,false);}
  @Delete(':id') remove(@Req() req: AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.docs.remove(req.userId,id);}
}
@Controller('admin/documents')
@UseGuards(JwtAuthGuard,AdminGuard)
export class AdminDocumentsController {
  constructor(private readonly docs: DocumentsService) {}
  @Get() @Header('Cache-Control','no-store') list(){return this.docs.queue();}
  @Get(':id/image') @Header('Cache-Control','no-store') image(@Req() req: AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.docs.image(req.userId,id,true);}
  @Patch(':id') review(@Req() req: AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() dto: ReviewDocumentDto){return this.docs.review(req.userId,id,dto);}
}
