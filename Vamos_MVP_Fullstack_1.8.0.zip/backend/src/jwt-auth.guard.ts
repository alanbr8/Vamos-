import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request } from 'express';
import { DataSource } from 'typeorm';

export type AuthRequest = Request & { userId: string };

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly jwt: JwtService, private readonly db: DataSource) {}
  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest<AuthRequest>();
    const token = request.headers.authorization?.replace(/^Bearer\s+/i, '');
    if (!token) throw new UnauthorizedException();
    let payload: { sub: string };
    try { payload = await this.jwt.verifyAsync<{ sub: string }>(token); }
    catch { throw new UnauthorizedException('Tu sesión expiró. Inicia sesión de nuevo.'); }
    if (typeof payload.sub !== 'string') throw new UnauthorizedException();
    const [user] = await this.db.query("SELECT id FROM users WHERE id=$1 AND status='ACTIVE'", [payload.sub]);
    if (!user) throw new UnauthorizedException('Tu cuenta no está activa');
    request.userId = payload.sub;
    return true;
  }
}
