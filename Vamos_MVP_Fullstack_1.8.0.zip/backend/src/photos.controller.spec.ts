import { NotFoundException } from '@nestjs/common';
import { PhotosService } from './photos.controller';
const photo='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1sAAAAASUVORK5CYII=';
describe('Fotos visibles en viajes',()=>{
  const original=process.env.DOCUMENT_ENCRYPTION_KEY;
  beforeEach(()=>{process.env.DOCUMENT_ENCRYPTION_KEY='cd'.repeat(32);});
  afterEach(()=>{if(original===undefined)delete process.env.DOCUMENT_ENCRYPTION_KEY;else process.env.DOCUMENT_ENCRYPTION_KEY=original;});
  it('impide cambiar la foto de un vehículo ajeno',async()=>{
    const query=jest.fn().mockResolvedValue([]);
    const service=new PhotosService({transaction:async(fn:Function)=>fn({query})} as never);
    await expect(service.save('outsider',{vehicleId:'car',base64:photo,consent:true})).rejects.toBeInstanceOf(NotFoundException);
    expect(query.mock.calls.some(c=>c[0].includes('INSERT'))).toBe(false);
  });
  it('guarda cifrado y muestra únicamente la foto destinada a los viajes',async()=>{
    let stored:any;
    const query=jest.fn(async(sql:string,args:any[])=>{
      if(sql.startsWith('INSERT INTO display_photos')){stored={ciphertext:args[2],iv:args[3],tag:args[4],mime:args[5]};return [{id:'photo'}];}
      if(sql.startsWith('SELECT p.ciphertext'))return [stored];
      return [];
    });
    const service=new PhotosService({query,transaction:async(fn:Function)=>fn({query})} as never);
    await service.save('owner',{base64:photo,consent:true});
    expect(stored.ciphertext.toString('base64')).not.toBe(photo);
    expect((await service.get('owner',false)).base64).toBe(photo);
    expect(query.mock.calls.some(c=>c[0].includes('verification_documents'))).toBe(false);
  });
  it('rechaza carga sin consentimiento de visibilidad',async()=>{
    const transaction=jest.fn();const service=new PhotosService({transaction} as never);
    await expect(service.save('owner',{base64:photo,consent:false})).rejects.toThrow();
    expect(transaction).not.toHaveBeenCalled();
  });
});
