import { NestExpressApplication } from '@nestjs/platform-express';
export function mountTrackingPage(app:NestExpressApplication){
 app.getHttpAdapter().get('/seguimiento',(_req:any,res:any)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Robots-Tag','noindex, nofollow');
  res.type('html').send(`<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>Seguir viaje · Vamos!</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>body{margin:0;background:#f4f8f4;color:#123d2c;font:16px system-ui}header,footer{padding:18px;max-width:900px;margin:auto}h1{font-size:24px;margin:0 0 12px}#map{height:65vh}#state{font-weight:600}footer{font-size:14px}</style>
<header><h1>Vamos! · Seguir viaje</h1><p id="state" role="status">Consultando ubicación…</p><small>Enlace privado. Compártelo solo con alguien de confianza.</small></header><div id="map"></div><footer>La línea es el recorrido estimado. El punto muestra la última ubicación recibida, no una garantía de llegada. Si se interrumpe la señal, contacta directamente a quien comparte el viaje.</footer>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
const token=location.hash.slice(1),statusText=document.getElementById('state');
const map=L.map('map').setView([-17.78,-63.18],12);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(map);
let driver=null,route=null,ends=[],active=true,loading=false,first=true;
function clearPrivate(){if(driver){map.removeLayer(driver);driver=null}if(route){map.removeLayer(route);route=null}ends.forEach(m=>map.removeLayer(m));ends=[];}
async function refresh(){if(!active||loading)return;loading=true;try{
 const response=await fetch('/api/v1/tracking/shared',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token}),cache:'no-store',signal:AbortSignal.timeout(10000)});
 if(!response.ok){clearPrivate();statusText.textContent='El seguimiento no está disponible. El enlace puede haber vencido o sido revocado.';if(response.status===404||response.status===400)active=false;return}
 const d=await response.json();
 if(first){const coords=(d.route||[]).map(p=>[p[1],p[0]]);if(coords.length>1&&d.routeEstimate?.provider==='openrouteservice'){route=L.polyline(coords,{color:'#087c48'}).addTo(map);map.fitBounds(route.getBounds(),{padding:[30,30]})}
 [[d.originLat,d.originLng,'Partida'],[d.destinationLat,d.destinationLng,'Destino']].forEach(p=>ends.push(L.marker([p[0],p[1]]).bindTooltip(p[2]).addTo(map)));first=false}
 const age=d.recordedAt?Math.max(0,(Date.parse(d.serverTime)-Date.parse(d.recordedAt))/1000):null;
 if(driver){map.removeLayer(driver);driver=null}
 if(!d.enabled){statusText.textContent='El conductor pausó la ubicación.'}
 else if(age===null){statusText.textContent='Esperando la primera ubicación del conductor.'}
 else{statusText.textContent=(age>120?'Señal sin actualizar. Última ubicación: ':'Ubicación recibida: ')+new Date(d.recordedAt).toLocaleTimeString()+' · precisión aproximada '+Math.round(d.accuracy)+' m';driver=L.circleMarker([d.latitude,d.longitude],{radius:10,color:age>120?'#777':'#1565c0',fillOpacity:0.8}).bindTooltip(age>120?'Última posición conocida':'Conductor').addTo(map)}
}catch{statusText.textContent='No se pudo actualizar. Comprueba tu conexión.';if(driver){map.removeLayer(driver);driver=null}}finally{loading=false}}
if(/^[a-f0-9]{64}$/.test(token)){refresh();setInterval(refresh,15000)}else{active=false;statusText.textContent='Enlace incompleto o inválido.'}
</script></html>`);
 });
}
