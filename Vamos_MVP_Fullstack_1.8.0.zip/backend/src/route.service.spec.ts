import { RouteService } from './route.service';
describe('Ruta por calles',()=>{
  const original=process.env.ORS_API_KEY;
  const dto={originLng:-63.2,originLat:-17.8,destinationLng:-63.18,destinationLat:-17.78};
  afterEach(()=>{jest.restoreAllMocks();if(original===undefined)delete process.env.ORS_API_KEY;else process.env.ORS_API_KEY=original;});
  it('devuelve geometría por calles, conserva extremos y reutiliza el cálculo',async()=>{
    process.env.ORS_API_KEY='local-test-key';
    const fetcher=jest.spyOn(global,'fetch').mockResolvedValue({ok:true,json:async()=>({features:[{geometry:{type:'LineString',coordinates:[[-63.199,-17.8],[-63.199,-17.78],[-63.181,-17.78]]},properties:{summary:{distance:4200,duration:540}}}]})} as Response);
    const service=new RouteService();const result=await service.estimate(dto);
    expect(result.route[0]).toEqual([-63.2,-17.8]);expect(result.route.at(-1)).toEqual([-63.18,-17.78]);
    expect(result.route).toHaveLength(5);expect(result.distanceMeters).toBe(4200);expect(result.durationSeconds).toBe(540);
    expect(await service.estimate(dto)).toEqual(result);expect(fetcher).toHaveBeenCalledTimes(1);
    expect(fetcher.mock.calls[0][0]).toBe('https://api.heigit.org/openrouteservice/v2/directions/driving-car/geojson');
  });
  it('sin clave no consulta al proveedor',async()=>{
    delete process.env.ORS_API_KEY;const fetcher=jest.spyOn(global,'fetch');
    await expect(new RouteService().estimate(dto)).rejects.toThrow('configurado');expect(fetcher).not.toHaveBeenCalled();
  });
  it('no inventa una línea recta si el proveedor falla',async()=>{
    process.env.ORS_API_KEY='secret';jest.spyOn(global,'fetch').mockRejectedValue(new Error('secret'));
    await expect(new RouteService().estimate(dto)).rejects.toThrow('No se pudo calcular');
  });
  it('rechaza geometrías malformadas',async()=>{
    process.env.ORS_API_KEY='secret';jest.spyOn(global,'fetch').mockResolvedValue({ok:true,json:async()=>({features:[]})} as Response);
    await expect(new RouteService().estimate(dto)).rejects.toThrow('No se pudo calcular');
  });
});
