import { Body, Controller, Delete, Get, Header, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Req, ServiceUnavailableException, UseGuards } from '@nestjs/common';
import { Equals, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';
import { DataSource } from 'typeorm';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { AuthRequest, JwtAuthGuard } from './jwt-auth.guard';
import { validateDocument } from './documents.service';
export class DisplayPhotoDto {
  @IsString() @MaxLength(1400000) base64!: string;
  @IsOptional() @IsUUID() vehicleId?: string;
  @Equals(true) consent!: boolean;
}
@Injectable()
export class PhotosService {
  constructor(private readonly db:DataSource){}
  private key(){
    const key=process.env.DOCUMENT_ENCRYPTION_KEY||'';
    if(!/^[a-fA-F0-9]{64}$/.test(key))throw new ServiceUnavailableException('El administrador debe configurar el almacenamiento de fotos');
    return Buffer.from(key,'hex');
  }
  async save(owner:string,dto:DisplayPhotoDto){
    const {bytes,mime}=validateDocument({kind:'CI_FRONT',base64:dto.base64,consent:dto.consent});
    const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',this.key(),iv);
    const encrypted=Buffer.concat([cipher.update(bytes),cipher.final()]);
    return this.db.transaction(async m=>{
      await m.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[owner]);
      if(dto.vehicleId){
        const [car]=await m.query('SELECT id FROM vehicles WHERE id=$1 AND owner_id=$2 FOR UPDATE',[dto.vehicleId,owner]);
        if(!car)throw new NotFoundException('Vehículo no encontrado');
      }
      const conflict=dto.vehicleId?'(vehicle_id) WHERE vehicle_id IS NOT NULL':'(owner_id) WHERE vehicle_id IS NULL';
      const [result]=await m.query(`INSERT INTO display_photos(owner_id,vehicle_id,ciphertext,iv,tag,mime)
      VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT ${conflict} DO UPDATE SET ciphertext=EXCLUDED.ciphertext,iv=EXCLUDED.iv,tag=EXCLUDED.tag,mime=EXCLUDED.mime,updated_at=now()
      RETURNING id`,[owner,dto.vehicleId||null,encrypted,iv,cipher.getAuthTag(),mime]);
      return result;
    });
  }
  async get(id:string,vehicle:boolean){
    // Fotos destinadas a los viajes, visibles a usuarios autenticados. Nunca se consulta verification_documents.
    const [photo]=await this.db.query(`SELECT p.ciphertext,p.iv,p.tag,p.mime FROM display_photos p JOIN users u ON u.id=p.owner_id
    WHERE u.status='ACTIVE' AND ${vehicle?'p.vehicle_id=$1':'p.owner_id=$1 AND p.vehicle_id IS NULL'}`,[id]);
    if(!photo)throw new NotFoundException('Sin foto');
    const decipher=createDecipheriv('aes-256-gcm',this.key(),photo.iv);decipher.setAuthTag(photo.tag);
    return {base64:Buffer.concat([decipher.update(photo.ciphertext),decipher.final()]).toString('base64'),mime:photo.mime};
  }
  async remove(owner:string,vehicleId?:string){
    await this.db.query(`DELETE FROM display_photos WHERE owner_id=$1 AND ${vehicleId?'vehicle_id=$2':'vehicle_id IS NULL'}`,vehicleId?[owner,vehicleId]:[owner]);
    return {removed:true};
  }
}
@Controller('photos')
@UseGuards(JwtAuthGuard)
export class PhotosController {
  constructor(private readonly photos:PhotosService){}
  @Post() save(@Req() req:AuthRequest,@Body() dto:DisplayPhotoDto){return this.photos.save(req.userId,dto);}
  @Get('profile/:id') @Header('Cache-Control','no-store') profile(@Param('id',ParseUUIDPipe) id:string){return this.photos.get(id,false);}
  @Get('vehicle/:id') @Header('Cache-Control','no-store') vehicle(@Param('id',ParseUUIDPipe) id:string){return this.photos.get(id,true);}
  @Delete('profile') removeProfile(@Req() req:AuthRequest){return this.photos.remove(req.userId);}
  @Delete('vehicle/:id') removeVehicle(@Req() req:AuthRequest,@Param('id',ParseUUIDPipe) id:string){return this.photos.remove(req.userId,id);}
}
